package com.ebay.bis.gro.service

import java.io.{OutputStreamWriter, BufferedWriter, PrintWriter}
import java.text.SimpleDateFormat
import java.util.Date
import javax.servlet.http.{HttpServletResponse, HttpServletRequest}

import com.ebay.bis.gro.dao.ElasticSearchDAO
import com.ebay.bis.gro.utils.CalDate
import org.elasticsearch.common.joda.time.DateTime
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.{RequestMapping, PathVariable, RequestMethod}
import org.springframework.web.bind.annotation.CrossOrigin

/**
  * Created by yangzhou on 12/2/15.
  */
@Controller
@RequestMapping(value = Array("/service/invsel"))
class SelectionServices {

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/version"), method = Array(RequestMethod.GET))
  def version(request: HttpServletRequest, response: HttpServletResponse): Unit = {
    response.getOutputStream.println("Inventory Selection Service v1.0.0")
  }


  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/alias/{alias}"), method = Array(RequestMethod.GET))
  def alias(@PathVariable("alias") alias: String,
            request: HttpServletRequest, response: HttpServletResponse): Unit = {
    val indexName = ElasticSearchDAO.getAliasIndexName(alias)
    response.setHeader("Content-Type", "application/json")

    if(!indexName.isDefined) {
      response.getOutputStream.write(
        s"""{"error":"alias [${alias}] missing or not pointing to any index","status":404}""".getBytes)
    } else {
      val rtlWk = getRetailWeeksFromIndexName(indexName.get)
      response.getOutputStream.write(
        s"""{"${indexName.get}":{"aliases":{"${alias}":{}},"rtlweek": ${rtlWk}}}""".getBytes)
    }
  }

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/search/{index}/{tipe}"),
    method = Array(RequestMethod.POST), produces = Array("application/json"))
  def query(@PathVariable("index") index: String, @PathVariable("tipe") tipe: String,
            request: HttpServletRequest, response: HttpServletResponse): Unit = {
    val jsonQuery = scala.io.Source.fromInputStream(request.getInputStream).getLines().mkString("\n")
    val results = ElasticSearchDAO.query(index, tipe, jsonQuery)
    response.setHeader("Content-Type", "application/json")
    response.getOutputStream.write(results.toString.getBytes())
  }

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/download/{site}"),
    method = Array(RequestMethod.POST), produces = Array("application/csv"))
  def download(@PathVariable("site") site: String,
               request: HttpServletRequest, response: HttpServletResponse): Unit = {
    val jsonQuery = request.getParameter("q")
    val columns = request.getParameter("c")
    val out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(response.getOutputStream)))

    response.setHeader("Content-disposition", "attachment; filename=magic-select-result.csv")
    ElasticSearchDAO.downloadToStream(site, jsonQuery, columns, out)
    out.close()
  }

  private def getRetailWeeksFromIndexName(indexName: String): String = {
    val datestr: String = indexName.split("-")(2)
    retailWeek(new SimpleDateFormat("yyyyMMdd").parse(datestr))
  }

  private def retailWeek(date: Date): String = {
    val dt = new DateTime(date)
    val bgnWkDt = CalDate.getWkBgnDt(dt)
    val oneWkAgo = bgnWkDt.minusDays(7)
    val twoWkAgo = bgnWkDt.minusDays(14)
    val threeWkAgo = bgnWkDt.minusDays(21)
    val fourWkAgo = bgnWkDt.minusDays(28)
    val fiveWkAgo = bgnWkDt.minusDays(35)

    val rtlCrntWk = new CalDate(bgnWkDt).rtlWk
    val rtlOneWk = new CalDate(oneWkAgo).rtlWk
    val rtlTwoWk = new CalDate(twoWkAgo).rtlWk
    val rtlThreeWk = new CalDate(threeWkAgo).rtlWk
    val rtlFourWk = new CalDate(fourWkAgo).rtlWk
    val rtlFiveWk = new CalDate(fiveWkAgo).rtlWk

    s"[${rtlCrntWk}, ${rtlOneWk}, ${rtlTwoWk}, ${rtlThreeWk}, ${rtlFourWk}, ${rtlFiveWk}]"
  }


}
