package com.ebay.bis.gro.dao

import scalikejdbc._
import play.api.libs.json.Json.JsValueWrapper
import play.api.libs.json.{Writes, Json}

object Models {

	case class CategoryMetric(date: String,
							  clusterId: Int,
							  leafCategId: Long,
							  likelihoodScore: Double,
							  entropyScore: Double,
							  vertical: String) {
	  val relevanceScore = likelihoodScore * entropyScore
	}

	object CategoryMetric extends SQLSyntaxSupport[CategoryMetric] {
	  override val tableName = "cluster_metrics"
	  def apply(rs: WrappedResultSet): CategoryMetric = new CategoryMetric(
		rs.string("create_dt"),
		rs.int("cluster_id"),
		rs.long("leaf_categ_id"),
		rs.double("likelihood_score"),
		rs.double("entropy_score"),
		rs.string("vertical")
	  )
	}

	case class Brand(date: String, dateRange:Int, leafCategId: Long, brand: String, count: Long)

	implicit val brandWriter = new Writes[Brand] {
	  def writes(rs: Brand) = {
		val fields = List[(String, JsValueWrapper)](
		  ("date" -> rs.date),
		  ("date_range" -> rs.dateRange),
		  ("leaf_categ_id" -> rs.leafCategId),
		  ("brand" -> rs.brand),
		  ("count" -> rs.count)
		)
		Json.obj(fields: _*)
	  }
	}

	object Brand extends SQLSyntaxSupport[Brand] {
	  override val tableName = "brand_distribution"
	  def apply(rs: WrappedResultSet): Brand = new Brand(
		rs.string("create_dt"),
		rs.int("date_range"),
		rs.long("leaf_categ_id"),
		rs.string("brand"),
		rs.long("count")
	  )
	}

	//case class Cluster(clusterId: Int, clusterName: String, siteId: Int, startDt: String, endDt: String, grpCd: String, grpName: String, desc: String)
	case class Cluster(clusterId: Int, clusterName: String)

	object Cluster extends SQLSyntaxSupport[Cluster] {
	  override val tableName = "cluster"
	  def apply(rs: WrappedResultSet): Cluster = new Cluster(
		rs.int("cluster_id"),
		rs.string("cluster_name")
	  )
	}

	implicit val clusterWriter = new Writes[Cluster] {
	  def writes(rs: Cluster) = {
		Json.obj(
		  ("cluster_id" -> rs.clusterId),
		  ("cluster_name" -> rs.clusterName)
		)
	  }
	}

	  case class CategoryFeatures(likelihood: Double, entropy: Double)
	  implicit val categoryFeaturesReader = Json.reads[CategoryFeatures]
	  implicit val categoryFeaturesWriter = Json.writes[CategoryFeatures]

	  case class ItemFeatures(num_trans_7: Int,gmv_7: Double,num_trans_14: Int,gmv_14: Double,
		num_trans_21: Int,gmv_21: Double,num_trans_28: Int,gmv_28: Double,num_wtch_7: Int,
		num_wtch_14: Int,num_wtch_21: Int,num_wtch_28: Int,num_vi_7: Int,num_vi_14: Int,
		num_vi_21: Int,num_vi_28: Int, var categoryFeatures: Option[CategoryFeatures])
	  implicit val itemFeaturesReader = Json.reads[ItemFeatures]
	  implicit val itemFeaturesWriter = Json.writes[ItemFeatures]


	  case class Item(id: Long, var leafCategId: Long, var features: Option[ItemFeatures], var score: Option[Double] = None, var rank: Option[Int] = None, var quality: Option[String] = None) {
		def toCsv(hasLeaf: Boolean): String = {
		  val f = features.get
		  val commons = List(
			f.num_trans_7.toString,
			f.gmv_7.toString,
			f.num_trans_14.toString,
			f.gmv_14.toString,
			f.num_trans_21.toString,
			f.gmv_21.toString,
			f.num_trans_28.toString,
			f.gmv_28.toString,
			f.num_wtch_7.toString,
			f.num_wtch_14.toString,
			f.num_wtch_21.toString,
			f.num_wtch_28.toString,
			f.num_vi_7.toString,
			f.num_vi_14.toString,
			f.num_vi_21.toString,
			f.num_vi_28.toString)
		  val leafs = if(hasLeaf) List(f.categoryFeatures.get.likelihood.toString, f.categoryFeatures.get.entropy.toString) else List()
		  (commons ::: leafs).mkString(",")
		}
	  }
	  implicit val itemReader = Json.reads[Item]
	  implicit val itemWriter = Json.writes[Item]

	  case class LeafCategory(leafCategId: Long, vertical: String, score: Double, userSelected: Boolean)
	  implicit val categReader = Json.reads[LeafCategory]
	  implicit val categWriter = Json.writes[LeafCategory]

	  case class CategoryRankScore(nRS: Double,
						   nVRS: Double,
                           nCRS: Double,
						   categoryCoverage: Double,
						   itemCoverage: Double,
						   currentLeaves: List[LeafCategory],
						   suggestLeaves: List[LeafCategory],
						   suggestVerticalLeaves: List[LeafCategory],
						   suggestCategoryLeaves: List[LeafCategory],
						   notScoreLeaves: List[LeafCategory])
	  implicit val rankScoreReader = Json.reads[CategoryRankScore]
	  implicit val rankScoreWriter = new Writes[CategoryRankScore] {
		def doubleFormat(field: String, value: Double): (String, JsValueWrapper) = {
		  if(value.isNaN) {
			(field -> "NaN")
		  } else {
			(field -> value)
		  }
		}
		def writes(rs: CategoryRankScore) = {
		  val fields = List[(String, JsValueWrapper)](
			doubleFormat("nRS", rs.nRS),
			doubleFormat("nVRS", rs.nVRS),
			doubleFormat("nCRS", rs.nCRS),
			doubleFormat("categoryCoverage", rs.categoryCoverage),
			doubleFormat("itemCoverage", rs.itemCoverage),
			("currentLeaves" -> rs.currentLeaves),
			("suggestLeaves" -> rs.suggestLeaves),
			("suggestVerticalLeaves" -> rs.suggestVerticalLeaves),
			("suggestCategoryLeaves" -> rs.suggestCategoryLeaves),
			("notScoreLeaves" -> rs.notScoreLeaves)
		  )
		  Json.obj(fields: _*)
	  }
	}

	case class ItemScoreSummary(coverage: Double)
	implicit val itemScoreSummaryReader = Json.reads[ItemScoreSummary]
	implicit val itemScoreSummaryWriter = Json.writes[ItemScoreSummary]

	case class ItemRankScore(summary: ItemScoreSummary, scoreItems: List[Item], noneScoreItems: List[Item])
	implicit val itemScoreReader = Json.reads[ItemRankScore]
	implicit val itemScoreWriter = Json.writes[ItemRankScore]
}
