package com.ebay.bis.gro.service

import javax.servlet.http.{HttpServletResponse, HttpServletRequest}

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.{RequestMapping, RequestMethod, PathVariable, RequestParam}
import org.springframework.web.bind.annotation.CrossOrigin
import com.ebay.bis.gro.dao.ElasticSearchDAO
import com.ebay.bis.gro.utils.ClusterMetrics
import com.ebay.bis.gro.utils.WekaModel
import com.ebay.bis.gro.utils.InvConfig
import com.ebay.bis.gro.dao.MySQLDAO

import play.api.libs.json._

@Controller
@RequestMapping(value = Array("/service/eventqlty"))
class EventQualityServices {

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/version"), method = Array(RequestMethod.GET))
  def version(request: HttpServletRequest, response: HttpServletResponse): Unit = {
    response.getOutputStream.println("Event Quality Service v1.0.0")
  }

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/category"), method = Array(RequestMethod.POST), produces = Array("application/json"))
  def categoryScore(request: HttpServletRequest, response: HttpServletResponse): Unit = {

    val jsonstr = scala.io.Source.fromInputStream(request.getInputStream).getLines().mkString("")

    val json = Json.parse(jsonstr)
    val clusterId = (json \ "clusterId").as[Int]
    val itemIds = (json \ "items").as[List[Long]]

    val items = ElasticSearchDAO.fetchItemFeatures(itemIds)

    val rScore = ClusterMetrics.rankScore(clusterId, items)

    response.setHeader("Content-Type", "application/json")
    response.getOutputStream.write(Json.stringify(Json.toJson(rScore)).getBytes)
  }


  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/item"), method = Array(RequestMethod.POST), produces = Array("application/json"))
  def itemScore(request: HttpServletRequest, response: HttpServletResponse): Unit = {
    val jsonstr = scala.io.Source.fromInputStream(request.getInputStream).getLines().mkString("")

    val json = Json.parse(jsonstr)
    val clusterId = (json \ "clusterId").as[Int]
    val itemIds = (json \ "items").as[List[Long]]

    val items = ElasticSearchDAO.fetchItemFeatures(itemIds)
    items.foreach(item => println(item))
    MySQLDAO.fetchCategoryFeatures(items, clusterId)

    val rankScore = WekaModel.scoreItems(items)

    response.setHeader("Content-Type", "application/json")
    response.getOutputStream.write(Json.stringify(Json.toJson(rankScore)).getBytes)
  }

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/brand"), method = Array(RequestMethod.GET), produces = Array("application/json"))
  def topBrand(@RequestParam leaf_categ_id: String, request: HttpServletRequest, response: HttpServletResponse): Unit = {
    val brands = MySQLDAO.getTopBrandOfCategory(InvConfig.BRAND_SIZE, leaf_categ_id.toLong)

    response.setHeader("Content-Type", "application/json")
    response.getOutputStream.write(Json.stringify(Json.toJson(brands)).getBytes)
  }

  @CrossOrigin(origins = Array("*"))
  @RequestMapping(value = Array("/clusters"), method = Array(RequestMethod.GET), produces = Array("application/json"))
  def getClusters(@RequestParam site_id: String, request: HttpServletRequest, response: HttpServletResponse): Unit = {
    val clusters = MySQLDAO.getClusters(site_id.toInt)
    response.setHeader("Content-Type", "application/json")
    response.getOutputStream.write(Json.stringify(Json.toJson(clusters)).getBytes)
  }

}
