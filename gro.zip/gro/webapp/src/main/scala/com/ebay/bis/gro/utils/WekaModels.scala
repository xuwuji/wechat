package com.ebay.bis.gro.utils

import weka.classifiers.Classifier
import weka.classifiers.Evaluation
import weka.core.FastVector
import weka.core.Instances
import weka.core.converters.CSVLoader
import weka.filters.Filter
import weka.filters.unsupervised.attribute.NumericToNominal

import java.io.File
import java.io.FileInputStream
import java.io.ObjectInputStream
import java.io.ByteArrayInputStream

import com.ebay.bis.gro.dao.Models._
import com.ebay.bis.gro.utils.InvConfig._

object WekaModel {

  val THRESHOLD = MODELTHRESHOLD

  def loadModel(path: String): Classifier = {
    val ois = new ObjectInputStream(new FileInputStream(path))
    ois.readObject().asInstanceOf[Classifier]
  }

  lazy val MODEL_WITH_LEAF: Classifier = loadModel(MODELWITHLEAF)
  lazy val MODEL_WITHOUT_LEAF: Classifier = loadModel(MODELWITHOUTLEAF)

  val WITH_LEAF_HEADER = List(
      "testing_target",
      "num_trans_7",
      "gmv_7",
      "num_trans_14",
      "gmv_14",
      "num_trans_21",
      "gmv_21",
      "num_trans_28",
      "gmv_30",
      "num_wtch_7",
      "num_wtch_14",
      "num_wtch_21",
      "num_wtch_28",
      "num_vi_7",
      "num_vi_14",
      "num_vi_21",
      "num_vi_28",
      "likelihood",
      "entropy").mkString(",")

  val WITHOUT_LEAF_HEADER = List(
      "testing_target",
      "num_trans_7",
      "gmv_7",
      "num_trans_14",
      "gmv_14",
      "num_trans_21",
      "gmv_21",
      "num_trans_28",
      "gmv_30",
      "num_wtch_7",
      "num_wtch_14",
      "num_wtch_21",
      "num_wtch_28",
      "num_vi_7",
      "num_vi_14",
      "num_vi_21",
      "num_vi_28").mkString(",")

  def model(hasLeaf: Boolean) = hasLeaf match {
    case true => MODEL_WITH_LEAF
    case false => MODEL_WITHOUT_LEAF
  }

  def string2Instance(strings: StringBuffer): Instances = {
    val testLoader: CSVLoader = new CSVLoader()
    testLoader.setSource(new ByteArrayInputStream(strings.toString.getBytes))
    val testData1:Instances = testLoader.getDataSet()
    val options = Array("-R", "1")
    val convertTest= new NumericToNominal()
    convertTest.setOptions(options);
    convertTest.setInputFormat(testData1);
    val testData:Instances  = Filter.useFilter(testData1, convertTest)
    testData.setClassIndex(0)
    testData
  }

  def loadData(items: List[Item], hasLeaf: Boolean): Instances = {
    val rand = scala.util.Random
    val strBuffer = new StringBuffer()
    strBuffer.append(if (hasLeaf) WITH_LEAF_HEADER else WITHOUT_LEAF_HEADER)
    strBuffer.append("\n")
    var idx = 0
    var inputItems = if(items.length == 1) items ::: items else items  // one item list is not valid for weka model, have to duplicate 
    for(item <- inputItems) {
      strBuffer.append((idx%2).toString).append(",")
      strBuffer.append(item.toCsv(hasLeaf))
      strBuffer.append("\n")
      idx = idx + 1
    }
    string2Instance(strBuffer)
  }

  def calculateScore(items: List[Item], hasLeaf: Boolean): List[Item] = {
    if(items.length > 0) {
        val cls = model(hasLeaf)
        val data = loadData(items, hasLeaf)
        items.zipWithIndex.map(entry => {
          val item = entry._1
          val index = entry._2
          val currentItemPrediction:Array[Double] = cls.distributionForInstance(data.instance(index))
          item.score = Option(currentItemPrediction(1))
          item
        })
    } else {
        items
    }
  }

  def scoreItems(items: List[Item]): ItemRankScore = {
    val threeItemLists: Map[String, List[Item]] = items.groupBy(itm =>
        if (!itm.features.isDefined)
          "NoScore"
        else if (itm.features.get.categoryFeatures.isDefined)
          "Leaf"
        else
          "NoLeaf"
        )

    val noScoreItems = threeItemLists.getOrElse("NoScore", List())
    val leafItems = calculateScore(threeItemLists.getOrElse("Leaf", List()), true)
    val noLeafItems = calculateScore(threeItemLists.getOrElse("NoLeaf", List()), false)

    val scoreItems = (leafItems ::: noLeafItems)
                      .sortWith(_.score.get > _.score.get)
                      .zipWithIndex.map{ 
                        case (e, i) => {
                          e.rank = Option(i + 1)
                          e.quality = if(e.score.get >= 0.6) 
                              Option("good")
                            else if(e.score.get >= 0.3)
                              Option("average")
                            else
                              Option("poor")
                          e
                        }
                      }.toList

    var totalConvert = 0
    scoreItems.foreach(item => if(item.score.getOrElse(0.0) >= THRESHOLD) totalConvert += 1)

    val totalScore = if(scoreItems.length > 0) totalConvert * 1.0 / scoreItems.length * 100 else 0

    ItemRankScore(ItemScoreSummary(totalScore), scoreItems, noScoreItems)
  }
}
