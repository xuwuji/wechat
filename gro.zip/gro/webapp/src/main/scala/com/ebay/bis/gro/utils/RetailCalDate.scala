package com.ebay.bis.gro.utils

import org.elasticsearch.common.joda.time.{Days, DateTime}

/**
  * Created by yangzhou on 11/30/15.
  *
  * Util class to calculate retail year and week on the fly.
  * Response should exactly match with the data stored in
  * table DW_CAL_DATE
  */
object CalDate {
  def getWkBgnDt(d: DateTime): DateTime = {
    d.minusDays(d.getDayOfWeek % 7)
  }

  def getWkEndDt(d: DateTime): DateTime = {
    d.plusDays(6 - d.getDayOfWeek % 7)
  }

  def isInCrssYrWk(d: DateTime): Boolean = {
    val bgnDt = getWkBgnDt(d)
    val endDt = getWkEndDt(d)
    bgnDt.getYear != endDt.getYear
  }

  def getDayOfWeek(d: DateTime): Int = d.getDayOfWeek match {
    case 1|2|3|4|5|6 => d.getDayOfWeek + 1
    case _ => 1
  }

  def getDomainYear(d: DateTime): Int = {
    val bgnDt = getWkBgnDt(d)
    val endDt = getWkEndDt(d)
    val dyOfWk = getDayOfWeek(d)

    if(dyOfWk <= 3)
      endDt.getYear
    else
      bgnDt.getYear
  }
}

class CalDate(date: DateTime) {

  import CalDate._

  val current = date.withTimeAtStartOfDay

  def init(): (DateTime, DateTime, Int, Int) = {
    val yrFrstDt = new DateTime(getDomainYear(current),1,1,0,0)

    // sunday is the first day of week for retail week
    // Sun: 1, ... Sat: 7
    val wkDaysFrstDt = getDayOfWeek(yrFrstDt)

    val lstYrWkDays = wkDaysFrstDt - 1
    val yrWkDays = 7 - lstYrWkDays

    val rtlYrBgnDt = if(lstYrWkDays > yrWkDays) {
      val bgnDt = yrFrstDt.plusDays(7-lstYrWkDays)
      if(bgnDt.isAfter(current)) {
        new CalDate(current.minusDays(7)).rtlYrBgnDt
      } else {
        bgnDt
      }
    } else {
      yrFrstDt.minusDays(lstYrWkDays)
    }

    val diffDays = Days.daysBetween(rtlYrBgnDt, current).getDays
    val rtlWk = diffDays/7 + 1

    val rtlWkBgnDt = getWkBgnDt(current)
    val rtlYr = getDomainYear(current)

    (rtlYrBgnDt, rtlWkBgnDt, rtlYr, rtlWk)
  }
  val (rtlYrBgnDt: DateTime, rtlWkBgnDt: DateTime, rtlYr: Int, rtlWk: Int) = init()


}