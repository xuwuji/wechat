package com.ebay.bis.gro.utils

import com.ebay.bis.gro.dao.MySQLDAO
import com.ebay.bis.gro.dao.Models._

object ClusterMetrics {
  def rankScore(clusterId: Int, items: List[Item]): CategoryRankScore = {
    val inputLeaves = items.map(_.leafCategId).toSet

    val inputCategoryMetrics = MySQLDAO.getClusterMetrics(clusterId, inputLeaves)

    val idealClusterSize = inputCategoryMetrics.size

    val RS = inputCategoryMetrics.foldLeft(0.0)((a, b) => a + b.relevanceScore)

    val inputVerticalSet = inputCategoryMetrics.map(_.vertical).toSet

    /*
    val idealClusters = if(inputVerticalSet.length > 1) {
      MySQLDAO.getTopNClusterMetricsInVerticalSet(idealClusterSize, inputVerticalSet, clusterId)
    } else {
      MySQLDAO.getTopNClusterMetrics(idealClusterSize, clusterId)
    }
    */
    val idealClusters = MySQLDAO.getTopNClusterMetricsInVerticalSet(idealClusterSize, inputVerticalSet, clusterId)

    val iRS = idealClusters.foldLeft(0.0)((a, b) => a + b.relevanceScore)

    val singleVertical = inputVerticalSet.size == 1

    def CategoryMetric2LeafCategory(cm: CategoryMetric) = LeafCategory(cm.leafCategId, cm.vertical, cm.relevanceScore, inputLeaves.contains(cm.leafCategId))

    val (ivRS: Double, suggestVerticalLeaves: List[LeafCategory]) = singleVertical match {
      case true => {
        val metaCategories: Set[Long] = MySQLDAO.getMetaCategorySet(inputLeaves, clusterId)
        //val vClusters = MySQLDAO.getTopNVerticalClusterMetrics(idealClusterSize, inputCategoryMetrics.head.vertical, clusterId)
        val vClusters = MySQLDAO.getTopNClusterMetricsInMetaCategory(idealClusterSize, metaCategories, clusterId)
        (vClusters.foldLeft(0.0)((a, b) => a + b.relevanceScore), vClusters.map(CategoryMetric2LeafCategory))
      }
      case false => (Double.NaN, List())
    }

    val (icRS: Double, suggestCategoryLeaves: List[LeafCategory]) = singleVertical match {
      case true => {
        val cClusters = MySQLDAO.getTopNClusterMetricsInCommonParentCategory(idealClusterSize, inputLeaves, clusterId)
        (cClusters.foldLeft(0.0)((a, b) => a + b.relevanceScore), cClusters.map(CategoryMetric2LeafCategory))
      }
      case false => (Double.NaN, List())
    }

    val nRS = (RS, iRS) match {
      case (_, 0.0) => Double.NaN
      case (a, b) => a/b * 100
    }

    val nVRS = (RS, ivRS) match {
      case (_, 0.0) => Double.NaN
      case (a, b) => a/b * 100
    }

    val nCRS = (RS, icRS) match {
      case (_, 0.0) => Double.NaN
      case (a, b) => a/b * 100
    }

    val currentLeaves: List[LeafCategory] = inputCategoryMetrics.map(CategoryMetric2LeafCategory)
    val suggestLeaves: List[LeafCategory] = idealClusters.map(CategoryMetric2LeafCategory)

    val scoreLeaves = inputCategoryMetrics.map(_.leafCategId).toSet
    val notScoreLeaves: List[LeafCategory] = inputLeaves.filter(id => !scoreLeaves.contains(id)).map(id => LeafCategory(id, "N/a", 0.0, false)).toList

    val nLeafCoverage = scoreLeaves.size * 1.0 / inputLeaves.size * 100
    val nItemCoverage = items.count(itm => scoreLeaves.contains(itm.leafCategId)) * 1.0 / items.size * 100

    CategoryRankScore(nRS, nVRS, nCRS, nLeafCoverage, nItemCoverage, currentLeaves, suggestLeaves, suggestVerticalLeaves, suggestCategoryLeaves, notScoreLeaves)
  }
}
