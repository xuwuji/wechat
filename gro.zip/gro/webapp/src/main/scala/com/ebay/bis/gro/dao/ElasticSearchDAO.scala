package com.ebay.bis.gro.dao

import java.io.{PrintWriter, OutputStream}

import com.ebay.bis.gro.utils.InvConfig._
import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.elasticsearch.action.search.SearchResponse
import org.elasticsearch.client.Client
import org.elasticsearch.client.transport.TransportClient
import org.elasticsearch.common.settings.ImmutableSettings
import org.elasticsearch.common.transport.InetSocketTransportAddress
import org.elasticsearch.common.unit.TimeValue
import org.elasticsearch.index.query.{FilterBuilders, QueryBuilders}
import org.elasticsearch.search.sort.{SortBuilders, SortOrder, SortBuilder}

import scala.collection.JavaConversions._
import com.ebay.bis.gro.dao.Models._

/**
  * Created by yangzhou on 12/2/15.
  */
object ElasticSearchDAO {

  lazy val client: Client = {
    val settings = ImmutableSettings.settingsBuilder().put("cluster.name", CLUSTERNAME).build()
    var client: TransportClient = new TransportClient(settings)
    HOSTS.foreach(host => {
      client = client.addTransportAddress(new InetSocketTransportAddress(host, PORT))
    })
    client
  }

  def getAliasIndexName(alias: String): Option[String] = {
    val allAliases = client.admin().cluster().prepareState().execute().actionGet().getState().getMetaData().getAliases()

    if(allAliases.containsKey(alias)) {
      val indices = allAliases.get(alias).keys()
      if(indices.size() <= 0) {
        None
      } else {
        Option(indices.head.value)
      }
    } else {
      None
    }
  }

  def query(index: String, tipe: String, query: String): SearchResponse = {
    val esRequest = ESQuery(query)

    val search = client.prepareSearch(index)
    search.setTypes(List(tipe):_*)

    search.setQuery(QueryBuilders.wrapperQuery(esRequest.queryContent))

    esRequest.sortFields.foreach(sort => {
      search.addSort(sort)
    })

    if(esRequest.aggregationContent.isDefined) {
      search.setAggregations(esRequest.aggregationContent.get.getBytes())
    }

    if(esRequest.from > 0) {
      search.setFrom(esRequest.from)
    }

    search.setSize(esRequest.size)

    search.execute().actionGet()
  }

  def downloadToStream(site: String, query: String, columns: String, out: PrintWriter): Unit = {
    val downloadColumns = if(columns == null) {
      COMMON_COLUMNS ::: SITE_COMP_COLUMNS(site) ::: COMP_DEAL_COLUMNS.toList
    } else {
      columns.split(",").toList
    }
    if(INVSEL_INDEX_MAP.contains(site) && query != null) {
      val request = ESQuery(query)
      val useScroll = request.size > SCROLL_SIZE

      var delimiter = ""
      downloadColumns.foreach(c => {
        out.print(delimiter)
        out.print("\"")
        out.print(c.replaceAll("\"", ""))
        out.print("\"")
        delimiter = ","
      })
      out.println()

      val search = client.prepareSearch(INVSEL_INDEX_MAP(site))

      if(useScroll) {
        search.setScroll(new TimeValue(SCROLL_LIVE_TIME))
      }

      search.setTypes(List("item"):_*)
      search.setQuery(QueryBuilders.wrapperQuery(request.queryContent))

      request.sortFields.foreach(sort => {
        search.addSort(sort)
      })

      if(request.from > 0) {
        search.setFrom(request.from)
      }

      if(useScroll) {
        search.setSize(SCROLL_SIZE)
      } else {
        search.setSize(request.size)
      }

      var scrollResp: SearchResponse = search.execute().actionGet()

      var done = false
      var outputRecordNum = 0
      while(!done) {
        scrollResp.getHits().getHits().foreach(hit => {
          outputRecordNum += 1
          if(outputRecordNum <= request.size) {
            val source = hit.getSource
            var delimiter = ""
            downloadColumns.foreach(c => {
              out.print(delimiter)
              out.print("\"")
              if(COMP_PRICE_COLUMNS.contains(c)) {
                if(source.contains("COMP_PRICE")) {
                  val vlist = source.get("COMP_PRICE").asInstanceOf[java.util.List[java.util.Map[String, AnyRef]]]
                  val vcomp = vlist.find(e => e.containsKey("comp") && e.get("comp").toString == c)
                  if(vcomp.isDefined) {
                    out.print(vcomp.get("price").toString)
                  }
                }
              } else if (COMP_DEAL_COLUMNS.contains(c)) {
                if(source.contains("COMP_DEAL")) {
                  val vlist = source.get("COMP_DEAL").asInstanceOf[java.util.List[java.util.Map[String, AnyRef]]]
                  val vcomp = vlist.find(e => e.containsKey("type") && e.get("type").toString == c)
                  out.print(vcomp.isDefined.toString)
                }
              } else {
                if(source.contains(c)) {
                  out.print(source.get(c).toString)
                }
              }
              out.print("\"")
              delimiter = ","
            })
            out.println()
          }
        })

        if(outputRecordNum >= request.size) {
          done = true
        } else {
          if(useScroll) {
            scrollResp = client.prepareSearchScroll(scrollResp.getScrollId()).setScroll(new TimeValue(SCROLL_LIVE_TIME)).execute().actionGet()
            if (scrollResp.getHits().getHits().length == 0) {
              done = true
            }
          } else {
            done = true
          }
        }
      }
    }
    out.flush()
  }

  def fetchItemFeatures(itemIds: List[Long]): List[Item] = {
      val ids = itemIds.map(itm => "\"" + itm + "\"").mkString(",")
      val queryContent: String = "{\"ids\":{\"type\":\"item\",\"values\":[" + ids + "]}}"
      
	  // US site only now. REMEMBER to change to different alias name by site later
      val search = client.prepareSearch(US_INDEX_NAME)
      search.setTypes(List("item"):_*)
      search.setQuery(QueryBuilders.wrapperQuery(queryContent))
      search.setFrom(0)
      search.setSize(itemIds.length)

      var scrollResp: SearchResponse = search.execute().actionGet()
      val itm2details = scrollResp.getHits().getHits().map(hit => {
          val source = hit.getSource
          val item_id = source.get("ITEM_ID").toString.toLong
          val leafCategId = source.getOrElse("LEAF_CATEG_ID", "0").toString.toLong
          val num_trans_7 = source.getOrElse("TRX_1_7_DAYS", "0").toString.toDouble.toInt
          val num_trans_14 = source.getOrElse("TRX_8_14_DAYS", "0").toString.toDouble.toInt + num_trans_7
          val num_trans_21 = source.getOrElse("TRX_15_21_DAYS", "0").toString.toDouble.toInt + num_trans_14
          val num_trans_28 = source.getOrElse("TRX_22_28_DAYS", "0").toString.toDouble.toInt + num_trans_21

          val gmv_7 = source.getOrElse("GMV_1_7_Days", "0.0").toString.toDouble
          val gmv_14 = source.getOrElse("GMV_8_14_Days", "0.0").toString.toDouble + gmv_7
          val gmv_21 = source.getOrElse("GMV_15_21_Days", "0.0").toString.toDouble + gmv_14
          val gmv_28 = source.getOrElse("GMV_22_28_Days", "0.0").toString.toDouble + gmv_21

          val num_wtch_7 = source.getOrElse("WATCH_CNT_1_7_Days", "0").toString.toDouble.toInt
          val num_wtch_14 = source.getOrElse("WATCH_CNT_8_14_Days", "0").toString.toDouble.toInt + num_wtch_7
          val num_wtch_21 = source.getOrElse("WATCH_CNT_15_21_Days", "0").toString.toDouble.toInt + num_wtch_14
          val num_wtch_28 = source.getOrElse("WATCH_CNT_22_28_Days", "0").toString.toDouble.toInt + num_wtch_21

          val num_vi_7 = source.getOrElse("VI_CNT_1_7_days", "0").toString.toDouble.toInt
          val num_vi_14 = source.getOrElse("VI_CNT_8_14_days", "0").toString.toDouble.toInt + num_vi_7
          val num_vi_21 = source.getOrElse("VI_CNT_15_21_days", "0").toString.toDouble.toInt + num_vi_14
          val num_vi_28 = source.getOrElse("VI_CNT_22_28_days", "0").toString.toDouble.toInt + num_vi_21

          val itemFeatures = new ItemFeatures(
              num_trans_7,
              gmv_7,
              num_trans_14,
              gmv_14,
              num_trans_21,
              gmv_21,
              num_trans_28,
              gmv_28,
              num_wtch_7,
              num_wtch_14,
              num_wtch_21,
              num_wtch_28,
              num_vi_7,
              num_vi_14,
              num_vi_21,
              num_vi_28,
              None
            )
          (item_id -> (leafCategId, Option(itemFeatures)))
      }).toMap

      itemIds.map(itemId => {
        val (leafCategId: Long, features: Option[ItemFeatures]) = itm2details.get(itemId).getOrElse((-1L, None))
        new Item(itemId, leafCategId, features)
      }).toList  
  }


  case class ESQuery(json: String) {
    val mapper = new ObjectMapper()
    val actualObj: JsonNode = mapper.readTree(json)

    val queryContent = actualObj.get("query").toString

    val aggregationContent = if (actualObj.has("aggregations")) Option(actualObj.get("aggregations").toString) else None

    val sortNode = Option(actualObj.get("sort"))

    def parse2SortBuilder(node: JsonNode): Option[SortBuilder] = {
      if (node.fields().hasNext) {
        val first = node.fields().next()
        val field = first.getKey
        val sortOrder = if (first.getValue.get("order").asText().toLowerCase() == "desc") {
          SortOrder.DESC
        } else {
          SortOrder.ASC
        }
        var sortBuilder = SortBuilders.fieldSort(field).order(sortOrder)
        if (first.getValue.has("nested_filter")) {
          val nestFilter = QueryBuilders.wrapperQuery(first.getValue.get("nested_filter").toString)
          sortBuilder = sortBuilder.setNestedFilter(FilterBuilders.queryFilter(nestFilter))
        }
        if (first.getValue.has("nested_path")) {
          val nestPath = first.getValue.get("nested_path").asText()
          sortBuilder = sortBuilder.setNestedPath(nestPath)
        }
        Some(sortBuilder)
      } else None
    }

    val sortFields = if (sortNode.isDefined) {
      if(sortNode.get.isArray) {
        sortNode.get.map(snode => {
          parse2SortBuilder(snode).get
        }).toList
      } else {
        val t = parse2SortBuilder(sortNode.get)
        if(t.isDefined) {
          List(t.get)
        } else {
          List[SortBuilder]()
        }
      }
    } else {
      List[SortBuilder]()
    }

    val from = if(actualObj.has("from")) actualObj.get("from").asInt() else 0
    val size = if(actualObj.has("size")) actualObj.get("size").asInt() else 50
  }
}
