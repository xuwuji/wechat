package com.ebay.bis.gro.dao

import scalikejdbc._
import scalikejdbc.config._
import com.ebay.bis.gro.dao.Models._

object MySQLDAO {

  DBs.setupAll()

  def getClusterMetrics(clusterId: Int, leafs: Set[Long]): List[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId} and leaf_categ_id in (${leafs})
      """.map(rs => CategoryMetric(rs)).list.apply()
    }
  }

  def getAllClusterMetrics(clusterId: Int): List[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId}
      """.map(rs => CategoryMetric(rs)).list.apply()
    }
  }

  def getCategoryMetric(clusterId: Int, categoryId: Long): Option[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId}
          and leaf_categ_id = ${categoryId}
      """.map(rs => CategoryMetric(rs)).single.apply()
    }
  }

  def getTopNClusterMetrics(n: Int, clusterId: Int): List[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId}
        order by likelihood_score * entropy_score desc
        limit ${n}
      """.map(rs => CategoryMetric(rs)).list.apply()
    }
  }

  def getMetaCategorySet(leafs: Set[Long], clusterId: Int): Set[Long] = {
    val metas = NamedDB('eq) readOnly {
      implicit session => sql"""
        select 
           distinct meta_categ_id
        from cluster_metrics
        where cluster_id = ${clusterId} and leaf_categ_id in (${leafs})
      """.map(rs => {
        rs.long("meta_categ_id")
      }).list.apply()
    }

    metas.toSet
  }

  def getTopNClusterMetricsInVerticalSet(n: Int, verticals: Set[String], clusterId: Int): List[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId}
          and vertical in (${verticals})
        order by likelihood_score * entropy_score desc
        limit ${n}
      """.map(rs => CategoryMetric(rs)).list.apply()
    }
  }

  def getTopNClusterMetricsInMetaCategory(n: Int, metas: Set[Long], clusterId: Int): List[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId}
          and meta_categ_id in (${metas})
        order by likelihood_score * entropy_score desc
        limit ${n}
      """.map(rs => CategoryMetric(rs)).list.apply()
    }
  }

  def getTopNVerticalClusterMetrics(n: Int, vertical: String, clusterId: Int): List[CategoryMetric] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select
          create_dt,
          cluster_id,
          leaf_categ_id,
          likelihood_score,
          entropy_score,
          vertical
        from cluster_metrics
        where cluster_id = ${clusterId}
          and vertical = ${vertical}
        order by likelihood_score * entropy_score desc
        limit ${n}
      """.map(rs => CategoryMetric(rs)).list.apply()
    }
  }

  def getTopNClusterMetricsInCommonParentCategory(n: Int, leafs: Set[Long], clusterId: Int): List[CategoryMetric] = {
    val parentCategoryLevel = NamedDB('eq) readOnly {
      implicit session => sql"""
        select 
          count(distinct meta_categ_id) metacnt,
          count(distinct categ_lvl2_id) lvl2cnt,
          count(distinct categ_lvl3_id) lvl3cnt,
          count(distinct categ_lvl4_id) lvl4cnt,
          count(distinct categ_lvl5_id) lvl5cnt,
          count(distinct categ_lvl6_id) lvl6cnt,
          count(distinct categ_lvl7_id) lvl7cnt 
        from cluster_metrics
        where cluster_id = ${clusterId} and leaf_categ_id in (${leafs})
      """.map(rs => (
          rs.int("metacnt"),
          rs.int("lvl2cnt"),
          rs.int("lvl3cnt"),
          rs.int("lvl4cnt"),
          rs.int("lvl5cnt"),
          rs.int("lvl6cnt"),
          rs.int("lvl7cnt")
        ) match {
          case (_, _, _, _, _, _, 1) => "categ_lvl7_id"
          case (_, _, _, _, _, 1, _) => "categ_lvl6_id"
          case (_, _, _, _, 1, _, _) => "categ_lvl5_id"
          case (_, _, _, 1, _, _, _) => "categ_lvl4_id"
          case (_, _, 1, _, _, _, _) => "categ_lvl3_id"
          case (_, 1, _, _, _, _, _) => "categ_lvl2_id"
          case (1, _, _, _, _, _, _) => "meta_categ_id"
          case _ => null
        }).single.apply()
    }

    if(parentCategoryLevel.isDefined) {
      val parentCategory = NamedDB('eq) readOnly {
        val column = sqls.createUnsafely(parentCategoryLevel.get)
        implicit session => sql"""
          select distinct ${column} v from cluster_metrics where cluster_id = ${clusterId} and leaf_categ_id in (${leafs})
        """.map(rs => rs.long("v")).single.apply()
      }

      if(parentCategory.isDefined) {
        NamedDB('eq) readOnly {
          val column = sqls.createUnsafely(parentCategoryLevel.get)
          implicit session => sql"""
              select
                create_dt,
                cluster_id,
                leaf_categ_id,
                likelihood_score,
                entropy_score,
                vertical
              from cluster_metrics
              where cluster_id = ${clusterId} and ${column} = ${parentCategory.get}
              order by likelihood_score * entropy_score desc
              limit ${n}
              """.map(rs => CategoryMetric(rs)).list.apply()
        }
      } else {
        //throw new RuntimeException("categories from same vertical should have same parent categories")
        List()
      }
    } else {
      //throw new RuntimeException("categories from same vertical should have same parent categories")
      List()
    }


  }

  def getTopBrandOfCategory(n: Int, categoryId: Long): List[Brand] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select *
        from brand_distribution
        where leaf_categ_id = ${categoryId}
        order by `count` desc
        limit ${n}
      """.map(rs => Brand(rs)).list.apply()
    }
  }

  def getClusters(siteId: Int): List[Cluster] = {
    NamedDB('eq) readOnly {
      implicit session => sql"""
        select distinct cluster_id, cluster_name
        from cluster
        where site_id = ${siteId}
      """.map(rs => Cluster(rs)).list.apply()
    }
  }

  def fetchCategoryFeatures(items: List[Item], clusterId: Int): List[Item] = {
	  items.foreach(item => {
		  if(item.features.isDefined) {
			val categoryMetric = getCategoryMetric(clusterId, item.leafCategId)
			if(categoryMetric.isDefined) {
			  // set categoryFeatures if given category existing
			  item.features.get.categoryFeatures = Option(
				  CategoryFeatures(categoryMetric.get.likelihoodScore, categoryMetric.get.entropyScore)
				)
			}
		  }
	  })
	  items
  }
}
