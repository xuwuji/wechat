package com.ebay.bis.gro.utils

import com.typesafe.config.ConfigFactory

/**
  * Created by yangzhou on 12/2/15.
  */
object InvConfig {

  val config = ConfigFactory.load("application.conf")

  lazy val CLUSTERNAME = config.getString("bpe.es.cluster.name")
  
  lazy val HOSTS = config.getString("bpe.es.hosts").split(",")

  lazy val PORT = config.getInt("bpe.es.port")
  
  lazy val SCROLL_SIZE = config.getInt("service.download.scroll.size")

  lazy val SCROLL_LIVE_TIME = config.getInt("service.download.scroll.live")

  lazy val COMMON_COLUMNS = config.getString("index.schema").split(",").filter(!_.isEmpty).toList

  lazy val COMP_PRICE_COLUMNS = Set("amazon.com","amazon.co.uk","amazon.de","rakuten_us","walmart_us","sears_us","tigerdirect_us","argos_uk")

  lazy val COMP_DEAL_COLUMNS = config.getString("index.deal.columns").split(",").filter(!_.isEmpty).toSet

  lazy val __SITES = config.getString("index.sites").split(",").toList
  
  lazy val SITE_COMP_COLUMNS = __SITES.map(site => {
    (site, config.getString(s"index.${site}.comp.columns").split(",").filter(!_.isEmpty).toList)
  }).toMap

  lazy val INVSEL_INDEX_MAP = __SITES.map(site => {
    (site, config.getString(s"index.${site}.alias"))
  }).toMap

  lazy val MODELWITHLEAF: String = config.getString("gro.invsel.eq.model.with.leaf")

  lazy val MODELWITHOUTLEAF: String = config.getString("gro.invsel.eq.model.without.leaf")

  lazy val MODELTHRESHOLD: Double = config.getDouble("gro.invsel.eq.model.threshold")
  
  lazy val BRAND_SIZE: Int = config.getInt("gro.invsel.eq.brand.size")

  lazy val US_INDEX_NAME: String = config.getString("index.us.alias")
}
