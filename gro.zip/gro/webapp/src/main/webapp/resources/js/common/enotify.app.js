/**
 * This js file is to initialize category performance summary/detail page. And
 * the Angular js controller/service/filter are for UI interaction.
 */
(function(angular, global) {
	'use strict';
	var app = angular.module('GroEnotifyModule', []);


	/*message services*/
	app.provider("GroEnotify.message",  [function(){ 
			var gOption = null;
			
			/*
			 * eNotifyURL: URL of eNotify service
			 */
			this.setOption = function(option){
				gOption = option;
			}

			this.$get = ['$http','$q', function($http, $q){
				return {
					debug: function(){
						//console.log("option: ", gOption);
					},

					option : gOption,
					
					makeCalls: function(userId){
						var notifyPromise = $http.get(gOption.eNotifyURL);
						//var latestPromise = $http.get(gOption.latestMessageURL + "/" + userId + ".json");
						return $q.all([notifyPromise /*, latestPromise*/ ]);
					},
					
					filterMessages: function(allMessages /*, latestMsg*/){
						if ( allMessages === null ) return [];
						if ( !angular.isArray(allMessages) ) return [allMessages];
						return allMessages.slice(0,5);
						/*
						return allMessages.filter(function(message){
							var pubDate = new Date(message.pubDate);
							return pubDate.getTime() > latestMsg.pubDate;
						});
						*/
					}
				}
			}]
		}
	]);

	var scripts = document.getElementsByTagName("script")
	var currentScriptPath = scripts[scripts.length-1].src;
	var basePath = currentScriptPath.substring(0, currentScriptPath.lastIndexOf('/') + 1);

	/**
	 * Internal functions -- make remote call to get messages.
	 */
	function getMessages(scope, message){
		var util = global.eBayGRO.util;
		var msgPromise = message.makeCalls(message.option.uid);
		msgPromise.then(function(okResults) {
			var eNotifyObj = util.xml2json(okResults[0].data);
			var filteredMessages = [];
			if (eNotifyObj && eNotifyObj.rss && eNotifyObj.rss.channel && eNotifyObj.rss.channel.item) {
				var messages = eNotifyObj.rss.channel.item;
				filteredMessages = message.filterMessages(messages);
				util.console.info("filteredMessages:", filteredMessages);
				var items = [];
				filteredMessages.forEach(function(msg){
					var d = new Date(msg.pubDate);
					items.push({head: msg.title, date: d.toLocaleString(), link: msg.link});
				})
				scope.items = items;
			}
		}, function(failedResults) {
			util.console.warn("failed:", failedResults);
		})
	}

	/*directives*/
	app.directive("groEnotifyProductNews", ['GroEnotify.message', '$interval', function(message, $interval){
		function link(scope, elem, attrs){
			scope.showPopup = false;
			var stop;

			scope.items = [];
			getMessages(scope, message);

			stop = $interval(function(){
				getMessages(scope, message);
			}, 1000 * 60);

			scope.$on('$destroy', function() {
				// Make sure that the interval is destroyed too
				if (angular.isDefined(stop)) {
					$interval.cancel(stop);
					stop = undefined;
		        }
		    });

			scope.click = function(){
				scope.showPopup = !scope.showPopup;
				if ( scope.showPopup ) scope.hasNewMessage = false;
			}
		}

		return {
			scope: {},
			restrict: 'AEC',
		    templateUrl: basePath + 'tpl-product-news.html',
		    link: link
		}
	}]);


	/**
	 * News notifier widget shown on top of the page.
	 */
	app.directive("groEnotifyNewsOnTop", ['GroEnotify.message', '$interval', function(message, $interval){

		function link(scope, elem, attrs){
			var stop;

			scope.items = [];
			scope.hideText = true;
			scope.classTxt="ge-not-view-thin";
			getMessages(scope, message);

			stop = $interval(function(){
				getMessages(scope, message);
			}, 1000 * 60 * 5);

			scope.$on('$destroy', function() {
				// Make sure that the interval is destroyed too
				if (angular.isDefined(stop)) {
					$interval.cancel(stop);
					stop = undefined;
		        }
		    });

			scope.click = function(){
				scope.hideText = !scope.hideText;
				scope.classTxt = scope.hideText ? "ge-not-view-thin" : "ge-not-view-fat";
			}
		}

		return {
			scope: {},
			restrict: 'AEC',
		    templateUrl: basePath + 'tpl-news-on-top.html',
		    link: link
		}
	}]);
})(angular, window);
