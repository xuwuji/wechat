!function(angular) {
		'use strict';
angular.module("tree-controller", [ 'ui.bootstrap','tree-service'])

.controller('itemSaveController', ['$scope','modalService','data','treeService','$log','$q','$document',function($scope,
				modalService, data,treeService, $log, $q,$document) {
			var promises = [];
			$scope.dto = {};
			promises.push(treeService.queryTreeMeta());
			if(data.mode==='U'&&data.id){
				promises.push(treeService.queryItem({id : data.id}));
			}
			$q.all(promises).then(function(response) {
				if(data.mode==='U'){
					var items = response[1];
					$scope.dto = items;
				}
				var fields = response[0][0];
				var booleanFields = response[0][1];
				fields.splice(0,1);
				fields.splice(2,1);
				$scope.fields = fields;
				$scope.booleanFields = booleanFields;
			}, function(res) { 
			});

			$document.bind("keydown", function(event) {
				$scope.$apply(function(){
					if(event.ctrlKey&&event.which===83){
						event.preventDefault();
						$scope.ok();
					}
				});
			});
			
			$scope.ok = function() {
				$scope.dto.pid = data.pid;
				treeService.saveTree($scope.dto).then(function(insertId) { 
					if(data.mode==='I'&&data.selectedItem){
						data.selectedItem.children = data.selectedItem.children||[];
						data.selectedItem.children.push({id:insertId,name:$scope.dto.name,parent:data.selectedItem});
					}
					modalService.close();
				}, function(res) { 
				});
			};
			$scope.cancel = function() {
				modalService.dismiss('cancel');
			};
		}])
		
.controller("treeController", ['$http','$scope','modalService','treeService','$document', '$timeout',function($http, $scope, modalService,treeService, $document,$timeout) {
			$scope.isModal = false;
			$scope.itemCheckedChanged = function($item, index) {
				if ($item.$$isChecked) {
					if ($scope.selectedItem && $scope.selectedItem !== $item) {
						$scope.selectedItem.$$isChecked = false;
					}
					$scope.selectedItem = $item;
					$scope.selectedPosistion = index;
				}
			};
			
			treeService.queryTreeJson().then(function(res) {
				if(res){
					$scope.tree = [ res ];
				} else {
					$scope.tree = [{id : "-1" ,name : "root"}];
				}
				$scope.tree[0].$$isChecked = true;
				$scope.itemCheckedChanged($scope.tree[0], 0);
					},function(res){});
			
			$document.bind("keydown", function(event) {
				$scope.$apply(function(){
					if(!$scope.isModal){
						if(event.which===85){
							$scope.itemClicked($scope.selectedItem);
						}
						if(event.which===73){
							$scope.insertItem();
						}
					}
				});
			});
			
			$scope.itemClicked = function($item) {
				$scope.isModal = true;
				modalService.open({
					mode : 'U', //for update item
					id : $item.id,
					pid : $item.parent.id
				}).whenClose(function(){
					$scope.isModal = false;
				});
			};
			
			$scope.publishTree = function(){
				treeService.publishTree().then(function(res) {
					$scope.success = true;
					var timer = $timeout(function(){
						$scope.success = false;
						$timeout.cancel( timer );
					} ,700);
				},function(res){});
			}
			
			$scope.deleteItem = function() {
				if (!$scope.selectedItem) {
					return;
				}
				var queue = [];
				var deletes = [];
				queue.push($scope.selectedItem);
				while(queue.length>0){
					var tempItem = queue.pop();
					deletes.push(tempItem.id);
					var children = tempItem.children;
					if(children){
						for(var i = 0, len = children.length ; i<len ;i++ ){
							queue.push(children[i]);
						}
					}
				}
				if($scope.selectedItem.id==='-1'){
					delete scope.selectedItem.children;
				}else { 
					$scope.selectedItem.parent.children.splice($scope.selectedPosistion,1);
					$scope.selectedItem = null;
					$scope.selectedPosistion = null;
				}
				var deleteStr = deletes.join(",");
				treeService.deleteItem({ids : deleteStr})
				.then(function(res) {
						
					});
				}
			
			$scope.insertItem = function() {
				if (!$scope.selectedItem) {
					return;
				}
				$scope.isModal = true;
				modalService.open({
					mode : 'I', //for insert item
					pid : $scope.selectedItem.id,
					selectedItem : $scope.selectedItem
				}).whenClose(function(){
					$scope.isModal = false;
				});
			}
		}	
		])
	}(angular);