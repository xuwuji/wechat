!function(angular) {
		'use strict';
angular.module('ui.bootstrap.demo', [ 'ui.bootstrap'])
.controller('TabsDemoCtrl', function ($scope, $window) {
	$scope.tabs = [{
      title: 'left nav',
      url: window.eBayGRO.CONTEXT_PATH + '/admin/tree_config'
  }, {
      title: 'permission',
      url: window.eBayGRO.CONTEXT_PATH + '/admin/permission_info'
  }, {
      title: 'internal',
      url: window.eBayGRO.CONTEXT_PATH + '/admin/internal_info'
}];
	});
	}(angular);