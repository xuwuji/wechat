(function(angular, global){
    'use strict';

    var epApp = angular.module('epApp',['GroEnotifyModule', 'angular-bootstrap-select', 'daterangepicker', 'cptServices', 'ui.bootstrap', 'datatables', 'highcharts-ng','GroStickyFilterModule']);

    var eBayGROUtil = global.eBayGRO.util;
	var user = eBayGROUtil.getUserInfo();

	epApp.config([ "GroEnotify.messageProvider",
		function(messageProvider) {
			messageProvider.setOption({
				eNotifyURL : eBayGRO.config.GRO_ENOTIFY_URL,
			});
		}
	]);

    epApp.controller('EventSelectionCtrl', ['$scope', '$modalInstance', 'data', 'cptEventService', '$log', 'DTOptionsBuilder','DTColumnDefBuilder',
        function ($scope, $modalInstance, data, eventService, $log, DTOptionsBuilder,DTColumnDefBuilder) {
            $scope.eventsSelected = angular.merge({},data.events);
            $scope.eventGroupId = data.eventGroupId;
            $scope.fromTo = angular.merge({},data.fromTo);
            $scope.loading = true;
            $scope.tableData = {};
            $scope.eventsMap = {};
            
            $scope.dtOptions = DTOptionsBuilder.newOptions()
                    .withOption("lengthMenu", [ [5, 10, 25, 50, -1], [5,10, 25, 50, "All"] ])
            		.withOption("order", [[4, "desc" ]]);
            
            $scope.dtColumnDefs = [
                                   DTColumnDefBuilder.newColumnDef(0).notSortable()
                               ];
            
            eventService.queryEvents($scope.eventGroupId, $scope.fromTo, function(data){
                $scope.tableData.data = data;
                $scope.loading = false;
                data.forEach(function(row){
                    $scope.eventsMap[row.value] = row;
                })
            }, function(hr){
                $log.error("failed to queryEvents, ", hr);
                $scope.loading = false;
            });

            $scope.ok = function () {
                var rows = [];
                for ( var key in $scope.eventsSelected ){
                    rows.push($scope.eventsMap[key]);
                }
                $modalInstance.close({eventsKey: $scope.eventsSelected, events: rows});
            };


            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };

            $scope.eventClicked = function(value){
                $log.info("eventClicked: ", value);
                if ( !$scope.eventsSelected[value] ) delete $scope.eventsSelected[value];
                if ( Object.keys($scope.eventsSelected).length > 5 ){
                    alert("Up to 5 events can be selected.");
                    delete $scope.eventsSelected[value];
                    return;
                }
                $log.info("eventsSelected: ", $scope.eventsSelected);
            }

    }]);
    
    epApp.controller('BuyerCountrySelectionCtrl', ['$scope', '$modalInstance', 'data', 'cptEventService', '$log', 'DTOptionsBuilder',
            function ($scope, $modalInstance, data, eventService, $log, DTOptionsBuilder) {
                $scope.buyerCountrySelected = angular.merge({},data.buyerCountrys);
                $scope.loading = true;
                $scope.tableData = {};
                $scope.buyerCountrysMap = {};

                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption("lengthMenu", [ [5, 10, 25, 50, -1], [5,10, 25, 50, "All"] ]);

                eventService.queryBuyerCountrys("",function(data){
                    $scope.tableData.data = data;
                    $scope.loading = false;
                    data.forEach(function(row){
                        $scope.buyerCountrysMap[row.value] = row;
                    })
                }, function(hr){
                    $log.error("failed to queryBuyerCountry, ", hr);
                    $scope.loading = false;
                });

                $scope.ok = function () {
                    var rows = [];
                    for ( var key in $scope.buyerCountrySelected ){
                        rows.push($scope.buyerCountrysMap[key]);
                    }
                    $modalInstance.close({buyerCountrysKey: $scope.buyerCountrySelected, buyerCountrys: rows});
                };


                $scope.cancel = function () {
                    $modalInstance.dismiss('cancel');
                };

                $scope.buyerCountryClicked = function(value){
                    $log.info("buyerCountryClicked: ", value);
                    if ( !$scope.buyerCountrySelected[value] ) delete $scope.buyerCountrySelected[value];
                    if ( Object.keys($scope.buyerCountrySelected).length > 5 ){
                        alert("Up to 5 buyer countries can be selected.");
                        delete $scope.buyerCountrySelected[value];
                        return;
                    }
                    $log.info("buyerCountrySelected: ", $scope.buyerCountrySelected);
                }

        }]);
    
    epApp.controller('EventDetailCtrl', ['$scope', '$modalInstance', 'data', 'cptEventService', '$log', 'DTOptionsBuilder',
        function ($scope, $modalInstance, data, cptEventService, $log, DTOptionsBuilder) {
            var eventId = data.eventId;
            var eventName = data.eventName;
            var buyerCountry = data.buyerCountry;
            var fromTo = angular.merge({},data.fromTo);
            $scope.loading = true;
            $scope.tableData = {};

            $scope.dtOptions = DTOptionsBuilder.newOptions()
                    .withOption("lengthMenu", [ [5, 10, 25, 50, -1], [5,10, 25, 50, "All"] ])
            		.withOption("order", [[2, "desc" ]]);
            
            cptEventService.itemDetailOnEvent(
                    {from: fromTo.from, to: fromTo.to, eventId: eventId,buyerCountry:buyerCountry},
                    function(resp){
                    	$scope.tableData.data = resp.data;
                        $scope.loading = false;
                    },
                    function(){
                        $scope.loading = false;
                    }
                );
            
            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
            
            $scope.downloadItems = function(){
                var dataList = $scope.tableData.data;
                var str = "Item ID,Item Name,Categories,Seller,Total Item Click,In Page Item Click,Total Sales,In Page Sales,Total Sold Quantity,In Page Sold Quantity,Current Price"+ "\n";
                for(var i=0;i<dataList.length;i++)
                {
                    var row = dataList[i];
                    if(row.title != null){
                    	if(row.currentPriceText != null){
                    		str = str + row.id + ","  + "\""+ (row.title).replace("\"","\'\'") + "\"" + ","  + "\""+ row.parentCategory +">"+row.category+ "\""+ ","  + "\""+ row.sellerName + "\"" + ","+row.totalClick+ "," +row.dealsClick+ "," +row.totalGMV+ "," + row.dealsGMV+ "," + row.totalQty + "," + row.dealsQty + ","+ "\"" + (row.currentPriceText).replace("£","GBP ") + "\"" + "\n";
                    	}else{
                    		str = str + row.id + ","  + "\""+ (row.title).replace("\"","\'\'") + "\"" + ","  + "\""+ row.parentCategory +">"+row.category+ "\""+ ","  + "\""+ row.sellerName + "\"" + ","+row.totalClick+ "," +row.dealsClick+ "," +row.totalGMV+ "," + row.dealsGMV+ "," + row.totalQty + "," + row.dealsQty + ","+ "\"" + row.currentPriceText + "\"" + "\n";
                    	}
                    }else{
                    	str = str + row.id + ","  + "\""+ row.title + "\"" + ","  + "\""+ row.category + "\""+ ","  + "\""+ row.sellerName + "\"" + ","+row.totalClick+ "," +row.dealsClick+ "," +row.totalGMV+ "," + row.dealsGMV+ "," + row.totalQty + "," + row.dealsQty + ","+ "\"" + row.currentPriceText + "\"" + "\n";
                    }
                }
                var csvname = "Event("+eventName+") Detail.csv";
                var blob = new Blob([str], {type: "text/csv;charset=utf-8"});
                saveAs(blob, csvname);
         }

    }]);



    var epCtrl = epApp.controller('EventPerformanceCtrl', ['$scope', '$timeout', 'cptEventService', '$modal', '$log', '$http', 'DTOptionsBuilder',
      function($scope, $timeout, cptEventService, $modal, $log, $http, DTOptionsBuilder){
        //items init as below
        var chartHeight = 250;
        var colors = ['#2f7ed8', '#0d233a', '#8bbc21', '#910000', '#1aadce', '#f28f43' ,'#77a1e5','#492970', '#c42525', '#a6c96a'];
        $scope.data = {};
        $scope.chartType = 'pie';
        $scope.items = [];
        $scope.eventsData = {};
        $scope.buyerCountrysData = {};
        $scope.chartHeight = chartHeight + "px";
        $scope.topItem = {};
        $scope.topEvent = {};
        $scope.data.pageView = 0;
        $scope.data.itemClick = 0;
        $scope.data.sales = 0;
        $scope.data.soldQty = 0;
        $scope.data.allEvent = false;
        $scope.overlay = true;
        //add pv flag
        $scope.pvSummaryFlag = false;
        $scope.pvChartFlag = false;
        $scope.displayDateTime = function(flag){
                  if(flag){
                       $("#datetime_select").attr("style","display:block;");
                       $("#datetime_normal").attr("style","display:none;");
                   }else{
                       $("#datetime_select").attr("style","display:none;");
                       $("#datetime_normal").attr("style","display:block;");
                   }
          }
        
        //functions define as below
        $scope.deleteEvent = function(event,index){
            var key = event.value;
            delete $scope.eventsData.eventsKey[key];
            $scope.eventsData.events.splice(index, 1);
            showChart();
        }

        $scope.deleteBuyerCountry = function(BuyerCountry,index){
            var key = BuyerCountry.value;
            delete $scope.buyerCountrysData.buyerCountrysKey[key];
            $scope.buyerCountrysData.buyerCountrys.splice(index, 1);
            showChart();
        }

        function getFromToAsLong(){
            var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
            var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
            var offset = $scope.data.timeZone;

            var strTz = "TZ00";
            if ( offset < 0 && offset > -10 ) strTz = "-0TZ00";
            if ( offset < -10  ) strTz = "-TZ00";
            if (offset >= 10 ) strTz = "TZ00";
            if ( offset > 0 && offset < 10) strTz = "0TZ00";

            strTz = strTz.replace(/TZ/, Math.abs(offset));
            var longFrom = moment(fromDateTime + " " + strTz, 'YYYY-MM-DD hh:mm Z').toDate().getTime();
            var longTo = moment(toDateTime + " " + strTz, 'YYYY-MM-DD hh:mm Z').toDate().getTime();
            return {from: longFrom, to: longTo};
        }
        //chart define
        $scope.selectChart = function(chart){
                                    if ( chart != "pie" && chart != "line" ) {
                                        alert("Only support Pie and Line for now.")
                                        return; //only supports line and pie by now.
                                    }
                                    $scope.chartType = chart;
                                    changeSelectedButtonColor(chart);
                                    showChart();
                                }

        function changeSelectedButtonColor(chart){
                     //console.log(chart);
                     if(chart=="pie"){
                         $("#pie").attr("class","btn btn-default btn-small btn-primary");
                         $("#line").attr("class","btn btn-default btn-small");
                     }else if(chart="line"){
                         $("#pie").attr("class","btn btn-default btn-small");
                         $("#line").attr("class","btn btn-default btn-small btn-primary");
                     }
                }


        function showChart(){
            var eventGroup = $scope.data.eventGroup;
            var compareBy = $scope.data.by;
            if(compareBy==0){//when user select dimension of compare by event
            	var buyerCountry = $scope.data.buyerCountry;
            	var eventRows = $scope.eventsData.events;
                var eventIds = [];
                eventIds.push(eventGroup);
                
                eventRows.forEach(function(event, idx){
                    eventIds.push(event.value);
                    event.from = formatEventTime(event.start);
                    event.to = formatEventTime(event.end);
                })

                //console.log("eventIds:"+eventIds);
                var fromTo = getFromToAsLong();

                $scope.chartDataLoaded = false;
                $scope.chartDataLoading = true;
                cptEventService.summaryOnEvents(
                    {events: eventIds, buyerCountry: buyerCountry, from: fromTo.from, to: fromTo.to},

                    function(resps){
                        var dataMap = {};
                        var groupTotalData = [];
                        resps.forEach(function(resp, idx){
                                 $scope.data.otherEventIndex = eventIds.length;
                                 if(idx==0){//get summary data by event group
                                     groupTotalData = resp.data;
                                     var pageView =0; var itemClick =0; var sales =0; var soldQty =0;
                                     for(var i=0 ; i< groupTotalData.length; i++){
                                         pageView = pageView + groupTotalData[i][1];
                                         itemClick = itemClick + groupTotalData[i][2];
                                         sales = sales + groupTotalData[i][3];
                                         soldQty = soldQty + groupTotalData[i][4];
                                     }
                                     $scope.data.pageView =pageView;
                                     $scope.data.itemClick =itemClick;
                                     $scope.data.sales =sales;
                                     $scope.data.soldQty =soldQty;
                                 }else{
                                    dataMap[eventIds[idx]] = resp.data;
                                 }
                        });
                        //console.log("---groupTotalData:", groupTotalData);
                        //console.log("---dataMap:", dataMap);
                        $scope.chartDataLoaded = true;
                        $scope.chartDataLoading = false;


                        $timeout(function(){
                            if ( $scope.chartType == 'pie' ){
                                $("#pie").attr("class","btn btn-default btn-small btn-primary");
                                showPieChart(dataMap,groupTotalData,eventRows);
                            }

                            if ( $scope.chartType == 'line' ){
                                showLineChart(dataMap,groupTotalData,eventRows);
                            }
                        }, 100);
                    },

                    function(){
                        $scope.chartDataLoading = false;
                        $log.error("Failed to call chart services.");
                    }
                )
            }else if(compareBy==1){//when user select dimension of compare by buyer country
            	
            	var buyerCountryRows = $scope.buyerCountrysData.buyerCountrys;
                var buyerCountrys = [];
                
                buyerCountryRows.forEach(function(buyerCountry, idx){
                	buyerCountrys.push(buyerCountry.value);
                })

                var fromTo = getFromToAsLong();

                $scope.chartDataLoaded = false;
                $scope.chartDataLoading = true;
                cptEventService.summaryOnBuyerCountry(
                    {eventGroup: eventGroup, buyerCountrys: buyerCountrys, from: fromTo.from, to: fromTo.to},

                    function(resps){
                        var dataMap = {};
                        var groupTotalData = [];
                        resps.forEach(function(resp, idx){
                                 $scope.data.otherEventIndex = buyerCountrys.length+1;
                                 if(idx==0){//get summary data by event group
                                     groupTotalData = resp.data;
                                     var pageView =0; var itemClick =0; var sales =0; var soldQty =0;
                                     for(var i=0 ; i< groupTotalData.length; i++){
                                         pageView = pageView + groupTotalData[i][1];
                                         itemClick = itemClick + groupTotalData[i][2];
                                         sales = sales + groupTotalData[i][3];
                                         soldQty = soldQty + groupTotalData[i][4];
                                     }
                                     $scope.data.pageView =pageView;
                                     $scope.data.itemClick =itemClick;
                                     $scope.data.sales =sales;
                                     $scope.data.soldQty =soldQty;
                                 }else{
                                     dataMap[buyerCountrys[idx-1]] = resp.data;
                                 }
                        });
                        //console.log("---groupTotalData:", groupTotalData);
                        //console.log("---dataMap:", dataMap);
                        $scope.chartDataLoaded = true;
                        $scope.chartDataLoading = false;


                        $timeout(function(){
                            if ( $scope.chartType == 'pie' ){
                                $("#pie").attr("class","btn btn-default btn-small btn-primary");
                                showPieChart(dataMap,groupTotalData,buyerCountryRows);
                            }

                            if ( $scope.chartType == 'line' ){
                                showLineChart(dataMap,groupTotalData,buyerCountryRows);
                            }
                        }, 100);
                    },

                    function(){
                        $scope.chartDataLoading = false;
                        $log.error("Failed to call chart services.");
                    }
                )
            }
            

        }
        //pie chart define
         var chartConfig = {
                    options:{
                        chart:
                        {
                            type:"pie",
                            height: chartHeight,
                            events: {
                                redraw: function(){
                                    //console.log("redraw is called.");
                                    if(!this.series[0]){
                                         return;
                                     }

                                    $.each(this.series[0].points, function(idx){
                                        this.graphic.attr({opacity:0.3});
                                    });
                                }
                            }
                        },
                        plotOptions: {
                            pie: {
                            	innerSize:130,
                                allowPointSelect: true,
                                cursor: 'pointer',
                                dataLabels: {enabled: false },
                                point: {
                                    events: {
                                        select: function(){
                                            var point = this,
                                                x = point.x;
                                            this.graphic.attr({opacity:1});
                                            setTimeout(function(){
                                                    if(!$('#chartTraffic').highcharts().series[0].data[x].selected){
                                                        $('#chartTraffic').highcharts().series[0].data[x].select(true);
                                                    }
                                                    if(!$('#chartEng1').highcharts().series[0].data[x].selected){
                                                        $('#chartEng1').highcharts().series[0].data[x].select(true);
                                                    }
                                                    if(!$('#chartGmvTraffic').highcharts().series[0].data[x].selected){
                                                        $('#chartGmvTraffic').highcharts().series[0].data[x].select(true);
                                                    }
                                                    if(!$('#chartTxn').highcharts().series[0].data[x].selected){
                                                       $('#chartTxn').highcharts().series[0].data[x].select(true);
                                                    }
                                            })

                                        },
                                        unselect: function(){
                                            this.graphic.attr({opacity:0.3});
                                        },
                                        click: function(){
                                            var point = this;
                                            if(point.selected)
                                            point.select(true);
                                        }

                                    }
                                }
                            }
                        },
                    },
                     credits:{enabled:false},
                     loading:false
         };


         function precisionData(value, precision){
                if ( precision>0 ) {
                    return parseFloat(value.toFixed(2));
                }

                return parseInt(value);
         }

         function genPieChartData(events, type, precision){
                var data = [];

                events.forEach(function(row,idx){
                    var color = colors[idx % colors.length];
                    if(type=="Page Views"){
                        data.push({color: color, name: row.name, y: precisionData(row.sumdata_traffic,precision)});
                    }else if(type=="In Page Item Click"){
                        data.push({color: color, name: row.name, y: precisionData(row.sumdata_engagement,precision)});
                    }else if(type=="In Page Sold Quantity"){
                        data.push({color: color, name: row.name, y: precisionData(row.sumdata_transaction,precision)});
                    }else if(type=="In Page Sales"){
                        data.push({color: color, name: row.name, y: precisionData(row.sumdata_gmb,precision)});
                    }

                })

                return data;
            }



        function showPieChart(dataMap, groupTotalData, eventRows){
            var sumarryEvents = [];
            //var eventRows = $scope.eventsData.events;
            eventRows.forEach(function(row){
                var key = row.value;
                $log.info("eventRows[i].value:", dataMap[key]);
                var dataArray = dataMap[key];
                $log.info("dataArray:", dataArray);
               // $log.info("dataArray:", dataMap[key].length);
                var sumdata_traffic=0; var sumdata_engagement=0; var sumdata_transaction=0;var sumdata_gmb=0;
                for(var i=0; i<dataArray.length; i++){
                    sumdata_traffic= sumdata_traffic + dataArray[i][1];
                    sumdata_engagement=sumdata_engagement + dataArray[i][2];
                    sumdata_gmb=sumdata_gmb + dataArray[i][3];
                    sumdata_transaction=sumdata_transaction + dataArray[i][4];
                }
                $log.info("sumdata_traffic:"+sumdata_traffic+"sumdata_engagement:"+sumdata_engagement+"sumdata_transaction:"+sumdata_transaction+"sumdata_gmb:"+sumdata_gmb);

                sumarryEvents.push({name:row.name, sumdata_traffic:sumdata_traffic,sumdata_engagement:sumdata_engagement,sumdata_transaction:sumdata_transaction,sumdata_gmb:sumdata_gmb});
            })
            //get others value
            if($scope.data.allEvent){
                var groupdata_traffic=0; var groupdata_engagement=0; var groupdata_transaction=0;var groupdata_gmb=0;
                //console.log("groupTotalData="+groupTotalData);
                for(var i=0 ; i< groupTotalData.length; i++){
                    groupdata_traffic= groupdata_traffic + groupTotalData[i][1];
                    groupdata_engagement=groupdata_engagement + groupTotalData[i][2];
                    groupdata_gmb=groupdata_gmb + groupTotalData[i][3];
                    groupdata_transaction=groupdata_transaction + groupTotalData[i][4];
                }
                //console.log("groupdata_traffic="+groupdata_traffic+" groupdata_engagement="+groupdata_engagement+" groupdata_gmb="+groupdata_gmb + " groupdata_transaction="+groupdata_transaction);
                for(var i=0; i<sumarryEvents.length; i++){
                    groupdata_traffic = groupdata_traffic - sumarryEvents[i].sumdata_traffic;
                    groupdata_engagement = groupdata_engagement - sumarryEvents[i].sumdata_engagement;
                    groupdata_gmb = groupdata_gmb - sumarryEvents[i].sumdata_gmb;
                    groupdata_transaction = groupdata_transaction - sumarryEvents[i].sumdata_transaction;
                }
                //if(groupdata_traffic<0){groupdata_traffic=0}//wait for check
                sumarryEvents.push({name:"Others", sumdata_traffic:groupdata_traffic,sumdata_engagement:groupdata_engagement,sumdata_transaction:groupdata_transaction,sumdata_gmb:groupdata_gmb});
            }
            //console.log("sumarryEvents=="+sumarryEvents);

            $scope.chartTrafficConfig = angular.merge({}, chartConfig);
            $scope.chartEng1Config = angular.merge({}, chartConfig);
            $scope.chartTxnConfig = angular.merge({}, chartConfig);
            $scope.chartGmvConfig = angular.merge({}, chartConfig);

            //console.log("dataMap---"+dataMap);
            pieChart($scope.chartTrafficConfig, "Page Views", 'PV', sumarryEvents,0);
            pieChart($scope.chartEng1Config, "In Page Item Click", "Clicks", sumarryEvents,0);
            pieChart($scope.chartTxnConfig, "In Page Sold Quantity", "Quantity", sumarryEvents,0);
            pieChart($scope.chartGmvConfig, "In Page Sales", "Sales", sumarryEvents, 2);

            function pieChart(config, text, name, sumarryEvents, precision){
                config.options.chart.type = "pie";
                config.title = {"text": text}
                config.series = [{name: name}];
                config.series[0].data = genPieChartData(sumarryEvents,text,precision);


            }
        }


        //line chart define
        var lineChartConfig = {
                    options:{
                        //global: {useUTC: true, timezoneOffset: 7*60},
                        chart: {type: 'spline',height: chartHeight},
                        xAxis: {
                            type: 'datetime',
                            dateTimeLabelFormats: {
                                hour: '%H:%M',
                                day: '%b %e'
                            }
                        },
                        legend: {enabled: false},
                        yAxis: {
                            title: { text: null },
                            showEmpty: false,
                            min: 0
                        },
                        tooltip: {shared: true},
                        plotOptions: {
                            spline: {
                                marker: {
                                    enabled: false
                                }
                            }

                        },
                        credits:{enabled:false},
                        loading:false
                    }
                }


        function showLineChart(dataMap,groupTotalData,eventRows){
            var msIn1Hour = 3600*1000;

            var fromTo = getFromToAsLong();
            var longFrom = fromTo.from;
            var longTo = fromTo.to;
            //$log.info("longFrom:"+longFrom+" longTo:"+longTo);

            var fromHour = (Math.floor(longFrom/msIn1Hour))*msIn1Hour;
            var toHour = (Math.ceil(longTo/msIn1Hour))*msIn1Hour;

            var timeRange = new Array();
            for(var i=0; i<=(toHour-fromHour)/msIn1Hour;i++){
                timeRange.push(fromHour +  i * msIn1Hour);
            }

            timeRange.indexof = function(value) {
            	var a = this;
            	for (var i = 0; i < a.length; i++) {
            		if (a[i] == value)
            		    return i;
                }
            }

            var newEvents = new Array();
            var tempArray = new Array();
           // var eventRows = $scope.eventsData.events;

            eventRows.forEach(function(row){
                for(var i=0;i<timeRange.length;i++){
                    tempArray[i]=new Array();
                    for(var j=0; j < 5; j++){
                        if(j==0){
                            tempArray[i][0]=timeRange[i];
                        }else{
                            tempArray[i][j]=0;
                        }
                    }
                }

                var key = row.value;
                var dataArray = dataMap[key];

                for(var i=0; i<dataArray.length; i++){
                    var index = timeRange.indexof(dataArray[i][0]);
                    tempArray[index][1]=dataArray[i][1];
                    tempArray[index][2]=dataArray[i][2];
                    tempArray[index][3]=dataArray[i][3];
                    tempArray[index][4]=dataArray[i][4];
                }

                var finalArray = new Array();
                finalArray[0] = new Array();
                finalArray[1] = new Array();
                finalArray[2] = new Array();
                finalArray[3] = new Array();
                for(var i=0; i<tempArray.length; i++){
                    finalArray[0][i] = tempArray[i][1];
                    finalArray[1][i] = tempArray[i][2];
                    finalArray[2][i] = tempArray[i][3];
                    finalArray[3][i] = tempArray[i][4];
                }
                newEvents.push({name:row.name, finalArray:finalArray});
            })
             //get others value
            if($scope.data.allEvent){
                 for(var i=0;i<timeRange.length;i++){
                    tempArray[i]=new Array();
                    for(var j=0; j < 5; j++){
                        if(j==0){
                            tempArray[i][0]=timeRange[i];
                        }else{
                            tempArray[i][j]=0;
                        }
                    }
                 }

                for(var i=0; i<groupTotalData.length; i++){
                    var index = timeRange.indexof(groupTotalData[i][0]);
                    tempArray[index][1]=groupTotalData[i][1];
                    tempArray[index][2]=groupTotalData[i][2];
                    tempArray[index][3]=groupTotalData[i][3];
                    tempArray[index][4]=groupTotalData[i][4];
                }

                var finalArray = new Array();
                finalArray[0] = new Array();
                finalArray[1] = new Array();
                finalArray[2] = new Array();
                finalArray[3] = new Array();
                for(var i=0; i<tempArray.length; i++){
                    var sum0 = 0; var sum1 = 0; var sum2 = 0; var sum3 = 0;
                    newEvents.forEach(function(row){
                        sum0 = sum0 + row.finalArray[0][i];
                        sum1 = sum1 + row.finalArray[1][i];
                        sum2 = sum2 + row.finalArray[2][i];
                        sum3 = sum3 + row.finalArray[3][i];
                    })
                    finalArray[0][i] = tempArray[i][1] -sum0;
                    finalArray[1][i] = tempArray[i][2] -sum1;
                    finalArray[2][i] = tempArray[i][3] -sum2;
                    finalArray[3][i] = tempArray[i][4] -sum3;
                    if(finalArray[0][i]<0){finalArray[0][i]=0}//wait for check
                }
                //console.log("others:"+finalArray);
                newEvents.push({name:"Others", finalArray:finalArray});
            }

            $scope.chartTrafficConfig = angular.merge({}, lineChartConfig);
            $scope.chartEng1Config = angular.merge({}, lineChartConfig);
            $scope.chartTxnConfig = angular.merge({}, lineChartConfig);
            $scope.chartGmvConfig = angular.merge({}, lineChartConfig);


            lineChart($scope.chartTrafficConfig, "Page Views", 'PV', newEvents,        fromHour);
            lineChart($scope.chartEng1Config, "In Page Item Click", "Clicks", newEvents,     fromHour);
            lineChart($scope.chartTxnConfig, "In Page Sold Quantity", "Quantity", newEvents,     fromHour);
            lineChart($scope.chartGmvConfig, "In Page Sales", "Sales", newEvents, fromHour);
        }

        function lineChart(config, type, yTitle,  newEvents, fromHour){
            config.options.chart.type = "spline";
            config.options.title = {"text": type};
            config.options.yAxis.title.text = null;
            if($scope.data.timeZone==-8){
                Highcharts.setOptions({
                        global: {
                            useUTC: true,
                            timezoneOffset: 8 * 60
                        }
                    });
            }else if($scope.data.timeZone==0){
                Highcharts.setOptions({
                        global: {
                            useUTC: true,
                            timezoneOffset: 0
                        }
                    });
            }else if($scope.data.timeZone==1){
                Highcharts.setOptions({
                        global: {
                            useUTC: true,
                            timezoneOffset: 0
                        }
                    });
            }else if($scope.data.timeZone==10){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 0
                    }
                });
            }else if($scope.data.timeZone==-5){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 5 * 60
                    }
                });
            }else if($scope.data.timeZone==5){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 0
                    }
                });
            }else if($scope.data.timeZone==-4){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 4 * 60
                    }
                });
            }
            
            var seriesData = [];
            newEvents.forEach(function(row, idx){
                //var line = {name: row.name}
                var color = colors[idx % colors.length];

                var defaultSeries = {color: color, name: row.name, pointStart: fromHour, pointInterval: 1 * 3600 * 1000};

                if(type=="Page Views"){
                    seriesData.push(angular.merge({data: row.finalArray[0]}, defaultSeries));
                }else if(type=="In Page Item Click"){
                    seriesData.push(angular.merge({data: row.finalArray[1]}, defaultSeries));
                }else if(type=="In Page Sold Quantity"){
                    seriesData.push(angular.merge({data: row.finalArray[3]}, defaultSeries));
                }else if(type=="In Page Sales"){
                    seriesData.push(angular.merge({data: row.finalArray[2]}, defaultSeries));
                }
            })
            config.series = seriesData;
        }



        //open selection window function define
        $scope.openSelectionWindow = function(){
        	if($scope.data.by==0){//event select function define
        		var modalInstance = $modal.open({
                    animation: true,
                    templateUrl: 'eventSelection.html',
                    controller: 'EventSelectionCtrl',
                    size: 'lg',
                    resolve: {
                        data: function () {
                            //console.log("events: "+$scope.eventsData.eventsKey);
                            return {events: $scope.eventsData.eventsKey, fromTo: getFromToAsLong(),  eventGroupId: $scope.data.eventGroup};
                        }
                    }
                });

                modalInstance.result.then(function (eventsData) {
                      $scope.eventsData = angular.merge({}, eventsData);
                      showChart();

                      $log.info('$scope.eventsData', $scope.eventsData);
                }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });
        	}else if($scope.data.by==1){ //buyer country select function define
        		var modalInstance = $modal.open({
                    animation: true,
                    templateUrl: 'buyerCountrySelection.html',
                    controller: 'BuyerCountrySelectionCtrl',
                    size: 'lg',
                    resolve: {
                        data: function () {
                            //console.log("buyer country: "+$scope.buyerCountrysData.buyerCountrysKey);
                            return {buyerCountrys: $scope.buyerCountrysData.buyerCountrysKey};
                        }
                    }
                });

                modalInstance.result.then(function (buyerCountrysData) {
                      $scope.buyerCountrysData = angular.merge({}, buyerCountrysData);
                      showChart();

                      $log.info('$scope.eventsData', $scope.buyerCountrysData);
                }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });
        	}
            
        }

        
        //event detail function define
        $scope.getEventDetail = function(event){
        	
        	$log.info("eventId:"+event.value);
            var modalInstance = $modal.open({
                animation: true,
                templateUrl: 'eventDetail.html',
                controller: 'EventDetailCtrl',
                size: 'lg',
                resolve: {
                    data: function () {
                        return {eventId: event.value, eventName: event.name, fromTo: getFromToAsLong(), buyerCountry: $scope.data.buyerCountry};
                    }
                }
            });
        }
        
        $scope.timeZones = [
                            {value: -8, display: "PDT"},
                            {value: 0, display: "GMT"},
                            {value: 1, display: "CET"},
                            {value: 10, display: "EAST"},
                            {value: -5, display: "EST"},
                            {value: 5, display: "IST"},
                            {value: -4, display: "AST"}                            
                           ];


        $scope.sites = [
            {value: 0, display: "US"},
            {value: 3, display: "UK"},
            {value: 77, display: "DE"},
            {value: 15, display: "AU"},
            {value: 2, display: "CA"},
            {value: 203, display: "IN"},
            {value: 101, display: "IT"},
            {value: 210, display: "CA(fr)"},
            {value: 186, display: "ES"},
            {value: 71, display: "FR"}
        ];

        $scope.bys = [
                    {value: 0, display: "Event"},
                    {value: 1, display: "Buyer Country"}
                  /*  {value: 2, display: "source"},
                    {value: 3, display: "category"}*/
                ];
        
        cptEventService.queryBuyerCountrys("All",
                function(data){
                    //console.log("success", data);
                    $scope.buyerCountrys = data;
                }
            );
        
        $scope.devices = [
                      {value: 0, display: "All"}
                  ];
        
        $scope.experiences = [
                      {value: 0, display: "Core Sites"}
                  ];

        function changeTime(new_offset,old_offset){
	       	 if(typeof(old_offset)== "undefined"){
	       		 var d = new Date();
	                var localTime = d.getTime();
	                var localOffset = d.getTimezoneOffset() * 60000;
	                var utc = localTime + localOffset;
	
	                var calctime = utc + (3600000*new_offset);
	                var now = moment(calctime);
	                var yesterday = now.clone().add(-90,'d');//间隔为1天
	                $scope.data.fromDate = yesterday.format('YYYY-MM-DD');
	                //$scope.data.fromTime = yesterday.format('HH:mm');
	                $scope.data.fromTime = yesterday.format('HH')+":00";
	                $scope.data.toDate = now.format('YYYY-MM-DD');
	                //$scope.data.toTime = now.format('HH:mm');
	                $scope.data.toTime = now.format('HH')+":00";
	                
	                if($scope.data.fromDate < "2015-10-05"){
	                	$scope.data.fromDate = "2015-10-05";
	                }
	                
	                var start = $scope.data.fromDate;
	                var end = $scope.data.toDate;
	                $("#fromDate").datetimepicker('setStartDate', start);
	                $("#fromDate").datetimepicker('setEndDate', end);
	                //$("#fromTime").datetimepicker('setStartDate', start);
	
	                $("#toDate").datetimepicker('setStartDate', start);
	                $("#toDate").datetimepicker('setEndDate', end);
	              //$("#toTime").datetimepicker('setEndDate', end);
	       	 }else{
	       		//get old time
	                var d = new Date();
	                var localOffset = d.getTimezoneOffset() * 60000;
	                
	                var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
	                var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
	                var longFrom = new Date(fromDateTime.replace("-","/").replace("-","/")).getTime() - (3600000*(old_offset));
	                var longTo = new Date(toDateTime.replace("-","/").replace("-","/")).getTime() - (3600000*(old_offset));
	                
	               //set new time
	               var from = moment(longFrom + (3600000*(new_offset)));
	               var to = moment(longTo + (3600000*(new_offset)));
	              
	               $scope.data.toDate = to.format('YYYY-MM-DD');
	               //$scope.data.toTime = to.format('HH:mm');
	               $scope.data.toTime = to.format('HH')+":00";
	               
	               $scope.data.fromDate = from.format('YYYY-MM-DD');
	               //$scope.data.fromTime = from.format('HH:mm');
	               $scope.data.fromTime = from.format('HH')+":00";
	       	 }
          
       }

        function formatEventTime(utcTime){
            var offset = $scope.data.timeZone;
            var d = new Date();
            var localOffset = d.getTimezoneOffset() * 60000;

            var calctime = parseInt(utcTime) + parseInt(3600000*offset) + parseInt(localOffset);
            var dateTime = moment(calctime);
            return dateTime.format('YYYY-MM-DD HH:mm:ss');
        }

        function checkTimeZone(countryCode){
                    if(countryCode==0){
                        $scope.data.timeZone = -8;
                    }else if(countryCode==3){
                        $scope.data.timeZone = 0;
                    }else if(countryCode==77){
                        $scope.data.timeZone = 1;
                    }else if(countryCode==15){
                        $scope.data.timeZone = 10;
                    }else if(countryCode==2){
                        $scope.data.timeZone = -5;
                    }else if(countryCode==203){
                        $scope.data.timeZone = 5;
                    }else if(countryCode==101){
                        $scope.data.timeZone = 1;
                    }else if(countryCode==210){
                        $scope.data.timeZone = -4;
                    }else if(countryCode==186){
                        $scope.data.timeZone = 1;
                    }else if(countryCode==71){
                        $scope.data.timeZone = 1;
                    }
                }
        
        function isEmptyObject(obj) {
            for (var key in obj) {
              return false;
            }
            return true;
          }
        
        //site changes triggers event group reloading.
        $scope.eventGroupLoading = false;
        $scope.$watch("data.site", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
            //console.log("site value changes from", oldValue, 'to', newValue);
            checkTimeZone(newValue);
            $scope.eventGroupLoading = true;
            cptEventService.queryEventGroups(
                newValue,
                function(data){
                    //console.log("success", data);
                    $scope.eventGroups = data;
                    if ( $scope.eventGroups.length > 0 )
                    	if($scope.data.site==0){
                    		$scope.data.eventGroup = "54243245e4b0d359ae4cd084";//set default as "holidays"
                    	}else{
                    		$scope.data.eventGroup = $scope.eventGroups[0].value;
                    	}
                    $scope.eventGroupLoading = false;
                },
                function(){
                    //console.log("failed");
                    $scope.eventGroupLoading = false;
                }
            );
        });

        //event-group changes triggers event reload.
        $scope.eventLoading = false;
        $scope.$watch("data.eventGroup", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
            $scope.eventsData = {};
            $scope.buyerCountrysData = {};
            $scope.topItem = {};
            $scope.topEvent = {};
            $scope.data.pageView = 0;
            $scope.data.itemClick = 0;
            $scope.data.sales = 0;
            $scope.data.soldQty = 0;
            $scope.chartDataLoaded = false;
            $scope.overlay = true;
            $(".page-overlay span").css('display',"block");
            $(".page-overlay img").css('display',"none");
        });

       $scope.$watch("data.timeZone", function(newValue, oldValue){
                  if ( newValue == oldValue ) return;
                  changeTime(newValue,oldValue);
              });

       $scope.$watch("data.by", function(newValue, oldValue){
           if ( newValue == oldValue ) return;
           if(newValue==0){
        	   if($scope.data.site==0 || $scope.data.site==3 || $scope.data.site==77){
               		$scope.pvSummaryFlag = true;
               		$scope.pvChartFlag = true;
       			}else{
       				$scope.pvSummaryFlag = false;
                    $scope.pvChartFlag = false;
       			}
        	   $scope.compareBy = "Events";
           }else if(newValue==1){
        	   if($scope.data.site==0 || $scope.data.site==3 || $scope.data.site==77){
              		$scope.pvSummaryFlag = true;
              		$scope.pvChartFlag = true;
      			}else{
      				$scope.pvSummaryFlag = false;
                    $scope.pvChartFlag = true;
      			}
               
        	   $scope.compareBy = "Countries";
        	   if($scope.data.buyerCountry !="0"){//when buyer country is not "All"
        		   $scope.data.buyerCountry="0";
        		   if($("#banner-gridholder ul li.active").eq(0).find("a").attr("href")=="#topEvents"){
        			   $scope.getTopEventsList();
        		   }else if($("#banner-gridholder ul li.active").eq(0).find("a").attr("href")=="#topItems"){
        			   $scope.getTopItemsList();
        		   }
        	   }
        	   
        	   if(typeof($scope.buyerCountrysData.buyerCountrys) == "undefined"){
        		   $scope.buyerCountrysData.buyerCountrys = [{value:1,code:"US",name:"United States"},
                   	                                         {value:3,code:"UK",name:"United Kingdom"},
                   	                                         {value:77,code:"DE",name:"Germany"},
                   	                                         {value:15,code:"AU",name:"Australia"},
                   	                                         {value:2,code:"CA",name:"Canada"}];
        		   $scope.buyerCountrysData.buyerCountrysKey = {"1":true, "3":true, "77":true, "15":true, "2":true};
        	   }
        	   
           }
           if(typeof(oldValue) != "undefined"){
        	   showChart();
           }
       });
       
      $scope.$watch("data.allEvent", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
            showChart();
        });

        $timeout(function(){
            $scope.data.site = 0;
            $scope.data.timeZone = -8;
            $scope.data.by = 0;
            $scope.data.buyerCountry = "0";
            $scope.data.device = 0;
            $scope.data.experience = 0;
        },100);


        $scope.topItemDtOptions = DTOptionsBuilder.newOptions()
                            .withOption("lengthMenu", [ [5, 10, 25, 50, -1], [5,10, 25, 50, "All"] ])
        					.withOption("order", [[ 2, "desc" ]]);
        
        $scope.topEventDtOptions = DTOptionsBuilder.newOptions()
					        .withOption("lengthMenu", [ [5, 10, 25, 50, -1], [5,10, 25, 50, "All"] ])
							.withOption("order", [[ 1, "desc" ]]);
        
        $scope.applyClick = function(){
            var timeZone=$("#timeZone").find("option:selected").text();
            if($scope.data.fromDate =="" ||$scope.data.fromTime =="" ||$scope.data.toDate ==""|| $scope.data.toTime ==""){
                alert("Please select time range !");
                return;
            }

            var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
            var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;

            if ( fromDateTime >= toDateTime ){
                alert("Wrong from/to time range !");
                return;
            }
            $scope.data.time2time = "From "+ fromDateTime+ " to " + toDateTime + " " + timeZone;
            $("#datetime_select").css("display","none");
            $("#datetime_normal").css("display","block");

            var fromTo = getFromToAsLong();
            $scope.itemDetailLoading = true;
            $scope.loading = true;
            $scope.chartDataLoading = true;
            $(".page-overlay").eq(0).css('display',"block");
            $(".page-overlay span").css('display',"none");
            $(".page-overlay img").css('display',"block")
            //set sticky filter values
            $scope.data.siteText = $("#site").find("option:selected").text();
            $scope.data.eventGroupText = $("#eventGroup").find("option:selected").text();
            $scope.data.deviceText = $("#device").find("option:selected").text();
            $scope.data.experienceText = $("#experience").find("option:selected").text();
            $scope.data.buyerCountryText = $("#buyerCountry").find("option:selected").text();
            $scope.overlay = true;
            //set pv value to "N/A"
            if($scope.data.site==0 || $scope.data.site==3 || $scope.data.site==77){
            	$scope.pvSummaryFlag = true;
                $scope.pvChartFlag = true;
    		}else{
    			if($scope.data.buyerCountry==0){
                	$scope.pvSummaryFlag = false;
                	if($scope.data.by==1){
                		$scope.pvChartFlag = true;
                	}else{
                		
                		$scope.pvChartFlag = false;
                	}
                    
                }else{
                	if($scope.data.by==0){
                		$scope.pvSummaryFlag = true;
                        $scope.pvChartFlag = true;
                	}
                }
    		}
            
            //get events
            $scope.topEvent.data = [];
            cptEventService.eventDetailOnEventGroup(
                            {from: fromTo.from, to: fromTo.to, eventGroupId: $scope.data.eventGroup, buyerCountry: $scope.data.buyerCountry},
                            function(resp){
                                //console.log("resp"+resp);
                                if(isEmptyObject($scope.eventsData)){
                                    var top5Event = [];
                                    var top5EventKey = "";

                                    for(var i=0; i<resp.length; i++){
                                            if(i<5){
                                                top5Event.push({display: resp[i].display, value: resp[i].value, name: resp[i].name, start: resp[i].start, end: resp[i].end});
                                                top5EventKey = top5EventKey +",\""+ resp[i].value+"\": true"
                                            }
                                    }

                                    $scope.eventsData.events = top5Event;
                                    $scope.eventsData.eventsKey = JSON.parse('{'+top5EventKey.substring(1)+'}');
                                    //console.log("$scope.eventsData.eventsKey"+$scope.eventsData.eventsKey);
                                }
                                showChart();
                                $scope.topEvent.data = resp;
                                $scope.loading = false;
                                $scope.itemDetailLoading = false;
                                $scope.overlay = false;
                            },
                            function(){
                                $scope.loading = false;
                                $scope.itemDetailLoading = false;
                                $scope.overlay = false;
                            }
                        )
        }

        $scope.getTopItemsList = function(){

                    var fromTo = getFromToAsLong();
                    $scope.topItem.data = [];
                    $scope.itemDetailLoading = true;
                    //get items
                    cptEventService.itemDetailOnEventGroup(
                                     {from: fromTo.from, to: fromTo.to, eventGroupId: $scope.data.eventGroup, buyerCountry: $scope.data.buyerCountry},
                                     function(resp){
                                         $scope.topItem.data = resp.data;
                                         $scope.itemDetailLoading = false;
                                     },
                                     function(){
                                         $scope.itemDetailLoading = false;
                                     }
                                 )
                };

         $scope.getTopEventsList = function(){

                            var fromTo = getFromToAsLong();
                            $scope.topItem.data = [];
                            $scope.itemDetailLoading = true;
                           //get events
                           $scope.topEvent = {};
                           cptEventService.eventDetailOnEventGroup(
                                            {from: fromTo.from, to: fromTo.to, eventGroupId: $scope.data.eventGroup, buyerCountry: $scope.data.buyerCountry},
                                            function(resp){
                                                //console.log("resp"+resp);
                                                $scope.topEvent.data = resp;
                                                $scope.itemDetailLoading = false;
                                            },
                                            function(){
                                                $scope.itemDetailLoading = false;
                                            }
                                        )
                }


         $scope.downloadEvents = function(){
        	 
        	 	var eventGroup=$("#eventGroup").find("option:selected").text();
                var dataList = $scope.topEvent.data;
                var str = "Event Name,Page Views,In Page Item Click,In Page Sales,In Page Sold Quantity"+ "\n";
                for(var i=0;i<dataList.length;i++)
                {
                    var row = dataList[i];
                    str = str + "\""+(row.name).replace("\"","\'\'")+"\""+ ","  +row.sumdata_traffic+ "," +row.sumdata_engagement+ "," + row.sumdata_gmb+ "," + row.sumdata_transaction + "\n";
                }
                var csvname = "Top Events of Group("+eventGroup+").csv";
                var blob = new Blob([str], {type: "text/csv;charset=utf-8"});
                saveAs(blob, csvname);
         }

         $scope.downloadItems = function(){
        	 	var eventGroup=$("#eventGroup").find("option:selected").text();
        	 	var dataList = $scope.topItem.data;
        	 	var str = "Item ID,Total Item Click,In Page Item Click,Total Sales,In Page Sales,Total Sold Quantity,In Page Sold Quantity"+ "\n";
        	 	for(var i=0;i<dataList.length;i++)
        	 	{
        	 		var row = dataList[i];
        	 		str = str + row.id+ "," +row.totalClick+ "," +row.dealsClick+ "," +row.totalGMV+ "," + row.dealsGMV+ "," + row.totalQty + "," + row.dealsQty + "\n";
        	 	}
        	 	var csvname = "Top Items of Group("+eventGroup+").csv";
        	 	var blob = new Blob([str], {type: "text/csv;charset=utf-8"});
        	 	saveAs(blob, csvname);
      }
    }]);


})(angular, window);
