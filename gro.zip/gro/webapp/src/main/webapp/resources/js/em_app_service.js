(function(angular){
'use strict';

var cptService = angular.module('cptServices', []);

cptService.factory('cptEventService', ['$http','$q', function($http, $q){
    var service = {};
    var drillBaseURL = window.eBayGRO.config.DRILL_BASE_URL;
    var realTimeBaseURL = window.eBayGRO.config.REAL_TIME_BASE_URL;
    var dealsSummaryURL = window.eBayGRO.config.RT_DEALS_SUMMARY_URL;
    var dealsTopItemURL = window.eBayGRO.config.RT_DEALS_TOP_ITEM_URL;
    function queryEventGroups(siteid, success, fail){
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                //query : "select url_txt as url, rpp_event_grp_id as grpid from dfs.tdhdp.`rpp_event_group` where site_id = SITEID".replace(/SITEID/g,siteid)
                query: "select a.url_txt as url, a.rpp_event_grp_id as grpid from dfs.tdhdp.`rpp_event_group` as a, dfs.tdhdp.`rpp_event` as b where a.site_id = SITEID and b.active_ind = 1 and a.rpp_event_grp_id = b.rpp_event_grp_id group by a.url_txt, a.rpp_event_grp_id".replace(/SITEID/g, siteid)

            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            if ( !resp.data.rows ){
                success([]);
                return;
            }

            var res = [];
            resp.data.rows.forEach(function(row, idx){
                res.push({display: row.url, value: row.grpid});
            })
            success(res);

        }, fail);
    }



    function queryEvents(eventGroupId, success, fail){
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                query : "select rpp_event_id as event_id, event_name as name, start_ts, end_ts from dfs.tdhdp.`rpp_event` where rpp_event_grp_id = 'EVENT_GRP_ID' and active_ind = 1 and url_txt is not null order by event_name".replace(/EVENT_GRP_ID/g,eventGroupId)
            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            if ( !resp.data.rows ){
                success([]);
                return;
            }

            var res = [];
            resp.data.rows.forEach(function(row, idx){
                res.push({display: row.name, value: row.event_id, start: row.start_ts, end: row.end_ts});
            })
            success(res);

        }, fail);
    }
    
    function queryEvent(eventId, success, fail){
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                query : "select url_txt as url, rpp_event_id as event_id, event_name, start_ts, end_ts, rpp_event_grp_id as event_group_id from dfs.tdhdp.`rpp_event` where rpp_event_id = 'RPP_EVENT_ID'".replace(/RPP_EVENT_ID/g,eventId)
            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            success(resp);
        }, fail);
    }

    function queryEventCountryByURL(eventURL, success, fail){
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                query : "select site_id from dfs.tdhdp.`rpp_event` where url_txt='RPP_EVENT_URL'".replace(/RPP_EVENT_URL/g,eventURL)
            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            success(resp);
        }, fail);
    }
    
    function itemDetailOnEvent(queryOptions, success, fail){
        var req = {
            url: realTimeBaseURL + "/itemDetail/" + queryOptions.eventId + "?from=" + queryOptions.from + "&to=" + queryOptions.to
        };

        return $http.get(req.url).then(function(resp){
            success(resp);
        }, fail);
    }

    function summaryOnEvents(queryOptions, success, fail){
             var events = queryOptions.events;
             var from = queryOptions.from;
             var to = queryOptions.to;

             var https = [];
             events.forEach(function(event, idx){
                 https.push($http.get(realTimeBaseURL + "/summary/" + event + "?from=" + from + "&to=" + to));
             });
             $q.all(https).then(success, fail);
         }

    
   /* function summaryOnDeals(queryOptions, success, fail){
        var pageId = queryOptions.pageId;
        var modules = queryOptions.modules;
        var from = queryOptions.from;
        var to = queryOptions.to;
        
        var https = [];
        modules.forEach(function(module){//todo
            https.push($http.get(dealsSummaryURL +"p" + pageId +"_"+ module + "?from=" + from + "&to=" + to));
        });
        $q.all(https).then(success, fail);
    }*/
    
    function summaryOnDeals(queryOptions, success, fail){
        var pageId = queryOptions.pageId;
        var modules = queryOptions.modules;
        var siteId = queryOptions.siteId;
        var from = queryOptions.from;
        var to = queryOptions.to;
        
        return $http.get(dealsSummaryURL +siteId+"/p" + pageId + "?from=" + from + "&to=" + to).then(function(resp){
            success(resp);
        }, fail);
    }
    
    
    function itemDetailOnDeals(queryOptions, success, fail){
    	var pageId = queryOptions.pageId;
    	var str_module = queryOptions.modules.join(',');
    	var siteId = queryOptions.siteId;
    	var from = queryOptions.from;
        var to = queryOptions.to;
        var req = {
            url: dealsTopItemURL +siteId+"?module="+str_module+ "&from=" + from + "&to=" + to
        };

        return $http.get(req.url).then(function(resp){
            success(resp);
        }, fail);
    }
    
    service.summaryOnEvents = summaryOnEvents;
    service.itemDetailOnEvent = itemDetailOnEvent;
    service.queryEventGroups = queryEventGroups;
    service.queryEvents = queryEvents;
    service.queryEvent = queryEvent;
    service.summaryOnDeals = summaryOnDeals;
    service.itemDetailOnDeals = itemDetailOnDeals;
    service.queryEventCountryByURL = queryEventCountryByURL;
    

    return service;
}]);
})(angular);