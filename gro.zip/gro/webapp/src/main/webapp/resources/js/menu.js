(function($, global){
	'use strict';
	
	var profileTemplate = 
		'<div class="gro-leftnav-profile">' + 
			'<div class="gro-leftnav-profile-img" id="profile-img" style="background-image: url(//nous.corp.ebay.com/ldappic/UID.jpg);">' + 
				'<a id="fake_a"></a>' + 
			'</div>' +
			'<div class="gro-leftnav-profile-info">' + 
				'<div id="profile-fullname" title="NAME">NAME</div>' + 
				'<div><a id="gro-leftnav-signout" href="javascript:void()">Sign out</a></div>' + 
			'</div>' + 
		'</div>';
	
	var currentScript = $('script').last();
	var currentScriptSrc = currentScript[0].src;
	
	//var substr = currentScriptSrc.replace("/resources/js/menu.js","");
	var startIdx = currentScriptSrc.indexOf("/resources/js/menu.js");
	var substr = currentScriptSrc.substring(0, startIdx);

	var menuJson = substr + "/dr/menu.json";
	var baseUrl = substr;
	var documentReady = false, jsonReady = false;
	var vData = null;
	
	function init(){
		if ( !global.eBayGRO || !global.eBayGRO.util ){
			alert("Please include " + baseUrl + "/resources/js/common/util.js before menu.js");
			return;
		}
		
		var util = global.eBayGRO.util;
		
		$.getJSON(menuJson, {base: baseUrl}, function(data){
			jsonReady = true;
			vData = data;
			render_menu(vData);
		}).fail(function(jqXHR, textStatus, errorThrown){
			alert("Failed to get menu information from: " + menuJson);
			util.console.error(jqXHR, textStatus, errorThrown);
		});
		
		function render_config(confData){
			var hashParams = util.getHashParams();
			var menuId = hashParams['_mid'];
			if ( menuId ){
				var conf = confData[menuId];
				if ( !conf ) return;
				if ( conf.title){
					document.title = conf.title;
				}
				
				var breadcrumb = conf.breadcrumb || conf.title || menuId;
				renderBreadCrumb(breadcrumb);
				
				renderShortCut(conf)
			}
		}
		
		function renderShortCut(conf){
			var href = conf.wiki || "";
			var contacts = conf.dl || "";
			var title = conf.title || "";

			global.ihubConfig = {
					rightbar: {
						enable: true,
						wiki: {
		                    class: "icon icon-wiki",
		                    href:href,
		                    enabled: true,
		                    target: "_blank"
		                },
		                contacts: {
		                    class: "icon icon-contact",
		                    href:"mailto:" + contacts + "?subject=Feedback for GRO " + conf.title,
		                    enabled: true
		                },
		                share: {
		                	enabled: false
		                },
		                usage:{
		                	enabled:true,
		                	selector: '[data-ihub-usage-trigger]'
		                }
				    }
			};
		}
		
		function renderBreadCrumb(text){
			var strBreadCrumb = "<div class='gro-breadcrumb'><div class='gro-breadcrumb-text'>HTML</div></div>";
			var $body = $("body");
	    	if ( $body ){
	    		var paddingTop = $body.css("padding-top");
	    		if ( paddingTop && paddingTop < "46px" ){
	    			$body.css("padding-top", "46px");
	    		}
	    		$body.append($(strBreadCrumb.replace(/HTML/g, text)));
	    	}
		}
		
		function render_menu(data){
			if ( !jsonReady || !documentReady ) return;
			render_config(data.id_config);
			var menus = data.menu;
			var hashParams = util.getHashParams();
			var menuId = hashParams['_mid'];
			if ( hashParams['_m']  ){
		    	dssui.leftnav.init(menus, menuId);
		    	
		    	var userInfo = util.getUserInfo();
		    	
		    	var profileHtml = profileTemplate.replace(/UID/g, userInfo.uid).replace(/NAME/g, userInfo.name);
		    	
		    	dssui.leftnav.profile_content(profileHtml);
		    	$("#gro-leftnav-signout").click(function(){
		    		window.location.href = substr + "/auth/logout";
		    	});
		    	
		    	var $body = $("body");
		    	if ( $body ){
		    		var paddingLeft = $body.css("padding-left");
		    		if ( paddingLeft && paddingLeft < "54px" ){
		    			$body.css("padding-left", "54px");
		    		}
		    	}else{
		    		util.console.warn("$('body') is not found.");
		    	}
			}
		}
		
		$(document).ready(function(){
			documentReady = true;
			render_menu(vData);
		});
	} //init
	
	init();
	
})(jQuery, window);