(function(angular){
'use strict';

var cptService = angular.module('cptServices', []);

cptService.factory('cptEventService', ['$http','$q', function($http, $q){
    var service = {};
    var drillBaseURL = window.eBayGRO.config.DRILL_BASE_URL;
    var realTimeBaseURL = window.eBayGRO.config.REAL_TIME_BASE_URL;
    function queryEventGroups(siteid, success, fail){
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                //query : "select url_txt as url, rpp_event_grp_id as grpid from dfs.tdhdp.`rpp_event_group` where site_id = SITEID".replace(/SITEID/g,siteid)
                query: "select a.url_txt as url, a.rpp_event_grp_id as grpid from dfs.tdhdp.`rpp_event_group` as a, dfs.tdhdp.`rpp_event` as b where a.site_id = SITEID and b.active_ind = 1 and a.rpp_event_grp_id = b.rpp_event_grp_id group by a.url_txt, a.rpp_event_grp_id".replace(/SITEID/g, siteid)

            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            if ( !resp.data.rows ){
                success([]);
                return;
            }

            var res = [];
            resp.data.rows.forEach(function(row, idx){
                res.push({display: row.url, value: row.grpid});
            })
            success(res);

        }, fail);
    }



    function queryEvents(eventGroupId, fromTo, success, fail){
        //console.log("fromTo"+fromTo);
        var from = fromTo.from;
        var to = fromTo.to;
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                query : "select rpp_event_id as event_id, url_txt as url, event_name as name, start_ts, end_ts from dfs.tdhdp.`rpp_event` where rpp_event_grp_id = 'EVENT_GRP_ID' and (start_ts < query_to and end_ts > query_from) and url_txt is not null  order by start_ts desc".replace(/EVENT_GRP_ID/g,eventGroupId).replace(/query_to/g,to).replace(/query_from/g,from)
            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            if ( !resp.data.rows ){
                success([]);
                return;
            }

            var res = [];
            resp.data.rows.forEach(function(row, idx){
            	res.push({display: row.url, value: row.event_id, name: row.name, start: row.start_ts, end: row.end_ts});
            })
            success(res);

        }, fail);
    }


    function itemDetailOnEventGroup(queryOptions, success, fail){
    	 var buyerCountry = queryOptions.buyerCountry;
        var req = {};
        if(buyerCountry==0){
        	req = {
                    url: realTimeBaseURL + "/itemDetail/" + queryOptions.eventGroupId + "?from=" + queryOptions.from + "&to=" + queryOptions.to
            };
        }else{
        	req = {
                    url: realTimeBaseURL + "/itemDetail/" + queryOptions.eventGroupId + "_"+ buyerCountry + "?from=" + queryOptions.from + "&to=" + queryOptions.to
            };
        }
        

        return $http.get(req.url).then(function(resp){
            success(resp);
        }, fail);
    }
    
    function itemDetailOnEvent(queryOptions, success, fail){
    	var buyerCountry = queryOptions.buyerCountry;
    	var req = {};
    	if(buyerCountry==0){
    		req = {
    	            url: realTimeBaseURL + "/itemDetail/" + queryOptions.eventId + "?from=" + queryOptions.from + "&to=" + queryOptions.to
    	        };
    	}else{
    		req = {
    	            url: realTimeBaseURL + "/itemDetail/" + queryOptions.eventId + "_"+ buyerCountry + "?from=" + queryOptions.from + "&to=" + queryOptions.to
    	        };
    	}
        

        return $http.get(req.url).then(function(resp){
            success(resp);
        }, fail);
    }

    function eventDetailOnEventGroup(queryOptions, success, fail){
            var eventGroupId = queryOptions.eventGroupId;
            var from = queryOptions.from;
            var to = queryOptions.to;
            var buyerCountry = queryOptions.buyerCountry;
            var req = {
                url: drillBaseURL,
                headers: {
                    'Content-Type': "application/json; charset=utf-8"
                },
                data: JSON.stringify({
                    queryType : "SQL",
                    query : "select rpp_event_id as event_id, url_txt as url, event_name as name, start_ts, end_ts from dfs.tdhdp.`rpp_event` where rpp_event_grp_id = 'EVENT_GRP_ID' and (start_ts < query_to and end_ts > query_from) and url_txt is not null  order by start_ts desc".replace(/EVENT_GRP_ID/g,eventGroupId).replace(/query_to/g,to).replace(/query_from/g,from)
                })
            };

            $http.post(req.url, req.data, req).then(function(resp){
                     if ( !resp.data.rows ){
                            success([]);
                            return;
                        }
                     var https = [];
                     var tempArray = [];
                     resp.data.rows.forEach(function(row, idx){
                    	 		 tempArray.push({display: row.url, value: row.event_id, name: row.name, start: row.start_ts, end: row.end_ts});
                    	 		 if(buyerCountry==0){
                    	 			https.push($http.get(realTimeBaseURL + "/summary/" + row.event_id + "?from=" + from + "&to=" + to));
                    	 		 }else{
                    	 			https.push($http.get(realTimeBaseURL + "/summary/" + row.event_id+ "_"+ buyerCountry + "?from=" + from + "&to=" + to));
                    	 		 }
                                 

                      })
                     $q.all(https).then(function(res){
                           //console.log("res="+res);
                           for(var i=0; i<res.length;i++){
                                var event_data = res[i].data;
                                if(event_data.length==0){
                                    tempArray[i].sumdata_traffic=0;
                                    tempArray[i].sumdata_engagement=0;
                                    tempArray[i].sumdata_transaction=0;
                                    tempArray[i].sumdata_gmb=0;
                                }else{
                                    var sumdata_traffic=0; var sumdata_engagement=0; var sumdata_transaction=0;var sumdata_gmb=0;
                                    for(var j=0; j<event_data.length; j++){
                                        sumdata_traffic= sumdata_traffic + event_data[j][1];
                                        sumdata_engagement=sumdata_engagement + event_data[j][2];
                                        sumdata_gmb=sumdata_gmb + event_data[j][3];
                                        sumdata_transaction=sumdata_transaction + event_data[j][4];
                                    }
                                    tempArray[i].sumdata_traffic=sumdata_traffic;
                                    tempArray[i].sumdata_engagement=sumdata_engagement;
                                    tempArray[i].sumdata_transaction=sumdata_transaction;
                                    tempArray[i].sumdata_gmb=sumdata_gmb;
                                }
                           }
                           success(tempArray);
                     }, fail);

            }, fail);

    }



    function summaryOnEvents(queryOptions, success, fail){
             var events = queryOptions.events;
             var from = queryOptions.from;
             var to = queryOptions.to;
             var buyerCountry = queryOptions.buyerCountry;
             var https = [];
        	 events.forEach(function(event, idx){
            	 if(buyerCountry==0){
            		 https.push($http.get(realTimeBaseURL + "/summary/" + event + "?from=" + from + "&to=" + to));
            	 }else{
            		 https.push($http.get(realTimeBaseURL + "/summary/" + event + "_"+ buyerCountry + "?from=" + from + "&to=" + to));
            	 }
             });
            
             $q.all(https).then(success, fail);
     }
    
    function summaryOnBuyerCountry(queryOptions, success, fail){
        var from = queryOptions.from;
        var to = queryOptions.to;
        var buyerCountrys = queryOptions.buyerCountrys;
        var eventGroup = queryOptions.eventGroup;
        var https = [];
        https.push($http.get(realTimeBaseURL + "/summary/" + eventGroup + "?from=" + from + "&to=" + to));
        buyerCountrys.forEach(function(buyerCountry, idx){
	       	https.push($http.get(realTimeBaseURL + "/summary/" + eventGroup + "_"+ buyerCountry + "?from=" + from + "&to=" + to));
        });
       
       
        $q.all(https).then(success, fail);
    }
    
    
    function queryBuyerCountrys(type,success, fail){
        
        var req = {
            url: drillBaseURL,
            headers: {
                'Content-Type': "application/json; charset=utf-8"
            },
            data: JSON.stringify({
                queryType : "SQL",
                query : "select distinct cntry_id, Upper(iso_cntry_code) as cntry_code, cntry_desc from dfs.tdhdp.dw_countries  where cntry_code <> 'NA' order by cntry_code"
            })
        };

        return $http.post(req.url, req.data, req).then(function(resp){
            if ( !resp.data.rows ){
                success([]);
                return;
            }

            var res=[];
            if(type=="All"){
            	res.push({name: "All", value: "0"});
            }
            resp.data.rows.forEach(function(row, idx){
            	if(row.cntry_code=="GB"){
            		res.push({name: row.cntry_desc, value: row.cntry_id, code: "UK"});
            	}else{
            		res.push({name: row.cntry_desc, value: row.cntry_id, code: row.cntry_code});
            	}
            })
            success(res);

        }, fail);
    }


    service.summaryOnEvents = summaryOnEvents;
    service.itemDetailOnEventGroup = itemDetailOnEventGroup;
    service.queryEventGroups = queryEventGroups;
    service.queryEvents = queryEvents;
    service.eventDetailOnEventGroup = eventDetailOnEventGroup;
    service.itemDetailOnEvent = itemDetailOnEvent;
    service.queryBuyerCountrys = queryBuyerCountrys;
    service.summaryOnBuyerCountry = summaryOnBuyerCountry;

    return service;
}]);
})(angular);