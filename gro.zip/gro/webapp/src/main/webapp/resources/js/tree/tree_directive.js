!function(angular) {
	'use strict';
angular.module("tree-directive",[])

.directive('treeView',[ function() {
	return {
		restrict : 'E',
		templateUrl : 'treeView.html',
		scope : {
			treeData : '=',
			canChecked : '&',
			textField : '@',
			itemClicked : '&',
			selectedItem : '=',
			selectedPosition : '=',
			isModal : '=',
			itemCheckedChanged : '&',
			itemTemplateUrl : '@'
		},
		controller : ['$scope','$document',function($scope , $document) {
			$scope.itemExpended = function(item, $event) {
				if(!$scope.isLeaf(item)){
					item.$$isExpend = !item.$$isExpend;
					$event.stopPropagation();
					if (item.$$isExpend && item.children && !item.children[0].parent) {
						var len = item.children.length;
						for (var i = 0; i < len; i++) {
							item.children[i].parent = item;
							}
						}
					}
				};
				
			$document.bind("keydown", function(event) {
				$scope.$apply(function(){
					if(!$scope.isModal){
						if(event.keyCode===9){
							event.preventDefault();
							$scope.itemExpended($scope.selectedItem,event);
						}
						if(event.keyCode===38){
							event.preventDefault();
							var selected = $scope.selectedItem;
							var position = $scope.selectedPosition;
							var father = selected.parent;
							if(position !== 0 ){
								position--;
								var obj = father.children[position];
								while(obj.$$isExpend){
									var objs = obj.children;
									position = objs.length-1;
									obj = objs[position];
								}
								obj.$$isChecked = true;
								$scope.warpCallback('itemCheckedChanged' , obj , event , position);
							} else if (father) {
								if(father.parent){
									position = father.parent.children.indexOf(father);
								}
								father.$$isChecked = true;
								$scope.warpCallback('itemCheckedChanged' , father , event , position );
							}
						}else if(event.keyCode===40){
							event.preventDefault();
							var selected = $scope.selectedItem;
							var position = $scope.selectedPosition;
							var father = selected.parent;
							if(selected.$$isExpend){
								var child = selected.children[0];
								child.$$isChecked = true;
								$scope.warpCallback('itemCheckedChanged' , child , event , 0 );
							} else if (position !== father.children.length-1) {
								var next = father.children[position+1];
								next.$$isChecked = true;
								$scope.warpCallback('itemCheckedChanged' , next , event , position+1 );
							} else {
								for(var grandpa = father.parent ; grandpa && position  == father.children.length-1;){
									position = grandpa.children.indexOf(father);
									father = grandpa;
									grandpa = father.parent;
								}
								var next = father.children[position+1];
								next.$$isChecked = true;
								$scope.warpCallback('itemCheckedChanged' , next , event , position+1 );
							} 
						}
					}
				})
			});
				
			$scope.getItemIcon = function(item) {
				var isLeaf = $scope.isLeaf(item);
				if (isLeaf) {
					return 'glyphicon glyphicon-leaf';
				}
				return item.$$isExpend ? 'glyphicon glyphicon-chevron-up' : 'glyphicon glyphicon-chevron-down';
			};
			
			$scope.isLeaf = function(item) {
				return !item.children || !item.children.length;
			};
			
			$scope.warpCallback = function( callback, item, $event, $index) {
				($scope[callback] || angular.noop)({ $item : item, $event : $event, $index : $index });
				};
			} ]
		};
	}])
}(angular);