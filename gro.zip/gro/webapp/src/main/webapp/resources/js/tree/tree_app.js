!function(angular) {
		'use strict';
angular.module("treeConfig", [ 'tree-directive','tree-controller']);
	}(angular);