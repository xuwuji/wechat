/**
 * This js file is to initialize category performance summary/detail page. And
 * the Angular js controller/service/filter are for UI interaction.
 */
(function(angular, global) {
	'use strict';
	var app = angular.module('category.performance', ['GroEnotifyModule', 'ui.bootstrap', 'highcharts-ng', 'ngResource', 'ngSanitize', 'angular-bootstrap-select', 'datatables' ]);
	
	app.config([ "GroEnotify.messageProvider",
		function(messageProvider) {
			messageProvider.setOption({
				eNotifyURL : eBayGRO.config.GRO_ENOTIFY_URL,
			});
		}
	]);

	app.constant(
			'CategoryConstant',
			{
				kylinParams : {
					"offset" : 0,
					"limit" : "500000",
					"acceptPartial" : true,
					"project" : "gro"
				},
				weeks : [ 'W01', 'W02', 'W03', 'W04', 'W05', 'W06', 'W07', 'W08', 'W09', 'W10', 'W11', 'W12', 'W13', 'W14', 'W15', 'W16', 'W17', 'W18', 'W19', 'W20', 'W21', 'W22', 'W23', 'W24', 'W25', 'W26', 'W27', 'W28', 'W29', 'W30', 'W31', 'W32', 'W33', 'W34', 'W35', 'W36', 'W37', 'W38', 'W39',
						'W40', 'W41', 'W42', 'W43', 'W44', 'W45', 'W46', 'W47', 'W48', 'W49', 'W50', 'W51', 'W52', 'W53' ]
			}).directive('linkScroll', function() {
		return {
			restrict : 'A',
			link : function(scope, element, attrs) {
				var childDivs = element.find('div');
				if (childDivs.length === 2) {
					var childDivF = $(childDivs[0]);
					var childDivS = $(childDivs[1]);
					childDivF.on('scroll', function() {
						childDivS.scrollLeft($(this).scrollLeft());
					});
					childDivS.on('scroll', function() {
						childDivF.scrollLeft($(this).scrollLeft());
					});
				}
			}
		};
	}).filter('currencynumber', [ '$filter', function($filter) {
		return function(input, symbol, franctionSize) {
			if (input === 0){
				return '0';
			}
			if (!input) {
				return '-';
			}
			if (input === 'NaN') {
				return '-';
			}
			var temp = Math.round(input);
			var result = temp + "";
			var len = result.length;
			if (len <4){
				return $filter('currency')(temp, symbol, 0);
			} else if (len >=4 && len < 7) {
				var index = len - 3;
				var value = result.substring(0, index) + "." + result.substring(index);
				return $filter('currency')(parseFloat(value), symbol, franctionSize) + "K"
			} else if (len >= 7 && len < 10) {
				var index = len - 6;
				var value = result.substring(0, index) + "." + result.substring(index);
				return $filter('currency')(parseFloat(value), symbol, franctionSize) + "M";
			} else {
				var index = len - 9;
				var value = result.substring(0, index) + "." + result.substring(index);
				return $filter('currency')(parseFloat(value), symbol, franctionSize) + "B";
			}

		};
	} ]).filter('percentage', [ '$filter', function($filter) {
		return function(input, fractionSize) {
			if (input === 0){
				return '0.00%';
			}
			if (!input) {
				return '-';
			}
			if (input === 'NaN' || input === 99999.99999) {
				return '-';
			}
			return $filter('number')(input, fractionSize) + '%';
		};
	} ]).factory('CategoryService', [ '$resource', function($resource) {
		return $resource(eBayGRO.CONTEXT_PATH + '/categoryservice/:service/:path0', {}, {
			query : {
				method : 'POST',
				isArray : true,
				headers : {
					'Content-Type' : 'application/json;charset=utf-8'
				}
			},
			get : {
				method : 'POST',
				headers : {
					'Content-Type' : 'application/json;charset=utf-8'
				}
			}
		});
	} ]).controller('CategoryPerfController', [ '$scope', '$q', 'CategoryService', '$uibModal', 'CategoryConstant', function($scope, $q, CategoryService, $uibModal, CategoryConstant) {
		/**
		 * All the scope variables
		 */
		$scope.filters = {};
		$scope.data = {
			refreshDate : '',
			weeks : {
				current : [],
				last : []
			},
			quarters : {
				current : [],
				last : []
			},
			years : {
				current : [],
				last : []
			}
		};
		$scope.data.summary = {
			weeks : {
				headers : [],
				metrics : {},
				cpmetrics : {},
				sgmts : {
					gmv : {},
					adll : {},
					str : {}
				},
				cpsgmts : {
					gmv : {},
					adll : {},
					str : {}
				}
			},
			quarters : {
				headers : [],
				metrics : {},
				sgmts : {
					gmv : {},
					adll : {},
					str : {}
				},
				cpsgmts : {
					gmv : {},
					adll : {},
					str : {}
				}
			},
			years : {
				headers : [],
				metrics : {},
				sgmts : {
					gmv : {},
					adll : {},
					str : {}
				},
				cpsgmts : {
					gmv : {},
					adll : {},
					str : {}
				}
			},
			isGMVCollapsed : true,
			isIHLLCollapsed : true,
			isSTRCollapsed : true
		};
		/**
		 * Initialize filters function
		 */
		function _init() {

			/**
			 * Init all the default values first loading*
			 */
			$scope.filters.slrcountry = 'US';
			$scope.filters.lstgsite = 'ebay.com';
			$scope.filters.coreSel = 'All';
			$scope.filters.vpLevel = 'All';
			$scope.filters.newVertical = 'All';
			$scope.filters.merch1Rp = 'All';
			$scope.filters.merch2Rp = 'All';
			$scope.filters.vaMeta = 'All';
			$scope.filters.gra1Level = 'All';
			$scope.filters.gra2Level = 'All';
			$scope.filters.sellerSgmt = 'All';
			$scope.filters.lstgType = 'All';
			$scope.filters.condition = 'All';
			$scope.filters.priceTranche = 'All';
			$scope.filters.duration = 'All';
			$scope.filters.coreRes = [ 'All', 'Core', 'Non-Core' ];
			$scope.filters.slrcountries = ['US'];
			$scope.filters.lstgsites = ['ebay.com']

			$scope.filters.iscompare = false;
		}

		_init();
		/**
		 * Get filters function
		 */
		function getFiltersByType(exp, filter, sqlParams, result) {
			$scope.$watch(function() {
				return exp;
			}, function() {
				CategoryService.query({
					service : 'filters'
				}, {
					filterType:filter,
					sqlParams : sqlParams,
					kylinParams : CategoryConstant.kylinParams
				}, function(data) {
					result = data;
				});
			});
		}

		/**
		 * Below is to retrieve filters
		 */
		// Get VP Level filter items
		$scope.$watch(function() {
			return $scope.filters.coreSel;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'vp',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.vpLevels = data;
			});
		});

		// Get New Vertical filter items
		$scope.$watch(function() {
			return $scope.filters.coreSel + $scope.filters.vpLevel;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'nv',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevel
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.newVerticals = data;
			});
		});
		// Get Merchant 1 Rollup
		$scope.$watch(function() {
			return $scope.filters.coreSel + $scope.filters.vpLevel + $scope.filters.newVertical;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'mc1rp',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevel
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVertical
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.merch1Rps = data;
			});
		});

		// Get Merchant 2 Rollup
		$scope.$watch(function() {
			return $scope.filters.coreSel + $scope.filters.vpLevel + $scope.filters.newVertical + $scope.filters.merch1Rp;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'mc2rp',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevel
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVertical
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.merch2Rps = data;
			});
		});

		// Get VA Mapped Meta
		$scope.$watch(function() {
			return $scope.filters.coreSel + $scope.filters.vpLevel + $scope.filters.newVertical + $scope.filters.merch1Rp + $scope.filters.merch2Rp;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'meta',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevel
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVertical
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
					value : $scope.filters.merch2Rp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.vaMetas = data;
			});
		});
		// Get Granular Level1
		$scope.$watch(function() {
			return $scope.filters.coreSel + $scope.filters.vpLevel + $scope.filters.newVertical + $scope.filters.merch1Rp + $scope.filters.merch2Rp + $scope.filters.vaMeta;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'gralev1',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevel
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVertical
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
					value : $scope.filters.merch2Rp
				}, {
					field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
					value : $scope.filters.vaMeta
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.gra1Levels = data;
			});
		});
		// Get Granular Level2
		$scope.$watch(function() {
			return $scope.filters.coreSel + $scope.filters.vpLevel + $scope.filters.newVertical + $scope.filters.merch1Rp + $scope.filters.merch2Rp + $scope.filters.vaMeta + $scope.filters.gra1Level;
		}, function() {
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'gralev2',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSel
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevel
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVertical
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
					value : $scope.filters.merch2Rp
				}, {
					field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
					value : $scope.filters.vaMeta
				}, {
					field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1',
					value : $scope.filters.gra1Level
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.gra2Levels = data;
			});
		});

		/**
		 * Below is to retrieve comparison filters
		 */
		// Get VP Level filter items
		$scope.$watch(function() {
			return $scope.filters.coreSelcp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'vp',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.vpLevelscp = data;
			});
		});

		// Get New Vertical filter items
		$scope.$watch(function() {
			return $scope.filters.coreSelcp + $scope.filters.vpLevelcp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'nv',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevelcp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.newVerticalscp = data;
			});
		});
		// Get Merchant 1 Rollup
		$scope.$watch(function() {
			return $scope.filters.coreSelcp + $scope.filters.vpLevelcp + $scope.filters.newVerticalcp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'mc1rp',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevelcp
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVerticalcp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.merch1Rpscp = data;
			});
		});

		// Get Merchant 2 Rollup
		$scope.$watch(function() {
			return $scope.filters.coreSelcp + $scope.filters.vpLevelcp + $scope.filters.newVerticalcp + $scope.filters.merch1Rpcp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'mc2rp',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevelcp
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVerticalcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rpcp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.merch2Rpscp = data;
			});
		});

		// Get VA Mapped Meta
		$scope.$watch(function() {
			return $scope.filters.coreSelcp + $scope.filters.vpLevelcp + $scope.filters.newVerticalcp + $scope.filters.merch1Rpcp + $scope.filters.merch2Rpcp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'meta',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevelcp
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVerticalcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rpcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
					value : $scope.filters.merch2Rpcp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.vaMetascp = data;
			});
		});
		// Get Granular Level1
		$scope.$watch(function() {
			return $scope.filters.coreSelcp + $scope.filters.vpLevelcp + $scope.filters.newVerticalcp + $scope.filters.merch1Rpcp + $scope.filters.merch2Rpcp + $scope.filters.vaMetacp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'gralev1',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevelcp
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVerticalcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rpcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
					value : $scope.filters.merch2Rpcp
				}, {
					field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
					value : $scope.filters.vaMetacp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.gra1Levelscp = data;
			});
		});
		// Get Granular Level2
		$scope.$watch(function() {
			return $scope.filters.coreSelcp + $scope.filters.vpLevelcp + $scope.filters.newVerticalcp + $scope.filters.merch1Rpcp + $scope.filters.merch2Rpcp + $scope.filters.vaMetacp + $scope.filters.gra1Levelcp;
		}, function() {
			if (!$scope.filters.coreSelcp) {
				return;
			}
			CategoryService.query({
				service : 'filters'
			}, {
				filterType:'gralev2',
				sqlParams : [ {
					field : 'CORE_NONCORE',
					value : $scope.filters.coreSelcp
				}, {
					field : 'CATG_MAPPING_PROC4.VP_LEVEL',
					value : $scope.filters.vpLevelcp
				}, {
					field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
					value : $scope.filters.newVerticalcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
					value : $scope.filters.merch1Rpcp
				}, {
					field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
					value : $scope.filters.merch2Rpcp
				}, {
					field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
					value : $scope.filters.vaMetacp
				}, {
					field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1',
					value : $scope.filters.gra1Levelcp
				} ],
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.filters.gra2Levelscp = data;
			});
		});

		/**
		 * Get refresh Date
		 */

		function getRefreshDate() {
			return CategoryService.get({
				service : 'getRefreshDate'
			}, {
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				$scope.data.refreshDate = data.refreshDate;
				$scope.data.isUp2Date = !(data.up2Date > data.refreshDate);
				$scope.data.notification = ($scope.data.isUp2Date ? 'Up to date. Data should be updated to '.concat(data.refreshDate) : 'Delayed. Data should be updated to '.concat(data.up2Date)).concat('.');
				$scope.data.weeks = data.weeks;
				$scope.data.quarters = data.quarters;
				$scope.data.years = data.years;
			}).$promise;
		}

		function getSqlParams(iscompare) {
			return [ {
				field : 'CORE_NONCORE',
				value : iscompare ? $scope.filters.coreSelcp : $scope.filters.coreSel
			}, {
				field : 'CATG_MAPPING_PROC4.VP_LEVEL',
				value : iscompare ? $scope.filters.vpLevelcp : $scope.filters.vpLevel
			}, {
				field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
				value : iscompare ? $scope.filters.newVerticalcp : $scope.filters.newVertical
			}, {
				field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
				value : iscompare ? $scope.filters.merch1Rpcp : $scope.filters.merch1Rp
			}, {
				field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
				value : iscompare ? $scope.filters.merch2Rpcp : $scope.filters.merch2Rp
			}, {
				field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
				value : iscompare ? $scope.filters.vaMetacp : $scope.filters.vaMeta
			}, {
				field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1',
				value : iscompare ? $scope.filters.gra1Levelcp : $scope.filters.gra1Level
			}, {
				field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2',
				value : iscompare ? $scope.filters.gra2Levelcp : $scope.filters.gra2Level
			} ];
		}
		/**
		 * Get metrics based on time range trailing weeks, quarters, years
		 */
		function getMetricsByTimerange(trType, iscompare) {
			var timerange, result;

			if (trType === 'weeks') {
				timerange = $scope.data.weeks;
				result = $scope.data.summary.weeks;
			} else if (trType === 'quarters') {
				timerange = $scope.data.quarters;
				result = $scope.data.summary.quarters;
			} else if (trType === 'years') {
				timerange = $scope.data.years;
				result = $scope.data.summary.years;
			} else {
				return;// TODO May need to throw out
				// exception
			}

			return CategoryService.get({
				service : 'metrics'
			}, {
				timeRangeType : trType,
				timerange : timerange,
				iscompare : iscompare,
				refreshDate : $scope.data.refreshDate,
				sqlParams : getSqlParams(iscompare),
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				result.headers = data.headers || result.headers;
				result.metrics = data.metrics || result.metrics;
				result.cpmetrics = data.cpmetrics || result.cpmetrics;
			}).$promise;
		}

		/**
		 * Get segments based on time range and segment type time range:
		 * trailing weeks, quarters, years segment type: gmv, adll, str, ihll
		 */
		function getSgmtsByTimerange(metricType, sgmtType, trType, iscompare) {
			var timerange, result;
			if (trType === 'weeks') {
				timerange = $scope.data.weeks;
				result = iscompare ? $scope.data.summary.weeks.cpsgmts : $scope.data.summary.weeks.sgmts;
			} else if (trType === 'quarters') {
				timerange = $scope.data.quarters;
				result = iscompare ? $scope.data.summary.quarters.cpsgmts : $scope.data.summary.quarters.sgmts
			} else if (trType === 'years') {
				timerange = $scope.data.years;
				result = iscompare ? $scope.data.summary.years.cpsgmts : $scope.data.summary.years.sgmts;
			} else {
				return;// TODO May need to throw out
				// exception
			}

			return CategoryService.get({
				service : 'segments'
			}, {
				metricType : metricType,
				sgmtType : sgmtType,
				timeRangeType : trType,
				timerange : timerange,
				refreshDate : $scope.data.refreshDate,
				sqlParams : getSqlParams(iscompare),
				kylinParams : CategoryConstant.kylinParams
			}, function(data) {
				if (data.gmv) {
					angular.merge(result.gmv, data.gmv);
				}
				if (data.adll) {
					angular.merge(result.adll, data.adll);
				}
				if (data.str) {
					angular.merge(result.str, data.str);
				}
			}).$promise;
		}

		/**
		 * Apply function to retrieve metrics and segments data.
		 */
		$scope.filters.apply = function() {
			$scope.overlayStyle = {
				display : 'block'
			};
			$scope.isloaded = false;
			$scope.iscploaded = false;
			$scope.data.summary.categoryTitle = getCategoryTitle();
			getRefreshDate().then(function() {
				var metrics_q, gmv_slr_q, gmv_lt_q, gmv_cond_q, gmv_ptr_q, gmv_misc_q, adllstr_slr_q, adllstr_lt_q, adllstr_cond_q, adllstr_ptr_q, adllstr_misc_q;
				metrics_q = getMetricsByTimerange($scope.data.summary.selectedTab, false);
				gmv_slr_q = getSgmtsByTimerange('gmv', 'slr', $scope.data.summary.selectedTab, false);
				gmv_lt_q = getSgmtsByTimerange('gmv', 'lt', $scope.data.summary.selectedTab, false);
				gmv_cond_q = getSgmtsByTimerange('gmv', 'cond', $scope.data.summary.selectedTab, false);
				gmv_ptr_q = getSgmtsByTimerange('gmv', 'ptr', $scope.data.summary.selectedTab, false);
				gmv_misc_q = getSgmtsByTimerange('gmv', 'misc', $scope.data.summary.selectedTab, false);
				adllstr_slr_q = getSgmtsByTimerange('adllstr', 'slr', $scope.data.summary.selectedTab, false);
				adllstr_lt_q = getSgmtsByTimerange('adllstr', 'lt', $scope.data.summary.selectedTab, false);
				adllstr_cond_q = getSgmtsByTimerange('adllstr', 'cond', $scope.data.summary.selectedTab, false);
				adllstr_ptr_q = getSgmtsByTimerange('adllstr', 'ptr', $scope.data.summary.selectedTab, false);
				adllstr_misc_q = getSgmtsByTimerange('adllstr', 'misc', $scope.data.summary.selectedTab, false);

				var promise = $q.all([ metrics_q, gmv_slr_q, gmv_lt_q, gmv_cond_q, gmv_ptr_q, gmv_misc_q, adllstr_slr_q, adllstr_lt_q, adllstr_cond_q, adllstr_ptr_q, adllstr_misc_q ]);

				if ($scope.filters.iscompare) {
					$scope.data.summary.cpcategoryTitle = getCPCategoryTitle();
					var cpmetrics_q, cpgmv_slr_q, cpgmv_lt_q, cpgmv_cond_q, cpgmv_ptr_q, cpgmv_misc_q, cpadllstr_slr_q, cpadllstr_lt_q, cpadllstr_cond_q, cpadllstr_ptr_q, cpadllstr_misc_q;
					cpmetrics_q = getMetricsByTimerange($scope.data.summary.selectedTab, true);
					cpgmv_slr_q = getSgmtsByTimerange('gmv', 'slr', $scope.data.summary.selectedTab, true);
					cpgmv_lt_q = getSgmtsByTimerange('gmv', 'lt', $scope.data.summary.selectedTab, true);
					cpgmv_cond_q = getSgmtsByTimerange('gmv', 'cond', $scope.data.summary.selectedTab, true);
					cpgmv_ptr_q = getSgmtsByTimerange('gmv', 'ptr', $scope.data.summary.selectedTab, true);
					cpgmv_misc_q = getSgmtsByTimerange('gmv', 'misc', $scope.data.summary.selectedTab, true);
					cpadllstr_slr_q = getSgmtsByTimerange('adllstr', 'slr', $scope.data.summary.selectedTab, true);
					cpadllstr_lt_q = getSgmtsByTimerange('adllstr', 'lt', $scope.data.summary.selectedTab, true);
					cpadllstr_cond_q = getSgmtsByTimerange('adllstr', 'cond', $scope.data.summary.selectedTab, true);
					cpadllstr_ptr_q = getSgmtsByTimerange('adllstr', 'ptr', $scope.data.summary.selectedTab, true);
					cpadllstr_misc_q = getSgmtsByTimerange('adllstr', 'misc', $scope.data.summary.selectedTab, true);

					$q.all([ promise, cpmetrics_q, cpgmv_slr_q, cpgmv_lt_q, cpgmv_cond_q, cpgmv_ptr_q, cpgmv_misc_q, cpadllstr_slr_q, cpadllstr_lt_q, cpadllstr_cond_q, cpadllstr_ptr_q, cpadllstr_misc_q ]).then(function() {
						$scope.isloaded = true;
						$scope.iscploaded = true;
						$scope.overlayStyle = {
							display : 'none'
						};
					});
				} else {
					promise.then(function() {
						$scope.isloaded = true;
						$scope.overlayStyle = {
							display : 'none'
						};
					});
				}
			});

		};
		var isInit = false;
		$scope.addComparison = function() {
			if (!isInit) {
				$scope.filters.slrcountrycp = 'US';
				$scope.filters.lstgsitecp = 'ebay.com';
				$scope.filters.coreSelcp = 'All';
				$scope.filters.vpLevelcp = 'All';
				$scope.filters.newVerticalcp = 'All';
				$scope.filters.merch1Rpcp = 'All';
				$scope.filters.merch2Rpcp = 'All';
				$scope.filters.vaMetacp = 'All';
				$scope.filters.gra1Levelcp = 'All';
				$scope.filters.gra2Levelcp = 'All';

				$scope.filters.slrcountriescp = ['US'];
				$scope.filters.lstgsitescp = ['ebay.com'];
				$scope.data.summary.cpcategoryTitle = getCPCategoryTitle();
				isInit = true;
			}
		}
		$scope.switchTab = function(tab) {
			$scope.data.summary.selectedTab = tab;
			$scope.filters.apply();
		};

		function getSubCategory() {
			if ($scope.filters.gra2Level !== 'All') {
				return 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2';
			}
			if ($scope.filters.gra1Level !== 'All') {
				return 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2';
			}
			if ($scope.filters.vaMeta !== 'All') {
				return 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1';
			}
			if ($scope.filters.merch2Rp !== 'All') {
				return 'CATG_MAPPING_PROC4.VA_MAPPED_META';
			}
			if ($scope.filters.merch1Rp !== 'All') {
				return 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP';
			}
			if ($scope.filters.newVertical !== 'All') {
				return 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP';
			}
			if ($scope.filters.vpLevel !== 'All') {
				return 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION';
			}
			if ($scope.filters.coreSel !== 'All') {
				return 'CATG_MAPPING_PROC4.VP_LEVEL';
			}
			return 'CORE_NONCORE';
		}

		function getCategoryTitle() {
			if ($scope.filters.gra2Level !== 'All') {
				return 'Granular Level 2: '.concat($scope.filters.gra2Level);
			}
			if ($scope.filters.gra1Level !== 'All') {
				return 'Granular Level 1: '.concat($scope.filters.gra1Level);
			}
			if ($scope.filters.vaMeta !== 'All') {
				return 'VA Mapped Meta: '.concat($scope.filters.vaMeta);
			}
			if ($scope.filters.merch2Rp !== 'All') {
				return 'Merchant 2 Rollup: '.concat($scope.filters.merch2Rp);
			}
			if ($scope.filters.merch1Rp !== 'All') {
				return 'Merchant 1 Rollup: '.concat($scope.filters.merch1Rp);
			}
			if ($scope.filters.newVertical !== 'All') {
				return 'New Vertical: '.concat($scope.filters.newVertical);
			}
			if ($scope.filters.vpLevel !== 'All') {
				return 'VP Level: '.concat($scope.filters.vpLevel);
			}
			if ($scope.filters.coreSel !== 'All') {
				return 'Core/Non-Core: '.concat($scope.filters.coreSel);
			}
			return 'Core/Non-Core: All';
		}

		function getCPSubCategory() {
			if ($scope.filters.gra2Levelcp !== 'All') {
				return 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2';
			}
			if ($scope.filters.gra1Levelcp !== 'All') {
				return 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2';
			}
			if ($scope.filters.vaMetacp !== 'All') {
				return 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1';
			}
			if ($scope.filters.merch2Rpcp !== 'All') {
				return 'CATG_MAPPING_PROC4.VA_MAPPED_META';
			}
			if ($scope.filters.merch1Rpcp !== 'All') {
				return 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP';
			}
			if ($scope.filters.newVerticalcp !== 'All') {
				return 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP';
			}
			if ($scope.filters.vpLevelcp !== 'All') {
				return 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION';
			}
			if ($scope.filters.coreSelcp !== 'All') {
				return 'CATG_MAPPING_PROC4.VP_LEVEL';
			}
			return 'CORE_NONCORE';
		}

		function getCPCategoryTitle() {
			if ($scope.filters.gra2Levelcp !== 'All') {
				return 'Granular Level 2: '.concat($scope.filters.gra2Levelcp);
			}
			if ($scope.filters.gra1Levelcp !== 'All') {
				return 'Granular Level 1: '.concat($scope.filters.gra1Levelcp);
			}
			if ($scope.filters.vaMetacp !== 'All') {
				return 'VA Mapped Meta: '.concat($scope.filters.vaMetacp);
			}
			if ($scope.filters.merch2Rpcp !== 'All') {
				return 'Merchant 2 Rollup: '.concat($scope.filters.merch2Rpcp);
			}
			if ($scope.filters.merch1Rpcp !== 'All') {
				return 'Merchant 1 Rollup: '.concat($scope.filters.merch1Rpcp);
			}
			if ($scope.filters.newVerticalcp !== 'All') {
				return 'New Vertical: '.concat($scope.filters.newVerticalcp);
			}
			if ($scope.filters.vpLevelcp !== 'All') {
				return 'VP Level: '.concat($scope.filters.vpLevelcp);
			}
			if ($scope.filters.coreSelcp !== 'All') {
				return 'Core/Non-Core: '.concat($scope.filters.coreSelcp);
			}
			return 'Core/Non-Core: All';

		}

		$scope.showDetail = function(metricSgmt) {
			var modalInstance = $uibModal.open({
				templateUrl : '/details.html',
				controller : 'CategoryDetailsController',
				size : 'lg',
				backdrop : 'static',
				resolve : {
					detailParams : function() {
						return {
							iscompare : $scope.filters.iscompare,
							filterParams : metricSgmt,
							subCategory : getSubCategory(),
							categoryTitle : getCategoryTitle(),
							cpSubCategory : getCPSubCategory(),
							cpCategoryTitle : getCPCategoryTitle(),
							refreshDate : $scope.data.refreshDate,
							curWeek : $scope.data.summary.weeks.headers[0],
							sqlParams : [ {
								field : 'CORE_NONCORE',
								value : $scope.filters.coreSel
							}, {
								field : 'CATG_MAPPING_PROC4.VP_LEVEL',
								value : $scope.filters.vpLevel
							}, {
								field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
								value : $scope.filters.newVertical
							}, {
								field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
								value : $scope.filters.merch1Rp
							}, {
								field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
								value : $scope.filters.merch2Rp
							}, {
								field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
								value : $scope.filters.vaMeta
							}, {
								field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1',
								value : $scope.filters.gra1Level
							}, {
								field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2',
								value : $scope.filters.gra2Level
							} ],
							cpSqlParams : $scope.filters.iscompare ? [ {
								field : 'CORE_NONCORE',
								value : $scope.filters.coreSelcp
							}, {
								field : 'CATG_MAPPING_PROC4.VP_LEVEL',
								value : $scope.filters.vpLevelcp
							}, {
								field : 'CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION',
								value : $scope.filters.newVerticalcp
							}, {
								field : 'CATG_MAPPING_PROC4.MERCHANT1_ROLLUP',
								value : $scope.filters.merch1Rpcp
							}, {
								field : 'CATG_MAPPING_PROC4.MERCHANT2_ROLLUP',
								value : $scope.filters.merch2Rpcp
							}, {
								field : 'CATG_MAPPING_PROC4.VA_MAPPED_META',
								value : $scope.filters.vaMetacp
							}, {
								field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL1',
								value : $scope.filters.gra1Levelcp
							}, {
								field : 'CATG_MAPPING_PROC4.GRANULAR_LEVEL2',
								value : $scope.filters.gra2Levelcp
							} ] : undefined
						};
					}
				}
			});
		}
	} ]).controller(
			'CategoryDetailsController',
			[ '$scope', '$filter', '$q', '$timeout', '$modalInstance', 'CategoryService', 'CategoryConstant', 'DTOptionsBuilder', 'DTColumnBuilder', 'detailParams',
					function($scope, $filter, $q, $timeout, $modalInstance, CategoryService, CategoryConstant, DTOptionsBuilder, DTColumnBuilder, detailParams) {
						$scope.filters = {};
						$scope.dt = {};
						var params = detailParams;
						var sqlParams = params.sqlParams, filterParams = params.filterParams, refreshed = params.refreshDate, iscompare = params.iscompare, subCategory = params.subCategory, cpSqlParams = params.cpSqlParams;
						$scope.categoryTitle = params.categoryTitle;
						$scope.cpCategoryTitle = params.cpCategoryTitle;
						$scope.curWeek = params.curWeek;
						$scope.iscompare = iscompare;
						function init() {
							$scope.filters.slrSgmt = 'All';
							$scope.filters.lstgType = 'All';
							$scope.filters.cond = 'All';
							$scope.filters.ptr = 'All';
							$scope.filters.df = 'All';
							$scope.filters.dura = 'All';
							$scope.filters.gtc = 'All';
							$scope.filters.rlf = 'All';

							$scope.filters.sellerSgmts = [ 'All', 'B2C MD', 'B2C UD', 'C2C' ];
							$scope.filters.lstgTypes = [ 'All', 'ABin', 'Auc', 'FP' ];
							$scope.filters.conditions = [ 'All', 'New', 'Refurbished', 'Used', 'Other' ];
							$scope.filters.priceTranches = [ 'All', '$0-$20', '$20-$100', '$100-$500', '>=$500', 'Other' ];
							$scope.filters.dealf = [ 'All', 'DD', 'Non-DD' ];
							$scope.filters.durations = [ 'All', '1', '3', '7', '10', '30', '-99' ];
							$scope.filters.gtcf = [ 'All', 'GTC', 'Non-GTC' ];
							$scope.filters.rlfs = [ 'All', 'Y', 'N' ];
							$scope.metrics = [ 'Average Daily Live Listings', 'ASP', 'Ended Listings', 'Fresh Listings', 'GMV', 'New Listings', 'Sell Through Rate', 'Sold Items' ];

							$scope.filters.metric = filterParams.metricType;
							var sgmt = filterParams.sgmtType;
							if (sgmt) {
								var sgmtValue = filterParams.sgmtValue;
								if (sgmt === 'slr') {
									$scope.filters.slrSgmt = sgmtValue;
								} else if (sgmt === 'lt') {
									$scope.filters.lstgType = sgmtValue;
								} else if (sgmt === 'cond') {
									$scope.filters.cond = sgmtValue;
								} else if (sgmt === 'pt') {
									$scope.filters.ptr = sgmtValue;
								} else if (sgmt === 'df') {
									$scope.filters.df = sgmtValue;
								} else if (sgmt === 'gtc') {
									$scope.filters.gtc = sgmtValue;
								}
							}
							var absChartConfig = {
								options : {
									chart : {
										zoomType : 'xy',
										events : {
											load : function(chart) {
												$timeout(function() {
													chart.target.reflow();
												});
											}
										},
										plotOptions : {
											series : {
												marker : {
													enabled : false
												}
											}
										},
										tooltip : {
//											shared : true
											crosshairs : true
										},
										lang : {
											download : 'Download chart data'
										},
										exporting : {
											buttons : {
												contextButton : {
													menuItems : null,
													_titleKey : 'download',
													onclick : function() {
														this.downloadCSV();
													}
												}
											},
											filename : $scope.filters.metric + " Absolute"
										}
									},
									plotOptions : {
										series : {
											marker : {
												enabled : false
											}
										}
									},
									tooltip : {
										shared : true,
										crosshairs : true
									},
									lang : {
										download : 'Download chart data'
									},
									exporting : {
										buttons : {
											contextButton : {
												menuItems : null,
												symbol : 'url(' + eBayGRO.CONTEXT_PATH + '/resources/images/download.png)',
												_titleKey : 'download',
												onclick : function() {
													this.downloadCSV();
												}
											}
										}
									}
								},
								title : {
									text : ''
								},
								series : [],
								loading : false,
								xAxis : {
									categories : CategoryConstant.weeks,
									crosshair : true,
									title : {}
								},
								yAxis : {
									labels : {
										formatter : function() {
											if ($scope.filters.metric === 'GMV' || $scope.filters.metric === 'ASP') {
												return $filter('currencynumber')(this.value, '$', 2);
											} else if ($scope.filters.metric === 'Sell Through Rate') {
												return $filter('percentage')(this.value, 2);
											} else {
												return $filter('currencynumber')(this.value, '', 2);
											}
										},
									},
									title : {
										text : ''
									}
								}
							};
							var yoyChartConfig = {
								options : {
									chart : {
										zoomType : 'xy',
										events : {
											load : function(chart) {
												$timeout(function() {
													chart.target.reflow();
												});
											}
										}
									},
									plotOptions : {
										series : {
											marker : {
												enabled : false
											}
										}
									},
									tooltip : {
										shared : true,
										crosshairs : true,
										valueSuffix : '%'
									},
									lang : {
										download : 'Download chart data'
									},
									exporting : {
										buttons : {
											contextButton : {
												menuItems : null,
												symbol : 'url(' + eBayGRO.CONTEXT_PATH + '/resources/images/download.png)',
												_titleKey : 'download',
												onclick : function() {
													this.downloadCSV();
												}
											}
										}
									}
								},
								series : [],
								title : {
									text : ''
								},
								loading : false,
								xAxis : {
									categories : CategoryConstant.weeks,
									title : {}
								},
								yAxis : {
									labels : {
										format : '{value} %',
									},
									title : {
										text : ''
									}
								}
							};

							$scope.chart = {
								selectedConfigabs : angular.copy(absChartConfig),
								comparisonConfigabs : angular.copy(absChartConfig),
								selectedConfigyoy : angular.copy(yoyChartConfig),
								comparisonConfigyoy : angular.copy(yoyChartConfig)
							};

							$scope.dt.options = {
								displayLength : 10,
								searching : false,
								bLengthChange : false
							};
						}
						init();

						$scope.close = function() {
							$modalInstance.dismiss('cancel');
						};

						function getSqlParams(params) {
							var sqlParams = params || [];
							return sqlParams.concat([ {
								field : 'IH_DAILY_FACT.SLR_SGMT',
								value : $scope.filters.slrSgmt
							}, {
								field : 'IH_DAILY_FACT.LSTG_TYPE',
								value : $scope.filters.lstgType
							}, {
								field : 'IH_DAILY_FACT.ITEM_CNDTN',
								value : $scope.filters.cond
							}, {
								field : 'IH_DAILY_FACT.PRICE_TRANCHE',
								value : $scope.filters.ptr
							}, {
								field : 'IH_DAILY_FACT.DD_FLAG',
								value : $scope.filters.df
							}, {
								field : 'IH_DAILY_FACT.SCHED_DURATION',
								value : $scope.filters.dura
							}, {
								field : 'IH_DAILY_FACT.GTC_FLAG',
								value : $scope.filters.gtc
							}, {
								field : 'IH_DAILY_FACT.RELIST_UP_FLAG',
								value : $scope.filters.rlf === 'All' ? 'All' : ($scope.filters.rlf === 'Y' ? '1' : '0')
							} ]);
						}

						function getMetricByTypeAndSgmts(iscompare, sqlParams) {
							return CategoryService.query({
								service : 'details',
								path0 : 'metric'
							}, {
								iscompare : iscompare,
								metricType : $scope.filters.metric,
								refreshDate : refreshed,
								sqlParams : getSqlParams(sqlParams),
								kylinParams : CategoryConstant.kylinParams
							}).$promise;
						}

						function getMetricByTypeAndSgmtsYoY(iscompare, sqlParams) {
							return CategoryService.query({
								service : 'details',
								path0 : 'metricyoy'
							}, {
								iscompare : iscompare,
								metricType : $scope.filters.metric,
								refreshDate : refreshed,
								sqlParams : getSqlParams(sqlParams),
								kylinParams : CategoryConstant.kylinParams
							}).$promise;
						}

						function getSubCategories(iscompare, sqlParams) {
							return CategoryService.query({
								service : 'details',
								path0 : 'subcatg'
							}, {
								iscompare : iscompare,
								subCatg : subCategory,
								refreshDate : refreshed,
								sqlParams : getSqlParams(sqlParams),
								kylinParams : CategoryConstant.kylinParams
							}, function(data) {
								$scope.dt.subcategories = data;
							}).$promise;
						}

						$scope.detailApply = function() {
							var yoyDelta = " YoY(%)";
							if ($scope.filters.metric === "Sell Through Rate"){
								yoyDelta = " Delta";
							}
							$scope.chart.selectedConfigabs.title.text = $scope.categoryTitle + ' - ' + $scope.filters.metric;
							$scope.chart.selectedConfigyoy.title.text = $scope.categoryTitle + ' - ' + $scope.filters.metric + yoyDelta;
							$scope.chart.selectedConfigabs.options.exporting.filename = $scope.chart.selectedConfigabs.title.text;
							$scope.chart.selectedConfigyoy.options.exporting.filename = $scope.chart.selectedConfigyoy.title.text;
							$scope.chart.selectedConfigabs.loading = true;
							$scope.chart.selectedConfigyoy.loading = true;
							$scope.dt.overlayStyle = {
								display : 'block'
							};

							getMetricByTypeAndSgmts(false, sqlParams).then(function(data) {
								$scope.chart.selectedConfigabs.series = data;
								$scope.chart.selectedConfigabs.loading = false;
							});
							// getMetricByTypeAndSgmtsYoY(false,
							// sqlParams).then(function(data) {
							// $scope.chart.selectedConfigyoy.series = data;
							// $scope.chart.selectedConfigyoy.loading = false;
							// });
							getSubCategories(true, sqlParams).then(function() {
								$scope.dt.overlayStyle = {
									display : 'none'
								};
							});
							if (iscompare) {
								$scope.chart.comparisonConfigabs.title.text = $scope.cpCategoryTitle + ' - ' + $scope.filters.metric;
								$scope.chart.comparisonConfigyoy.title.text = $scope.cpCategoryTitle + ' - ' + $scope.filters.metric + yoyDelta;
								$scope.chart.comparisonConfigabs.options.exporting.filename = $scope.chart.comparisonConfigabs.title.text;
								$scope.chart.comparisonConfigyoy.options.exporting.filename = $scope.chart.comparisonConfigyoy.title.text;
								$scope.chart.comparisonConfigabs.loading = true;
								$scope.chart.comparisonConfigyoy.loading = true;

								getMetricByTypeAndSgmts(true, cpSqlParams).then(function(data) {
									$scope.chart.comparisonConfigabs.series = data;
									$scope.chart.comparisonConfigabs.loading = false;
								});
								// getMetricByTypeAndSgmtsYoY(true,
								// cpSqlParams).then(function(data) {
								// $scope.chart.comparisonConfigyoy.series =
								// data;
								// $scope.chart.comparisonConfigyoy.loading =
								// false;
								// });

								$q.all([ getMetricByTypeAndSgmtsYoY(false, sqlParams), getMetricByTypeAndSgmtsYoY(true, cpSqlParams) ]).then(function(data) {
									$scope.chart.selectedConfigyoy.series = data[0];
									$scope.chart.comparisonConfigyoy.series = data[1];
									$scope.chart.selectedConfigyoy.loading = false;
									$scope.chart.comparisonConfigyoy.loading = false;

									var selData = data[0][0].data.concat(data[0][1].data), cpData = data[1][0].data.concat(data[1][1].data);
									var max = Math.max(Math.max.apply(null, selData), Math.max.apply(null, cpData));
									var min = Math.min(Math.min.apply(null, selData), Math.min.apply(null, cpData));
									$scope.chart.selectedConfigyoy.yAxis.max = max;
									$scope.chart.selectedConfigyoy.yAxis.min = min;

									$scope.chart.comparisonConfigyoy.yAxis.max = max;
									$scope.chart.comparisonConfigyoy.yAxis.min = min;
								});
							} else {
								getMetricByTypeAndSgmtsYoY(false, sqlParams).then(function(data) {
									$scope.chart.selectedConfigyoy.series = data;
									$scope.chart.selectedConfigyoy.loading = false;
								});
							}
						};

						$scope.selectMetric = function() {
							var yoyDelta = " YoY(%)";
							if ($scope.filters.metric === "Sell Through Rate"){
								yoyDelta = " Delta";
							}
							$scope.chart.selectedConfigabs.title.text = $scope.categoryTitle + ' - ' + $scope.filters.metric;
							$scope.chart.selectedConfigyoy.title.text = $scope.categoryTitle + ' - ' + $scope.filters.metric + yoyDelta;
							$scope.chart.selectedConfigabs.options.exporting.filename = $scope.chart.selectedConfigabs.title.text;
							$scope.chart.selectedConfigyoy.options.exporting.filename = $scope.chart.selectedConfigyoy.title.text;
							$scope.chart.selectedConfigabs.loading = true;
							$scope.chart.selectedConfigabs.loading = true;
							$scope.chart.selectedConfigyoy.loading = true;

							getMetricByTypeAndSgmts(false, sqlParams).then(function(data) {
								$scope.chart.selectedConfigabs.series = data;
								$scope.chart.selectedConfigabs.loading = false;
							});
							// getMetricByTypeAndSgmtsYoY(false,
							// sqlParams).then(function(data) {
							// $scope.chart.selectedConfigyoy.series = data;
							// $scope.chart.selectedConfigyoy.loading = false;
							// });

							if (iscompare) {
								$scope.chart.comparisonConfigabs.title.text = $scope.cpCategoryTitle + ' - ' + $scope.filters.metric;
								$scope.chart.comparisonConfigyoy.title.text = $scope.cpCategoryTitle + ' - ' + $scope.filters.metric + yoyDelta;
								$scope.chart.comparisonConfigabs.options.exporting.filename = $scope.chart.comparisonConfigabs.title.text;
								$scope.chart.comparisonConfigyoy.options.exporting.filename = $scope.chart.comparisonConfigyoy.title.text;
								$scope.chart.comparisonConfigabs.loading = true;
								$scope.chart.comparisonConfigyoy.loading = true;

								getMetricByTypeAndSgmts(true, cpSqlParams).then(function(data) {
									$scope.chart.comparisonConfigabs.series = data;
									$scope.chart.comparisonConfigabs.loading = false;
								});
								// getMetricByTypeAndSgmtsYoY(false,
								// sqlParams).then(function(data) {
								// $scope.chart.comparisonConfigyoy.series =
								// data;
								// $scope.chart.comparisonConfigyoy.loading =
								// false;
								// });

								$q.all([ getMetricByTypeAndSgmtsYoY(false, sqlParams), getMetricByTypeAndSgmtsYoY(true, cpSqlParams) ]).then(function(data) {
									$scope.chart.selectedConfigyoy.series = data[0];
									$scope.chart.comparisonConfigyoy.series = data[1];
									$scope.chart.selectedConfigyoy.loading = false;
									$scope.chart.comparisonConfigyoy.loading = false;

									var selData = data[0][0].data.concat(data[0][1].data), cpData = data[1][0].data.concat(data[1][1].data);
									var max = Math.max(Math.max.apply(null, selData), Math.max.apply(null, cpData));
									var min = Math.min(Math.min.apply(null, selData), Math.min.apply(null, cpData));
									$scope.chart.selectedConfigyoy.yAxis.max = max;
									$scope.chart.selectedConfigyoy.yAxis.min = min;

									$scope.chart.comparisonConfigyoy.yAxis.max = max;
									$scope.chart.comparisonConfigyoy.yAxis.min = min;
								});
							} else {
								getMetricByTypeAndSgmtsYoY(false, sqlParams).then(function(data) {
									$scope.chart.selectedConfigyoy.series = data;
									$scope.chart.selectedConfigyoy.loading = false;
								});
							}
						}
						$scope.detailApply();
					} ]);
}(window.angular));
