(function(angular, $, global){
    'use strict';
    var app = angular.module("GroStickyFilterModule", []);

    /*directives*/
    app.directive("groStickyFilter", ['$interval', function(message, $interval){
       return {
        restrict: 'ACE',
        scope: {},
        link: function(scope, $elem, attrs){
            var options = {};
            var filterData = attrs.filterData;
            if ( filterData ) options = angular.fromJson(filterData);

            var elemExp = $("div.filter-expand", $elem);
            var elemCol = $("div.filter-collapse", $elem);
            if ( options.top ) {
                elemCol.css("top", options.top);
                elemExp.css("top", options.top);
            }

            scope.expanded = true;
            showOrHide();
            addEditLink();

            /**===================================================
             * event registeration
             ====================================================*/
            scope.$watch("expanded", function(){
                showOrHide();
            })

            $(window).scroll(function(){
                var scrollTop = $(this).scrollTop();
                scope.$evalAsync(function(){
                    scope.expanded = (scrollTop <= 50);
                    elemExp.removeClass("gro-pos-fixed");
                })
                //elemCol.offset({top: top + scrollTop})
            })

            /**===================================================
             * Internal functions
             ====================================================*/
            function showOrHide(){
                var elemShow = scope.expanded ? elemExp : elemCol;
                var elemHide = scope.expanded ? elemCol : elemExp;

                elemShow.show();
                elemHide.hide();
            }

            function addEditLink(){
               var $edit = $('<a class="btn btn-default btn-xs gro-filter-edit" href="javascript:void(0)" role="button">Edit</a>');
               $edit.click(function(){
                    elemExp.addClass("gro-pos-fixed");
                    scope.$evalAsync(function(){
                        scope.expanded = true;
                    })
               })
               elemCol.append($edit)
            }
        } // link
       }
    }]) //directive

})(angular, jQuery, window);