(function($, global){
	'use strict';
	
	var currentScript = $('script').last();
	var currentScriptSrc = currentScript[0].src;
	
	var baseUrl = currentScriptSrc.replace("/resources/js/gro-login.js","");
	function init(){
		if ( !global.eBayGRO || !global.eBayGRO.util ){
			alert("Please include " + baseUrl + "/resources/js/common/util.js before gro-login.js");
			return;
		}
		
		
		var util = global.eBayGRO.util;
		var userInfo = util.getUserInfo();
		//no login
		if ( userInfo.uid === '' ){
			$("body").hide();
			var currentUrl = window.location.href;
			window.location.href=baseUrl + "/auth/login?old_url=" + btoa(currentUrl);
		}
	}
	init();
	
})(jQuery, window);