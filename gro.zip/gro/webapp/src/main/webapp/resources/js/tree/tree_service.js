!function(angular){
'use strict';

angular.module('tree-service', [ 'ui.bootstrap' ])

.factory('modalService', ['$http','$q','$modal', function($http,$q,$modal){
	var modalInstance = null;
	return {
		open : function(obj){
			modalInstance = $modal.open({
				animation : true,
				templateUrl : 'itemSave.html',
				controller : 'itemSaveController',
				size : 'lg',
				resolve : {
					data : function() {
						return obj;
					}
				}
			});
			return this;
		},
		whenClose : function(callback){
			modalInstance.result.then(callback , callback);
		}
		,close : function(){
			modalInstance.close();
		},
		dismiss :function(){
			modalInstance.dismiss('cancel');
		}
	};
}])

.factory('treeService', ['$http','$q', function($http ,$q ){
	function httpPost(url , obj ,transformRes){
		var prefix = window.eBayGRO.CONTEXT_PATH+'/tree/';
		var deferred = $q.defer();
		var config = {method:'post',url : prefix + url};
		if(obj){
			config.data = obj;
		}
		if(transformRes){
			config.transformResponse = transformRes;
		}
		$http(config).success(function(data) {
			deferred.resolve(data);
		}).error(function(data) {
			deferred.reject(data);
		});  
		return deferred.promise;
	}
	
	return {
		saveTree : function(obj){
			return httpPost('tree_save',obj);
		},
		queryTreeMeta : function(){
			return httpPost('tree_meta');
		},
		queryTreeJson : function(){
			return httpPost('tree_json');
		},
		deleteItem : function(obj){
			return httpPost('tree_delete',obj);
		},
		publishTree : function(){
			return httpPost('tree_publish',null,function (data){
				return data;
			});
		},
		queryItem : function(obj){
			return httpPost('tree_item',obj);
		}
    };
}]);

}(angular);