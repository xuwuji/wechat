(function($, global){
	//global.DSSUI_DEBUG = true;
	var gro = global.eBayGRO = global.eBayGRO || {};
	var util = gro.util = gro.util || {};
	
	util.GRO_TOKEN = "gro-token";
	
	function getCookie(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
	    }
	    return "";
	}
	
	function getUserInfo(){
		var groToken = getCookie(util.GRO_TOKEN);
		if ( groToken === "" ) return {uid: "", name: ""};
		var rtnArray = /uid\|([^,]+)/.exec(groToken);
		var uId = "";
		if ( rtnArray != null  ){
			uId = atob(rtnArray[1]);
		}
		
		rtnArray = /name\|([^,]+)/.exec(groToken);
		var name = "";
		if ( rtnArray != null  ){
			name = atob(rtnArray[1]);
		}
		return {uid: uId, name: name};
	}
	
	function getHashParams() {
	    var hashParams = {};
	    var e,
	        a = /\+/g,  // Regex for replacing addition symbol with a space
	        r = /([^&;=]+)=?([^&;]*)/g,
	        d = function (s) { return decodeURIComponent(s.replace(a, " ")); },
	        q = window.location.hash.substring(1);

	    while (e = r.exec(q)) hashParams[d(e[1])] = d(e[2]);
	    
	    return hashParams;
	}
	
	function track(prod,app,page,user){
		if ( !prod ) prod = "GRO";
		if ( !app ) app = "Unknown";
		if ( !page ) page = "Unknown";
		if ( !user || "" === user ) user = "Unknown";

        var TRACKING_SITEID=12;
		var piwikTracker, pkBaseURL;
	    if (typeof Piwik !== "undefined" && Piwik !== null) {
	        pkBaseURL = ("https:" === document.location.protocol ? "https" : "http") + "://opspiwik.corp.ebay.com/piwik/";
	        piwikTracker = Piwik.getTracker("" + pkBaseURL + "piwik.php", TRACKING_SITEID);      // 1 is the website ID, replace it with your site ID
	        piwikTracker.setCustomVariable(1, "User", user, "visit");  // 1 is custom variable id, no need to change it. This line is to add custom variable "User"
	        piwikTracker.setCustomVariable(2, "App", app, "page");  // 1 is custom variable id, no need to change it. This line is to add custom variable "User"
	        piwikTracker.setCustomVariable(3, "PageName", page, "page");  // 1 is custom variable id, no need to change it. This line is to add custom variable "User"
	        piwikTracker.setCustomVariable(4, "Prod", prod, "page");  // 1 is custom variable id, no need to change it. This line is to add custom variable "User"

	        piwikTracker.trackPageView();
	        return piwikTracker.enableLinkTracking();
	    }else{
	    	this.console.warn("Piwik if not defined or null.");
	    };
	};
	
	
	/*function to convert xml text to an json object*/
	function xml2json(strXml){
		var typeX2js = typeof X2JS;
		if ( typeX2js !== 'function' ){
			util.console.error("X2JS is not included, return null.");
			return null;
		}

		var x2Js = new X2JS();
		return x2Js.xml_str2json(strXml);
	}

	function getSiteIDByURL(url){
		if ( url === null ) return -1;
		url = url.toLowerCase();
		if ( url.indexOf(".ebay.com") >= 0 ) return 0;
		if ( url.indexOf(".ebay.co.uk") >= 0 ) return 3;
		if ( url.indexOf(".ebay.de") >= 0 ) return 77;
		return -1;
	}
	
	
	//public functions
	util.getCookie = getCookie;
	util.getUserInfo = getUserInfo;
	util.getHashParams = getHashParams;
	
	util.console =  global.console || { 
		log: function(){},
		warn: function(){},
		debug: function(){},
		info: function(){},
		error: function(){}
	};
	
	util.track = track;
	util.xml2json = xml2json;
	util.getSiteIDByURL = getSiteIDByURL;
	
})(jQuery, window);
