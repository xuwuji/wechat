!function(angular) {
		'use strict';
angular.module("permission-app", [])

.controller('permissionController', ['$scope','$http',function($scope,$http) {
		var requestUrl = window.eBayGRO.CONTEXT_PATH+'/permission/permissions';		
		var config = {method:'post',url :  requestUrl};
		$http(config).success(function(data) {
			$scope.permissionData = data.resp;
		});
	}]);
}(angular);