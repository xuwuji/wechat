(function($, global){
	global.eBayGRO.config = {
		DRILL_BASE_URL: "//nous.corp.ebay.com/drill/query.json",
		REAL_TIME_BASE_URL: "//nous.corp.ebay.com/sedsrv/v1/rpp",
		//PROXY_URL : "//kairos-7327.phx01.dev.ebayc3.com/proxy/miniProxy.php/",	
		//PROXY_URL : "//kairos-proxy.corp.ebay.com/proxy/miniProxy.php/",
		PROXY_URL : "//pri-web01.corp.ebay.com/proxy/miniProxy.php/",

		RT_DEALS_ITEM_PERFORMANCE_URL: "//nous.corp.ebay.com/sedsrv/v2/deals/itemPerformance/",
        RT_DEALS_TOP_ITEM_URL: "//nous.corp.ebay.com/sedsrv/v2/deals/itemDetail/",
        RT_DEALS_SUMMARY_URL: "//nous.corp.ebay.com/sedsrv/v2/deals/summary/",
        
        RT_RPP_TOP_ITEM_URL: "//nous.corp.ebay.com/sedsrv/v1/rpp/itemDetail/",
        RT_RPP_ITEM_PERFORMANCE_URL: "//nous.corp.ebay.com/sedsrv/v1/rpp/itemPerformance?",
        GRO_ENOTIFY_URL: "//enotify.corp.ebay.com/rss/notification?product=GRO+Communication"
        //GRO_ENOTIFY_URL: "//enotify.corp.ebay.com/rss/notification?type=m&product=BPE-Nous"
	};
})(jQuery, window);