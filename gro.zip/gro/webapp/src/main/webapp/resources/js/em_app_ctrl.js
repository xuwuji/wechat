(function(angular, global){
    'use strict';

    var eBayGROUtil = global.eBayGRO.util;

    var epApp = angular.module('emApp',['GroEnotifyModule', 'angular-bootstrap-select', 'daterangepicker', 'cptServices', 'ui.bootstrap', 'datatables', 'highcharts-ng']);
		epApp.config([ "GroEnotify.messageProvider",
			function(messageProvider) {
				messageProvider.setOption({
					eNotifyURL : eBayGRO.config.GRO_ENOTIFY_URL,
				});
			}
		]);

    var epCtrl = epApp.controller('EventMonitorCtrl', ['$scope', '$timeout', 'cptEventService', '$modal', '$log', '$http', 'DTOptionsBuilder',
      function($scope, $timeout, cptEventService, $modal, $log, $http, DTOptionsBuilder){
        //items init as below
        var chartHeight = 250;
        var colors = ['#2f7ed8', '#0d233a', '#8bbc21', '#910000', '#1aadce', '#f28f43' ,'#77a1e5','#492970', '#c42525', '#a6c96a'];
        $scope.data = {};
        $scope.chartType = 'line';
        $scope.items = [];
        $scope.chartHeight = chartHeight + "px";
        $scope.topItem = {};
        $scope.overlay = true;
        $scope.eventFlag = false;
        $scope.searchType = true;
        $scope.bannerFlag = false;
        $scope.displayDateTime = function(flag){
                  if(flag){
                       $("#datetime_select").attr("style","display:block;");
                       $("#datetime_normal").attr("style","display:none;");
                   }else{
                       $("#datetime_select").attr("style","display:none;");
                       $("#datetime_normal").attr("style","display:block;");
                   }
          }

        function getFromToAsLong(){
            var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
            var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
            var offset = $scope.data.timeZone;

            var strTz = "TZ00";
            if ( offset < 0 && offset > -10 ) strTz = "-0TZ00";
            if ( offset < -10  ) strTz = "-TZ00";
            if (offset >= 10 ) strTz = "TZ00";
            if ( offset > 0 && offset < 10) strTz = "0TZ00";
            
            strTz = strTz.replace(/TZ/, Math.abs(offset));
            var longFrom = moment(fromDateTime + " " + strTz, 'YYYY-MM-DD hh:mm Z').toDate().getTime();
            var longTo = moment(toDateTime + " " + strTz, 'YYYY-MM-DD hh:mm Z').toDate().getTime();
            return {from: longFrom, to: longTo};
        }
        //chart define
        function showChart(eventId){
            var eventIds = [];
            //if($scope.data.allEvent){
            eventIds.push(eventId);
            var fromTo = getFromToAsLong();

            $scope.chartDataLoaded = false;
            $scope.chartDataLoading = true;
            cptEventService.summaryOnEvents(
                {events: eventIds, from: fromTo.from, to: fromTo.to},
                function(resps){
                    var dataMap = {};
                    resps.forEach(function(resp, idx){
                                 var pageView =0; var itemClick =0; var sales =0; var soldQty =0;
                                 for(var i=0 ; i< resp.data.length; i++){
                                     pageView = pageView + resp.data[i][1];
                                     itemClick = itemClick + resp.data[i][2];
                                     sales = sales + resp.data[i][3];
                                     soldQty = soldQty + resp.data[i][4];
                                 }
                                 $scope.data.pageView =pageView;
                                 $scope.data.itemClick =itemClick;
                                 $scope.data.sales =sales;
                                 $scope.data.soldQty =soldQty;
                                 dataMap[eventIds[idx]] = resp.data;
                    });
                    $scope.chartDataLoaded = true;
                    $scope.chartDataLoading = false;


                    $timeout(function(){
                        if ( $scope.chartType == 'line' ){
                            showLineChart(dataMap,eventId);
                        }
                    }, 100);
                },

                function(){
                    $scope.chartDataLoading = false;
                    $log.error("Failed to call chart services.");
                }
            )
        }

        
        //line chart define
        var lineChartConfig = {
                    options:{
                        //global: {useUTC: true, timezoneOffset: 7*60},
                        chart: {type: 'spline',height: chartHeight},
                        xAxis: {
                            type: 'datetime',
                            dateTimeLabelFormats: {
                                hour: '%H:%M',
                                day: '%b %e'
                            }
                        },
                        legend: {enabled: false},
                        yAxis: {
                            title: { text: null },
                            showEmpty: false,
                            min: 0
                        },
                        tooltip: {shared: true},
                        plotOptions: {
                            spline: {
                                marker: {
                                    enabled: false
                                }
                            }

                        },
                        credits:{enabled:false},
                        loading:false
                    }
                }


        function showLineChart(dataMap,eventId){
            var msIn1Hour = 3600*1000;

            var fromTo = getFromToAsLong();
            var longFrom = fromTo.from;
            var longTo = fromTo.to;
            //$log.info("longFrom:"+longFrom+" longTo:"+longTo);

            var fromHour = (Math.floor(longFrom/msIn1Hour))*msIn1Hour;
            var toHour = (Math.floor(longTo/msIn1Hour))*msIn1Hour;

            var timeRange = new Array();
            for(var i=0; i<=(toHour-fromHour)/msIn1Hour;i++){
                timeRange.push(fromHour +  i * msIn1Hour);
            }

            timeRange.indexof = function(value) {
            	var a = this;
            	for (var i = 0; i < a.length; i++) {
            		if (a[i] == value)
            		    return i;
                }
            }

            var newEvents = new Array();
            var tempArray = new Array();

                for(var i=0;i<timeRange.length;i++){
                    tempArray[i]=new Array();
                    for(var j=0; j < 5; j++){
                        if(j==0){
                            tempArray[i][0]=timeRange[i];
                        }else{
                            tempArray[i][j]=0;
                        }
                    }
                }

                
                var dataArray = dataMap[eventId];

                for(var i=0; i<dataArray.length; i++){
                    var index = timeRange.indexof(dataArray[i][0]);
                    tempArray[index][1]=dataArray[i][1];
                    tempArray[index][2]=dataArray[i][2];
                    tempArray[index][3]=dataArray[i][3];
                    tempArray[index][4]=dataArray[i][4];
                }

                var finalArray = new Array();
                finalArray[0] = new Array();
                finalArray[1] = new Array();
                finalArray[2] = new Array();
                finalArray[3] = new Array();
                for(var i=0; i<tempArray.length; i++){
                    finalArray[0][i] = tempArray[i][1];
                    finalArray[1][i] = tempArray[i][2];
                    finalArray[2][i] = tempArray[i][3];
                    finalArray[3][i] = tempArray[i][4];
                }
               // var eventName=$("#data.event").find("option:selected").text();
               // var eventName="test";
               // alert(eventName);
                newEvents.push({finalArray:finalArray});

            $scope.chartTrafficConfig = angular.merge({}, lineChartConfig);
            $scope.chartEng1Config = angular.merge({}, lineChartConfig);
            $scope.chartTxnConfig = angular.merge({}, lineChartConfig);
            $scope.chartGmvConfig = angular.merge({}, lineChartConfig);


            lineChart($scope.chartTrafficConfig, "Page Views", 'PV', newEvents,        fromHour, msIn1Hour);
            lineChart($scope.chartEng1Config, "In Page Item Click", "Clicks", newEvents,     fromHour ,msIn1Hour);
            lineChart($scope.chartTxnConfig, "In Page Sold Quantity", "Quantity", newEvents,     fromHour,msIn1Hour);
            lineChart($scope.chartGmvConfig, "In Page Sales", "Sales", newEvents, fromHour,msIn1Hour);
        }

        function lineChart(config, type, yTitle,  newEvents, fromTime, pointInterval){
            config.options.chart.type = "spline";
            config.options.title = {"text": type};
            config.options.yAxis.title.text = null;
            if($scope.data.timeZone==-8){
                Highcharts.setOptions({
                        global: {
                            useUTC: true,
                            timezoneOffset: 8 * 60
                        }
                    });
            }else if($scope.data.timeZone==0){
                Highcharts.setOptions({
                        global: {
                            useUTC: true,
                            timezoneOffset: 0
                        }
                    });
            }else if($scope.data.timeZone==1){
                Highcharts.setOptions({
                        global: {
                            useUTC: true,
                            timezoneOffset: 0
                        }
                    });
            }else if($scope.data.timeZone==10){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 0
                    }
                });
            }else if($scope.data.timeZone==-5){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 5 * 60
                    }
                });
            }else if($scope.data.timeZone==5){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 0
                    }
                });
            }else if($scope.data.timeZone==-4){
                Highcharts.setOptions({
                    global: {
                        useUTC: true,
                        timezoneOffset: 4 * 60
                    }
                });
            }

            var seriesData = [];
            newEvents.forEach(function(row, idx){
                //var line = {name: row.name}
                var color = colors[idx % colors.length];
                
                var defaultSeries = {color: color, name: type, pointStart: fromTime, pointInterval: pointInterval};
                
                if(type=="Page Views"){
                    seriesData.push(angular.merge({data: row.finalArray[0]}, defaultSeries));
                }else if(type=="In Page Item Click"){
                    seriesData.push(angular.merge({data: row.finalArray[1]}, defaultSeries));
                }else if(type=="In Page Sold Quantity"){
                    seriesData.push(angular.merge({data: row.finalArray[3]}, defaultSeries));
                }else if(type=="In Page Sales"){
                    seriesData.push(angular.merge({data: row.finalArray[2]}, defaultSeries));
                }
            })
            config.series = seriesData;
        }

        $scope.timeZones = [
                            {value: -8, display: "PDT"},
                            {value: 0, display: "GMT"},
                            {value: 1, display: "CET"},
                            {value: 10, display: "EAST"},
                            {value: -5, display: "EST"},
                            {value: 5, display: "IST"},
                            {value: -4, display: "AST"}
                           ];


        $scope.sites = [
            {value: 0, display: "US"},
            {value: 3, display: "UK"},
            {value: 77, display: "DE"},
            {value: 15, display: "AU"},
            {value: 2, display: "CA"},
            {value: 203, display: "IN"},
            {value: 101, display: "IT"},
            {value: 210, display: "CA(fr)"},
            {value: 186, display: "ES"},
            {value: 71, display: "FR"}
        ];

        $scope.bys = [
                    {value: 0, display: "Event"},
                    {value: 1, display: "URL"},
                ];
        $scope.devices = [
                          {value: 0, display: "All"}
                      ];
            
        $scope.experiences = [
                      {value: 0, display: "Core Sites"}
                  ];

        
        function changeTime(new_offset,old_offset){
        	 if(typeof(old_offset)== "undefined"){
        		 var d = new Date();
                 var localTime = d.getTime();
                 var localOffset = d.getTimezoneOffset() * 60000;
                 var utc = localTime + localOffset;

                 var calctime = utc + (3600000*new_offset);
                 var now = moment(calctime);
                 var yesterday = now.clone().add(-7,'d');
                 $scope.data.fromDate = yesterday.format('YYYY-MM-DD');
                 $scope.data.fromTime = yesterday.format('HH:mm');
                // $scope.data.fromTime = yesterday.format('HH')+":00";
                 $scope.data.toDate = now.format('YYYY-MM-DD');
                 $scope.data.toTime = now.format('HH:mm');
                 //$scope.data.toTime = now.format('HH')+":00";
                 
                 if($scope.data.fromDate < "2015-10-05"){
                 	$scope.data.fromDate = "2015-10-05";
                 }
                 
                 var start = $scope.data.fromDate;
                 var end = $scope.data.toDate;
                 $("#fromDate").datetimepicker('setStartDate', start);
                 $("#fromDate").datetimepicker('setEndDate', end);
                 //$("#fromTime").datetimepicker('setStartDate', start);

                 $("#toDate").datetimepicker('setStartDate', start);
                 $("#toDate").datetimepicker('setEndDate', end);
               //$("#toTime").datetimepicker('setEndDate', end);
        	 }else{
        		//get old time
                 var d = new Date();
                 var localOffset = d.getTimezoneOffset() * 60000;
                 
                 var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
                 var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
                 var longFrom = new Date(fromDateTime.replace("-","/").replace("-","/")).getTime() - (3600000*(old_offset));
                 var longTo = new Date(toDateTime.replace("-","/").replace("-","/")).getTime() - (3600000*(old_offset));
                 
                //set new time
                var from = moment(longFrom + (3600000*(new_offset)));
                var to = moment(longTo + (3600000*(new_offset)));
               
                $scope.data.toDate = to.format('YYYY-MM-DD');
                $scope.data.toTime = to.format('HH:mm');
                
                $scope.data.fromDate = from.format('YYYY-MM-DD');
                $scope.data.fromTime = from.format('HH:mm');
        	 }
           
        }
        
        function formatEventTime(utcTime){
            var offset = $scope.data.timeZone;
            var d = new Date();
            var localOffset = d.getTimezoneOffset() * 60000;

            var calctime = parseInt(utcTime) + parseInt(3600000*offset) + parseInt(localOffset);
            var dateTime = moment(calctime);
            return dateTime.format('YYYY-MM-DD HH:mm');
        }
        
        function checkTimeZone(countryCode){
                    if(countryCode==0){
                        $scope.data.timeZone = -8;
                    }else if(countryCode==3){
                        $scope.data.timeZone = 0;
                    }else if(countryCode==77){
                        $scope.data.timeZone = 1;
                    }else if(countryCode==15){
                        $scope.data.timeZone = 10;
                    }else if(countryCode==2){
                        $scope.data.timeZone = -5;
                    }else if(countryCode==203){
                        $scope.data.timeZone = 5;
                    }else if(countryCode==101){
                        $scope.data.timeZone = 1;
                    }else if(countryCode==210){
                        $scope.data.timeZone = -4;
                    }else if(countryCode==186){
                        $scope.data.timeZone = 1;
                    }else if(countryCode==71){
                        $scope.data.timeZone = 1;
                    }
                }
        
        function cleanData(){
        	 $("#alertMessageLeft").remove();
        	 //$("#alertMessageRight").remove();
        	 $("#proxyIFrame").attr("src","");
        	 $scope.bannerFlag = false;	
        	 $scope.eventName = "";
			 $scope.eventFrom = "";
			 $scope.eventTo = "";
        	 $scope.data.url = "";
             $scope.topItem = {};
             $scope.data.pageView = 0;
             $scope.data.itemClick = 0;
             $scope.data.sales = 0;
             $scope.data.soldQty = 0;
             $scope.chartDataLoaded = false;
             $scope.overlay = true;
        }
        //site changes triggers event group reloading.
        $scope.eventGroupLoading = false;
        
        $scope.$watch("data.by", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
            $("#activeTime").show();
            //$("#overlay").show();
            //clean data
            //cleanData();
            if(newValue==0){
            	$scope.searchType = true;
            }else{
            	$scope.searchType = false;
            }
        });
        
        $scope.$watch("data.site", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
            //clean data
           // cleanData();
            
            //console.log("site value changes from", oldValue, 'to', newValue);
            checkTimeZone(newValue);
            //$scope.timeZone = $("#timeZone").find("option:selected").text();;
            $scope.eventGroupLoading = true;
            cptEventService.queryEventGroups(
                newValue,
                function(data){
                    //console.log("success", data);
                    $scope.eventGroups = data;
                    if ( $scope.eventGroups.length > 0 )
                    	if($scope.data.site==0){
                    		$scope.data.eventGroup = "54243245e4b0d359ae4cd084";//set default as "holidays"
                    	}else{
                    		$scope.data.eventGroup = $scope.eventGroups[0].value;
                    	}
                    $scope.eventGroupLoading = false;
                },
                function(){
                    //console.log("failed");
                    $scope.eventGroupLoading = false;
                }
            );
        });

        //event-group changes triggers event reload.
        $scope.eventMap = {};
        $scope.eventLoading = false;
        $scope.$watch("data.eventGroup", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
          //clean data
           // cleanData();
            
            $scope.eventLoading = true;
            cptEventService.queryEvents(newValue,
                function(data){
                   // events_id2name = {};
                    $scope.events = data;
                    if ( $scope.events.length > 0 ){
                        $scope.data.event = $scope.events[0].value;
                       /* data.forEach(function(row, idx){
                        	row.from = formatEventTime(row.start);
                        	row.to = formatEventTime(row.end);
                        	$scope.eventMap[row.value] = row;
                        })*/
                    }
                    $scope.eventLoading = false;
                },
                function(){
                    $scope.eventLoading = false;
                });
            
        });
        
        
        //event changes triggers event reload.
        $scope.$watch("data.event", function(newValue, oldValue){
            if ( newValue == oldValue ) return;
            //clean data
            //cleanData();
        });
        
       $scope.$watch("data.timeZone", function(newValue, oldValue){
                  if ( newValue == oldValue ) return;
                   changeTime(newValue,oldValue);
                  // $scope.timeZone = $("#timeZone").find("option:selected").text();
              });

       /*$scope.$watch("data.siteURL", function(newValue, oldValue){
           if ( newValue == oldValue ) return;
           alert("I have changed");
       });*/
       /*Time range selector by time interval (minute/hour/day)*/
       /*$scope.$watch("data.fromDate", function(newValue, oldValue){
           //if ( newValue == oldValue ) return;
           // changeTime($scope.data.timeZone);
           // $scope.timeZone = $("#timeZone").find("option:selected").text();
    	   if($scope.data.fromDate=="2015-10-25"){
    		   //$("#fromTime").attr("disabled",true)
    		   $("#fromTime").attr("minView","day")
    		   $("#fromTime").datetimepicker({
    		        enabled :false,
    		        autoclose: true,
    		        format: "hh:ii",
    		        startView:"day",
    		        minView:"day",
    		        formatViewType: "time"
    		   	 });
    	   }else{
    		   //$("#fromTime").attr("disabled",false)
    		   $("#fromTime").empty();
    		   $("#fromTime").datetimepicker({
   		        enabled :false,
		        autoclose: true,
		        format: "hh:ii",
		        startView:"day",
		        minuteStep: 1,
		        formatViewType: "time"
		   	 });
    	   }
       });*/


        $timeout(function(){
            $scope.data.site = 0;
            $scope.data.timeZone = -8;
            $scope.data.by = 0;
            $scope.data.device = 0;
            $scope.data.experience = 0;
        });


        $scope.topItemDtOptions = DTOptionsBuilder.newOptions()
                            .withOption("lengthMenu", [ [5, 10, 25, 50, -1], [5,10, 25, 50, "All"] ])
        					.withOption("order", [[ 2, "desc" ]]);
        //prepare for click event
        var ITEM_PREFIX = "hash=item";
		var POPUP_CONTAINER = "popup-container";
		var global_from_to = {};

		document.domain = "ebay.com";

		var is_iframe_loaded = false;
		var current_cover = null;
		var gcolors = $.BPE.gradient_colors([255,255,255],[255,0,0],254);

		var gConfigService = $.BPE.page_config_service({iframe_doc_fn: iframe_doc});
		var gPageConfig = null;

		var gid = '';
		var gitem_info = null;
		var grealtime_service = null;
		var pid = '';
		var modules = null ; 

		var gscale = 1.0;


		function cover_internal($elems, item_map, pInterval, gid){
			if ( !gitem_info ) return;
			$(".proxy_cover_div", iframe_doc()).remove();
			$(".webui-popover").remove();

			var min_click = Math.pow(2,32) - 1, max_click = -999;
			$.each(item_map, function(item_key, item){
				var click = item.click;
				if ( min_click > click ) min_click = click;
				if ( max_click < click ) max_click = click;
			});

			$elems.each(function(idx){
				var $this = $(this);
				var item_info = gitem_info.extract_content_info($(this));
				if ( item_info === null ) return;
				var key = gitem_info.getKeyByItem(item_info);//item_info.id + "-" + item_info.sp;

				var offset = $this.offset();
				var top = offset.top, left = offset.left, width = $this.innerWidth(), height = $this.innerHeight(), margin_left = $this.css('margin-left');

				var item = item_map[key];
				var rgb = gcolors.get_rgb_color(min_click, max_click, item.click);

				var $cover_div = $("<div class='proxy_cover_div container-fluid'><div class='row'></div></div></div></div>");

				$cover_div.css({
					opacity: 0.4,
					height: height,
					width: width,
					top: top,
					left: left,
					"z-index": 1000,
					position: "fixed",
					overflow: "overlay",
					background: rgb,
					border: "1px solid black"});

				$cover_div.data(POPUP_CONTAINER, $this);
				var $content = gitem_info.popover_content({content_info: item, interval: pInterval, gid : gid});
				$cover_div
						.webuiPopover('destroy')
						.webuiPopover({
							content: $content,
							trigger:'hover',
							delay: 0,
							placement:'top',
							arrow: false,
							animation: 'fade',
							multi: false ,
							width: '400px'})
						.on('shown.webui.popover', function(e){
							var container = $(this).data(POPUP_CONTAINER);
							var iframeTop = $iframe().offset().top;
							var iframeLeft = $iframe().offset().left;

							var scrollTop = $($iframe()[0].contentWindow).scrollTop();
							var scrollLeft = $($iframe()[0].contentWindow).scrollLeft();

							var $popover = $(".webui-popover.in");

							var voffset = container.offset();
							var newTop = voffset.top * gscale + iframeTop - scrollTop;
							var newLeft = voffset.left * gscale + iframeLeft - scrollLeft;

							if ( newLeft < 0 ) newLeft = iframeLeft;
							$popover.offset({top: newTop, left: newLeft});

							gitem_info.content_shown({container:$popover, content_info: item});
						});
				$(iframe_doc().body).append($cover_div);
			});
		}


		var createCovering = false;
		function create_covers(fromTo, gid, siteId){
			if ( createCovering ) {
				eBayGROUtil.console.info("Covers are being created, skip duplicate one.");
				return;
			}
			createCovering = true;

			var $elems = gitem_info.areas_highlighted(iframe_doc());//$("div.gl-itm:has(a.ranc)",iframe_doc());
			var item_list = gitem_info.extract_contents($elems);
			//var interval = 24*60;
			var interval = 0;//default
			
			grealtime_service.ajaxGetDealInfo({
					"from-to": fromTo,
					"content-type": "summary",
					"item-info":item_list,
					"siteId":siteId
				}, function(item_map){
		            showIframe();
		            cover_internal($elems, item_map, interval, gid);
				}, function(){
					alert("service call failed.");
				}, function(){
					createCovering = false;
				}
			);
		};

		//bug fix -- not showing scrollbar
		//deals.ebay.com page will set min-height value on dd-container div, this may cause scrollbar shown.
		//set it to 0 to disable the scrollbar.
		function bugfix_no_scrollbar(){
			var x = $("#dd-container",iframe_doc()).css("min-height");
			//console.log("min-height", x);
			if ( x && x !== "0px" ){
				$("#dd-container",iframe_doc()).css("min-height", "0px");
				setTimeout(function(){
					bugfix_no_scrollbar();
				}, 50);
			}
		}


		function showIframe(){
			$("#iframe-loading").hide();
			$iframe().show();
			bugfix_no_scrollbar();
		}


		function hideIframe(){
			$("#iframe-loading").show();
			$iframe().hide();
		}

		function iframe_doc(){
			return $iframe()[0].contentWindow.document;
		};

		function $iframe(){
			return $("#proxyIFrame");
		}

		function fetchUrl(url){
			var aEle = document.createElement("a");
			aEle.href = url;
			var path = aEle.pathname.toLowerCase();
			if ( !path.startsWith("/") ) path = "/" + path;
			aEle.remove();
			if ( path === '/' ) path = "/daily-deals";
			if ( path.endsWith('/') ) path = path.slice(0, -1); //remove last "/"
			return path;
		}

		function showMessageLeft(succesmessage){
		    var success = $('<div id="alertMessageLeft" class="alert alert-warning" style="position: fixed;left: 21%;top: 20%;z-index: 10000;"><a href="#" class="close" data-dismiss="alert">&times;</a><strong></strong>'+succesmessage+'</div>');
		    success.appendTo('body');
		}
		
		
		 $("#iframe-container").resize(function(){
          		var container_size = $(this).innerWidth();
          		gscale = 1;
          		if ( container_size < 1280 ) {
          			gscale = container_size / 1280;
          		}

          		$iframe().css({
          			"transform": "scale(" + gscale + ")",
          			"transform-origin": "0 0 0"
          		})
          	});
		 
		 	
	   		var old_body = null;
     		$("#proxyIFrame").load(function(){
     			document.domain = "ebay.com";
     			$("#activeTime").show();
     			$("#alertMessageLeft").remove();
     			//before iframe is reloaded.
     			$($iframe()[0].contentWindow).unload(function(){
     				is_iframe_loaded = false;
     				hideIframe();
     			});

     			is_iframe_loaded = true;
     			bugfix_no_scrollbar();

     	           //update site value
     			var href = iframe_doc().location.href.replace(/http(s)?:/i,'');
     			var PROXY_URL = window.eBayGRO.config.PROXY_URL;
     			var proxyUrl = PROXY_URL.replace(/http(s)?:/i,'');

     	        var ebay_url = href.substr(proxyUrl.length);
     	        //eBayGROUtil.console.info("siteid", eBayGROUtil.getSiteIDByURL(ebay_url));
     	        $("#siteURL").val(ebay_url);
     	        var siteId = eBayGROUtil.getSiteIDByURL(ebay_url)
     	        if(siteId==0 || siteId==3 || siteId==77){
    				$scope.eventFlag = true;
    			}else{
    				$scope.eventFlag = false;
    			}
     	        gitem_info = null, gid = null, grealtime_service = null, pid = null, modules = null ;
     	        var eId = null;

     			gPageConfig = gConfigService.lookup_conf({url: ebay_url, doc: iframe_doc()})
     			if ( gPageConfig ) {
     				gid = gPageConfig.group;
     				gitem_info = gPageConfig.item_info;
     				pid = gPageConfig.pageid;
       				modules = gPageConfig.modules({doc: iframe_doc()});
       				if ( gid === 'rpp' ){
       					eId = gitem_info.getEID(iframe_doc());
       				}
     			}

     			if ( gitem_info ) grealtime_service = gitem_info.options.realtime_item_service;
     			if ( old_body ) old_body.unbind('resize');
     			var new_body = $('body', iframe_doc());

     			//$iframe().css("height", iframe_doc().body.clientHeight);
     			var fromTo = getFromToAsLong();
     			new_body.resize(function(){
     				//console.log("resize");
     				//$iframe().css("height", iframe_doc().body.clientHeight);
     				if ( is_iframe_loaded && gitem_info ) create_covers(fromTo,gid,siteId);
     			});
     			old_body = new_body;

     			if(!gitem_info) {
     				$('#page_support_not_indi').show();
    	            $('#page_support_indi').hide();
    	            $("#chartTraffic").empty();
    	            $("#chartEng1").empty();
    	            $("#chartGmvTraffic").empty();
    	            $("#chartTxn").empty();
    				showIframe();
    				$("#chartDataLoading").hide();
    				$("#itemDetailLoading").hide();
    				$("#activeTime").hide();
    				$(".page-overlay").eq(0).css('display',"none");
    				if(ebay_url!=""){
    					showMessageLeft("Warning! This page is not supported by the tool.");
    				}
    				
     				return;
     			}// not find valid item for the page;

     			$('#page_support_not_indi').hide();
     	        $('#page_support_indi').show();
     	       
     			var $that = $(this);
         		setTimeout(
    				function(){
          				var old_height = parseInt($that.css("height"),10);
          				var new_height = iframe_doc().body.clientHeight + 10;
          				//console.log("old:", old_height, "new:", new_height);
          				if ( old_height < new_height ) {
          					$that.css("height", new_height + "px");
          				}
          				create_covers(fromTo,gid,siteId);
    				}, 10
    			);
         		$(window).trigger('PAGE_URL_CHANGED', {ebay_url:ebay_url, fromTo:fromTo, gid:gid, modules: modules, eid: eId, siteId: siteId});
     		});
     		
     		$(window).on('PAGE_URL_CHANGED', function(e, data){
     			var fromTo = data.fromTo;
	            var ebay_url = data.ebay_url;
	            var gid = data.gid;
	            var modules = data.modules;
	            var siteId = data.siteId;
	            
    			$scope.eventName = "";
				$scope.eventFrom = "";
				$scope.eventTo = "";
	            $scope.topItem = {};
	            $scope.data.pageView = 0;
	            $scope.data.itemClick = 0;
	            $scope.data.sales = 0;
	            $scope.data.soldQty = 0;
	            $scope.itemDetailLoading = true;
	            
	            var eventId = data.eid;

				if(gid === 'rpp' && eventId != null){
					cptEventService.queryEvent(eventId,
		                    function(resp){
								if(resp.data.rows[0].event_name==null){
										$("#activeTime").hide();
								}
		            	 		$scope.eventName = resp.data.rows[0].event_name;
		            	 		if(resp.data.rows[0].start_ts !=null){
 									$scope.eventFrom = formatEventTime(resp.data.rows[0].start_ts);
 								}
 								if(resp.data.rows[0].end_ts != null){
 									$scope.eventTo = formatEventTime(resp.data.rows[0].end_ts);
 								}
								$scope.timeZone = $("#timeZone").find("option:selected").text();
								$scope.bannerFlag = true;
								showChart(eventId);
								//check whether need reset query or not
								var eventGroup = resp.data.rows[0].event_group_id;
								if($scope.data.by == 0){
									if($scope.data.eventGroup != eventGroup){
										$scope.data.eventGroup = eventGroup;
										$timeout(function(){
											$scope.data.event = eventId;
					       	 	        },2000);
										
									}else{
										if($scope.data.event!=eventId){
											$scope.data.event = eventId
										}
									}
								}else{
									if($scope.data.url != ebay_url){
	         		                	$scope.data.url = ebay_url;
	         		                }
								}
					});
					
					cptEventService.itemDetailOnEvent(
		                    {from: fromTo.from, to: fromTo.to, eventId: eventId},
		                    function(resp){
		                        $scope.topItem.data = resp.data;
		                        $scope.itemDetailLoading = false;
		                        $scope.overlay = false;
		                    },
		                    function(){
		                        $scope.itemDetailLoading = false;
		                        $scope.overlay = false;
		                    }
		            );
				}else{
					if(gid=="deals"){
						$scope.eventFlag = false;
						//when user input deals url, but not select timezone, need set default timezone by url's site
       	 			 	checkTimeZone(siteId);
	       	 			$timeout(function(){
	       	 				var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
		       	 			var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
		       	 			var timeZone = $("#timeZone").find("option:selected").text();
	       	 			 	$scope.data.time2time = "From "+ fromDateTime+ " to " + toDateTime + " " + timeZone;
	       	 	        },100);
						//end
							
						
						$("#activeTime").hide();
						//get deals data
						$scope.chartDataLoaded = false;
                        $scope.chartDataLoading = true;
                        
                        
     					cptEventService.summaryOnDeals({pageId: pid, modules : modules, siteId: siteId, from : fromTo.from, to : fromTo.to},
     		                    function(resp){
     								//console.log("resp:"+resp);
     								var pageView =0; var itemClick =0; var sales =0; var soldQty =0;
     								var finalArray = new Array();
     	                                finalArray[0] = new Array();
     	                                finalArray[1] = new Array();
     	                                finalArray[2] = new Array();
     	                                finalArray[3] = new Array();
     								
     		                        var msIn1Hour = 60*60*1000;
     		                        var longFrom = fromTo.from;
     		                        var longTo = fromTo.to;
     		                        var day = (longTo - longFrom)/(24*msIn1Hour);
     		                        if(day>1){
     		                        	var fromHour = (Math.floor(longFrom/msIn1Hour))*msIn1Hour;
     		                            var toHour = (Math.floor(longTo/msIn1Hour))*msIn1Hour;

     		                            var timeRange = new Array();
     		                            for(var i=0; i<=(toHour-fromHour)/msIn1Hour;i++){
     		                                timeRange.push(fromHour +  i * msIn1Hour);
     		                            }

     		                            timeRange.indexof = function(value) {
     		                            	var a = this;
     		                            	for (var i = 0; i < a.length; i++) {
     		                            		if (a[i] == value)
     		                            		    return i;
     		                                }
     		                            }
     		                            var tempArray = new Array();

     		                            for(var i=0;i<timeRange.length;i++){
     		                                tempArray[i]=new Array();
     		                                for(var j=0; j < 5; j++){
     		                                    if(j==0){
     		                                        tempArray[i][0]=timeRange[i];
     		                                    }else{
     		                                        tempArray[i][j]=0;
     		                                    }
     		                                }
     		                            }
     		                            
     		                           for(var i=0; i<resp.data.length; i++){
  	                                      pageView = pageView + resp.data[i][4];
  	                                      itemClick = itemClick + resp.data[i][1];
  	                                      sales = sales + resp.data[i][2];
  	                                      soldQty = soldQty + resp.data[i][3];
      	                                  
  	                                      var index = timeRange.indexof(Math.floor(resp.data[i][0]/msIn1Hour)*msIn1Hour);
  	                                      tempArray[index][1] = tempArray[index][1] + resp.data[i][4];
  	                                      tempArray[index][2] = tempArray[index][2] + resp.data[i][1];
  	                                      tempArray[index][3] = tempArray[index][3] + resp.data[i][2];
  	                                      tempArray[index][4] = tempArray[index][4] + resp.data[i][3];
     		                           }
     		                          for(var i=0; i<tempArray.length; i++){
     		                             finalArray[0][i] = tempArray[i][1];
     		                             finalArray[1][i] = tempArray[i][2];
     		                             finalArray[2][i] = tempArray[i][3];
     		                             finalArray[3][i] = tempArray[i][4];
     		                          }
     		                            
     		                       }else{
     		                        	for(var i=0; i<resp.data.length; i++){
   	                                      pageView = pageView + resp.data[i][4];
   	                                      itemClick = itemClick + resp.data[i][1];
   	                                      sales = sales + resp.data[i][2];
   	                                      soldQty = soldQty + resp.data[i][3];
       	                                  
                                    	  finalArray[0][i] = resp.data[i][4];
     	                                  finalArray[1][i] = resp.data[i][1];
     	                                  finalArray[2][i] = resp.data[i][2];
     	                                  finalArray[3][i] = resp.data[i][3];
     		                        	}
     		                       }
 	                                $scope.data.pageView =pageView;
 	                                $scope.data.itemClick =itemClick;
 	                                $scope.data.sales =sales;
 	                                $scope.data.soldQty =soldQty;
                                      
                                     var msIn1Minute = 60*1000;
                                     var fromMinute = (Math.floor(longFrom/msIn1Minute))*msIn1Minute;
                                     var fromHour = (Math.floor(longFrom/msIn1Hour))*msIn1Hour;
                                     
                                     var newEvents = new Array();
                                     newEvents.push({finalArray:finalArray});

                                     $scope.chartTrafficConfig = angular.merge({}, lineChartConfig);
                                     $scope.chartEng1Config = angular.merge({}, lineChartConfig);
                                     $scope.chartTxnConfig = angular.merge({}, lineChartConfig);
                                     $scope.chartGmvConfig = angular.merge({}, lineChartConfig);
                                     if(day>1){//show chart by hours
                                    	 lineChart($scope.chartTrafficConfig, "Page Views", 'PV', newEvents,        fromHour, msIn1Hour);
                                         lineChart($scope.chartEng1Config, "In Page Item Click", "Clicks", newEvents,     fromHour, msIn1Hour);
                                         lineChart($scope.chartTxnConfig, "In Page Sold Quantity", "Quantity", newEvents,     fromHour , msIn1Hour);
                                         lineChart($scope.chartGmvConfig, "In Page Sales", "Sales", newEvents, fromHour, msIn1Hour);
                                     }else{//show chart by minutes
                                         lineChart($scope.chartTrafficConfig, "Page Views", 'PV', newEvents,        fromMinute, msIn1Minute);
                                         lineChart($scope.chartEng1Config, "In Page Item Click", "Clicks", newEvents,     fromMinute, msIn1Minute);
                                         lineChart($scope.chartTxnConfig, "In Page Sold Quantity", "Quantity", newEvents,     fromMinute , msIn1Minute);
                                         lineChart($scope.chartGmvConfig, "In Page Sales", "Sales", newEvents, fromMinute, msIn1Minute);
                                     }
                                     
	                                     
 	                                 $scope.chartDataLoaded = true;
                                     $scope.chartDataLoading = false;
                                       
     							}
     					);
     					//top items
     					cptEventService.itemDetailOnDeals({pageId: pid, modules : modules, siteId: siteId, from: fromTo.from, to: fromTo.to},
 		                    function(resp){
 		                        $scope.topItem.data = resp.data;
 		                        $scope.itemDetailLoading = false;
 		                        $scope.overlay = false;
 		                        
 		                    },
 		                    function(){
 		                        $scope.itemDetailLoading = false;
 		                        $scope.overlay = false;
 		                    }
 		                );
     					if($scope.data.url!=ebay_url){
 		                	$scope.data.url=ebay_url;
 		                }
     					
					}
				}
    		});
		 
			
        //click event
        $scope.applyClick = function(){

            if($scope.data.fromDate =="" ||$scope.data.fromTime =="" ||$scope.data.toDate ==""|| $scope.data.toTime ==""){
                alert("Please select time range !");
                return;
            }

            var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
            var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;

            if ( fromDateTime >= toDateTime ){
                alert("Wrong from/to time range !");
                return;
            }
            
            //check URL
            if($scope.data.by!=0 && (typeof($scope.data.url) == "undefined" || $scope.data.url =="")){
            	alert("Please input URL !");
                return;
            }
            //check the selected time range 
            var fromTo = getFromToAsLong();
	        var msIn1Hour = 60*60*1000;
	        var longFrom = fromTo.from;
	        var longTo = fromTo.to;
	        var day = (longTo - longFrom)/(24*msIn1Hour);
	        if(day>7){
	        	$scope.data.fromTime = "00:00";
	        	$scope.data.toTime = "00:00";
	        }else if(day>1){
	        	var fromTime = $scope.data.fromTime;
	        	var toTime = $scope.data.toTime;
	        	$scope.data.fromTime = fromTime.substring(0,3)+"00";
	        	$scope.data.toTime = toTime.substring(0,3)+"00";
	        }
	        var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
            var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
            var timeZone=$("#timeZone").find("option:selected").text();
            $scope.data.time2time = "From "+ fromDateTime+ " to " + toDateTime + " " + timeZone;
            $scope.timeZone = timeZone;
            $("#datetime_select").css("display","none");
            $("#datetime_normal").css("display","block");

            $("#chartDataLoading").show();
			$("#itemDetailLoading").show();
            $scope.itemDetailLoading = true;
            $scope.chartDataLoading = true;
            $(".page-overlay").eq(0).css('display',"block");
            $(".page-overlay span").css('display',"none");
            $(".page-overlay img").css('display',"block")
            $scope.overlay = true;
            //get items
             var PROXY_URL = window.eBayGRO.config.PROXY_URL;
    		 $scope.eventName = "";
			 $scope.eventFrom = "";
			 $scope.eventTo = "";
             $scope.topItem = {};
             $scope.data.pageView = 0;
             $scope.data.itemClick = 0;
             $scope.data.sales = 0;
             $scope.data.soldQty = 0;
             $("#chartTraffic").empty();
             $("#chartEng1").empty();
             $("#chartGmvTraffic").empty();
             $("#chartTxn").empty();
            if($scope.data.by==0){//search by event id
            	 var eventId = $scope.data.event;
	             //left split panel
	             cptEventService.queryEvent(eventId,
	                    function(resp){
	            	 		var eventURL = resp.data.rows[0].url;
							$scope.bannerFlag = true;	
	            	 		if(eventURL!=null){
	                             var url = PROXY_URL + eventURL;
	                             $("#proxyIFrame").attr("src",url);
	                     		 is_iframe_loaded = false;
	                     		 hideIframe();
	            	 		}else{
	            	 			$("#proxyIFrame").attr("src","");
	            	 			var message = "Warning! This event is expired ! "
	            	 			showMessageLeft(message);
	            	 		}
	           			   
	                    },function(){//errors
	            	 			$("#proxyIFrame").attr("src","");
	            	 			var message = "Warning! Connection is time out ! "
	            	 			showMessageLeft(message);
	                    }
	                )
            }else{//search by URL
            	
    	 		var eventURL = $scope.data.url;
    	 		if(eventURL!=null){
		 			 //set the suitable timezone by url
		 			cptEventService.queryEventCountryByURL(eventURL,
		                    function(resp){
		            	 		var countryCode = resp.data.rows[0].site_id;
		       	 			 	checkTimeZone(countryCode);
			       	 			$timeout(function(){
			       	 				var fromDateTime = $scope.data.fromDate + " " +$scope.data.fromTime;
				       	 			var toDateTime = $scope.data.toDate + " " +$scope.data.toTime;
				       	 			var timeZone = $("#timeZone").find("option:selected").text();
			       	 			 	$scope.data.time2time = "From "+ fromDateTime+ " to " + toDateTime + " " + timeZone;
			       	 	        },100);
		 					});
		 			
	                var url = PROXY_URL + eventURL;
	                $("#proxyIFrame").attr("src",url);
	         		is_iframe_loaded = false;
	         		hideIframe();
    	 		}
	                                          
            }
        }

        
         $scope.downloadItems = function(){
                         var dataList = $scope.topItem.data;
                         var str = "In Page Items,Total Item Click,In Page Item Click,Total Sales,In Page Sales,Total Sold Quantity,In Page Sold Quantity"+ "\n";
                         for(var i=0;i<dataList.length;i++)
                         {
                             var row = dataList[i];
                             str = str + row.id+ "," +row.totalClick+ "," +row.dealsClick+ "," +row.totalGMV+ "," + row.dealsGMV+ "," + row.totalQty + "," + row.dealsQty + "\n";
                         }
                         var csvname = 'Top Items.csv';
                         var blob = new Blob([str], {type: "text/csv;charset=utf-8"});
                         saveAs(blob, csvname);
                  }
    }]);


})(angular, window);
