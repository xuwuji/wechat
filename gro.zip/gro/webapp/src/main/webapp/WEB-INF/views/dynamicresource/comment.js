(function($, global) {
	"use strict";
	
	var currentScript = $('script').last();
	var currentScriptSrc = currentScript[0].src;
	
	var baseUrl = currentScriptSrc.replace("/dr/comment.js","");
	
	function init(){
		if ( !global.eBayGRO || !global.eBayGRO.util ){
			alert("Please include " + baseUrl + "/resources/js/common/util.js before comment.js");
			return;
		}
		
		var util = global.eBayGRO.util;
		
		// ==================== configuration for different env ======================
		if ('dev' === '${ENV}') {
			util.console.log('comment.js: Get updated version by appending ?debug=true');
		}
	
		var configAll = {
			'qa' : {
				comUrl : '//nous.corp.ebay.com'
			},
	
			'dev' : {
				comUrl : '//nous.corp.ebay.com'
			},
			'prod' : {
				comUrl : '//nous.corp.ebay.com'
			}
		};
		// ===================== config done ==========================================
	
		var config = configAll['${ENV}'];
		var comUrl = config.comUrl;
	
		var llWidth = 0;
		
	
		$(document).ready(function() {
			function resizeIfr(ele) {
				var win = $('.nous-com-ifr')[0].contentWindow;
				win.postMessage(JSON.stringify({
					"width" : llWidth,
					"success" : "ok",
					"indi" : "resize"
				}), "*");
				$('iframe').show();
			}
				
			if (global.addEventListener) {
				global.addEventListener("message", receiveMessage,false);
			} else {
				if (global.attachEvent) {
					global.attachEvent("onmessage", receiveMessage);
				}
			}
	
			function receiveMessage(event) {
				var eData = event.data;
	
				if (!eData.success) eData = JSON.parse(event.data);
	
				if (eData.indi == 'resize') {
					$('.nous-com-ifr').height(eData.height + 50 + 'px');
				}
	
				else if (eData.indi == 'reply'){
					$('html, body').animate({
						scrollTop : $(".nous-comments").offset().top - 100
					},'normal');
				}
			}
	
			var cl = $('.nous-comments');
	
			setInterval(function() {
				var nnWidth = $(cl).parent().width() - 10;
				if (nnWidth != llWidth && nnWidth > 0) {
					llWidth = nnWidth;
					$('.nous-com-ifr').width(nnWidth);
					resizeIfr(null);
				}
			}, 100);
	
			var cd = $(cl).data();
			if ( cd == null ) return;
	
			if (cd.href == null) {
				alert("comment: href can't be empty.");
				return;
			}
			
			var cdHref = cd.href + "-" + "${ENV}";
	
			if (cd.width == null) {
				cd.width = $(cl).parent().width() - 10;
			}
	
			if (cd.theme == null) {
				cd.theme = 'light';
			}
	
			if (cd.numposts == null) cd.numposts = 6;
			var userInfo = util.getUserInfo();
			
			var $iframe = 
				$('<iframe class="nous-com-ifr" style ="border:none;width:100%;" src="'
					+ comUrl
					+ '/comment/grolistlazy?width='
					+ cd.width
					+ '&numposts='
					+ cd.numposts
					+ '&href='
					+ encodeURIComponent(cdHref)
					+ '&uid=' + userInfo.uid
					+ '&uname=' + encodeURIComponent(userInfo.name)
					+ '"></iframe>');
			$iframe.load(function(){
				resizeIfr(null);
			});
			
			$(cl).append($iframe);
		});
	}//init
	
	init();
})(jQuery, window);