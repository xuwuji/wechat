package com.ebay.bis.gro.interceptor;

import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ebay.bis.gro.exception.ApplicationException;
import com.ebay.bis.gro.utils.Constants;
import com.ebay.bis.gro.utils.CookieUtils;
import com.ebay.bis.gro.utils.GroConfig;
import com.ebay.bis.gro.utils.GroToken;

public class AuthCheckInterceptor implements HandlerInterceptor {
	private final static Logger logger = LoggerFactory.getLogger(AuthCheckInterceptor.class);
	
	@Autowired
	private GroConfig config;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String loginEnabled = config.getValue(GroConfig.LOGIN_ENABLED);
		if ( !"true".equalsIgnoreCase(loginEnabled) ) return true;
		
		Cookie[] cookies = request.getCookies();
		if ( cookies == null ) cookies = new Cookie[0];
		String token = CookieUtils.getCookieByName(cookies, Constants.COOKIE_GRO_TOKEN, "");
		//String contextPath = request.getServletContext().getContextPath();
		RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/auth/pre-login");
		
		//token is not found.
		if ( StringUtils.isEmpty(token) ){
			dispatcher.forward(request, response);
			return false;
		}
		
		//verify token
		GroToken groToken = new GroToken(token);
		try{
			Map<String, String> kvs = groToken.decryptT(config.getGroCookieKey());
			
			//set user id into request attributes, so that subsequent operations can get it.
			String uid = kvs.get("uid");
			String level = kvs.get("l");
			request.setAttribute(Constants.CURRENT_USER_ID, uid);
			request.setAttribute(Constants.USER_LEVEL, level);
		}catch(ApplicationException ae){
			logger.error("Failed to decrypt gro-token,", ae);
			dispatcher.forward(request, response);
			return false;
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		
	}

}
