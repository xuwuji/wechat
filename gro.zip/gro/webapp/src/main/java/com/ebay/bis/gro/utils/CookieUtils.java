package com.ebay.bis.gro.utils;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;

public class CookieUtils {
	public static String getCookieByName(Cookie[] cookies, String nameToFind, String defaultValue){
		String result = defaultValue;
		
		//find cookie with name of "gro-token"
		for ( Cookie cookie : cookies ){
			String name = cookie.getName();
			String value = cookie.getValue();
			//logger.info("Name:" +  name + " ,Value: " + value);
			
			if ( StringUtils.equals(nameToFind, name)){
				return value;
			}
		}
		return result;
	}
}
