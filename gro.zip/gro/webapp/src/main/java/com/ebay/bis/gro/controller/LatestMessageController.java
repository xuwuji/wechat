package com.ebay.bis.gro.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ebay.bis.gro.datamodel.pojo.LatestMessage;
import com.ebay.bis.gro.datamodel.pojo.RestResponse;
import com.ebay.bis.gro.service.GroupKeyValueService;
import com.ebay.bis.gro.utils.Constants;
import com.ebay.bis.gro.utils.GroConfig;
import com.ebay.bis.gro.utils.JsonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
@RequestMapping("/latestmessage")
public class LatestMessageController {
	
	@Autowired 
	private GroConfig config;
	
	@Autowired 
	private GroupKeyValueService service;

	@RequestMapping(path="/{id}.json", method=RequestMethod.GET)
	@ResponseBody
	public String getLatestMessage(@PathVariable("id") String userId, HttpServletRequest req) throws JsonProcessingException{
		String loginUserId = (String)req.getAttribute(Constants.CURRENT_USER_ID);
		if ( StringUtils.isEmpty(loginUserId) ){
			return JsonUtil.writeValueAsString(RestResponse.LOGIN_ERROR);
		}
		String jsonTxt = service.queryValueByGroupKey(GroupKeyValueService.GROUP_LASTMESSAGE, loginUserId);
		if ( null == jsonTxt ){
			return JsonUtil.writeValueAsString(new LatestMessage(loginUserId, "-1", -1L));
		}

		return jsonTxt;
		//return String.format("{\"userId\": \"%s\", \"guid\":\"123\", \"pubDate\":1320782900000}", loginUserId);
	}
}