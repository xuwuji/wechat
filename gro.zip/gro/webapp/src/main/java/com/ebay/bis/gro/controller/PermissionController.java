package com.ebay.bis.gro.controller;

import com.ebay.bis.gro.exception.ErrorCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ebay.bis.gro.datamodel.db.PermissionDo;
import com.ebay.bis.gro.datamodel.pojo.RestResponse;
import com.ebay.bis.gro.service.PermissionService;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/permission")
public class PermissionController {
	
	@Autowired
	private PermissionService ps;
	
	@RequestMapping(path="/adduser", method=RequestMethod.GET)
	@ResponseBody
	public RestResponse addUser(@RequestParam("path") String path, @RequestParam("users") String users) throws JsonProcessingException{
		if ( StringUtils.isEmpty(path) || StringUtils.isEmpty(users) ){
			return RestResponse.errorResponse(ErrorCode.INVALID_INPUT, "resource and user can't be empty.");
		}
		PermissionDo p = ps.addUserToPath(path, users);
		if ( null == p ){
			return RestResponse.errorResponse(ErrorCode.NOT_FOUND, String.format("Path '%s' not found.", path));
		}
		return RestResponse.goodResponse(p);
	}

	@RequestMapping(path="/removeuser", method=RequestMethod.GET)
	@ResponseBody
	public RestResponse removeUser(@RequestParam("path") String path, @RequestParam("users") String users) throws JsonProcessingException{
		if ( StringUtils.isEmpty(path) || StringUtils.isEmpty(users) ){
			return RestResponse.errorResponse(ErrorCode.INVALID_INPUT, "resource and user can't be empty.");
		}
		PermissionDo p = ps.removeUserFromPath(path, users);
		if ( null == p ){
			return RestResponse.errorResponse(ErrorCode.NOT_FOUND, String.format("Path '%s' not found.", path));
		}
		return RestResponse.goodResponse(p);

	}

	/**
	 * To check if the given user have the rights to access the given resource.
	 * @param resource
	 * @param user
     * @return
     */
	@RequestMapping(path="/pubsvc/check", method=RequestMethod.GET)
	@ResponseBody
	public RestResponse checkPermission(@RequestParam("resource") String resource, @RequestParam("user") String user){
		if ( StringUtils.isEmpty(resource) || StringUtils.isEmpty(user) ){
			return RestResponse.errorResponse(ErrorCode.INVALID_INPUT, "resource and user can't be empty.");
		}

		boolean granted = ps.hasPermission(resource, user);
		Map<String, Boolean> result = new HashMap();
		result.put("access", granted);
		return RestResponse.goodResponse(result);
	}
	
	@RequestMapping(path="/permissions", method=RequestMethod.POST)
	@ResponseBody
	public RestResponse getPermissions() throws JsonProcessingException{
		List<PermissionDo> list = ps.getPermissions();
		return RestResponse.goodResponse(list);
	}
	
}
