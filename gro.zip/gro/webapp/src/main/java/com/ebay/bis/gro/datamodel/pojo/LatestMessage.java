package com.ebay.bis.gro.datamodel.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LatestMessage {
	private String userId;
	private String guid;
	private long pubDate;

	public LatestMessage(String userId, String guid, long pubDate) {
		super();
		this.userId = userId;
		this.guid = guid;
		this.pubDate = pubDate;
	}

	@JsonProperty("userId")
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@JsonProperty("guid")
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}

	@JsonProperty("pubDate")
	public long getPubDate() {
		return pubDate;
	}
	public void setPubDate(long pubDate) {
		this.pubDate = pubDate;
	}

}
