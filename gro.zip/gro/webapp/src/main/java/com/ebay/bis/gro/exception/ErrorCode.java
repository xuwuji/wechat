package com.ebay.bis.gro.exception;

/**
 * Created by wenliu2 on 12/17/15.
 */
public enum ErrorCode {
    INVALID_INPUT(422, "Invalid Input"),
    NOT_FOUND(404, "Not Found"),
    LOGIN_NEEDED(-100, "Login Needed");

    private int value;
    private String msg;
    ErrorCode(int value, String msg){
        this.value = value;
        this.msg = msg;
    }

    public int getValue(){
        return value;
    }
    public String getMsg() {
        return msg;
    }
}
