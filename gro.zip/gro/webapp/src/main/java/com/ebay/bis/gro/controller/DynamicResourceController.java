package com.ebay.bis.gro.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ebay.bis.gro.service.TreeConfigService;
import com.ebay.bis.gro.utils.CacheUtils;
import com.ebay.bis.gro.utils.GroConfig;

@Controller
@RequestMapping("/dr") //dynamic resource
public class DynamicResourceController {
	private static final Logger logger = LoggerFactory.getLogger(DynamicResourceController.class);
	
	@Autowired 
	private GroConfig config;
	
	@Autowired
	private CacheUtils cacheUtils;
	
	@Autowired
	private TreeConfigService service;
	
	
	@RequestMapping(path="/comment.js", method=RequestMethod.GET)
	@ResponseBody
	public String commentJs(HttpServletRequest req, 
			@RequestParam(name="debug", required=false, defaultValue="false") boolean debug) throws IOException{
		String env = config.getValue(GroConfig.GRO_ENV);
		logger.info("commentJs is called, debug = " + debug);
		String realPath = req.getServletContext().getRealPath("/WEB-INF/views/dynamicresource/comment.js");
		return cacheUtils.getTextWithReplacement(realPath, env, "${ENV}", debug);
	}
	
	@RequestMapping(path="/menu.json", method=RequestMethod.GET)
	@ResponseBody
	public  String menuJson(@RequestParam("base") String base, 
			@RequestParam(name="debug", required=false, defaultValue="false") boolean debug,
			HttpServletRequest req) throws IOException{
		String env = config.getValue(GroConfig.GRO_ENV);
		String text = service.queryTree(null);
		return text.replace("${BASE}", base);
	}
}
