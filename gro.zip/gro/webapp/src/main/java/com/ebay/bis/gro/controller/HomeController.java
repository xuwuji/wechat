package com.ebay.bis.gro.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ebay.bis.gro.utils.GroConfig;

@Controller
@RequestMapping("/home")
public class HomeController {
	@Autowired 
	private GroConfig config;
	
	@RequestMapping(path="/t/{prefix}", method=RequestMethod.GET)
	public ModelAndView t(@PathVariable("prefix") String prefix){
		return new ModelAndView("home/" + prefix);
	}
	
	@RequestMapping(path="/iframe", method=RequestMethod.GET)
	public ModelAndView iframe(@RequestParam("url") String url, Map<String, Object>model){
		model.put("url", url);
		return new ModelAndView("home/iframe", model);
	}
	
	/**
	 * command_id is used by PermissonCheck to identify current command, 
	 * no matter what command_id is, home/iframe is always used as view.
	 */
	@RequestMapping(path="/iframe/{command_id}", method=RequestMethod.GET)
	public ModelAndView iframeCommandId(@RequestParam("url") String url, Map<String, Object>model){
		model.put("url", url);
		return new ModelAndView("home/iframe", model);
	}
}
