package com.ebay.bis.gro.utils;

public final class Constants {
	public static final String UTF8 = "UTF-8";
	public static final String COOKIE_GRO_TOKEN = "gro-token";
	public static final String CURRENT_USER_ID = "req.current.user.id";
	public static final String REQUEST_PATH = "req.request_path";
	public static final String USER_LEVEL = "req.request_level";
}
