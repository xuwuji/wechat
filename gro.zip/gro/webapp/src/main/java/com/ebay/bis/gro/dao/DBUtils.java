package com.ebay.bis.gro.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.BeanProcessor;

import com.ebay.bis.gro.datamodel.pojo.KeyValue;

public class DBUtils {
	private static BeanProcessor beanProcessor = new BeanProcessor();
	public static <T> List<T> toBeanList(ResultSet rs, Class<T> type) throws SQLException{
		return beanProcessor.toBeanList(rs, type);
	}

	public static Map<String, Object> listToMap(NamedParameterKeyValue ... list){
		Map<String, Object> m = new HashMap<String, Object>();
		for ( KeyValue<String, Object> kv : list ){
			m.put(kv.getKey(), kv.getValue());
		}
		return m;
	}

	public static NamedParameterKeyValue KV(String key, Object value){
		return new NamedParameterKeyValue(key, value);
	}
}
