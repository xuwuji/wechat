package com.ebay.bis.gro.utils;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import com.ebay.bis.gro.exception.ApplicationException;
import com.google.common.io.BaseEncoding;

//import org.apache.commons.codec.binary.Base64;

public class TrippleDes {
	//no change this PADDING_STR
	private static final String PADDING_STR = "=!@3^7%3$##$#%^&*(5tr432wddghhttt224t-";
	
	private static final String UNICODE_FORMAT = "UTF8";
	public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	private KeySpec ks;
	private SecretKeyFactory skf;
	private Cipher cipher;
	byte[] arrayBytes;
	private String myEncryptionKey;
	private String myEncryptionScheme;
	SecretKey key;

	public TrippleDes() {
		this("DEFAULT_KEY");
	}

	public TrippleDes(String passwd) {
		try {
			if ( passwd.length() < 24 ) passwd = passwd + PADDING_STR;
			myEncryptionKey = passwd;
			myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
			arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
			ks = new DESedeKeySpec(arrayBytes);
			skf = SecretKeyFactory.getInstance(myEncryptionScheme);
			cipher = Cipher.getInstance(myEncryptionScheme);
			key = skf.generateSecret(ks);
		} catch (Exception e) {
			throw new ApplicationException("excpetion when init tripple des", e);
		}
	}

	public String encrypt(String unencryptedString) {
		String encryptedString = null;
		try {
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
			byte[] encryptedText = cipher.doFinal(plainText);
			BaseEncoding be = BaseEncoding.base64();
			encryptedString = new String(be.encode(encryptedText));
		} catch (Exception e) {
			throw new ApplicationException("excpetion when encrypt", e);
		}
		return encryptedString;
	}

	public String decrypt(String encryptedString) {
		String decryptedText = null;
		try {
			cipher.init(Cipher.DECRYPT_MODE, key);
			BaseEncoding be = BaseEncoding.base64();
			byte[] encryptedText = be.decode(encryptedString);
			byte[] plainText = cipher.doFinal(encryptedText);
			decryptedText = new String(plainText);
		} catch (Exception e) {
			throw new ApplicationException("excpetion when decrypt", e);
		}
		return decryptedText;
	}

	/*
	 * public static void main(String args []) throws Exception { TimeDifference
	 * timed = new TimeDifference(); timed.start();
	 * 
	 * TrippleDes td= new TrippleDes(); System.out.println("construct: " +
	 * timed.pass(true));
	 * 
	 * //String target="imparator";
	 * 
	 * for ( int i=0; i<10; i++){ String target = RandomStringUtils.random(i);
	 * System.out.println("random: " + timed.pass(true));
	 * 
	 * String encrypted=td.encrypt(target); System.out.println("Encrypt: " +
	 * timed.pass(true));
	 * 
	 * String decrypted=td.decrypt(encrypted); System.out.println("Decrypt: " +
	 * timed.pass(true));
	 * 
	 * 
	 * //System.out.println("String To Encrypt: "+ target);
	 * //System.out.println("Encrypted String:" + encrypted);
	 * //System.out.println("Decrypted String:" + decrypted); if (
	 * !decrypted.equals(target) ){ System.out.println("failed."); } }
	 * 
	 * System.out.println("OK."); }
	 */

}
