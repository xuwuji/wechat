package com.ebay.bis.gro.datamodel.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class GroupKeyValueDo {
	private int id;
	private String group;
	private String key;
	private String value;
	private Timestamp createDt;
	private Timestamp lastModifiedDt;

	public GroupKeyValueDo(){
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Timestamp getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}
	public Timestamp getLastModifiedDt() {
		return lastModifiedDt;
	}
	public void setLastModifiedDt(Timestamp lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public static GroupKeyValueDo fromResultSet(ResultSet rs) throws SQLException{
		GroupKeyValueDo kv = new GroupKeyValueDo();
		kv.setId(rs.getInt("id"));
		kv.setGroup(rs.getString("group"));
		kv.setKey(rs.getString("key"));
		kv.setValue(rs.getString("value"));
		kv.setCreateDt(rs.getTimestamp("create_dt"));
		kv.setLastModifiedDt(rs.getTimestamp("last_mod_dt"));
		return kv;
	}
}
