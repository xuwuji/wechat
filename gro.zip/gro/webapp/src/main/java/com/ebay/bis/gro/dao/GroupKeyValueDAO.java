package com.ebay.bis.gro.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import com.ebay.bis.gro.datamodel.db.GroupKeyValueDo;

@Repository
public class GroupKeyValueDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	class SimpleListRowHandler implements RowCallbackHandler{
		public SimpleListRowHandler(){};
		private List<GroupKeyValueDo> result = new ArrayList<GroupKeyValueDo>();
		public void processRow(ResultSet rs) throws SQLException{
			result.add(GroupKeyValueDo.fromResultSet(rs));
		}
		public List<GroupKeyValueDo> getResult(){
			return result;
		}
	}

	public GroupKeyValueDo queryByGroupKey(final String group, final String key) {
		String sql = "select * from group_keyvalue t where t.group = ? and t.key = ?";
		SimpleListRowHandler handler = new SimpleListRowHandler(); 
		jdbcTemplate.query(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, group);
				ps.setString(2, key);
			}
		}, handler);
		List<GroupKeyValueDo> list = handler.getResult();
		if ( list.size() == 0 ) return null;
		return list.get(0);
	}

	/*
	public void addNewResource(final String resource) {
		String sql = "INSERT INTO resource (resource_content) VALUES (?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, resource);
			}
		});
	}

	public void deleteRole(final String roleId) {
		String sql = "DELETE FROM role WHERE id = ?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
			}
		});
	}
	*/
}
