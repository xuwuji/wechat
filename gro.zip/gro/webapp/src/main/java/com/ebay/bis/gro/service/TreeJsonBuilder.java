package com.ebay.bis.gro.service;

import com.ebay.bis.gro.datamodel.db.Item;

public interface TreeJsonBuilder {
	
	void buildAttrs(StringBuilder sb, Item cur);
	
	public void buildChildren(StringBuilder sb);
	
}
