package com.ebay.bis.gro.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.math3.util.Precision;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ebay.bis.gro.utils.GroConfig;
import com.ebay.bis.gro.utils.KylinSQLBuilder;
import com.ebay.bis.gro.utils.RetailDimensionMapping;
import com.ebay.bis.gro.utils.TimeRangeGenerator;
import com.ebay.bis.gro.utils.TimeRangeGenerator.TimeRangeIdType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

@RestController
@RequestMapping("/categoryservice")
public class GroCategoryPerformanceController {
	// Parameter Names
	private static final String FILTER_TYPE = "filterType";
	private static final String SQL_PARAMS = "sqlParams";
	private static final String KYLIN_PARAMS = "kylinParams";
	private static final String REFRESH_DATE = "refreshDate";
	private static final String UP_TO_DATE = "up2Date";
	private static final String IS_COMPARE = "iscompare";
	private static final String TIME_RANGE_TYPE = "timeRangeType";
	private static final String METRIC_TYPE = "metricType";
	private static final String SGMT_TYPE = "sgmtType";
	private static final String SUB_CATG = "subCatg";
	private static final String TIME_RANGE = "timerange";
	private static final String WEEKS = "weeks";
	private static final String QUARTERS = "quarters";
	private static final String YEARS = "years";
	private static final String CURRENT = "current";
	private static final String LAST = "last";
	private static final String SQL_PARAMS_FIELD = "field";
	private static final String SQL_PARAMS_VALUE = "value";
	private static final String KYLIN_SQL_PARAM = "sql";
	private static final String RESP_RESULTS = "results";
	private static final String SUMMARY_HEADERS = "headers";
	private static final String SUMMARY_METRICS = "metrics";
	private static final String SUMMARY_METRICS_CP = "cpmetrics";
	private static final String ABS_FIELD = "abs";
	private static final String YOY_FIELD = "yoy";
	private static final String SHARE_PERCENTAGE = " Share %";

	private static final String VP_LEVEL = "CATG_MAPPING_PROC4.VP_LEVEL";
	private static final String NEW_VERTICAL_DEFINITION = "CATG_MAPPING_PROC4.NEW_VERTICAL_DEFINITION";
	private static final String MERCHANT1_ROLLUP = "CATG_MAPPING_PROC4.MERCHANT1_ROLLUP";
	private static final String MERCHANT2_ROLLUP = "CATG_MAPPING_PROC4.MERCHANT2_ROLLUP";
	private static final String VA_MAPPED_META = "CATG_MAPPING_PROC4.VA_MAPPED_META";
	private static final String GRANULAR_LEVEL1 = "CATG_MAPPING_PROC4.GRANULAR_LEVEL1";
	private static final String GRANULAR_LEVEL2 = "CATG_MAPPING_PROC4.GRANULAR_LEVEL2";
	private static final String SLR_SGMT = "SLR_SGMT";
	private static final String LSTG_TYPE = "LSTG_TYPE";
	private static final String ITEM_CNDTN = "ITEM_CNDTN";
	private static final String PRICE_TRANCHE = "PRICE_TRANCHE";
	private static final String GTC_FLAG = "GTC_FLAG";
	private static final String DD_FLAG = "DD_FLAG";
	private static final String METRIC_GMV = "GMV";
	private static final String METRIC_LL = "LIVE_LSTG_CNT";
	private static final String METRIC_SI = "QUANTITY";
	private static final String METRIC_EL = "ENDED_LSTG_CNT";
	private static final String METRIC_NL = "NEW_LSTG_CNT";
	private static final String METRIC_FL = "FRESH_LSTG_CNT";

	private static final String RTL_WEEK_BEG_DT = "RTL_WEEK_BEG_DT";
	private static final String QTR_ID = "QTR_ID";
	private static final String YEAR_ID = "YEAR_ID";

	private static final String[] SLR_VALUES = { "B2C MD", "B2C UD", "C2C" };
	private static final String[] LT_VALUES = { "ABin", "Auc", "FP" };
	private static final String[] COND_VALUES = { "New", "Refurbished", "Used" };
	private static final String[] PTR_VALUES = { "$0-$20", "$20-$100", "$100-$500", ">=$500" };
	private static final String[] MISC_VALUES = { "DD", "GTC" };
	private static final String[] CHART_COLORS = { "#628CD1", "#8FDC87", "#D7B875" };

	@Autowired
	private GroConfig config;

	/**
	 * Get all filters by this method.
	 * 
	 * @param filter
	 * @param requestEntity
	 * @param request
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping(value = "/filters", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String queryFilters(HttpEntity<ObjectNode> requestEntity, HttpServletRequest request) throws Throwable {
		ObjectNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}
		String filter = requestBody.get(FILTER_TYPE).asText();
		String filterName = "";
		switch (filter) {
		case "vp":
			filterName = VP_LEVEL;
			break;
		case "nv":
			filterName = NEW_VERTICAL_DEFINITION;
			break;
		case "mc1rp":
			filterName = MERCHANT1_ROLLUP;
			break;
		case "mc2rp":
			filterName = MERCHANT2_ROLLUP;
			break;
		case "meta":
			filterName = VA_MAPPED_META;
			break;
		case "gralev1":
			filterName = GRANULAR_LEVEL1;
			break;
		case "gralev2":
			filterName = GRANULAR_LEVEL2;
			break;
		}

		String sql = KylinSQLBuilder.buildFilterSQL(filterName, (ArrayNode) requestBody.get(SQL_PARAMS));
		JsonNode kylinParams = requestBody.get(KYLIN_PARAMS);
		if (kylinParams == null) {
			throw new Exception("The Kylin request parameters can not be empty!");
		}
		((ObjectNode) kylinParams).put(KYLIN_SQL_PARAM, sql);
		JsonNode rootNode = getResponseContent(kylinParams, request.getParameterMap());
		if (rootNode == null) {
			return "";
		}

		JsonNode resNode = rootNode.get("results");
		if (resNode == null) {
			return "";
		}

		ArrayNode result = new ArrayNode(new JsonNodeFactory(false));
		result.add("All");
		Iterator<JsonNode> it = resNode.iterator();
		while (it.hasNext()) {
			JsonNode item = it.next();
			if (item.isArray() && item.size() == 1) {
				result.add(item.get(0).asText());
			} else {
				result.add(item.asText());
			}
		}
		return result.toString();
	}

	private JsonNode getResponseContent(JsonNode kylinParams, Map<String, ?> reqParamMap) {
		if (kylinParams == null) {
			return null;
		}
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Content-Type", "application/json;charset=UTF-8");
		responseHeaders.add("Authorization", "Basic X05PVVNfUkVBRE9OTFk6QWFCYkNjQDIwITU=");
		HttpEntity<JsonNode> reqEntity = new HttpEntity<JsonNode>(kylinParams, responseHeaders);
		RestTemplate template = new RestTemplate();
		ResponseEntity<JsonNode> resp = template.exchange(config.getKylinUrl(), HttpMethod.POST, reqEntity,
				JsonNode.class, reqParamMap);
		return resp.getBody();
	}

	/**
	 * Retrieve for weeks metrics data
	 * 
	 * @param requestEntity
	 * @param request
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping(value = "/getRefreshDate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getRefreshedDate(HttpEntity<JsonNode> requestEntity, HttpServletRequest request) throws Exception {
		JsonNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}
		JsonNode kylinParams = requestBody.get(KYLIN_PARAMS);
		if (kylinParams == null) {
			throw new Exception("The Kylin request parameters can not be empty!");
		}
		((ObjectNode) kylinParams).put(KYLIN_SQL_PARAM, KylinSQLBuilder.buildRefreshDateSQL());
		JsonNode rootNode = getResponseContent(kylinParams, request.getParameterMap());
		if (rootNode == null) {
			return "";
		}
		JsonNode resNode = rootNode.get("results");
		if (resNode == null) {
			return "";
		}

		String refreshDate = resNode.get(0).get(0).asText();

		ObjectNode result = new ObjectNode(new JsonNodeFactory(false));
		result.put(REFRESH_DATE, refreshDate);
		result.put(UP_TO_DATE, TimeRangeGenerator.addDaysToDate(TimeRangeGenerator.getRecentWeekQuarterYearID(null, 1, TimeRangeIdType.RTL_WEEK_BEG_DT).get(0), 6));
		ObjectNode weeks = result.putObject(WEEKS);
		ObjectNode quarters = result.putObject(QUARTERS);
		ObjectNode years = result.putObject(YEARS);

		List<String> recentWeeks = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshDate,
				TimeRangeGenerator.getTrailingNumber(TimeRangeIdType.RTL_WEEK_BEG_DT), TimeRangeIdType.RTL_WEEK_BEG_DT);
		ArrayNode curweeks = weeks.putArray(CURRENT);
		ArrayNode lstweeks = weeks.putArray(LAST);
		for (String w : recentWeeks) {
			curweeks.add(w);
			lstweeks.add(TimeRangeGenerator.getYoYWeekQuarterYearID(w));
		}

		List<String> recentQuarters = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshDate,
				TimeRangeGenerator.getTrailingNumber(TimeRangeIdType.QTR_ID), TimeRangeIdType.QTR_ID);
		ArrayNode curquarters = quarters.putArray(CURRENT);
		ArrayNode lstquarters = quarters.putArray(LAST);
		for (String q : recentQuarters) {
			curquarters.add(q);
			lstquarters.add(TimeRangeGenerator.getYoYWeekQuarterYearID(q));
		}

		List<String> recentYears = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshDate,
				TimeRangeGenerator.getTrailingNumber(TimeRangeIdType.YEAR_ID), TimeRangeIdType.YEAR_ID);
		ArrayNode curyears = years.putArray(CURRENT);
		ArrayNode lstyears = years.putArray(LAST);
		for (String y : recentYears) {
			curyears.add(y);
			lstyears.add(TimeRangeGenerator.getYoYWeekQuarterYearID(y));
		}

		return result.toString();
	}

	/**
	 * Retrieve for weeks metrics data
	 * 
	 * @param requestEntity
	 * @param request
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping(value = "/metrics", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String queryMetricsByTR(HttpEntity<JsonNode> requestEntity, HttpServletRequest request) throws Throwable {
		JsonNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}

		boolean iscompare = requestBody.get(IS_COMPARE).asBoolean();
		String timerange = requestBody.get(TIME_RANGE_TYPE).asText();
		String refreshed = requestBody.get(REFRESH_DATE).asText();
		JsonNode time_range = requestBody.get(TIME_RANGE);
		ArrayNode cur_time_range = (ArrayNode) time_range.get(CURRENT);
		ArrayNode lst_time_range = (ArrayNode) time_range.get(LAST);
		ArrayNode sqlParams = (ArrayNode) requestBody.get(SQL_PARAMS);
		ObjectNode kylinParams = (ObjectNode) requestBody.get(KYLIN_PARAMS);
		// Create the front end data model.
		ObjectNode result = new ObjectNode(new JsonNodeFactory(false));
		ArrayNode headers = result.putArray(SUMMARY_HEADERS);
		ObjectNode metrics = iscompare ? result.putObject(SUMMARY_METRICS_CP) : result.putObject(SUMMARY_METRICS);
		ArrayNode gmv = metrics.putArray("gmv");
		ArrayNode adll = metrics.putArray("adll");
		ArrayNode si = metrics.putArray("si");
		ArrayNode asp = metrics.putArray("asp");
		ArrayNode nl = metrics.putArray("nl");
		ArrayNode el = metrics.putArray("el");
		ArrayNode str = metrics.putArray("str");
		ArrayNode fl = metrics.putArray("fl");
		ArrayNode ul = metrics.putArray("ul");
		switch (timerange) {
		case "weeks":
			String latestWeek = RetailDimensionMapping.convertToWeek(cur_time_range.get(0).asText());
			headers.add(latestWeek);
			headers.add(RetailDimensionMapping.convertToWeek(cur_time_range.get(1).asText()));
			headers.add(RetailDimensionMapping.convertToWeek(cur_time_range.get(2).asText()));
			headers.add(RetailDimensionMapping.convertToWeek(cur_time_range.get(3).asText()));
			headers.add(latestWeek.concat(SHARE_PERCENTAGE));

			ObjectNode time_range_sqlParam = sqlParams.addObject();
			time_range_sqlParam.put(SQL_PARAMS_FIELD, RTL_WEEK_BEG_DT);
			time_range_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(cur_time_range).addAll(lst_time_range);
			String sql_week = KylinSQLBuilder.buildMetricsGenericSQL(RTL_WEEK_BEG_DT, sqlParams);
			kylinParams.put(KYLIN_SQL_PARAM, sql_week);
			ArrayNode wresultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			buildMetrics(wresultRoot, gmv, adll, si, asp, nl, el, str, fl, cur_time_range, lst_time_range, true);

			time_range_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(cur_time_range);
			List<ArrayNode> curweekUIRes = getULMetricBySql(RTL_WEEK_BEG_DT, refreshed, cur_time_range, sqlParams,
					kylinParams, request);
			time_range_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(lst_time_range);
			List<ArrayNode> lstweekUIRes = getULMetricBySql(RTL_WEEK_BEG_DT,
					TimeRangeGenerator.getLastYearSameDay(refreshed), lst_time_range, sqlParams, kylinParams, request);
			buildULMetric(ul, curweekUIRes, lstweekUIRes);
			break;
		case "quarters":
			ArrayNode curQs = cur_time_range.deepCopy();
			ArrayNode lstQs = lst_time_range.deepCopy();

			String firstQ = cur_time_range.get(0).asText();
			headers.add(firstQ + "QTD");
			String curQ = cur_time_range.remove(0).asText();
			String lstQ = lst_time_range.remove(0).asText();
			headers.addAll(cur_time_range);
			headers.add(firstQ + "QTD" + SHARE_PERCENTAGE);

			String curQStartD = TimeRangeGenerator.getQuarterStartTimeAsString(refreshed);
			String lstQStartD = TimeRangeGenerator.getLastYearSameDay(curQStartD);
			String lstQEndD = TimeRangeGenerator.getLastYearSameDay(refreshed);
			long qcurAvgDays = TimeRangeGenerator.calQTDDays(refreshed);
			long qlstAvgDays = TimeRangeGenerator.calQTDDays(lstQEndD);
			String sql_qtd = KylinSQLBuilder.buildMetricsToDateSQL(QTR_ID, curQStartD, refreshed, lstQStartD, lstQEndD,
					sqlParams);
			kylinParams.put(KYLIN_SQL_PARAM, sql_qtd);
			ArrayNode qtdresultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			buildQuarterYearToDateMetrics(qtdresultRoot, gmv, adll, si, asp, nl, el, str, fl, curQ, lstQ, qcurAvgDays,
					qlstAvgDays);

			ObjectNode timerangeQ_sqlParam = sqlParams.addObject();
			timerangeQ_sqlParam.put(SQL_PARAMS_FIELD, QTR_ID);
			timerangeQ_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(cur_time_range).addAll(lst_time_range);
			String sql_quarter = KylinSQLBuilder.buildMetricsGenericSQL(QTR_ID, sqlParams);
			kylinParams.put(KYLIN_SQL_PARAM, sql_quarter);
			ArrayNode qresultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			buildMetrics(qresultRoot, gmv, adll, si, asp, nl, el, str, fl, cur_time_range, lst_time_range, false);

			timerangeQ_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(curQs);
			List<ArrayNode> curquarterUIRes = getULMetricBySql(QTR_ID, refreshed, curQs, sqlParams, kylinParams,
					request);
			timerangeQ_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(lstQs);
			List<ArrayNode> lstquarterUIRes = getULMetricBySql(QTR_ID, lstQEndD, lstQs, sqlParams, kylinParams,
					request);
			buildULMetric(ul, curquarterUIRes, lstquarterUIRes);
			break;
		case "years":
			ArrayNode curYs = cur_time_range.deepCopy();
			ArrayNode lstYs = lst_time_range.deepCopy();

			String firstY = cur_time_range.get(0).asText();
			headers.add(firstY + "YTD");
			String curY = cur_time_range.remove(0).asText();
			String lstY = lst_time_range.remove(0).asText();
			headers.addAll(cur_time_range);
			headers.add(firstY + "YTD" + SHARE_PERCENTAGE);

			String curYStartD = TimeRangeGenerator.getYearStartTimeAsString(refreshed);
			String lstYStartD = TimeRangeGenerator.getLastYearSameDay(curYStartD);
			String lstYEndD = TimeRangeGenerator.getLastYearSameDay(refreshed);
			long ycurAvgDays = TimeRangeGenerator.calYTDDays(refreshed);
			long ylstAvgDays = TimeRangeGenerator.calYTDDays(lstYEndD);
			String sql_ytd = KylinSQLBuilder.buildMetricsToDateSQL(YEAR_ID, curYStartD, refreshed, lstYStartD, lstYEndD,
					sqlParams);
			kylinParams.put(KYLIN_SQL_PARAM, sql_ytd);
			ArrayNode ytdresultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			buildQuarterYearToDateMetrics(ytdresultRoot, gmv, adll, si, asp, nl, el, str, fl, curY, lstY, ycurAvgDays,
					ylstAvgDays);

			ObjectNode timerangeY_sqlParam = sqlParams.addObject();
			timerangeY_sqlParam.put(SQL_PARAMS_FIELD, YEAR_ID);
			timerangeY_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(cur_time_range).addAll(lst_time_range);
			String sql_year = KylinSQLBuilder.buildMetricsGenericSQL(YEAR_ID, sqlParams);
			kylinParams.put(KYLIN_SQL_PARAM, sql_year);
			ArrayNode yresultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			buildMetrics(yresultRoot, gmv, adll, si, asp, nl, el, str, fl, cur_time_range, lst_time_range, false);

			timerangeY_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(curYs);
			List<ArrayNode> curyearUIRes = getULMetricBySql(YEAR_ID, refreshed, curYs, sqlParams, kylinParams, request);
			timerangeY_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(lstYs);
			List<ArrayNode> lstyearUIRes = getULMetricBySql(YEAR_ID, lstYEndD, lstYs, sqlParams, kylinParams, request);
			buildULMetric(ul, curyearUIRes, lstyearUIRes);
			break;
		}
		return result.toString();
	}

	private List<ArrayNode> getULMetricBySql(String timerangeType, String lessDate, ArrayNode trparams,
			ArrayNode sqlParams, ObjectNode kylinParams, HttpServletRequest request) throws Exception {
		String sql = KylinSQLBuilder.buildULMetricSQL(timerangeType, lessDate, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> result = shuffleResult(trparams, kylinRes);
		return result;
	}

	private ArrayNode buildULMetric(ArrayNode ul, List<ArrayNode> curRes, List<ArrayNode> lstRes) throws Exception {
		for (int i = 0, size = curRes.size(); i < size; i++) {
			ArrayNode curItem = curRes.get(i);
			ArrayNode lstItem = lstRes.get(i);
			if (curItem != null && lstItem != null) {
				ul.add(buildABSYoYObject(curItem.get(1).asDouble(), lstItem.get(1).asDouble(), 1, 1));
			} else if (curItem != null && lstItem == null) {
				ul.add(buildABSYOYObjectLastNull(curItem.get(1).asDouble(), 1));
			} else if (curItem == null && lstItem != null) {
				ul.add(buildABSYOYObjectCurrentNull());
			} else if (curItem == null && lstItem == null) {
				ul.add(buildABSYOYObjectBothNull());
			}
		}
		return ul;
	}

	private void buildQuarterYearToDateMetrics(ArrayNode results, ArrayNode gmv, ArrayNode adll, ArrayNode si,
			ArrayNode asp, ArrayNode nl, ArrayNode el, ArrayNode str, ArrayNode fl, String curTR, String lstTR,
			long curAvgDays, long lstAvgDays) throws Exception {
		int resSize = results.size();
		if (resSize == 2) {
			ArrayNode itemCurArray = (ArrayNode) results.get(0);
			ArrayNode itemLstArray = (ArrayNode) results.get(1);

			double cur_gmv = itemCurArray.get(1).asDouble();
			double lst_gmv = itemLstArray.get(1).asDouble();
			gmv.add(buildABSYoYObject(cur_gmv, lst_gmv, 1, 1));

			double cur_nl = itemCurArray.get(2).asDouble();
			double lst_nl = itemLstArray.get(2).asDouble();
			nl.add(buildABSYoYObject(cur_nl, lst_nl, 1, 1));

			double cur_el = itemCurArray.get(3).asDouble();
			double lst_el = itemLstArray.get(3).asDouble();
			el.add(buildABSYoYObject(cur_el, lst_el, 1, 1));

			double cur_si = itemCurArray.get(4).asDouble();
			double lst_si = itemLstArray.get(4).asDouble();
			si.add(buildABSYoYObject(cur_si, lst_si, 1, 1));

			// Daily Average Live Listings, 5 is the Live Listings index in
			// Kylin result
			// Formula:DALL=LL/7 (Live Listings / 7)
			double cur_ll = itemCurArray.get(5).asDouble();
			double lst_ll = itemLstArray.get(5).asDouble();
			adll.add(buildABSYoYObject(cur_ll, lst_ll, curAvgDays, lstAvgDays));

			// Sell Through Rate
			// Formula:STR=SI/LL
			double cur_str = cur_si / cur_ll;
			double lst_str = lst_si / lst_ll;
			str.add(buildABSYoYObject(cur_str * 100, lst_str * 100, 1, 1));

			// Average Sold Price
			// Formula: ASP=GMV/SI

			double cur_asp = cur_gmv / cur_si;
			double lst_asp = lst_gmv / lst_si;
			asp.add(buildABSYoYObject(cur_asp, lst_asp, 1, 1));

			double cur_fl = itemCurArray.get(6).asDouble();
			double lst_fl = itemLstArray.get(6).asDouble();
			fl.add(buildABSYoYObject(cur_fl, lst_fl, 1, 1));
		} else if (resSize == 1 && curTR.equals(results.get(0).asText())) {
			ArrayNode itemCurArray = (ArrayNode) results.get(0);
			double cur_gmv = itemCurArray.get(1).asDouble();
			gmv.add(buildABSYOYObjectLastNull(cur_gmv, 1));

			double cur_nl = itemCurArray.get(2).asDouble();
			nl.add(buildABSYOYObjectLastNull(cur_nl, 1));

			double cur_el = itemCurArray.get(3).asDouble();
			el.add(buildABSYOYObjectLastNull(cur_el, 1));

			double cur_si = itemCurArray.get(4).asDouble();
			si.add(buildABSYOYObjectLastNull(cur_si, 1));

			// Daily Average Live Listings, 5 is the Live Listings index in
			// Kylin result
			// Formula:DALL=LL/7 (Live Listings / 7)
			double cur_ll = itemCurArray.get(5).asDouble();
			adll.add(buildABSYOYObjectLastNull(cur_ll, curAvgDays));

			// Sell Through Rate
			// Formula:STR=SI/LL
			double cur_str = cur_si / cur_ll;
			str.add(buildABSYOYObjectLastNull(cur_str * 100, 1));

			// Average Sold Price
			// Formula: ASP=GMV/SI

			double cur_asp = cur_gmv / cur_si;
			asp.add(buildABSYOYObjectLastNull(cur_asp, 1));

			double cur_fl = itemCurArray.get(6).asDouble();
			fl.add(buildABSYOYObjectLastNull(cur_fl, 1));
		} else if (resSize == 1 && lstTR.equals(results.get(0).asText())) {
			gmv.add(buildABSYOYObjectCurrentNull());
			nl.add(buildABSYOYObjectCurrentNull());
			el.add(buildABSYOYObjectCurrentNull());
			si.add(buildABSYOYObjectCurrentNull());
			adll.add(buildABSYOYObjectCurrentNull());
			str.add(buildABSYOYObjectCurrentNull());
		} else if (resSize == 0) {
			gmv.add(buildABSYOYObjectBothNull());
			nl.add(buildABSYOYObjectBothNull());
			el.add(buildABSYOYObjectBothNull());
			si.add(buildABSYOYObjectBothNull());
			adll.add(buildABSYOYObjectBothNull());
			str.add(buildABSYOYObjectBothNull());
		}
	}

	private void buildMetrics(ArrayNode results, ArrayNode gmv, ArrayNode adll, ArrayNode si, ArrayNode asp,
			ArrayNode nl, ArrayNode el, ArrayNode str, ArrayNode fl, ArrayNode curTR, ArrayNode lstTR, boolean isWeek)
					throws Throwable {
		List<ArrayNode> curArray = new ArrayList<ArrayNode>();
		List<ArrayNode> lstArray = new ArrayList<ArrayNode>();
		int resSize = results.size();

		// Get all the current results and set non-exist as null
		for (int i = 0, size = curTR.size(); i < size; i++) {
			String tr = curTR.get(i).asText();
			ArrayNode matched = null;
			for (int j = 0; j < resSize; j++) {
				ArrayNode resItem = (ArrayNode) results.get(j);
				String trv = resItem.get(0).asText();// 0 is the time range id
				if (trv.equals(tr)) {
					matched = resItem;
					break;
				}
			}
			curArray.add(matched);
		}

		// Get all the last results and set non-exist as null
		for (int i = 0, size = lstTR.size(); i < size; i++) {
			String tr = lstTR.get(i).asText();
			ArrayNode matched = null;
			for (int j = 0; j < resSize; j++) {
				ArrayNode resItem = (ArrayNode) results.get(j);
				String trv = resItem.get(0).asText();// 0 is the time range id
				if (trv.equals(tr)) {
					matched = resItem;
					break;
				}
			}
			lstArray.add(matched);
		}

		// calculate the gmv, adll, etc.
		for (int i = 0, size = curArray.size(); i < size; i++) {
			int curAvg = 7, lstAvg = 7;
			if (!isWeek) {
				curAvg = TimeRangeGenerator.getQuarterYearDays(curTR.get(i).asText());
				lstAvg = TimeRangeGenerator.getQuarterYearDays(lstTR.get(i).asText());
			}
			ArrayNode itemCurArray = curArray.get(i);
			ArrayNode itemLstArray = lstArray.get(i);

			if (itemCurArray != null && itemLstArray != null) {
				double cur_gmv = itemCurArray.get(1).asDouble();
				double lst_gmv = itemLstArray.get(1).asDouble();
				gmv.add(buildABSYoYObject(cur_gmv, lst_gmv, 1, 1));

				double cur_nl = itemCurArray.get(2).asDouble();
				double lst_nl = itemLstArray.get(2).asDouble();
				nl.add(buildABSYoYObject(cur_nl, lst_nl, 1, 1));

				double cur_el = itemCurArray.get(3).asDouble();
				double lst_el = itemLstArray.get(3).asDouble();
				el.add(buildABSYoYObject(cur_el, lst_el, 1, 1));

				double cur_si = itemCurArray.get(4).asDouble();
				double lst_si = itemLstArray.get(4).asDouble();
				si.add(buildABSYoYObject(cur_si, lst_si, 1, 1));

				// Daily Average Live Listings, 5 is the Live Listings index in
				// Kylin result
				// Formula:DALL=LL/7 (Live Listings / 7)
				double cur_ll = itemCurArray.get(5).asDouble();
				double lst_ll = itemLstArray.get(5).asDouble();
				adll.add(buildABSYoYObject(cur_ll, lst_ll, curAvg, lstAvg));

				// Sell Through Rate
				// Formula:STR=SI/LL
				double cur_str = cur_si / cur_ll;
				double lst_str = lst_si / lst_ll;
				str.add(buildABSYoYObject(cur_str * 100, lst_str * 100, 1, 1));

				// Average Sold Price
				// Formula: ASP=GMV/SI

				double cur_asp = cur_gmv / cur_si;
				double lst_asp = lst_gmv / lst_si;
				asp.add(buildABSYoYObject(cur_asp, lst_asp, 1, 1));

				double cur_fl = itemCurArray.get(6).asDouble();
				double lst_fl = itemLstArray.get(6).asDouble();
				fl.add(buildABSYoYObject(cur_fl, lst_fl, 1, 1));
			} else if (itemCurArray == null && itemLstArray != null) {
				gmv.add(buildABSYOYObjectCurrentNull());
				nl.add(buildABSYOYObjectCurrentNull());
				el.add(buildABSYOYObjectCurrentNull());
				si.add(buildABSYOYObjectCurrentNull());
				adll.add(buildABSYOYObjectCurrentNull());
				str.add(buildABSYOYObjectCurrentNull());
				fl.add(buildABSYOYObjectCurrentNull());
			} else if (itemCurArray == null && itemLstArray == null) {
				gmv.add(buildABSYOYObjectBothNull());
				nl.add(buildABSYOYObjectBothNull());
				el.add(buildABSYOYObjectBothNull());
				si.add(buildABSYOYObjectBothNull());
				adll.add(buildABSYOYObjectBothNull());
				str.add(buildABSYOYObjectBothNull());
				fl.add(buildABSYOYObjectBothNull());
			} else if (itemCurArray != null && itemLstArray == null) {
				double cur_gmv = itemCurArray.get(1).asDouble();
				gmv.add(buildABSYOYObjectLastNull(cur_gmv, 1));

				double cur_nl = itemCurArray.get(2).asDouble();
				nl.add(buildABSYOYObjectLastNull(cur_nl, 1));

				double cur_el = itemCurArray.get(3).asDouble();
				el.add(buildABSYOYObjectLastNull(cur_el, 1));

				double cur_si = itemCurArray.get(4).asDouble();
				si.add(buildABSYOYObjectLastNull(cur_si, 1));

				// Daily Average Live Listings, 5 is the Live Listings index in
				// Kylin result
				// Formula:DALL=LL/7 (Live Listings / 7)
				double cur_ll = itemCurArray.get(5).asDouble();
				adll.add(buildABSYOYObjectLastNull(cur_ll, curAvg));

				// Sell Through Rate
				// Formula:STR=SI/LL
				double cur_str = cur_si / cur_ll;
				str.add(buildABSYOYObjectLastNull(cur_str * 100, 1));

				// Average Sold Price
				// Formula: ASP=GMV/SI

				double cur_asp = cur_gmv / cur_si;
				asp.add(buildABSYOYObjectLastNull(cur_asp, 1));

				double cur_fl = itemCurArray.get(6).asDouble();
				fl.add(buildABSYOYObjectLastNull(cur_fl, 1));
			}
		}
	}

	private ObjectNode buildABSYoYObject(double cur, double lst, long curAvgDays, long lstAvgDays) throws Exception {
		double yoy = (cur / curAvgDays - lst / lstAvgDays) / (lst / lstAvgDays);
		ObjectNode objNode = new ObjectNode(new JsonNodeFactory(false));
		double abs = Precision.round(cur / curAvgDays, 2);
		if (Double.isInfinite(abs) || Double.isNaN(abs)) {
			objNode.put(ABS_FIELD, "NaN");
		} else {
			objNode.put(ABS_FIELD, abs);
		}

		if (Double.isInfinite(yoy) || Double.isNaN(yoy)) {
			objNode.put(YOY_FIELD, "NaN");
		} else {
			objNode.put(YOY_FIELD, Precision.round(yoy * 100, 2));
		}
		return objNode;
	}

	private ObjectNode buildABSYOYObjectCurrentNull() {
		ObjectNode objNode = new ObjectNode(new JsonNodeFactory(false));
		objNode.put(ABS_FIELD, "NaN").put(YOY_FIELD, -100);
		return objNode;
	}

	private ObjectNode buildABSYOYObjectBothNull() {
		ObjectNode objNode = new ObjectNode(new JsonNodeFactory(false));
		objNode.put(ABS_FIELD, "NaN").put(YOY_FIELD, "NaN");
		return objNode;
	}

	private ObjectNode buildABSYOYObjectLastNull(double cur, long curAvgDays) {
		ObjectNode objNode = new ObjectNode(new JsonNodeFactory(false));
		objNode.put(ABS_FIELD, Precision.round(cur / curAvgDays, 2)).put(YOY_FIELD, 99999.99999);
		return objNode;
	}

	/**
	 * Retrieve segment result based on segment
	 * 
	 * @param requestEntity
	 * @param request
	 * @return
	 * @throws Throwable
	 */

	@RequestMapping(value = "/segments", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String querySegmentsByTR(HttpEntity<ObjectNode> requestEntity, HttpServletRequest request) throws Throwable {
		JsonNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}
		String metricType = requestBody.get(METRIC_TYPE).asText();
		String timerange = requestBody.get(TIME_RANGE_TYPE).asText();
		String sgmtType = requestBody.get(SGMT_TYPE).asText();
		JsonNode time_range = requestBody.get(TIME_RANGE);
		String refreshed = requestBody.get(REFRESH_DATE).asText();
		ArrayNode cur_time_range = (ArrayNode) time_range.get(CURRENT);
		ArrayNode lst_time_range = (ArrayNode) time_range.get(LAST);
		ArrayNode sqlParams = (ArrayNode) requestBody.get(SQL_PARAMS);
		ObjectNode kylinParams = (ObjectNode) requestBody.get(KYLIN_PARAMS);

		// Create the front end data model.
		ObjectNode result = new ObjectNode(new JsonNodeFactory(false));
		switch (timerange) {
		case "weeks":
			if ("gmv".equals(metricType)) {
				buildGMVSgmts(result, sgmtType, RTL_WEEK_BEG_DT, sqlParams, kylinParams,
						cur_time_range.addAll(lst_time_range), 4, true, null, null, null, null, null, null, request);
			} else if ("adllstr".equals(metricType)) {
				buildADLLSTRSgmts(result, sgmtType, RTL_WEEK_BEG_DT, sqlParams, kylinParams,
						cur_time_range.addAll(lst_time_range), 4, true, null, null, null, null, null, null, 0, 0,
						request);
			}
			break;
		case "quarters":
			String curQStartD = TimeRangeGenerator.getQuarterStartTimeAsString(refreshed);
			String lstQStartD = TimeRangeGenerator.getLastYearSameDay(curQStartD);
			String lstQEndD = TimeRangeGenerator.getLastYearSameDay(refreshed);
			String cur_Q = cur_time_range.remove(0).asText();
			String lst_Q = lst_time_range.remove(0).asText();
			if ("gmv".equals(metricType)) {
				buildGMVSgmts(result, sgmtType, QTR_ID, sqlParams, kylinParams, cur_time_range.addAll(lst_time_range),
						3, false, cur_Q, lst_Q, curQStartD, refreshed, lstQStartD, lstQEndD, request);
			} else if ("adllstr".equals(metricType)) {
				long qtdcurAvgDays = TimeRangeGenerator.calQTDDays(refreshed);
				long qtdlstAvgDays = TimeRangeGenerator.calQTDDays(lstQEndD);
				buildADLLSTRSgmts(result, sgmtType, QTR_ID, sqlParams, kylinParams,
						cur_time_range.addAll(lst_time_range), 3, false, cur_Q, lst_Q, curQStartD, refreshed,
						lstQStartD, lstQEndD, qtdcurAvgDays, qtdlstAvgDays, request);
			}
			break;
		case "years":
			String curYStartD = TimeRangeGenerator.getYearStartTimeAsString(refreshed);
			String lstYStartD = TimeRangeGenerator.getLastYearSameDay(curYStartD);
			String lstYEndD = TimeRangeGenerator.getLastYearSameDay(refreshed);
			String cur_Y = cur_time_range.remove(0).asText();
			String lst_Y = lst_time_range.remove(0).asText();
			if ("gmv".equals(metricType)) {
				buildGMVSgmts(result, sgmtType, YEAR_ID, sqlParams, kylinParams, cur_time_range.addAll(lst_time_range),
						2, false, cur_Y, lst_Y, curYStartD, refreshed, lstYStartD, lstYEndD, request);
			} else if ("adllstr".equals(metricType)) {
				long ytdcurAvgDays = TimeRangeGenerator.calYTDDays(refreshed);
				long ytdlstAvgDays = TimeRangeGenerator.calYTDDays(lstYEndD);
				buildADLLSTRSgmts(result, sgmtType, YEAR_ID, sqlParams, kylinParams,
						cur_time_range.addAll(lst_time_range), 2, false, cur_Y, lst_Y, curYStartD, refreshed,
						lstYStartD, lstYEndD, ytdcurAvgDays, ytdlstAvgDays, request);
			}
			break;
		}
		return result.toString();
	}

	/**
	 * 
	 * @param result
	 * @param sgmtType
	 * @param timeRangeId
	 * @param sqlParams
	 * @param kylinParams
	 * @param time_range
	 * @param request
	 * @throws Exception
	 */
	private void buildGMVSgmts(ObjectNode result, String sgmtType, String timeRangeId, ArrayNode sqlParams,
			ObjectNode kylinParams, ArrayNode time_range, int skip, boolean isWeek, String curTR, String lstTR,
			String curStartD, String curEndD, String lstStartD, String lstEndD, HttpServletRequest request)
					throws Exception {
		ObjectNode gmv = result.putObject("gmv");
		switch (sgmtType) {
		case "slr":
			List<ArrayNode> gmv_td_slr = null;
			if (!isWeek) {
				gmv_td_slr = getSgmtsToDateAsList(SLR_SGMT, SLR_VALUES, METRIC_GMV, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}

			ObjectNode tr_slr_sqlParam = sqlParams.addObject();
			tr_slr_sqlParam.put(SQL_PARAMS_FIELD, timeRangeId);
			tr_slr_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(time_range);
			ArrayNode slr = gmv.putArray("slr");
			List<ArrayNode> gmv_slr = getSgmtsAsList(SLR_SGMT, SLR_VALUES, METRIC_GMV, timeRangeId, time_range,
					sqlParams, kylinParams, request);
			buildSegmentArray(slr, gmv_slr, skip, isWeek, gmv_td_slr);
			break;
		case "lt":
			List<ArrayNode> gmv_td_lt = null;
			if (!isWeek) {
				gmv_td_lt = getSgmtsToDateAsList(LSTG_TYPE, LT_VALUES, METRIC_GMV, timeRangeId, curTR, lstTR, curStartD,
						curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}

			ObjectNode tr_lt_sqlParam = sqlParams.addObject();
			tr_lt_sqlParam.put(SQL_PARAMS_FIELD, timeRangeId);
			tr_lt_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(time_range);
			ArrayNode lt = gmv.putArray("lt");
			List<ArrayNode> gmv_lt = getSgmtsAsList(LSTG_TYPE, LT_VALUES, METRIC_GMV, timeRangeId, time_range,
					sqlParams, kylinParams, request);
			buildSegmentArray(lt, gmv_lt, skip, isWeek, gmv_td_lt);
			break;
		case "cond":
			List<ArrayNode> gmv_td_cond = null;
			if (!isWeek) {
				gmv_td_cond = getSgmtsToDateAsList(ITEM_CNDTN, COND_VALUES, METRIC_GMV, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}

			ObjectNode tr_cond_sqlParam = sqlParams.addObject();
			tr_cond_sqlParam.put(SQL_PARAMS_FIELD, timeRangeId);
			tr_cond_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(time_range);
			ArrayNode cond = gmv.putArray("cond");
			List<ArrayNode> gmv_cond = getSgmtsAsList(ITEM_CNDTN, COND_VALUES, METRIC_GMV, timeRangeId, time_range,
					sqlParams, kylinParams, request);
			buildSegmentArray(cond, gmv_cond, skip, isWeek, gmv_td_cond);
			break;
		case "ptr":
			List<ArrayNode> gmv_td_ptr = null;
			if (!isWeek) {
				gmv_td_ptr = getSgmtsToDateAsList(PRICE_TRANCHE, PTR_VALUES, METRIC_GMV, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}

			ObjectNode tr_ptr_sqlParam = sqlParams.addObject();
			tr_ptr_sqlParam.put(SQL_PARAMS_FIELD, timeRangeId);
			tr_ptr_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(time_range);
			ArrayNode ptr = gmv.putArray("ptr");
			List<ArrayNode> gmv_ptr = getSgmtsAsList(PRICE_TRANCHE, PTR_VALUES, METRIC_GMV, timeRangeId, time_range,
					sqlParams, kylinParams, request);
			buildSegmentArray(ptr, gmv_ptr, skip, isWeek, gmv_td_ptr);
			break;
		case "misc":
			List<ArrayNode> gmv_td_misc = null;
			if (!isWeek) {
				String toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(GTC_FLAG, METRIC_GMV, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, "AND GTC_FLAG='GTC'");
				kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);
				ArrayNode to_date_gtc = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
						.get(RESP_RESULTS);

				toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(DD_FLAG, METRIC_GMV, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, "AND DD_FLAG='DD'");
				kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);
				ArrayNode to_date_dd = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
						.get(RESP_RESULTS);

				gmv_td_misc = buildSegment(to_date_dd.addAll(to_date_gtc), MISC_VALUES);
			}

			ObjectNode tr_misc_sqlParam = sqlParams.addObject();
			tr_misc_sqlParam.put(SQL_PARAMS_FIELD, timeRangeId);
			tr_misc_sqlParam.putArray(SQL_PARAMS_VALUE).addAll(time_range);
			String gtc_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, GTC_FLAG, METRIC_GMV, time_range, sqlParams,
					"AND GTC_FLAG='GTC'");
			kylinParams.put(KYLIN_SQL_PARAM, gtc_sql);
			ArrayNode gtc_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);

			String dd_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, DD_FLAG, METRIC_GMV, time_range, sqlParams,
					"AND DD_FLAG='DD'");
			kylinParams.put(KYLIN_SQL_PARAM, dd_sql);
			ArrayNode dd_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);

			ArrayNode misc = gmv.putArray("misc");
			List<ArrayNode> gmv_misc = buildSegment(dd_resultRoot.addAll(gtc_resultRoot), MISC_VALUES);
			buildSegmentArray(misc, gmv_misc, skip, isWeek, gmv_td_misc);
			break;
		}
	}

	private List<ArrayNode> buildSegment(ArrayNode lt_resultRoot, String[] sgmtValues) throws Exception {
		List<ArrayNode> sgmtRes = new ArrayList<ArrayNode>();
		for (String ltv : sgmtValues) {
			ArrayNode matched = null;
			for (int i = 0, size = lt_resultRoot.size(); i < size; i++) {
				ArrayNode itemArray = (ArrayNode) lt_resultRoot.get(i);
				String ltName = itemArray.get(0).asText();
				if (ltv.equals(ltName)) {
					matched = itemArray;
					break;
				}
			}
			sgmtRes.add(matched);
		}
		return sgmtRes;
	}

	/**
	 * 
	 * @param result
	 * @param sgmtType
	 * @param timeRangeId
	 * @param sqlParams
	 * @param kylinParams
	 * @param time_range
	 * @param request
	 * @throws Exception
	 */
	private void buildADLLSTRSgmts(ObjectNode result, String sgmtType, String timeRangeId, ArrayNode sqlParams,
			ObjectNode kylinParams, ArrayNode time_range, int skip, boolean isWeek, String curTR, String lstTR,
			String curStartD, String curEndD, String lstStartD, String lstEndD, long tdcurAvgDays, long tdlstAvgDays,
			HttpServletRequest request) throws Exception {
		ObjectNode adll = result.putObject("adll");
		ObjectNode str = result.putObject("str");

		switch (sgmtType) {
		case "slr":
			List<ArrayNode> ll_td_slr = null;
			List<ArrayNode> si_td_slr = null;
			if (!isWeek) {
				ll_td_slr = getSgmtsToDateAsList(SLR_SGMT, SLR_VALUES, METRIC_LL, timeRangeId, curTR, lstTR, curStartD,
						curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
				si_td_slr = getSgmtsToDateAsList(SLR_SGMT, SLR_VALUES, METRIC_SI, timeRangeId, curTR, lstTR, curStartD,
						curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}
			ArrayNode adll_slr = adll.putArray("slr");
			List<ArrayNode> ll_slr = getSgmtsAsList(SLR_SGMT, SLR_VALUES, METRIC_LL, timeRangeId, time_range, sqlParams,
					kylinParams, request);

			ArrayNode str_slr = str.putArray("slr");
			List<ArrayNode> si_slr = getSgmtsAsList(SLR_SGMT, SLR_VALUES, METRIC_SI, timeRangeId, time_range, sqlParams,
					kylinParams, request);

			buildAdLLSTRSegmentsArray(adll_slr, str_slr, ll_slr, si_slr, time_range, skip, isWeek, ll_td_slr, si_td_slr,
					tdcurAvgDays, tdlstAvgDays);
			break;
		case "lt":
			List<ArrayNode> ll_td_lt = null;
			List<ArrayNode> si_td_lt = null;
			if (!isWeek) {
				ll_td_lt = getSgmtsToDateAsList(LSTG_TYPE, LT_VALUES, METRIC_LL, timeRangeId, curTR, lstTR, curStartD,
						curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
				si_td_lt = getSgmtsToDateAsList(LSTG_TYPE, LT_VALUES, METRIC_SI, timeRangeId, curTR, lstTR, curStartD,
						curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}
			ArrayNode adll_lt = adll.putArray("lt");
			List<ArrayNode> ll_lt = getSgmtsAsList(LSTG_TYPE, LT_VALUES, METRIC_LL, timeRangeId, time_range, sqlParams,
					kylinParams, request);

			ArrayNode str_lt = str.putArray("lt");
			List<ArrayNode> si_lt = getSgmtsAsList(LSTG_TYPE, LT_VALUES, METRIC_SI, timeRangeId, time_range, sqlParams,
					kylinParams, request);

			buildAdLLSTRSegmentsArray(adll_lt, str_lt, ll_lt, si_lt, time_range, skip, isWeek, ll_td_lt, si_td_lt,
					tdcurAvgDays, tdlstAvgDays);
			break;
		case "cond":
			List<ArrayNode> ll_td_cond = null;
			List<ArrayNode> si_td_cond = null;
			if (!isWeek) {
				ll_td_cond = getSgmtsToDateAsList(ITEM_CNDTN, COND_VALUES, METRIC_LL, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
				si_td_cond = getSgmtsToDateAsList(ITEM_CNDTN, COND_VALUES, METRIC_SI, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}
			ArrayNode adll_cond = adll.putArray("cond");
			List<ArrayNode> ll_cond = getSgmtsAsList(ITEM_CNDTN, COND_VALUES, METRIC_LL, timeRangeId, time_range,
					sqlParams, kylinParams, request);

			ArrayNode str_cond = str.putArray("cond");
			List<ArrayNode> si_cond = getSgmtsAsList(ITEM_CNDTN, COND_VALUES, METRIC_SI, timeRangeId, time_range,
					sqlParams, kylinParams, request);

			buildAdLLSTRSegmentsArray(adll_cond, str_cond, ll_cond, si_cond, time_range, skip, isWeek, ll_td_cond,
					si_td_cond, tdcurAvgDays, tdlstAvgDays);
			break;
		case "ptr":
			List<ArrayNode> ll_td_ptr = null;
			List<ArrayNode> si_td_ptr = null;
			if (!isWeek) {
				ll_td_ptr = getSgmtsToDateAsList(PRICE_TRANCHE, PTR_VALUES, METRIC_LL, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
				si_td_ptr = getSgmtsToDateAsList(PRICE_TRANCHE, PTR_VALUES, METRIC_SI, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, kylinParams, request);
			}
			ArrayNode adll_ptr = adll.putArray("ptr");
			List<ArrayNode> ll_ptr = getSgmtsAsList(PRICE_TRANCHE, PTR_VALUES, METRIC_LL, timeRangeId, time_range,
					sqlParams, kylinParams, request);

			ArrayNode str_ptr = str.putArray("ptr");
			List<ArrayNode> si_ptr = getSgmtsAsList(PRICE_TRANCHE, PTR_VALUES, METRIC_SI, timeRangeId, time_range,
					sqlParams, kylinParams, request);

			buildAdLLSTRSegmentsArray(adll_ptr, str_ptr, ll_ptr, si_ptr, time_range, skip, isWeek, ll_td_ptr, si_td_ptr,
					tdcurAvgDays, tdlstAvgDays);
			break;
		case "misc":
			List<ArrayNode> ll_td_misc = null;
			List<ArrayNode> si_td_misc = null;
			if (!isWeek) {
				String toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(GTC_FLAG, METRIC_LL, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, "AND GTC_FLAG='GTC'");
				kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);
				ArrayNode ll_to_date_gtc = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
						.get(RESP_RESULTS);

				toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(DD_FLAG, METRIC_LL, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, "AND DD_FLAG='DD'");
				kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);
				ArrayNode ll_to_date_dd = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
						.get(RESP_RESULTS);
				ll_td_misc = buildSegment(ll_to_date_dd.addAll(ll_to_date_gtc), MISC_VALUES);

				toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(GTC_FLAG, METRIC_SI, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, "AND GTC_FLAG='GTC'");
				kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);
				ArrayNode si_to_date_gtc = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
						.get(RESP_RESULTS);

				toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(DD_FLAG, METRIC_SI, timeRangeId, curTR, lstTR,
						curStartD, curEndD, lstStartD, lstEndD, sqlParams, "AND DD_FLAG='DD'");
				kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);
				ArrayNode si_to_date_dd = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
						.get(RESP_RESULTS);
				si_td_misc = buildSegment(si_to_date_dd.addAll(si_to_date_gtc), MISC_VALUES);
			}

			String ll_dd_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, DD_FLAG, METRIC_LL, time_range, sqlParams,
					"AND DD_FLAG='DD'");
			kylinParams.put(KYLIN_SQL_PARAM, ll_dd_sql);
			ArrayNode ll_dd_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);

			String ll_gtc_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, GTC_FLAG, METRIC_LL, time_range, sqlParams,
					"AND GTC_FLAG='GTC'");
			kylinParams.put(KYLIN_SQL_PARAM, ll_gtc_sql);
			ArrayNode ll_gtc_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			List<ArrayNode> ll_gtc = buildSegment(ll_dd_resultRoot.addAll(ll_gtc_resultRoot), MISC_VALUES);

			String si_dd_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, DD_FLAG, METRIC_SI, time_range, sqlParams,
					"AND DD_FLAG='DD'");
			kylinParams.put(KYLIN_SQL_PARAM, si_dd_sql);
			ArrayNode si_dd_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);

			String si_gtc_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, GTC_FLAG, METRIC_SI, time_range, sqlParams,
					"AND GTC_FLAG='GTC'");
			kylinParams.put(KYLIN_SQL_PARAM, si_gtc_sql);
			ArrayNode si_gtc_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
					.get(RESP_RESULTS);
			List<ArrayNode> si_gtc = buildSegment(si_dd_resultRoot.addAll(si_gtc_resultRoot), MISC_VALUES);

			ArrayNode adll_misc = adll.putArray("misc");
			ArrayNode str_misc = str.putArray("misc");

			buildAdLLSTRSegmentsArray(adll_misc, str_misc, ll_gtc, si_gtc, time_range, skip, isWeek, ll_td_misc,
					si_td_misc, tdcurAvgDays, tdlstAvgDays);
			break;
		}
	}

	private List<ArrayNode> getSgmtsToDateAsList(String sgmtType, String[] sgmtValues, String metricType,
			String timeRangeId, String curTR, String lstTR, String curStartD, String curEndD, String lstStartD,
			String lstEndD, ArrayNode sqlParams, ObjectNode kylinParams, HttpServletRequest request) throws Exception {
		String toDateSQL = KylinSQLBuilder.buildSgmtsToDateSQL(sgmtType, metricType, timeRangeId, curTR, lstTR,
				curStartD, curEndD, lstStartD, lstEndD, sqlParams, null);
		kylinParams.put(KYLIN_SQL_PARAM, toDateSQL);

		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		return buildSegment(kylinRes, sgmtValues);
	}

	private List<ArrayNode> getSgmtsAsList(String sgmtType, String[] sgmtValues, String metricType, String timeRangeId,
			ArrayNode timeRange, ArrayNode sqlParams, ObjectNode kylinParams, HttpServletRequest request)
					throws Exception {
		String si_ptr_sql = KylinSQLBuilder.buildSgmtsSQL(timeRangeId, sgmtType, metricType, timeRange, sqlParams,
				null);
		kylinParams.put(KYLIN_SQL_PARAM, si_ptr_sql);
		ArrayNode si_ptr_resultRoot = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
				.get(RESP_RESULTS);
		return buildSegment(si_ptr_resultRoot, sgmtValues);
	}

	// STR = (SI/RATIO)/Daily Average LL, RATIO IS 7 OR DAYS TO DATE LIKE QTD,
	// YTD
	private void buildAdLLSTRSegmentsArray(ArrayNode adll_sgmt, ArrayNode str_sgmt, List<ArrayNode> llRes,
			List<ArrayNode> siRes, ArrayNode timerange, int skip, boolean isWeek, List<ArrayNode> llTDRes,
			List<ArrayNode> siTDRes, long tdcurAvgDays, long tdlstAvgDays) throws Exception {
		long curAvgDays = 7, lstAvgDays = 7;

		for (int i = 0, len = llRes.size(); i < len; i++) {
			ArrayNode adllsubArray = adll_sgmt.addArray();
			ArrayNode strsubArray = str_sgmt.addArray();

			if (!isWeek) {
				ArrayNode lltdArray = llTDRes.get(i);
				ArrayNode sitdArray = siTDRes.get(i);
				if (lltdArray != null && sitdArray != null) {
					double cur_ll = lltdArray.get(1).asDouble();
					double lst_ll = lltdArray.get(2).asDouble();
					double cur_si = sitdArray.get(1).asDouble();
					double lst_si = sitdArray.get(2).asDouble();
					adllsubArray.add(buildABSYoYObject(cur_ll, lst_ll, tdcurAvgDays, tdlstAvgDays));
					strsubArray.add(buildABSYoYObject((cur_si / cur_ll) * 100, (lst_si / lst_ll) * 100, 1, 1));
				} else if (lltdArray == null && sitdArray == null) {
					adllsubArray.add(buildABSYOYObjectBothNull());
					strsubArray.add(buildABSYOYObjectBothNull());
				} else if (lltdArray != null && sitdArray == null) {
					double cur_ll = lltdArray.get(1).asDouble();
					double lst_ll = lltdArray.get(2).asDouble();
					adllsubArray.add(buildABSYoYObject(cur_ll, lst_ll, tdcurAvgDays, tdlstAvgDays));
					strsubArray.add(buildABSYOYObjectBothNull());
				} else if (lltdArray == null && sitdArray != null) {
					adllsubArray.add(buildABSYOYObjectBothNull());
					strsubArray.add(buildABSYOYObjectCurrentNull());
				}
			}

			ArrayNode llItemArray = llRes.get(i);
			ArrayNode siItemArray = siRes.get(i);
			if (llItemArray != null && siItemArray != null) {
				for (int j = 1; j <= skip; j++) {
					if (!isWeek) {
						curAvgDays = TimeRangeGenerator.getQuarterYearDays(timerange.get(j - 1).asText());
						lstAvgDays = TimeRangeGenerator.getQuarterYearDays(timerange.get(j - 1 + skip).asText());
					}
					double cur_ll = llItemArray.get(j).asDouble();
					double lst_ll = llItemArray.get(j + skip).asDouble();
					double cur_si = siItemArray.get(j).asDouble();
					double lst_si = siItemArray.get(j + skip).asDouble();
					adllsubArray.add(buildABSYoYObject(cur_ll, lst_ll, curAvgDays, lstAvgDays));
					strsubArray.add(buildABSYoYObject((cur_si / cur_ll) * 100, (lst_si / lst_ll) * 100, 1, 1));
				}
			} else if (llItemArray == null && siItemArray == null) {
				for (int j = 1; j <= skip; j++) {
					adllsubArray.add(buildABSYOYObjectBothNull());
					strsubArray.add(buildABSYOYObjectBothNull());
				}
			} else if (llItemArray != null && siItemArray == null) {
				for (int j = 1; j <= skip; j++) {
					if (!isWeek) {
						curAvgDays = TimeRangeGenerator.getQuarterYearDays(timerange.get(j - 1).asText());
						lstAvgDays = TimeRangeGenerator.getQuarterYearDays(timerange.get(j - 1 + skip).asText());
					}
					double cur_ll = llItemArray.get(j).asDouble();
					double lst_ll = llItemArray.get(j + skip).asDouble();
					adllsubArray.add(buildABSYoYObject(cur_ll, lst_ll, curAvgDays, lstAvgDays));
					strsubArray.add(buildABSYOYObjectBothNull());
				}
			} else if (llItemArray == null && siItemArray != null) {
				for (int j = 1; j <= skip; j++) {
					adllsubArray.add(buildABSYOYObjectBothNull());
					strsubArray.add(buildABSYOYObjectCurrentNull());
				}
			}
		}
	}

	/**
	 * The numbers in buildSegmentArray method are reflecting to the index in
	 * the Kylin result. They are fixed unless SQL change.
	 * 
	 * @param result
	 * @param sgmt
	 * @param curAvgDays
	 * @param lstAvgDays
	 * @throws Exception
	 */
	private void buildSegmentArray(ArrayNode sgmt, List<ArrayNode> sgmtRes, int skip, boolean isWeek,
			List<ArrayNode> sgmtTDRes) throws Exception {
		for (int i = 0, len = sgmtRes.size(); i < len; i++) {
			ArrayNode itemArray = sgmtRes.get(i);
			ArrayNode subArray = sgmt.addArray();
			if (!isWeek) {
				ArrayNode tdArray = sgmtTDRes.get(i);
				if (tdArray == null) {
					subArray.add(buildABSYOYObjectBothNull());
				} else {
					double cur = tdArray.get(1).asDouble();
					double lst = tdArray.get(2).asDouble();
					subArray.add(buildABSYoYObject(cur, lst, 1, 1));
				}
			}
			for (int j = 1; j <= skip; j++) {
				if (itemArray == null) {
					subArray.add(buildABSYOYObjectBothNull());
				} else {
					double cur = itemArray.get(j).asDouble();
					double lst = itemArray.get(j + skip).asDouble();
					subArray.add(buildABSYoYObject(cur, lst, 1, 1));
				}
			}
		}
	}

	@RequestMapping(value = "/details/metric", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String queryDetailMetric(HttpEntity<JsonNode> requestEntity, HttpServletRequest request) throws Exception {
		JsonNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}
		boolean iscompare = requestBody.get(IS_COMPARE).asBoolean();
		String metricType = requestBody.get(METRIC_TYPE).asText();
		String refreshed = requestBody.get(REFRESH_DATE).asText();
		ArrayNode sqlParams = (ArrayNode) requestBody.get(SQL_PARAMS);
		ObjectNode kylinParams = (ObjectNode) requestBody.get(KYLIN_PARAMS);

		// Create the front end data model.
		ArrayNode result = new ArrayNode(new JsonNodeFactory(false));
		refreshed = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshed, 1, TimeRangeIdType.RTL_WEEK_BEG_DT).get(0);
		List<String> recentYears = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshed, 3, TimeRangeIdType.YEAR_ID);

		String line1_id = iscompare ? recentYears.get(0).concat(IS_COMPARE) : recentYears.get(0);
		String line2_id = iscompare ? recentYears.get(1).concat(IS_COMPARE) : recentYears.get(1);
		String line3_id = iscompare ? recentYears.get(2).concat(IS_COMPARE) : recentYears.get(2);
		String type = iscompare ? "line" : "line";
		String dashStyle = iscompare ? "solid" : "solid";
		switch (metricType) {
		case "GMV":
			result.add(buildYearTDWeeksDetailMetric(METRIC_GMV, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_GMV, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_GMV, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), 1, request));
			break;
		case "New Listings":
			result.add(buildYearTDWeeksDetailMetric(METRIC_NL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_NL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_NL, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), 1, request));
			break;
		case "Fresh Listings":
			result.add(buildYearTDWeeksDetailMetric(METRIC_FL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_FL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_FL, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), 1, request));
			break;
		case "Ended Listings":
			result.add(buildYearTDWeeksDetailMetric(METRIC_EL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_EL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_EL, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), 1, request));
			break;
		case "Sold Items":
			result.add(buildYearTDWeeksDetailMetric(METRIC_SI, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_SI, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetric(METRIC_SI, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), 1, request));
			break;
		case "Average Daily Live Listings":
			result.add(buildYearTDWeeksDetailMetric(METRIC_LL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 7, request));
			result.add(buildYearWeeksDetailMetric(METRIC_LL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 7, request));
			result.add(buildYearWeeksDetailMetric(METRIC_LL, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), 7, request));
			break;
		case "Sell Through Rate":
			result.add(buildYearTDWeeksDetailMetricDiv(METRIC_SI, METRIC_LL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), true, request));
			result.add(buildYearWeeksDetailMetricDiv(METRIC_SI, METRIC_LL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), true, request));
			result.add(buildYearWeeksDetailMetricDiv(METRIC_SI, METRIC_LL, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), true, request));
			break;
		case "ASP":
			result.add(buildYearTDWeeksDetailMetricDiv(METRIC_GMV, METRIC_SI, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), false, request));
			result.add(buildYearWeeksDetailMetricDiv(METRIC_GMV, METRIC_SI, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), false, request));
			result.add(buildYearWeeksDetailMetricDiv(METRIC_GMV, METRIC_SI, recentYears.get(2), sqlParams, kylinParams,
					produceSeriesItem(line3_id, recentYears.get(2), type, CHART_COLORS[2], dashStyle), false, request));
			break;
		}
		return result.toString();
	}

	private JsonNode buildYearTDWeeksDetailMetric(String metricType, String date, ArrayNode sqlParams,
			ObjectNode kylinParams, ObjectNode seriesItem, long daily, HttpServletRequest request) throws Exception {
		List<ArrayNode> result = getYearTDWeeksDetailMetric(metricType, date, sqlParams, kylinParams, request);
		ObjectNode dataNode = produceDataItem(result, seriesItem, daily);
		return dataNode;
	}

	private List<ArrayNode> getYearTDWeeksDetailMetric(String metricType, String date, ArrayNode sqlParams,
			ObjectNode kylinParams, HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildSoFarWeeksByYearSQL(date);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		String sql = KylinSQLBuilder.buildYearSoFarDetailsMetricSQL(metricType, date, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> result = shuffleResult(weeks, kylinRes);
		return result;
	}

	private JsonNode buildYearWeeksDetailMetric(String metricType, String year, ArrayNode sqlParams,
			ObjectNode kylinParams, ObjectNode seriesItem, long daily, HttpServletRequest request) throws Exception {
		List<ArrayNode> result = getYearWeeksDetailMetric(metricType, year, sqlParams, kylinParams, request);
		ObjectNode dataNode = produceDataItem(result, seriesItem, daily);
		return dataNode;
	}

	private List<ArrayNode> getYearWeeksDetailMetric(String metricType, String year, ArrayNode sqlParams,
			ObjectNode kylinParams, HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildWeeksAYearSQL(year);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		String sql = KylinSQLBuilder.buildDetailsMetricSQL(metricType, year, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> result = shuffleResult(weeks, kylinRes);
		return result;
	}

	private JsonNode buildYearTDWeeksDetailMetricDiv(String fractionMetricType, String denominatorMetricType,
			String date, ArrayNode sqlParams, ObjectNode kylinParams, ObjectNode seriesItem, boolean isPercent,
			HttpServletRequest request) throws Exception {
		List<ArrayNode> fracResult = getYearTDWeeksDetailMetric(fractionMetricType, date, sqlParams, kylinParams,
				request);
		List<ArrayNode> denoResult = getYearTDWeeksDetailMetric(denominatorMetricType, date, sqlParams, kylinParams,
				request);
		ObjectNode dataNode = produceDataItem(fracResult, denoResult, seriesItem, isPercent);
		return dataNode;
	}

	private JsonNode buildYearWeeksDetailMetricDiv(String fractionMetricType, String denominatorMetricType, String year,
			ArrayNode sqlParams, ObjectNode kylinParams, ObjectNode seriesItem, boolean isPercent,
			HttpServletRequest request) throws Exception {
		List<ArrayNode> fracResult = getYearWeeksDetailMetric(fractionMetricType, year, sqlParams, kylinParams,
				request);
		List<ArrayNode> denoResult = getYearWeeksDetailMetric(denominatorMetricType, year, sqlParams, kylinParams,
				request);
		ObjectNode dataNode = produceDataItem(fracResult, denoResult, seriesItem, isPercent);
		return dataNode;
	}

	private ObjectNode produceSeriesItem(String id, String name, String type, String color, String dashStyle) {
		ObjectNode obj = new ObjectNode(new JsonNodeFactory(false));
		obj.put("id", id);
		obj.put("name", name);
		obj.put("type", type);
		obj.put("color", color);
		obj.put("dashStyle", dashStyle);
		return obj;
	}

	private ObjectNode produceDataItem(List<ArrayNode> result, ObjectNode seriesItem, long daily) {
		ObjectNode obj = null;
		if (seriesItem == null) {
			obj = new ObjectNode(new JsonNodeFactory(false));
		} else {
			obj = seriesItem;
		}
		ArrayNode data = obj.putArray("data");
		for (ArrayNode item : result) {
			if (item != null) {
				double res = Precision.round(item.get(1).asDouble() / daily, 2);
				data.add(res);
			} else {
				data.addNull();
			}
		}
		return obj;
	}

	private ObjectNode produceDataItem(List<ArrayNode> fracResult, List<ArrayNode> denoResult, ObjectNode seriesItem,
			boolean isPercent) {
		ObjectNode obj = null;
		if (seriesItem == null) {
			obj = new ObjectNode(new JsonNodeFactory(false));
		} else {
			obj = seriesItem;
		}
		ArrayNode data = obj.putArray("data");
		for (int i = 0, size = fracResult.size(); i < size; i++) {
			ArrayNode fracItem = fracResult.get(i);
			ArrayNode denoItem = denoResult.get(i);
			if (fracItem != null && denoItem != null) {
				double res = fracItem.get(1).asDouble() / denoItem.get(1).asDouble();
				if (Double.isInfinite(res) || Double.isNaN(res)) {
					data.addNull();
				} else {
					data.add(Precision.round(isPercent ? res * 100 : res, 2));
				}
			} else {
				data.addNull();
			}
		}
		return obj;
	}

	private List<ArrayNode> shuffleResult(ArrayNode params, ArrayNode result) {
		List<ArrayNode> shuffledRes = new ArrayList<ArrayNode>();
		int j = 0;
		JsonNode paramItem = null;
		String param = "";
		for (int i = 0, size = params.size(); i < size; i++) {
			paramItem = params.get(i);
			if (paramItem.isArray()) {
				param = paramItem.get(0).asText();
			} else {
				param = paramItem.asText();
			}
			ArrayNode item = (ArrayNode) result.get(j);
			if (item != null && param.equals(item.get(0).asText())) {
				shuffledRes.add(item);
				j++;
			} else {
				shuffledRes.add(null);
			}
		}
		return shuffledRes;
	}

	@RequestMapping(value = "/details/metricyoy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String queryDetailMetricYoY(HttpEntity<JsonNode> requestEntity, HttpServletRequest request)
			throws Exception {
		JsonNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}
		boolean iscompare = requestBody.get(IS_COMPARE).asBoolean();
		String metricType = requestBody.get(METRIC_TYPE).asText();
		String refreshed = requestBody.get(REFRESH_DATE).asText();
		ArrayNode sqlParams = (ArrayNode) requestBody.get(SQL_PARAMS);
		ObjectNode kylinParams = (ObjectNode) requestBody.get(KYLIN_PARAMS);
		ArrayNode result = new ArrayNode(new JsonNodeFactory(false));
		refreshed = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshed, 1, TimeRangeIdType.RTL_WEEK_BEG_DT).get(0);
		List<String> recentYears = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshed, 2, TimeRangeIdType.YEAR_ID);
		String type = iscompare ? "line" : "line";
		String dashStyle = iscompare ? "solid" : "solid";
		String line1_id = iscompare ? recentYears.get(0).concat(IS_COMPARE) : recentYears.get(0);
		String line2_id = iscompare ? recentYears.get(1).concat(IS_COMPARE) : recentYears.get(1);
		switch (metricType) {
		case "GMV":
			result.add(buildYearTDWeeksDetailMetricYoY(METRIC_GMV, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetricYoY(METRIC_GMV, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			break;
		case "New Listings":
			result.add(buildYearTDWeeksDetailMetricYoY(METRIC_NL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetricYoY(METRIC_NL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			break;
		case "Fresh Listings":
			result.add(buildYearTDWeeksDetailMetricYoY(METRIC_FL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetricYoY(METRIC_FL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			break;
		case "Ended Listings":
			result.add(buildYearTDWeeksDetailMetricYoY(METRIC_EL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetricYoY(METRIC_EL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			break;
		case "Sold Items":
			result.add(buildYearTDWeeksDetailMetricYoY(METRIC_SI, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 1, request));
			result.add(buildYearWeeksDetailMetricYoY(METRIC_SI, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 1, request));
			break;
		case "Average Daily Live Listings":
			result.add(buildYearTDWeeksDetailMetricYoY(METRIC_LL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), 7, request));
			result.add(buildYearWeeksDetailMetricYoY(METRIC_LL, recentYears.get(1), sqlParams, kylinParams,
					produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle), 7, request));
			break;
		case "Sell Through Rate":
			result.add(buildYearTDWeeksDetailMetricDivYoY(METRIC_SI, METRIC_LL, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), true, request));
			result.add(buildYearWeeksDetailMetricDivYoY(METRIC_SI, METRIC_LL, recentYears.get(1), sqlParams,
					kylinParams, produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle),
					true, request));
			break;
		case "ASP":
			result.add(buildYearTDWeeksDetailMetricDivYoY(METRIC_GMV, METRIC_SI, refreshed, sqlParams, kylinParams,
					produceSeriesItem(line1_id, recentYears.get(0), type, CHART_COLORS[0], dashStyle), false, request));
			result.add(buildYearWeeksDetailMetricDivYoY(METRIC_GMV, METRIC_SI, recentYears.get(1), sqlParams,
					kylinParams, produceSeriesItem(line2_id, recentYears.get(1), type, CHART_COLORS[1], dashStyle),
					false, request));
			break;
		}

		return result.toString();
	}

	private JsonNode buildYearTDWeeksDetailMetricYoY(String metricType, String date, ArrayNode sqlParams,
			ObjectNode kylinParams, ObjectNode seriesItem, long daily, HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildSoFarWeeksByYearSQL(date);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		String sql = KylinSQLBuilder.buildYearSoFarDetailsMetricSQL(metricType, date, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> curresult = shuffleResult(weeks, kylinRes);

		String lstStart = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(0).get(0).asText());
		String lstEnd = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(weeks.size() - 1).get(0).asText());
		List<ArrayNode> lstresult = getYearBTWeeksDetailMetric(metricType, lstStart, lstEnd, sqlParams, kylinParams,
				request);
		ObjectNode dataNode = produceDataItemYoY(curresult, lstresult, seriesItem, daily);
		return dataNode;
	}

	private JsonNode buildYearWeeksDetailMetricYoY(String metricType, String year, ArrayNode sqlParams,
			ObjectNode kylinParams, ObjectNode seriesItem, long daily, HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildWeeksAYearSQL(year);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		String sql = KylinSQLBuilder.buildDetailsMetricSQL(metricType, year, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> curresult = shuffleResult(weeks, kylinRes);

		String lstStart = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(0).get(0).asText());
		String lstEnd = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(weeks.size() - 1).get(0).asText());
		List<ArrayNode> lstresult = getYearBTWeeksDetailMetric(metricType, lstStart, lstEnd, sqlParams, kylinParams,
				request);
		ObjectNode dataNode = produceDataItemYoY(curresult, lstresult, seriesItem, daily);
		return dataNode;
	}

	private ObjectNode produceDataItemYoY(List<ArrayNode> fracResult, List<ArrayNode> denoResult, ObjectNode seriesItem,
			long daily) {
		ObjectNode obj = null;
		if (seriesItem == null) {
			obj = new ObjectNode(new JsonNodeFactory(false));
		} else {
			obj = seriesItem;
		}
		ArrayNode data = obj.putArray("data");
		for (int i = 0, size = fracResult.size(); i < size; i++) {
			ArrayNode fracItem = fracResult.get(i);
			ArrayNode denoItem = denoResult.get(i);
			if (fracItem != null && denoItem != null) {
				double fracvalue = fracItem.get(1).asDouble();
				double denovalue = denoItem.get(1).asDouble();
				double res = Precision.round(((fracvalue / daily - denovalue / daily) / (denovalue / daily)) * 100, 2);
				if (Double.isInfinite(res) || Double.isNaN(res)) {
					data.addNull();
				} else {
					data.add(res);
				}
			} else if (fracItem == null && denoItem != null) {
				data.add(-100);
			} else {
				data.addNull();
			}
		}
		return obj;
	}

	private List<ArrayNode> getYearBTWeeksDetailMetric(String metricType, String start, String end, ArrayNode sqlParams,
			ObjectNode kylinParams, HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildWeeksBetweenSQL(start, end);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		String sql = KylinSQLBuilder.buildDetailsMetricBetweenSQL(metricType, start, end, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode kylinRes = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> result = shuffleResult(weeks, kylinRes);
		return result;
	}

	private JsonNode buildYearTDWeeksDetailMetricDivYoY(String fractionMetricType, String denominatorMetricType,
			String date, ArrayNode sqlParams, ObjectNode kylinParams, ObjectNode seriesItem, boolean isDelta,
			HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildSoFarWeeksByYearSQL(date);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);

		String sql = KylinSQLBuilder.buildYearSoFarDetailsMetricSQL(fractionMetricType, date, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode curfrac = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> curfracRes = shuffleResult(weeks, curfrac);

		sql = KylinSQLBuilder.buildYearSoFarDetailsMetricSQL(denominatorMetricType, date, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode curdeno = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> curdenoRes = shuffleResult(weeks, curdeno);

		String lstStart = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(0).get(0).asText());
		String lstEnd = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(weeks.size() - 1).get(0).asText());
		List<ArrayNode> lstfracRes = getYearBTWeeksDetailMetric(fractionMetricType, lstStart, lstEnd, sqlParams,
				kylinParams, request);
		List<ArrayNode> lstdenoRes = getYearBTWeeksDetailMetric(denominatorMetricType, lstStart, lstEnd, sqlParams,
				kylinParams, request);
		ObjectNode dataNode = produceDataItemDivYoY(curfracRes, curdenoRes, lstfracRes, lstdenoRes, seriesItem,
				isDelta);
		return dataNode;
	}

	private JsonNode buildYearWeeksDetailMetricDivYoY(String fractionMetricType, String denominatorMetricType,
			String year, ArrayNode sqlParams, ObjectNode kylinParams, ObjectNode seriesItem, boolean isDelta,
			HttpServletRequest request) throws Exception {
		String weekSql = KylinSQLBuilder.buildWeeksAYearSQL(year);
		kylinParams.put(KYLIN_SQL_PARAM, weekSql);
		ArrayNode weeks = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);

		String sql = KylinSQLBuilder.buildDetailsMetricSQL(fractionMetricType, year, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode curfrac = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> curfracRes = shuffleResult(weeks, curfrac);

		sql = KylinSQLBuilder.buildDetailsMetricSQL(denominatorMetricType, year, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, sql);
		ArrayNode curdeno = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> curdenoRes = shuffleResult(weeks, curdeno);

		String lstStart = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(0).get(0).asText());
		String lstEnd = TimeRangeGenerator.getYoYWeekQuarterYearID(weeks.get(weeks.size() - 1).get(0).asText());
		List<ArrayNode> lstfracRes = getYearBTWeeksDetailMetric(fractionMetricType, lstStart, lstEnd, sqlParams,
				kylinParams, request);
		List<ArrayNode> lstdenoRes = getYearBTWeeksDetailMetric(denominatorMetricType, lstStart, lstEnd, sqlParams,
				kylinParams, request);
		ObjectNode dataNode = produceDataItemDivYoY(curfracRes, curdenoRes, lstfracRes, lstdenoRes, seriesItem,
				isDelta);
		return dataNode;
	}

	private ObjectNode produceDataItemDivYoY(List<ArrayNode> curfracResult, List<ArrayNode> curdenoResult,
			List<ArrayNode> lstfracResult, List<ArrayNode> lstdenoResult, ObjectNode seriesItem, boolean isDelta) {
		ObjectNode obj = null;
		if (seriesItem == null) {
			obj = new ObjectNode(new JsonNodeFactory(false));
		} else {
			obj = seriesItem;
		}
		ArrayNode data = obj.putArray("data");
		for (int i = 0, size = curfracResult.size(); i < size; i++) {
			ArrayNode curfracItem = curfracResult.get(i);
			ArrayNode curdenoItem = curdenoResult.get(i);
			ArrayNode lstfracItem = lstfracResult.get(i);
			ArrayNode lstdenoItem = lstdenoResult.get(i);
			if (curfracItem != null && curdenoItem != null && lstfracItem != null && lstdenoItem != null) {
				double curvalue = curfracItem.get(1).asDouble() / curdenoItem.get(1).asDouble();
				double lstvalue = lstfracItem.get(1).asDouble() / lstdenoItem.get(1).asDouble();
				double yoyvalue = isDelta ? (curvalue - lstvalue) : ((curvalue - lstvalue) / lstvalue);
				if (Double.isInfinite(yoyvalue) || Double.isNaN(yoyvalue)) {
					data.addNull();
				} else {
					data.add(Precision.round(yoyvalue * 100, 2));
				}
			} else if (curfracItem == null && curdenoItem == null && lstfracItem != null && lstdenoItem != null) {
				data.add(-100);
			} else {
				data.addNull();
			}
		}
		return obj;
	}

	@RequestMapping(value = "/details/subcatg", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String queryDetailSubCatg(HttpEntity<JsonNode> requestEntity, HttpServletRequest request) throws Exception {
		JsonNode requestBody = requestEntity.getBody();
		if (requestBody == null) {
			throw new Exception("The request body can not be empty!");
		}
		String subcatg = requestBody.get(SUB_CATG).asText();
		String refreshed = requestBody.get(REFRESH_DATE).asText();
		ArrayNode sqlParams = (ArrayNode) requestBody.get(SQL_PARAMS);
		ObjectNode kylinParams = (ObjectNode) requestBody.get(KYLIN_PARAMS);
		// Create the front end data model.
		ArrayNode result = new ArrayNode(new JsonNodeFactory(false));

		String subcatgItemSql = KylinSQLBuilder.buildCategoryItemsSQL(subcatg, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, subcatgItemSql);
		ArrayNode subCatgItems = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
				.get(RESP_RESULTS);

		String curYW = TimeRangeGenerator.getRecentWeekQuarterYearID(refreshed, 1, TimeRangeIdType.RTL_WEEK_BEG_DT)
				.get(0);
		String totalSql = KylinSQLBuilder.buildTotalSubCategoriesSQL(curYW, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, totalSql);
		ArrayNode totalResults = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap())
				.get(RESP_RESULTS);

		String curYSql = KylinSQLBuilder.buildSubCategoriesSQL(subcatg, curYW, sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, curYSql);
		ArrayNode curResults = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> currentRes = shuffleResult(subCatgItems, curResults);

		String lstYSql = KylinSQLBuilder.buildSubCategoriesSQL(subcatg,
				TimeRangeGenerator.getYoYWeekQuarterYearID(curYW), sqlParams);
		kylinParams.put(KYLIN_SQL_PARAM, lstYSql);
		ArrayNode lstResults = (ArrayNode) getResponseContent(kylinParams, request.getParameterMap()).get(RESP_RESULTS);
		List<ArrayNode> lastRes = shuffleResult(subCatgItems, lstResults);

		double total_gmv = totalResults.get(0).get(0).asDouble();
		double total_si = totalResults.get(0).get(1).asDouble();
		double total_ll = totalResults.get(0).get(2).asDouble();
		double total_nl = totalResults.get(0).get(3).asDouble();
		for (int i = 0, size = currentRes.size(); i < size; i++) {
			ArrayNode curItem = currentRes.get(i);
			ArrayNode lstItem = lastRes.get(i);
			ObjectNode dataItem = result.addObject();
			dataItem.put("name", subCatgItems.get(i).get(0).asText());
			if (curItem != null && lstItem != null) {
				double cur_gmv = curItem.get(1).asDouble();
				double lst_gmv = lstItem.get(1).asDouble();
				setSubCatgItemValue(dataItem, "gmvyoy", ((cur_gmv - lst_gmv) / lst_gmv * 100));
				setSubCatgItemValue(dataItem, "gmvshare", (cur_gmv / total_gmv * 100));

				double cur_si = curItem.get(2).asDouble();
				double lst_si = lstItem.get(2).asDouble();
				setSubCatgItemValue(dataItem, "siyoy", (cur_si - lst_si) / lst_si * 100);
				setSubCatgItemValue(dataItem, "sishare", cur_si / total_si * 100);

				double cur_ll = curItem.get(3).asDouble();
				double lst_ll = lstItem.get(3).asDouble();
				setSubCatgItemValue(dataItem, "llyoy", (cur_ll - lst_ll) / lst_ll * 100);
				setSubCatgItemValue(dataItem, "llshare", cur_ll / total_ll * 100);

				double cur_nl = curItem.get(4).asDouble();
				double lst_nl = lstItem.get(4).asDouble();
				setSubCatgItemValue(dataItem, "nlyoy", (cur_nl - lst_nl) / lst_nl * 100);
				setSubCatgItemValue(dataItem, "nlshare", cur_nl / total_nl * 100);

				setSubCatgItemValue(dataItem, "str", (cur_si / cur_ll - lst_si / lst_ll) * 100);
				double cur_asp = cur_gmv / cur_si;
				double lst_asp = lst_gmv / lst_si;
				setSubCatgItemValue(dataItem, "asp", (cur_asp - lst_asp) / lst_asp * 100);
			} else if (curItem == null && lstItem != null) {
				dataItem.put("gmvyoy", -100);
				dataItem.put("gmvshare", 0);

				double lst_si = lstItem.get(2).asDouble();
				dataItem.put("siyoy", -100);
				dataItem.put("sishare", 0);

				double lst_ll = lstItem.get(3).asDouble();
				dataItem.put("llyoy", -100);
				dataItem.put("llshare", 0);

				dataItem.put("nlyoy", -100);
				dataItem.put("nlshare", 0);

				setSubCatgItemValue(dataItem, "str", -lst_si / lst_ll * 100);
				dataItem.put("asp", -100);
			} else if (curItem != null && lstItem == null) {
				double cur_gmv = curItem.get(1).asDouble();
				dataItem.put("gmvyoy", "NaN");
				setSubCatgItemValue(dataItem, "gmvshare", cur_gmv / total_gmv);

				double cur_si = curItem.get(2).asDouble();
				dataItem.put("siyoy", "NaN");
				setSubCatgItemValue(dataItem, "sishare", cur_si / total_si);

				double cur_ll = curItem.get(3).asDouble();
				dataItem.put("llyoy", "NaN");
				setSubCatgItemValue(dataItem, "llshare", cur_ll / total_ll);

				double cur_nl = curItem.get(4).asDouble();
				dataItem.put("nlyoy", "NaN");
				setSubCatgItemValue(dataItem, "nlshare", cur_nl / total_nl);

				setSubCatgItemValue(dataItem, "str", cur_si / cur_ll);
				dataItem.put("asp", "NaN");
			} else if (curItem == null && lstItem == null) {
				dataItem.put("gmvyoy", "NaN");
				dataItem.put("gmvshare", 0);

				dataItem.put("siyoy", "NaN");
				dataItem.put("sishare", 0);

				dataItem.put("llyoy", "NaN");
				dataItem.put("llshare", 0);

				dataItem.put("nlyoy", "NaN");
				dataItem.put("nlshare", 0);

				dataItem.put("str", "NaN");
				dataItem.put("asp", "NaN");
			}
		}
		return result.toString();
	}

	private void setSubCatgItemValue(ObjectNode dataItem, String name, double value) {
		if (Double.isInfinite(value) || Double.isNaN(value)) {
			dataItem.put(name, "NaN");
		} else {
			dataItem.put(name, value);
		}
	}
}
