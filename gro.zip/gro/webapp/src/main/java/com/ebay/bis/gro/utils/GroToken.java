package com.ebay.bis.gro.utils;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ebay.bis.gro.exception.ApplicationException;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.io.BaseEncoding;

public class GroToken {
	public final static Logger logger = LoggerFactory.getLogger(GroToken.class);
	public final static String KV_SPLIT_1 = "|";
	public final static String TOKEN_FORMAT_STR = "uid|%s,name|%s,t|%s";
	public final static String T = "t";
	private String token;
	private Map<String, String> kvMap = new HashMap<String,String>();
	
	
	public GroToken(String rawToken){
		this.token = rawToken;
		tokenToMap();
	}
	
	private void tokenToMap(){
		List<String> sourceList = Splitter.on(",").splitToList(token);
		for ( String str : sourceList ){
			List<String> kv = Splitter.on(KV_SPLIT_1).splitToList(str);
			if ( kv.size() != 2 ) {
				logger.warn("skip key value in gro-token: " + str);
			}else{
				kvMap.put(kv.get(0), kv.get(1));
			}
		}
	}
	
	public String getT(){
		return kvMap.get(T);
	}
	
	public Map<String, String> decryptT(String key){
		TrippleDes td = new TrippleDes(key);
		String tValue = getT();
		if (StringUtils.isEmpty(tValue)){
			throw new ApplicationException("T value is empty.");
		}
		
		String decryptedToken = td.decrypt(tValue);
		
		if ( logger.isInfoEnabled() ){
			logger.info("decrypted token: " + decryptedToken);
		}
		Map<String, String> valueMap = MapStringConvertor.toMap(decryptedToken);
		
		if ( logger.isInfoEnabled() ){
			logger.info("Key/Value in token: " + Joiner.on("&").withKeyValueSeparator("=").join(valueMap));
		}
		return valueMap;
	}

	public static String buildTokenString(String uid, String name,String level, String groCookieKey) throws ApplicationException {
		BaseEncoding base64 = BaseEncoding.base64();
		
		String uid64;
		String name64;
		String level64;
		try {
			uid64 = base64.encode(uid.getBytes(Constants.UTF8));
			name64 = base64.encode(name.getBytes(Constants.UTF8));
			level64 = base64.encode(level.getBytes(Constants.UTF8));
		} catch (UnsupportedEncodingException e) {
			throw new ApplicationException("Base64 encode failed.", e);
		}
		
		
		Map<String,String> cookieTokenMap = new HashMap<String,String>();
		cookieTokenMap.put("uid", uid);
		cookieTokenMap.put("ts", "" + System.currentTimeMillis());
		cookieTokenMap.put("l", level);
		String cookieToken = MapStringConvertor.toStr(cookieTokenMap);
		
		TrippleDes tdCookie = new TrippleDes(groCookieKey);
		String encCookieToken = tdCookie.encrypt(cookieToken);
		
		return String.format(TOKEN_FORMAT_STR, uid64, name64, encCookieToken);
	}
}

