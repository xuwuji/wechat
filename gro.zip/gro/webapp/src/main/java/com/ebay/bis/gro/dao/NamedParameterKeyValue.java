package com.ebay.bis.gro.dao;

import com.ebay.bis.gro.datamodel.pojo.KeyValue;

public class NamedParameterKeyValue extends KeyValue<String, Object> {

	public NamedParameterKeyValue(String k, Object v) {
		super(k, v);
	}
}
