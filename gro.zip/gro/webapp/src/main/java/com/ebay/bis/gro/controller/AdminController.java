package com.ebay.bis.gro.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.ebay.bis.gro.utils.GroConfig;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired 
	private GroConfig config;
	
	@RequestMapping(value="/tree_config", method=RequestMethod.GET)
	public String treeConfigPage(){
		return "admin/tree_config";
	}
	
	@RequestMapping(value="/index", method=RequestMethod.GET)
	public String indexPage(){
		return "admin/index";
	}

	@RequestMapping(value="/permission_info", method=RequestMethod.GET)
	public String permissionPage(){
		return "admin/permission_info";
	}
	
	@RequestMapping(value="/internal_info", method=RequestMethod.GET)
	public ModelAndView internalInfo(){
		Map<String,String> model = new TreeMap<String,String>();
		
		//current environment
		
		//model.put("CURRENT_ENV", config.getValue(GroConfig.GRO_ENV));
		
		String hostName = "UNKNOWN";
		try {
			InetAddress inet = InetAddress.getLocalHost();
			hostName = inet.toString();
		} catch (UnknownHostException e) {
			hostName = "UNKNOWN";
		}
		
		model.put("HostName", hostName);
		Date now = new Date();
		model.put("NOW", now.toString());
		
		for ( GroConfig.Key key: GroConfig.Key.allKeys() ){
			model.put(key.getKey(), config.getValueForDisplay(key));
		}
		
		ModelAndView mv = new ModelAndView("admin/internal_info");
		mv.addObject("results", model);
		return mv;
	}
	

}