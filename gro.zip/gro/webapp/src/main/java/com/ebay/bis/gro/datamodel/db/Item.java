package com.ebay.bis.gro.datamodel.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.google.common.base.Strings.isNullOrEmpty;


public class Item {
	
	private String id = "";
	private String pid = "";
	private String name = "";
	private String menuId = "";
	private String attr1 = "";
	private String attr2 = "";
	private String editor = "";
	
	public String getEditor() {
		return editor;
	}
	public void setEditor(String editor) {
		this.editor = editor;
	}
	
	public String getAttr2() {
		return attr2;
	}
	public void setAttr2(String attr2) {
		this.attr2 = attr2;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
	public String getAttr1() {
		return attr1;
	}
	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}

	public String toJsonString(){
		StringBuilder sb = new StringBuilder("{");
		sb.append("\"id\":\"" + id + "\",");
		sb.append("\"name\":\"" + name + "\",");
		sb.append("\"menuId\":\"" + menuId + "\"" );
		sb.append(!isNullOrEmpty(attr1)?","+attr1:"");
		sb.append(!isNullOrEmpty(attr2)?","+attr2:"");
		sb.append("}");
		return sb.toString();
	}

	
}
