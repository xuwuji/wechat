package com.ebay.bis.gro.service;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ebay.bis.gro.dao.PermissionDAO;
import com.ebay.bis.gro.datamodel.db.PermissionDo;
import com.ebay.bis.gro.exception.ApplicationException;
import com.ebay.bis.gro.utils.CacheUtils;

@Component
@Service
public class PermissionService {
	private static final Logger logger = LoggerFactory.getLogger(PermissionService.class);
	private static final char USER_SEPARATOR = ',';
	@Autowired
	private CacheUtils cacheUtils;

	@Autowired
	private PermissionDAO permissionDao;
	
	public PermissionService(){}
	
	//@Transactional
	public boolean hasPermission(String resourceId, String user){
		try {
			PermissionDo permission = this.cacheGetPermission(resourceId);
			if ( null == permission ) return true; //by default, allow users to access the resource
			String strUser = StringUtils.trimToEmpty(permission.getUsers()).toLowerCase();
			String[] users = StringUtils.split(strUser, USER_SEPARATOR);
			Set<String> userSet = new HashSet<String>(Arrays.asList(users));
			if ( userSet.contains("*") ) return true;
			if ( userSet.contains(user.toLowerCase()) ) return true;
			return false;
		} catch (Exception e) {
			throw new ApplicationException("load permission failed.", e);
		}
	}
	
	public List<PermissionDo> getPermissions(){
		return permissionDao.getPermissions();
	}

	public PermissionDo cacheGetPermission(String resourceId){
		try {
			logger.info("resourceId = " + resourceId);
			PermissionDo permission = permissionDao.cacheGetPermissionByPath(resourceId);
			return permission;
		} catch (Exception e) {
			throw new ApplicationException("load permission failed.", e);
		}
	}

	private PermissionDo addOrRemoveUsers(String path, String strUsers, boolean add){
		PermissionDo permission = permissionDao.getPermissionByPath(path);
		if ( null == permission ) return null;
		String strUser = StringUtils.trimToEmpty(permission.getUsers()).toLowerCase();
		String[] users = StringUtils.split(strUser, USER_SEPARATOR);
		Set<String> userSet = new HashSet<String>(Arrays.asList(users));
		List<String> userList = Arrays.asList(StringUtils.split(StringUtils.trimToEmpty(strUsers).toLowerCase(), USER_SEPARATOR));

		if ( add ){
			userSet.addAll(userList);
		}else{
			userSet.removeAll(userList);
		}

		String newUsers = StringUtils.join(userSet, USER_SEPARATOR);

		permission.setUsers(newUsers);
		permission.setLastModDt(new Timestamp(System.currentTimeMillis()));

		permissionDao.updatePermissionUsers(permission);

		return permission;
	}

	@Transactional
	public PermissionDo addUserToPath(String path, String usersToAdd) {
		return addOrRemoveUsers(path, usersToAdd, true) ;
	}

	@Transactional
	public PermissionDo removeUserFromPath(String path, String usersToRemove) {
		return addOrRemoveUsers(path, usersToRemove, false);
	}
}
