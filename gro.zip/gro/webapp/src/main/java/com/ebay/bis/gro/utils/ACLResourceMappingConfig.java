package com.ebay.bis.gro.utils;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Component("aclResourceMapping")
public class ACLResourceMappingConfig {

	private final static Logger logger = LoggerFactory.getLogger(ACLResourceMappingConfig.class);
	private Map<String, String> inverseResources = new HashMap<String, String>();
	private Map<String, List<String>> resources = new HashMap<String, List<String>>();
	
	public ACLResourceMappingConfig(){
		this.loadACLResource();
	}
	
	public String lookupGroupByResource(String path){
		if (StringUtils.isEmpty(path)){
			return null;
		}
		String resourceGroupId = inverseResources.get(path);
		return resourceGroupId;
	}
	
	public List<String> lookupResourcesByGroup(String group){
		if (StringUtils.isEmpty(group)){
			return null;
		}
		return resources.get(group);
	}
	
	private void loadACLResource(){
		ClassPathResource resource = new ClassPathResource("/aclResourceMapping.json");
		InputStream is;
		try {
			is = resource.getInputStream();
			ObjectNode resourceNode = JsonUtil.readValue(is, ObjectNode.class);
			Iterator<Entry<String, JsonNode>> fields = resourceNode.fields();
			while(fields.hasNext()){
				Entry<String, JsonNode> field = fields.next();
				ArrayNode value = (ArrayNode)field.getValue();
				List<String> values = new ArrayList<String>();
				for (int i = 0, len = value.size(); i < len; i++){
					String strValue = value.get(i).asText();
					if (!values.contains(strValue)){
						values.add(strValue);
					}
					inverseResources.put(strValue, field.getKey());
				}
				resources.put(field.getKey(), values);
			}
		} catch (Exception e) {
			logger.error("Error while reading and parsing ACL resources JSON file!");
		}
	}
	
	public Map<String, String> inverseResources(){
		return inverseResources;
	}
	
	public Map<String, List<String>> getResources(){
		return resources;
	}
}
