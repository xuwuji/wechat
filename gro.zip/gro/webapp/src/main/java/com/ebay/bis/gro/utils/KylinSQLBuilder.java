package com.ebay.bis.gro.utils;

import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class KylinSQLBuilder {
	private static String FILTER_SQL = "SELECT DISTINCT {{FILTER_NAME}} FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT INNER JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID = CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID = CATG_MAPPING_PROC4.LEAF_CATEG_ID INNER JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_DAILY_FACT.CAL_DT = DW_CAL_DT_IH.CAL_DT WHERE 1=1 ${^$@$^}$ ORDER BY {{FILTER_NAME}} ASC";
	private static String SGMT_FILTER_SQL = "SELECT IH_DAILY_FACT.{{FILTER_NAME}} FROM IH_DAILY_FACT_V2 IH_DAILY_FACT GROUP BY IH_DAILY_FACT.{{FILTER_NAME}} ORDER BY IH_DAILY_FACT.{{FILTER_NAME}} ASC";
	private static String METRIC_GENERIC_SQL = "SELECT CAL.{{TIME_RANGE_NAME}} AS {{TIME_RANGE_NAME}}, SUM(IH_DAILY_FACT.GMV) AS GMV, SUM(IH_DAILY_FACT.NEW_LSTG_CNT) AS NL, SUM(IH_DAILY_FACT.ENDED_LSTG_CNT) AS EL, SUM(IH_DAILY_FACT.QUANTITY) AS SI, SUM(LIVE_LSTG_CNT) AS LL, SUM(FRESH_LSTG_CNT) AS FL FROM IH_DAILY_FACT_V2 IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS CAL ON CAL.CAL_DT=IH_DAILY_FACT.CAL_DT WHERE 1=1 ${^$@$^}$ GROUP BY CAL.{{TIME_RANGE_NAME}} ORDER BY CAL.{{TIME_RANGE_NAME}} DESC";
	private static String METRIC_UL_SQL = "SELECT DW_CAL_DT_IH.{{TIME_RANGE_NAME}},COUNT(DISTINCT IH_UNIQLSTR_DAILY.SLR_ID) FROM IH_UNIQLSTR_DAILY AS IH_UNIQLSTR_DAILY JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_UNIQLSTR_DAILY.CAL_DT = DW_CAL_DT_IH.CAL_DT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_UNIQLSTR_DAILY.SITE_ID = CATG_MAPPING_PROC4.SITE_ID AND IH_UNIQLSTR_DAILY.LEAF_CATEG_ID = CATG_MAPPING_PROC4.LEAF_CATEG_ID WHERE (DW_CAL_DT_IH.CAL_DT <= '${^$1$^}$') ${^$@$^}$ GROUP BY DW_CAL_DT_IH.{{TIME_RANGE_NAME}} ORDER BY DW_CAL_DT_IH.{{TIME_RANGE_NAME}} DESC";
	private static String METRIC_TO_DATE_SQL = "SELECT CAL.{{TIME_RANGE_NAME}} AS {{TIME_RANGE_NAME}}, SUM(IH_DAILY_FACT.GMV) AS GMV, SUM(IH_DAILY_FACT.NEW_LSTG_CNT) AS NL, SUM(IH_DAILY_FACT.ENDED_LSTG_CNT) AS EL, SUM(IH_DAILY_FACT.QUANTITY) AS SI, SUM(LIVE_LSTG_CNT) AS LL , SUM(FRESH_LSTG_CNT) AS FL FROM IH_DAILY_FACT_V2 IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS CAL ON CAL.CAL_DT=IH_DAILY_FACT.CAL_DT WHERE ((CAL.CAL_DT BETWEEN '${^$1$^}$' AND '${^$2$^}$') OR (CAL.CAL_DT BETWEEN '${^$3$^}$' AND '${^$4$^}$'))  ${^$@$^}$ GROUP BY CAL.{{TIME_RANGE_NAME}} ORDER BY CAL.{{TIME_RANGE_NAME}} DESC";
	private static String SGMT_GENERIC_WEEK_SQL = "SELECT A.{{SGMT_TYPE}}, SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$1$^}$' THEN {{METRIC_TYPE}} ELSE 0 END), SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$2$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$3$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$4$^}$' THEN {{METRIC_TYPE}} ELSE 0 END), SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$5$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$6$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$7$^}$' THEN {{METRIC_TYPE}} ELSE 0 END), SUM(CASE WHEN A.RTL_WEEK_BEG_DT = '${^$8$^}$' THEN {{METRIC_TYPE}} ELSE 0 END) FROM (SELECT IH_DAILY_FACT.{{SGMT_TYPE}} AS {{SGMT_TYPE}},CAL.RTL_WEEK_BEG_DT AS RTL_WEEK_BEG_DT, SUM({{METRIC_TYPE}}) AS {{METRIC_TYPE}} FROM IH_DAILY_FACT_V2 IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS CAL ON CAL.CAL_DT=IH_DAILY_FACT.CAL_DT WHERE 1=1 ${^$@$^}$ {{EXTRA_WHERE_CLAUSE}} GROUP BY IH_DAILY_FACT.{{SGMT_TYPE}}, CAL.RTL_WEEK_BEG_DT) A GROUP BY A.{{SGMT_TYPE}} ORDER BY A.{{SGMT_TYPE}} ASC";
	private static String SGMT_GENERIC_QUARTER_SQL = "SELECT A.{{SGMT_TYPE}}, SUM(CASE WHEN A.QTR_ID = '${^$1$^}$' THEN {{METRIC_TYPE}} ELSE 0 END), SUM(CASE WHEN A.QTR_ID = '${^$2$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.QTR_ID = '${^$3$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.QTR_ID = '${^$4$^}$' THEN {{METRIC_TYPE}} ELSE 0 END), SUM(CASE WHEN A.QTR_ID = '${^$5$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.QTR_ID = '${^$6$^}$' THEN {{METRIC_TYPE}} ELSE 0 END) FROM (SELECT IH_DAILY_FACT.{{SGMT_TYPE}} AS {{SGMT_TYPE}},CAL.QTR_ID AS QTR_ID, SUM({{METRIC_TYPE}}) AS {{METRIC_TYPE}} FROM IH_DAILY_FACT_V2 IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS CAL ON CAL.CAL_DT=IH_DAILY_FACT.CAL_DT WHERE 1=1 ${^$@$^}$ {{EXTRA_WHERE_CLAUSE}} GROUP BY IH_DAILY_FACT.{{SGMT_TYPE}}, CAL.QTR_ID) A GROUP BY A.{{SGMT_TYPE}} ORDER BY A.{{SGMT_TYPE}} ASC";
	private static String SGMT_GENERIC_YEAR_SQL = "SELECT A.{{SGMT_TYPE}}, SUM(CASE WHEN A.YEAR_ID = '${^$1$^}$' THEN {{METRIC_TYPE}} ELSE 0 END), SUM(CASE WHEN A.YEAR_ID = '${^$2$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.YEAR_ID = '${^$3$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.YEAR_ID = '${^$4$^}$' THEN {{METRIC_TYPE}} ELSE 0 END) FROM (SELECT IH_DAILY_FACT.{{SGMT_TYPE}} AS {{SGMT_TYPE}},CAL.YEAR_ID AS YEAR_ID, SUM({{METRIC_TYPE}}) AS {{METRIC_TYPE}} FROM IH_DAILY_FACT_V2 IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS CAL ON CAL.CAL_DT=IH_DAILY_FACT.CAL_DT WHERE 1=1 ${^$@$^}$ {{EXTRA_WHERE_CLAUSE}} GROUP BY IH_DAILY_FACT.{{SGMT_TYPE}}, CAL.YEAR_ID) A GROUP BY A.{{SGMT_TYPE}} ORDER BY A.{{SGMT_TYPE}} ASC";
	private static String SGMT_TO_DATE_SQL = "SELECT A.{{SGMT_TYPE}},SUM(CASE WHEN A.{{TIME_RANGE_NAME}} = '${^$1$^}$' THEN {{METRIC_TYPE}} ELSE 0 END),SUM(CASE WHEN A.{{TIME_RANGE_NAME}} = '${^$2$^}$' THEN {{METRIC_TYPE}} ELSE 0 END) FROM (SELECT IH_DAILY_FACT.{{SGMT_TYPE}} AS {{SGMT_TYPE}},CAL.{{TIME_RANGE_NAME}} AS {{TIME_RANGE_NAME}}, SUM({{METRIC_TYPE}}) AS {{METRIC_TYPE}} FROM IH_DAILY_FACT_V2 IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH CAL ON IH_DAILY_FACT.CAL_DT = CAL.CAL_DT WHERE ((CAL.CAL_DT BETWEEN '${^$3$^}$' AND '${^$4$^}$') OR (CAL.CAL_DT BETWEEN '${^$5$^}$' AND '${^$6$^}$')) ${^$@$^}$ {{EXTRA_WHERE_CLAUSE}} GROUP BY IH_DAILY_FACT.{{SGMT_TYPE}}, CAL.{{TIME_RANGE_NAME}}) A GROUP BY A.{{SGMT_TYPE}} ORDER BY A.{{SGMT_TYPE}} ASC";
	private static String METRIC_DETAIL_SQL = "SELECT DW_CAL_DT_IH.RTL_WEEK_BEG_DT, SUM(IH_DAILY_FACT.{{METRIC_TYPE}}) FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_DAILY_FACT.CAL_DT=DW_CAL_DT_IH.CAL_DT WHERE DW_CAL_DT_IH.RETAIL_YEAR=${^$1$^}$ ${^$@$^}$ GROUP BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ORDER BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT  ASC";
	private static String YEAR_SOFAR_METRIC_DETAIL_SQL = "SELECT DW_CAL_DT_IH.RTL_WEEK_BEG_DT, SUM(IH_DAILY_FACT.{{METRIC_TYPE}}) FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_DAILY_FACT.CAL_DT=DW_CAL_DT_IH.CAL_DT WHERE DW_CAL_DT_IH.RTL_WEEK_BEG_DT<='${^$1$^}$' AND DW_CAL_DT_IH.RETAIL_YEAR=${^$2$^}$ ${^$@$^}$ GROUP BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ORDER BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT  ASC";
	private static String METRIC_DETAIL_BETWEEN_SQL = "SELECT DW_CAL_DT_IH.RTL_WEEK_BEG_DT, SUM(IH_DAILY_FACT.{{METRIC_TYPE}}) FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID=CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID=CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_DAILY_FACT.CAL_DT=DW_CAL_DT_IH.CAL_DT WHERE (DW_CAL_DT_IH.RTL_WEEK_BEG_DT BETWEEN '${^$1$^}$' AND '${^$2$^}$') ${^$@$^}$ GROUP BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ORDER BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT  ASC";
	private static String YEAR_WEEKS_SOFAR_SQL = "SELECT DW_CAL_DT_IH.RTL_WEEK_BEG_DT FROM DW_CAL_DT_IH AS DW_CAL_DT_IH WHERE DW_CAL_DT_IH.RTL_WEEK_BEG_DT <= '${^$1$^}$' AND DW_CAL_DT_IH.RETAIL_YEAR=${^$2$^}$ GROUP BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ORDER BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ASC";
	private static String WEEKS_A_YEAR_SQL = "SELECT DW_CAL_DT_IH.RTL_WEEK_BEG_DT FROM DW_CAL_DT_IH AS DW_CAL_DT_IH WHERE DW_CAL_DT_IH.YEAR_ID='${^$1$^}$' GROUP BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ORDER BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ASC";
	private static String WEEKS_BETWEEN_SQL = "SELECT DW_CAL_DT_IH.RTL_WEEK_BEG_DT FROM DW_CAL_DT_IH AS DW_CAL_DT_IH WHERE DW_CAL_DT_IH.RTL_WEEK_BEG_DT >= '${^$1$^}$' AND DW_CAL_DT_IH.RTL_WEEK_BEG_DT<='${^$2$^}$' GROUP BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ORDER BY DW_CAL_DT_IH.RTL_WEEK_BEG_DT ASC";
	private static String SUBCATEGORY_SQL = "SELECT {{SUB_CATEGORY}} AS SUBCATEGORY,SUM(IH_DAILY_FACT.GMV) AS GMV,SUM(IH_DAILY_FACT.QUANTITY) AS SOLD_ITEMS,SUM(IH_DAILY_FACT.LIVE_LSTG_CNT) AS LIVE_LSTG_CNT,SUM(IH_DAILY_FACT.NEW_LSTG_CNT) AS NEW_LSTG_CNT FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID = CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID = CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_DAILY_FACT.CAL_DT = DW_CAL_DT_IH.CAL_DT WHERE DW_CAL_DT_IH.RTL_WEEK_BEG_DT='${^$1$^}$' ${^$@$^}$ GROUP BY {{SUB_CATEGORY}} ORDER BY SUBCATEGORY ASC";
	private static String TOTAL_SUBCATEGORY_SQL = "SELECT SUM(IH_DAILY_FACT.GMV) AS GMV,SUM(IH_DAILY_FACT.QUANTITY) AS SOLD_ITEMS,SUM(IH_DAILY_FACT.LIVE_LSTG_CNT) AS LIVE_LSTG_CNT,SUM(IH_DAILY_FACT.NEW_LSTG_CNT) AS NEW_LSTG_CNT FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID = CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID = CATG_MAPPING_PROC4.LEAF_CATEG_ID JOIN DW_CAL_DT_IH AS DW_CAL_DT_IH ON IH_DAILY_FACT.CAL_DT = DW_CAL_DT_IH.CAL_DT WHERE DW_CAL_DT_IH.RTL_WEEK_BEG_DT='${^$1$^}$' ${^$@$^}$";
	private static String SUBCATEGORY_ITEMS_SQL = "SELECT {{SUB_CATEGORY}} AS SUBCATEGORY FROM IH_DAILY_FACT_V2 AS IH_DAILY_FACT JOIN CATG_MAPPING_PROC4_V2 AS CATG_MAPPING_PROC4 ON IH_DAILY_FACT.SITE_ID = CATG_MAPPING_PROC4.SITE_ID AND IH_DAILY_FACT.LEAF_CATEG_ID = CATG_MAPPING_PROC4.LEAF_CATEG_ID WHERE 1=1 ${^$@$^}$ GROUP BY {{SUB_CATEGORY}} ORDER BY SUBCATEGORY ASC"; // Refreshed
																																																																																													// Date
	private static String REFRESH_DATE_SQL = "SELECT CAL_DT FROM IH_DAILY_FACT_V2 GROUP BY CAL_DT ORDER BY CAL_DT DESC";

	private static int WEEK_PARAMS_LEN = 8;
	private static int QUARTER_PARAMS_LEN = 6;
	private static int YEAR_PARAMS_LEN = 4;

	private static String IN = "IN";
	private static String AND = "AND";
	private static String LEFT_BRACE = "(";
	private static String SINGLE_QUOTE = "'";
	private static String RIGHT_BRACE = ")";
	private static String BLANK_SPACE = " ";
	private static String COMMA = ",";
	private static String SQL_PARAM_PLACEHOLDER = "${^$@$^}$";
	private static String FILTER_NAME_PLACEHOLDER = "{{FILTER_NAME}}";
	private static String TIME_RANGE_NAME_PLACEHOLDER = "{{TIME_RANGE_NAME}}";
	private static String SMGT_TYPE_PLACEHOLDER = "{{SGMT_TYPE}}";
	private static String METRIC_TYPE_PLACEHOLDER = "{{METRIC_TYPE}}";
	private static String SUB_CATEGORY_PLACEHOLDER = "{{SUB_CATEGORY}}";
	private static String EXTRA_WHERE_CLAUSE = "{{EXTRA_WHERE_CLAUSE}}";
	private static String FIELD = "field";
	private static String VALUE = "value";
	private static String SQL_COL_PARAM_1 = "${^$1$^}$";
	private static String SQL_COL_PARAM_2 = "${^$2$^}$";
	private static String SQL_COL_PARAM_3 = "${^$3$^}$";
	private static String SQL_COL_PARAM_4 = "${^$4$^}$";
	private static String SQL_COL_PARAM_5 = "${^$5$^}$";
	private static String SQL_COL_PARAM_6 = "${^$6$^}$";
	private static String SQL_COL_PARAM_7 = "${^$7$^}$";
	private static String SQL_COL_PARAM_8 = "${^$8$^}$";

	public static String buildKylinSQL(String sql, ArrayNode sqlParams) throws Exception {
		if (sqlParams == null) {
			return StringUtils.replace(sql, SQL_PARAM_PLACEHOLDER, "");
		}
		Iterator<JsonNode> params = sqlParams.iterator();
		StringBuffer sb = new StringBuffer();
		while (params.hasNext()) {
			JsonNode node = params.next();
			JsonNode value = node.get(VALUE);
			JsonNode field = node.get(FIELD);
			if (value == null || field == null || StringUtils.isEmpty(field.asText())) {
				throw new Exception("SQL parameter is not valid!");
			}
			if ("All".equalsIgnoreCase(value.asText())) {
				continue;
			}
			sb.append(AND).append(BLANK_SPACE);
			sb.append(field.asText()).append(BLANK_SPACE);
			sb.append(IN).append(BLANK_SPACE).append(LEFT_BRACE);
			if (value.isArray()) {
				for (int i = 0; i < value.size(); i++) {
					sb.append(SINGLE_QUOTE).append(value.get(i).asText()).append(SINGLE_QUOTE).append(COMMA);
				}
				sb.deleteCharAt(sb.length() - 1);
			} else {
				sb.append(SINGLE_QUOTE).append(value.asText()).append(SINGLE_QUOTE);
			}
			sb.append(RIGHT_BRACE).append(BLANK_SPACE);
		}

		return StringUtils.replace(sql, SQL_PARAM_PLACEHOLDER, sb.toString());
	}

	public static String buildRefreshDateSQL() {
		return REFRESH_DATE_SQL;
	}

	public static String buildFilterSQL(String filterName, ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(filterName)) {
			throw new Exception("Filter name can not be empty!");
		}
		String sql = StringUtils.replace(FILTER_SQL, FILTER_NAME_PLACEHOLDER, filterName);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildSgmtsFilterSQL(String filterName, ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(filterName)) {
			throw new Exception("Filter name can not be empty!");
		}
		String sql = StringUtils.replace(SGMT_FILTER_SQL, FILTER_NAME_PLACEHOLDER, filterName);
		return buildKylinSQL(sql, sqlParams);
	}

	/**
	 * Generate weekly, quarterly, yearly SQL to retrieve metrics.
	 * 
	 * @param timerange
	 * @param sqlParams
	 * @return
	 * @throws Exception
	 */
	public static String buildMetricsGenericSQL(String timerange, ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(timerange)) {
			throw new Exception("Time range can not be empty!");
		}
		String sql = StringUtils.replace(METRIC_GENERIC_SQL, TIME_RANGE_NAME_PLACEHOLDER, timerange);
		return buildKylinSQL(sql, sqlParams);
	}

	/**
	 * Generate quarter to date, year to date SQL
	 * 
	 * @param timerange
	 * @param curStartD
	 * @param curEndD
	 * @param lstStartD
	 * @param lstEndD
	 * @param sqlParams
	 * @return
	 * @throws Exception
	 */
	public static String buildMetricsToDateSQL(String timerange, String curStartD, String curEndD, String lstStartD,
			String lstEndD, ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(timerange)) {
			throw new Exception("Time range can not be empty!");
		}
		if (StringUtils.isEmpty(curStartD) || StringUtils.isEmpty(curEndD) || StringUtils.isEmpty(lstStartD)
				|| StringUtils.isEmpty(lstEndD)) {
			throw new Exception("The day parameters can not be empty!");
		}
		String[] searchList = { TIME_RANGE_NAME_PLACEHOLDER, SQL_COL_PARAM_1, SQL_COL_PARAM_2, SQL_COL_PARAM_3,
				SQL_COL_PARAM_4 };
		String[] replacementList = { timerange, curStartD, curEndD, lstStartD, lstEndD };
		String sql = StringUtils.replaceEach(METRIC_TO_DATE_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildSgmtsSQL(String trId, String sgmtType, String metricType, ArrayNode timerange,
			ArrayNode sqlParams, String extra) throws Exception {
		switch (trId) {
		case "RTL_WEEK_BEG_DT":
			return buildSgmtsGenericWeekSQL(sgmtType, metricType, timerange, sqlParams, extra);
		case "QTR_ID":
			return buildSgmtsGenericQuarterSQL(sgmtType, metricType, timerange, sqlParams, extra);
		case "YEAR_ID":
			return buildSgmtsGenericYearSQL(sgmtType, metricType, timerange, sqlParams, extra);
		}
		throw new Exception("Time range type is invalid! It should be one of 'RTL_WEEK_BEG_DT', 'QTR_ID', 'YEAR_ID'.");
	}

	private static String buildSgmtsGenericWeekSQL(String sgmtType, String metricType, ArrayNode weeks,
			ArrayNode sqlParams, String extra) throws Exception {
		if (StringUtils.isEmpty(sgmtType)) {
			throw new Exception("Segment type can not be empty!");
		}
		if (weeks == null || weeks.size() != WEEK_PARAMS_LEN) {
			throw new Exception("Parameter is invalid for segments!");
		}
		String[] searchList = { SMGT_TYPE_PLACEHOLDER, METRIC_TYPE_PLACEHOLDER, SQL_COL_PARAM_1, SQL_COL_PARAM_2,
				SQL_COL_PARAM_3, SQL_COL_PARAM_4, SQL_COL_PARAM_5, SQL_COL_PARAM_6, SQL_COL_PARAM_7, SQL_COL_PARAM_8,
				EXTRA_WHERE_CLAUSE };
		String[] replacementList = new String[11];
		replacementList[0] = sgmtType;
		replacementList[1] = metricType;
		for (int i = 0, size = weeks.size(); i < size; i++) {
			replacementList[i + 2] = weeks.get(i).asText();
		}

		replacementList[10] = StringUtils.isEmpty(extra) ? "" : extra;
		String sql = StringUtils.replaceEachRepeatedly(SGMT_GENERIC_WEEK_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	private static String buildSgmtsGenericQuarterSQL(String sgmtType, String metricType, ArrayNode quarters,
			ArrayNode sqlParams, String extra) throws Exception {
		if (StringUtils.isEmpty(sgmtType)) {
			throw new Exception("Segment type can not be empty!");
		}
		if (quarters == null || quarters.size() != QUARTER_PARAMS_LEN) {
			throw new Exception("Parameter is invalid for segments!");
		}
		String[] searchList = { SMGT_TYPE_PLACEHOLDER, METRIC_TYPE_PLACEHOLDER, SQL_COL_PARAM_1, SQL_COL_PARAM_2,
				SQL_COL_PARAM_3, SQL_COL_PARAM_4, SQL_COL_PARAM_5, SQL_COL_PARAM_6, EXTRA_WHERE_CLAUSE };
		String[] replacementList = new String[9];
		replacementList[0] = sgmtType;
		replacementList[1] = metricType;
		for (int i = 0, size = quarters.size(); i < size; i++) {
			replacementList[i + 2] = quarters.get(i).asText();
		}
		replacementList[8] = StringUtils.isEmpty(extra) ? "" : extra;
		String sql = StringUtils.replaceEachRepeatedly(SGMT_GENERIC_QUARTER_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	private static String buildSgmtsGenericYearSQL(String sgmtType, String metricType, ArrayNode years,
			ArrayNode sqlParams, String extra) throws Exception {
		if (StringUtils.isEmpty(sgmtType)) {
			throw new Exception("Segment type can not be empty!");
		}
		if (years == null || years.size() != YEAR_PARAMS_LEN) {
			throw new Exception("Parameter is invalid for segments!");
		}
		String[] searchList = { SMGT_TYPE_PLACEHOLDER, METRIC_TYPE_PLACEHOLDER, SQL_COL_PARAM_1, SQL_COL_PARAM_2,
				SQL_COL_PARAM_3, SQL_COL_PARAM_4, EXTRA_WHERE_CLAUSE };
		String[] replacementList = new String[7];
		replacementList[0] = sgmtType;
		replacementList[1] = metricType;
		for (int i = 0, size = years.size(); i < size; i++) {
			replacementList[i + 2] = years.get(i).asText();
		}
		replacementList[6] = StringUtils.isEmpty(extra) ? "" : extra;
		String sql = StringUtils.replaceEachRepeatedly(SGMT_GENERIC_YEAR_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildSgmtsToDateSQL(String sgmtType, String metricType, String timerange, String curTR,
			String lstTR, String curStartD, String curEndD, String lstStartD, String lstEndD, ArrayNode sqlParams,
			String extra) throws Exception {
		if (StringUtils.isEmpty(timerange)) {
			throw new Exception("Time range can not be empty!");
		}
		if (StringUtils.isEmpty(curStartD) || StringUtils.isEmpty(curEndD) || StringUtils.isEmpty(lstStartD)
				|| StringUtils.isEmpty(lstEndD)) {
			throw new Exception("The day parameters can not be empty!");
		}
		String[] searchList = { SMGT_TYPE_PLACEHOLDER, METRIC_TYPE_PLACEHOLDER, TIME_RANGE_NAME_PLACEHOLDER,
				SQL_COL_PARAM_1, SQL_COL_PARAM_2, SQL_COL_PARAM_3, SQL_COL_PARAM_4, SQL_COL_PARAM_5, SQL_COL_PARAM_6,
				EXTRA_WHERE_CLAUSE };
		String[] replacementList = { sgmtType, metricType, timerange, curTR, lstTR, curStartD, curEndD, lstStartD,
				lstEndD, StringUtils.isEmpty(extra) ? "" : extra };
		String sql = StringUtils.replaceEachRepeatedly(SGMT_TO_DATE_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildYearSoFarDetailsMetricSQL(String metricType, String date, ArrayNode sqlParams)
			throws Exception {
		if (StringUtils.isEmpty(metricType) || StringUtils.isEmpty(date)) {
			throw new Exception("Metric type and year id can not be empty!");
		}

		String[] searchList = { METRIC_TYPE_PLACEHOLDER, SQL_COL_PARAM_1, SQL_COL_PARAM_2 };
		String[] replacementList = { metricType, date, date.substring(0, 4) };
		String sql = StringUtils.replaceEachRepeatedly(YEAR_SOFAR_METRIC_DETAIL_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildDetailsMetricSQL(String metricType, String rtl_year, ArrayNode sqlParams)
			throws Exception {
		if (StringUtils.isEmpty(metricType) || StringUtils.isEmpty(rtl_year)) {
			throw new Exception("Metric type and year id can not be empty!");
		}
		String[] searchList = { METRIC_TYPE_PLACEHOLDER, SQL_COL_PARAM_1 };
		String[] replacementList = { metricType, rtl_year };
		String sql = StringUtils.replaceEachRepeatedly(METRIC_DETAIL_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildSoFarWeeksByYearSQL(String date) throws Exception {
		String[] searchList = { SQL_COL_PARAM_1, SQL_COL_PARAM_2 };
		String[] replacementList = { date, date.substring(0, 4) };
		String sql = StringUtils.replaceEachRepeatedly(YEAR_WEEKS_SOFAR_SQL, searchList, replacementList);
		return sql;
	}

	public static String buildWeeksAYearSQL(String year) throws Exception {
		String sql = StringUtils.replace(WEEKS_A_YEAR_SQL, SQL_COL_PARAM_1, year);
		return sql;
	}

	public static String buildWeeksBetweenSQL(String start, String end) throws Exception {
		String[] searchList = { SQL_COL_PARAM_1, SQL_COL_PARAM_2 };
		String[] replacementList = { start, end };
		String sql = StringUtils.replaceEachRepeatedly(WEEKS_BETWEEN_SQL, searchList, replacementList);
		return sql;
	}

	public static String buildDetailsMetricBetweenSQL(String metricType, String startW, String endW,
			ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(metricType)) {
			throw new Exception("Metric type can not be empty!");
		}
		String[] searchList = { METRIC_TYPE_PLACEHOLDER, SQL_COL_PARAM_1, SQL_COL_PARAM_2 };
		String[] replacementList = { metricType, startW, endW };
		String sql = StringUtils.replaceEachRepeatedly(METRIC_DETAIL_BETWEEN_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildSubCategoriesSQL(String subcatg, String date, ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(subcatg)) {
			throw new Exception("Category type can not be empty!");
		}
		String[] searchList = { SUB_CATEGORY_PLACEHOLDER, SQL_COL_PARAM_1 };
		String[] replacementList = { subcatg, date };
		String sql = StringUtils.replaceEachRepeatedly(SUBCATEGORY_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildTotalSubCategoriesSQL(String date, ArrayNode sqlParams) throws Exception {
		String sql = StringUtils.replace(TOTAL_SUBCATEGORY_SQL, SQL_COL_PARAM_1, date);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildCategoryItemsSQL(String subcatg, ArrayNode sqlParams) throws Exception {
		if (StringUtils.isEmpty(subcatg)) {
			throw new Exception("Category type can not be empty!");
		}
		String[] searchList = { SUB_CATEGORY_PLACEHOLDER };
		String[] replacementList = { subcatg };
		String sql = StringUtils.replaceEachRepeatedly(SUBCATEGORY_ITEMS_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

	public static String buildULMetricSQL(String timerange, String less, ArrayNode sqlParams) throws Exception {
		String[] searchList = { TIME_RANGE_NAME_PLACEHOLDER, SQL_COL_PARAM_1 };
		String[] replacementList = { timerange, less };
		String sql = StringUtils.replaceEachRepeatedly(METRIC_UL_SQL, searchList, replacementList);
		return buildKylinSQL(sql, sqlParams);
	}

}
