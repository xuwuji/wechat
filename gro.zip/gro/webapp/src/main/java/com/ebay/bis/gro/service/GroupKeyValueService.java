package com.ebay.bis.gro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebay.bis.gro.dao.GroupKeyValueDAO;
import com.ebay.bis.gro.datamodel.db.GroupKeyValueDo;

@Service
public class GroupKeyValueService {
	public static String GROUP_LASTMESSAGE = "last_message";
	
	@Autowired
	GroupKeyValueDAO dao;

	public String queryValueByGroupKey(String group, String key){
		GroupKeyValueDo g = dao.queryByGroupKey(group, key);
		if ( null == g ) return null;
		
		return g.getValue();
	}
}
