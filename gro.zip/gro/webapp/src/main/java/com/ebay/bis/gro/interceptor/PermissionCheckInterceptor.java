package com.ebay.bis.gro.interceptor;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ebay.bis.gro.service.PermissionService;
import com.ebay.bis.gro.utils.ACLResourceMappingConfig;
import com.ebay.bis.gro.utils.Constants;
import com.ebay.bis.gro.utils.GroConfig;

public class PermissionCheckInterceptor implements HandlerInterceptor {
	private final static Logger logger = LoggerFactory.getLogger(PermissionCheckInterceptor.class);
	
	@Autowired
	private GroConfig config;
	
	@Autowired
	private ACLResourceMappingConfig aclResourceMapping;
	
	@Autowired 
	private PermissionService ps;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		//permission check is enabled only when login is enabled.
		String loginEnabled = config.getValue(GroConfig.LOGIN_ENABLED);
		if ( !"true".equalsIgnoreCase(loginEnabled) ) return true;
		
		
		Cookie[] cookies = request.getCookies();
		if ( cookies == null ) cookies = new Cookie[0];
		RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/auth/no-permission");
		
		String uid = (String)request.getAttribute(Constants.CURRENT_USER_ID);
		logger.info("current user id: " + uid);
		if ( StringUtils.isEmpty(uid) ) {
			logger.warn("No current user info found, ignore permission check.");
			return true;
		}
		
		
		String accessPath = request.getServletPath();
		logger.info("servlet path: " + accessPath);
		
		String resourceGroupId = aclResourceMapping.lookupGroupByResource(accessPath);
		accessPath = StringUtils.isEmpty(resourceGroupId) ? accessPath : resourceGroupId;
		
		boolean granted = ps.hasPermission(accessPath, uid);
		if ( !granted ){
			request.setAttribute(Constants.REQUEST_PATH, accessPath);
			dispatcher.forward(request, response);
			return false;
		}
		
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		
	}

}
