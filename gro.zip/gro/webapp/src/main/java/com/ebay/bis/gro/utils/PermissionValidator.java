package com.ebay.bis.gro.utils;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ebay.bis.gro.dao.PermissionOperation;

@Service
public class PermissionValidator {
	@Autowired
	private PermissionOperation op;

	public boolean isValid(String userId, String url, String httpMethod) {
		Set<String> roles = op.queryRolesByUser(userId);
		String capital = null;
		if ("post".equals(httpMethod)) {
			capital = "p";
		} else if ("get".equals(httpMethod)) {
			capital = "g";
		} else {
			throw new IllegalArgumentException("argument httpMethod should be post/get");
		}
		for (String role : roles) {
			Set<String> resources = op.queryResourceByRole(role);
			if (resources.contains(capital + PermissionOperation.RESOURCE_SPLITTER + url)) {
				return true;
			}
		}
		return false;
	}
}
