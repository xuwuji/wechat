package com.ebay.bis.gro.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.PreparedStatementSetter;

@Repository
public class PermissionOperation {

	public static final String RESOURCE_SPLITTER = "Y(#^.^#)Y";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Cacheable(value = "roleCache", key = "#userId")
	public Set<String> queryRolesByUser(final String userId) {
		final Set<String> result = new HashSet<String>(16);
		String sql = "select ur.role_id from user_role ur where ur.user_id = ?";
		jdbcTemplate.query(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, userId);
			}
		}, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				result.add(rs.getString(1));
			}
		});
		return result;
	}

	@Cacheable(value = "resourceCache", key = "#roleId")
	public Set<String> queryResourceByRole(final String roleId) {
		final Set<String> result = new HashSet<String>(16);
		String sql = "select rr.operation ,r.resource_content from role_resource rr left join resource r on rr.resource_id = r.id where rr.role_id = ?";
		jdbcTemplate.query(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
			}
		}, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				result.add(rs.getString(1) + RESOURCE_SPLITTER
						+ rs.getString(2));
			}
		});
		return result;
	}

	public void addNewResource(final String resource) {
		String sql = "INSERT INTO resource (resource_content) VALUES (?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, resource);
			}
		});
	}

	public void deleteResource(final String resourceId) {
		String sql = "DELETE FROM resource WHERE  id = ?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, resourceId);
			}
		});
	}

	public void addNewRole(final String role) {
		String sql = "INSERT INTO role (name) VALUES (?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, role);
			}
		});
	}

	public void deleteRole(final String roleId) {
		String sql = "DELETE FROM role WHERE id = ?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
			}
		});
	}

	@CacheEvict(value = "resourceCache", key = "#roleId")
	public void addResourceToRole(final String roleId, final String resourceId,
			final String method) {
		String sql = "INSERT INTO role_resource (role_id,resource_id,operation) VALUES (?,?,?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
				ps.setString(2, resourceId);
				ps.setString(3, method);
			}
		});
	}

	@CacheEvict(value = "resourceCache", key = "#roleId")
	public void deleteResourceForRole(final String roleId,
			final String resourceId, final String method) {
		String sql = "DELETE FROM role_resource where role_id = ? and resource_id = ? and operation = ?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
				ps.setString(2, resourceId);
				ps.setString(3, method);
			}
		});
	}

	@CacheEvict(value = "roleCache", key = "#userId")
	public void addRoleToUser(final String userId, final String roleId) {
		String sql = "INSERT INTO user_role (role_id,user_id) VALUES (?,?)";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
				ps.setString(2, userId);
			}
		});
	}

	@CacheEvict(value = "roleCache", key = "#userId")
	public void deleteRoleForUser(final String userId, final String roleId) {
		String sql = "DELETE FROM user_role where role_id = ? and user_id = ?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, roleId);
				ps.setString(2, userId);
			}
		});
	}

}
