package com.ebay.bis.gro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/index")
public class IndexController {
	
	//@Autowired 
	//private GroConfig config;
	
	@RequestMapping(path="", method=RequestMethod.GET)
	public ModelAndView test(){
		return new ModelAndView("index");
	}

	@RequestMapping(path="/test/{path}", method=RequestMethod.GET)
	public ModelAndView path(@PathVariable("path") String path){
		return new ModelAndView("test/" + path);
	}
}
