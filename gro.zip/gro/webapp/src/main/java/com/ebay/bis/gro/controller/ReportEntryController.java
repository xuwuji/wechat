package com.ebay.bis.gro.controller;

import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.ebay.bis.gro.utils.GroConfig;

@Controller
@RequestMapping("/report")
public class ReportEntryController {
	@Autowired 
	private GroConfig config;
	
	@RequestMapping(value="/event_performance", method=RequestMethod.GET)
	public ModelAndView eventPerformance(){
		Map<String,String> model = new HashMap<String,String>();
		return new ModelAndView("report/event_performance", model);
	}
	
	@RequestMapping(value="/event_monitor", method=RequestMethod.GET)
	public String eventMonitor(){
		return "report/event_monitor";
	}
	
	@RequestMapping(value="/category_performance", method=RequestMethod.GET)
	public String categoryPerformance(){
		return "report/category_performance";
	}
	
	@RequestMapping(value="/category_filter", method=RequestMethod.GET)
	public String filter(){
		return "report/category_filter";
	}
}
