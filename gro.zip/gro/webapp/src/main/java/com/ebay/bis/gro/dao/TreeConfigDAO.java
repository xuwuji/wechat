package com.ebay.bis.gro.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import com.ebay.bis.gro.datamodel.db.Item;
import com.ebay.bis.gro.datamodel.db.KeyValueDo;

@Repository
public class TreeConfigDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedJdbcTemplate;

	public List<KeyValueDo> queryDictionary() {
		String sql = "select d.key ,d.value  from dictionary d where d.key like 'tree_config%';";
		return jdbcTemplate.query(sql , new BeanPropertyRowMapper<KeyValueDo>(KeyValueDo.class));
	}

	public List<Item> queryItems( boolean partOnly) {
		String sql;
		if(partOnly){
			sql = "SELECT id as 'id' , pid as 'pid' , text_content as 'name' FROM tree_config ;";
		}else{
			sql = "SELECT id as 'id' , pid as 'pid' , text_content as 'name' , menu_id as 'menuId', attr1 as 'attr1' ,attr2 as 'attr2'  FROM tree_config ;";
		}
		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<Item>(Item.class));
	}

	public int deleteItems(final String[] deletes ) {
		int[] affected = jdbcTemplate.batchUpdate("delete from tree_config where id =?",
				new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, deletes[i]);
					}
					@Override
					public int getBatchSize() {
						return deletes.length;
					}
				});
		return affected.length;
	}

	public long updateItem(Item item) {
		String sql  ="update tree_config set pid = :pid,text_content = :name,menu_id = :menuId,attr1 = :attr1,attr2 = :attr2 where id = :id";
		SqlParameterSource paramSource = new BeanPropertySqlParameterSource(item);
		namedJdbcTemplate.update(sql, paramSource);
		return Long.parseLong(item.getId());
	}

	public long addItem(Item item) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String sql = "insert into tree_config (pid,text_content,menu_id,attr1,attr2,editor) values(:pid,:name,:menuId,:attr1,:attr2,:editor)";
		SqlParameterSource paramSource = new BeanPropertySqlParameterSource(item);
		namedJdbcTemplate.update(sql, paramSource, keyHolder);
		long id = keyHolder.getKey().longValue();
		return id;
	}

	public String queryTree() {
		String sql = "SELECT content FROM nav_tree where id = (select max(id) from nav_tree);";
		return jdbcTemplate.queryForObject(sql,  String.class );
	}
	
	public String queryTree(final String version) {
		String sql = "SELECT content FROM nav_tree where  version = ?);";
		return jdbcTemplate.queryForObject(sql,  String.class  ,version);
	}

	public Item queryItem(final String id) {
		String sql = "SELECT id as 'id' , text_content as 'name' , menu_id as 'menuId' , attr1 as 'attr1' , attr2  as 'attr2'  FROM tree_config where id =?;";
		return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<Item>(Item.class), id);
	}
	
	public void insertTree(Map<String,String> map) {
		String sql  = "insert into nav_tree (version , content , editor) values ( :version , :content , :editor)";
		SqlParameterSource paramSource = new MapSqlParameterSource(map);
		namedJdbcTemplate.update(sql, paramSource);
	}
	
	public String queryVersion() {
		String sql = "select max(version) from nav_tree ";
		return jdbcTemplate.queryForObject(sql, String.class );
	}

}
