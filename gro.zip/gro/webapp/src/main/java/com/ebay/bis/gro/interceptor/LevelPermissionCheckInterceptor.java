package com.ebay.bis.gro.interceptor;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ebay.bis.gro.utils.Constants;

/**
 * Interceptor used to check user's eBay finance level, allowed levels are defined in allowLevels properties. 
 * @author wenliu2
 *
 */
public class LevelPermissionCheckInterceptor implements HandlerInterceptor {
	//private final static Logger logger = LoggerFactory.getLogger(Level2PermissionCheckInterceptor.class);
	private Set<String> allowLevels = new HashSet<String>();
	
	@SuppressWarnings("unchecked")
	public void setAllowLevels(String levels){
		String[] levelArray = StringUtils.split(levels, ',');
		allowLevels.addAll(Arrays.asList(levelArray));
	}
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		Cookie[] cookies = request.getCookies();
		if ( cookies == null ) cookies = new Cookie[0];
		
		//TODO: use different no-permission for Level2PermissionCheck failure
		RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/auth/no-general-access");
		
		//USER_LEVEL is set in AuthCheckInterceptor
		String level = (String)request.getAttribute(Constants.USER_LEVEL);
		
		if ( allowLevels.contains(level) ){
			return true;
		}
		
		dispatcher.forward(request, response);
		return false;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		
	}

}
