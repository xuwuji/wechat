package com.ebay.bis.gro.dao;

import static com.ebay.bis.gro.dao.DBUtils.KV;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ebay.bis.gro.datamodel.db.PermissionDo;

@Repository
public class PermissionDAO {
	private final static Logger logger = LoggerFactory.getLogger(PermissionDAO.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedJdbcTemplate;
	//private static SimpleListResultExtractor<PermissionDo> extractor = new SimpleListResultExtractor<PermissionDo>(PermissionDo.class);

	public PermissionDo getPermissionByPath(final String path){
		String sql = "select id, path, admin_email as adminEmail, users, create_dt as createDt, last_mod_dt as lastModDt from permission where path = :name";

		Map<String, Object> args = DBUtils.listToMap(KV("name", path));

		List<PermissionDo> result = namedJdbcTemplate.query(sql, args, new BeanPropertyRowMapper<PermissionDo>(PermissionDo.class));

		int size = result.size();
		if ( size == 0 ){
			return null;
		}
		if ( size > 1 ){
			logger.warn("Multiple Permissions found with path of " + path);
		}
		return result.get(0);
	}

	@Cacheable(cacheNames="permissionCache")
	public PermissionDo cacheGetPermissionByPath(final String path){
		logger.info("cacheGetPermissionByPath is called.");
		return getPermissionByPath(path);
	}

	public void updatePermissionUsers(final PermissionDo permission) {
		String sql = "update permission set users=?, last_mod_dt=? where id=?";
		jdbcTemplate.update(sql, new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, permission.getUsers());
				ps.setTimestamp(2, permission.getLastModDt());
				ps.setInt(3, permission.getId());
			}
		});
	}

	public List<PermissionDo> getPermissions() {
		String sql = "select id, path, admin_email as adminEmail, users, create_dt as createDt, last_mod_dt as lastModDt from permission";
		List<PermissionDo> result = namedJdbcTemplate.query(sql, new BeanPropertyRowMapper<PermissionDo>(PermissionDo.class));
		int size = result.size();
		return result;
	}
}
