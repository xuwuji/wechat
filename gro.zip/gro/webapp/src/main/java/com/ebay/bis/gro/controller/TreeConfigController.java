package com.ebay.bis.gro.controller;

import java.util.LinkedHashMap;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ebay.bis.gro.service.TreeConfigService;
import com.ebay.bis.gro.utils.Constants;

@Controller
@RequestMapping("/tree")
public class TreeConfigController {
	@Autowired
	private TreeConfigService service;

	
	@ResponseBody
	@RequestMapping(value = "/tree_json", method = RequestMethod.POST)
	public String treeJson() {
		return service.getTreeJson();
	}

	@ResponseBody
	@RequestMapping(value = "/tree_save", method = RequestMethod.POST)
	public long treeSave(@RequestBody LinkedHashMap<String, String> fields , HttpServletRequest request ) {
		String user = (String) request.getAttribute(Constants.CURRENT_USER_ID);
		if(fields.containsKey("id")){
			return service.updateItem(fields , user);
		}else {
			return service.addItem(fields , user);
		}
	}

	@ResponseBody
	@RequestMapping(value = "/tree_meta", method = RequestMethod.POST)
	public String itemMeta() {
		return service.allTreeFields();
	}

	@ResponseBody
	@RequestMapping(value = "/tree_item", method = RequestMethod.POST)
	public String queryItem(@RequestBody LinkedHashMap<String, String> map) {
		return service.queryItem(map.get("id"));
	}

	@ResponseBody
	@RequestMapping(value = "/tree_delete", method = RequestMethod.POST)
	public int deleteItem(@RequestBody LinkedHashMap<String, String> map) {
		return service.deleteItems(map.get("ids"));
	}

	@ResponseBody
	@RequestMapping(value = "/tree_config", method = RequestMethod.POST)
	public String queryTree(@RequestBody LinkedHashMap<String, String> map) {
		return service.queryTree( map.get("version"));
	}

	@ResponseBody
	@RequestMapping(value = "/tree_publish", method = RequestMethod.POST)
	public String publishTree( HttpServletRequest request) {
		String user = (String) request.getAttribute(Constants.CURRENT_USER_ID);
		return service.publishTree( user);
	}

}