package com.ebay.bis.gro.utils;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;

import com.ebay.bis.gro.exception.ApplicationException;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.io.BaseEncoding;

/**
 * To convert Map<String,String> to String and vice versa, using base64 to encode 
 * String internally.
 * 
 * @author wenliu2
 *
 */
public class MapStringConvertor {
	private static final String UTF8 = "UTF-8";
	private static final String CONNECTOR1 = "&";
	private static final String CONNECTOR2 = "@";
	private static final BaseEncoding be = BaseEncoding.base64();
	
	public static String toStr(Map<String, String> map){
		List<Entry<String,String>> sourceList = Lists.newArrayList(map.entrySet());
		
		List<String> targetList = Lists.transform(sourceList, new Function<Entry<String,String>, String>(){
			
			@Override
			public String apply(Entry<String, String> input) {
				String key = StringUtils.trimToEmpty(input.getKey());
				String value = StringUtils.trimToEmpty(input.getValue());
				
				try{
					String encodedKey = be.encode(key.getBytes(UTF8));
					String encodedValue = be.encode(value.getBytes(UTF8));
					return encodedKey + CONNECTOR2 + encodedValue;
				}catch(UnsupportedEncodingException e){
					throw new ApplicationException("encode string failed: " + key + "," + value, e);
				}
			}
		});
		
		return Joiner.on(CONNECTOR1).skipNulls().join(targetList);
	}
	
	public static Map<String,String> toMap(String str){
		List<String> sourceList = Splitter.on(CONNECTOR1).splitToList(str);
		
		Map<String, String> map = new HashMap<String,String>();
		Splitter sp = Splitter.on(CONNECTOR2);
		for ( String strKV : sourceList ){
			List<String> listKV = sp.splitToList(strKV);
			if ( listKV.size() != 2 ){
				throw new ApplicationException("Invalid KV String: " + str);
			}
			
			String encodedKey = listKV.get(0);
			String encodedValue = listKV.get(1);
			
			try {
				String key = new String(be.decode(encodedKey), UTF8);
				String value = new String(be.decode(encodedValue), UTF8);
				map.put(key, value);
			} catch (UnsupportedEncodingException e) {
				throw new ApplicationException("failed when converting text to map: " + str, e);
			}
		}
		
		return map;
	}
}
