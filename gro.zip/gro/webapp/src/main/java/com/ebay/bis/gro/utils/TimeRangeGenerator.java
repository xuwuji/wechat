package com.ebay.bis.gro.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;

public class TimeRangeGenerator {

	public enum TimeRangeIdType {
		RTL_WEEK_BEG_DT, QTR_ID, YEAR_ID
	}

	private static String DATE_FORMAT = "yyyy-MM-dd";

	public static int getTrailingNumber(TimeRangeIdType timeDimensionType) {
		int ret = 4;
		switch (timeDimensionType) {
		case QTR_ID:
			ret = 4;
			break;
		case RTL_WEEK_BEG_DT:
			ret = 4;
			break;
		case YEAR_ID:
			ret = 3;
			break;
		default:
			ret = 4;
			break;
		}
		return ret;
	}

	public static ArrayList<String> getRecentWeekQuarterYearID(String baseDate, int recentN, TimeRangeIdType idType)
			throws Exception {
		DateTime baselineDate;
		if (baseDate == null || baseDate.length() == 0) {
			baselineDate = DateTime.now();
		} else {
			baselineDate = DateTime.parse(baseDate);
		}
		ArrayList<String> retVal = new ArrayList<String>();

		for (int i = 0; i < recentN; i++) {
			DateTime tempDate;
			switch (idType) {
			case QTR_ID:
				tempDate = baselineDate.minusMonths(i * 3);
				retVal.add(composeQtrID(tempDate));
				break;
			case RTL_WEEK_BEG_DT:
				tempDate = baselineDate.minusWeeks(i);
				retVal.add(composeWeekID(tempDate));
				break;
			case YEAR_ID:
				tempDate = baselineDate.minusYears(i);
				retVal.add(String.valueOf(tempDate.getYear()));
				break;
			default:
				throw new Exception("Invalid TimeRangeIdType");
			}
		}
		return retVal;
	}

	public static String getYoYWeekQuarterYearID(String currentID) throws Exception {
		StringBuilder retVal = new StringBuilder();
		if (currentID.indexOf("Q") == 4) {
			String[] tmp = StringUtils.split(currentID, "Q");
			retVal.append(Integer.valueOf(tmp[0]) - 1).append("Q").append(tmp[1]);
		} else if (currentID.length() == 10) {
			DateTime retailWeek = DateTime.parse(currentID);
			retVal.append(retailWeek.minusWeeks(52).toString(DATE_FORMAT));
		} else if (currentID.length() == 4) {
			retVal.append(Integer.valueOf(currentID) - 1);
		} else {
			throw new Exception("Invalid WeekQuarterYearID " + currentID);
		}
		return retVal.toString();
	}

	public static int getQuarterYearDays(String quarterYearID) throws Exception {
		int retVal = 0;
		if (quarterYearID.indexOf("Q") == 4) {
			String[] tmp = StringUtils.split(quarterYearID, "Q");
			if (tmp[1].equals("01")) {
				int year = Integer.parseInt(tmp[0]);
				if (isLeapYear(year) == true) {
					retVal = 91;
				} else {
					retVal = 90;
				}
			} else if (tmp[1].equals("02")) {
				retVal = 91;
			} else if (tmp[1].equals("03")) {
				retVal = 92;
			} else if (tmp[1].equals("04")) {
				retVal = 92;
			}
		} else if (quarterYearID.length() == 4) {
			int year = Integer.parseInt(quarterYearID);
			if (isLeapYear(year) == true) {
				retVal = 366;
			} else {
				retVal = 365;
			}
		} else {
			throw new Exception("Invalid WeekQuarterYearID " + quarterYearID);
		}
		return retVal;
	}

	public static Date getQuarterStartTime(String date) throws Exception {
		Calendar cal = Calendar.getInstance();
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		cal.setTime(day);
		int curMonth = cal.get(Calendar.MONTH);
		if (curMonth >= 0 && curMonth <= 2) {
			cal.set(Calendar.MONTH, 0);
		} else if (curMonth >= 3 && curMonth <= 5) {
			cal.set(Calendar.MONTH, 3);
		} else if (curMonth >= 6 && curMonth <= 8) {
			cal.set(Calendar.MONTH, 6);
		} else if (curMonth >= 9 && curMonth <= 11) {
			cal.set(Calendar.MONTH, 9);
		}
		cal.set(Calendar.DAY_OF_MONTH, 1);

		return cal.getTime();
	}

	public static Date getYearStartTime(String date) throws Exception {
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(day);
		cal.set(Calendar.DAY_OF_YEAR, 1);
		return cal.getTime();
	}

	public static String getQuarterStartTimeAsString(String date) throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date d = getQuarterStartTime(date);
		return format.format(d);
	}

	public static String getLastYearSameDay(String date) throws Exception {
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(day);

		cal.add(Calendar.YEAR, -1);
		return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
	}
	
	public static String addDaysToDate(String date, int days) throws Exception{
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(day);
		cal.add(Calendar.DATE, days);
		return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
	}

	public static String getYearStartTimeAsString(String date) throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date d = getYearStartTime(date);
		return format.format(d);
	}
	
	public static long calQTDDays(String date) throws Exception {
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		Date qst = getQuarterStartTime(date);
		long qtdTime = day.getTime();
		long qstTime = qst.getTime();

		long diff = (qtdTime - qstTime) / (1000 * 60 * 60 * 24);

		return diff + 1;
	}

	public static long calYTDDays(String date) throws Exception {
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(day);
		cal.set(Calendar.DAY_OF_YEAR, 1);

		long ytdTime = day.getTime();
		long ysdTime = cal.getTimeInMillis();

		long diff = (ytdTime - ysdTime) / (1000 * 60 * 60 * 24);
		return diff + 1;
	}
	
	public static String getYearByDate(String date) throws Exception{
		Date day = DateUtils.parseDate(date, "yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(day);
		return cal.get(Calendar.YEAR) + "";
	}

	private static boolean isLeapYear(int year) {
		if (year % 4 == 0) {
			return true;
		} else {
			return false;
		}
	}

	private static String composeWeekID(DateTime date) throws Exception {
		int dayInWeek = date.getDayOfWeek();
		// week start from Sunday
		if (dayInWeek == 7) {
			dayInWeek = 0;
		}
		DateTime weekBegin;
		if (dayInWeek == 6) {
			weekBegin = date.minusDays(dayInWeek);
		} else {
			weekBegin = date.minusDays(dayInWeek).minusWeeks(1);
		}
		return weekBegin.toString("yyyy-MM-dd");
	}

	private static String composeQtrID(DateTime date) throws Exception {
		return date.getYear() + "Q" + getQtrID(date.getMonthOfYear());
	}

	private static String getQtrID(int month) throws Exception {
		String val = "";
		if (month >= 1 && month <= 3) {
			val = "01";
		} else if (month >= 4 && month <= 6) {
			val = "02";
		} else if (month >= 7 && month <= 9) {
			val = "03";
		} else if (month >= 10 && month <= 12) {
			val = "04";
		} else {
			throw new Exception("Invalid month");
		}
		return val;
	}
}
