package com.ebay.bis.gro.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component("gro_env")
public class Env {
	@Autowired 
	private GroConfig config;
	
	public Env(){}
	
	public String getEnv(){
		String env = config.getValue(GroConfig.GRO_ENV);
		if ( StringUtils.isEmpty(env) ) env = "dev";
		//System.out.println("env = " + env);
		return env;
	}

	public GroConfig getGroConfig(){
		return config;
	}
}
