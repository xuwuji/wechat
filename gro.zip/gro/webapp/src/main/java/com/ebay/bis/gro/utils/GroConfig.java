package com.ebay.bis.gro.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;


@Configuration
@PropertySources({
	@PropertySource(value = "classpath:config.properties"/*,ignoreResourceNotFound=true*/),
	@PropertySource("file:${user.home}/.gro/gro-config.properties") //if same key, this will 'win'
})
public class GroConfig {
	public final static Key LOGIN_ENABLED = Key.newKey("login.enabled");
	public final static Key GRO_COOKIE_DOMAIN = Key.newKey("gro.cookie.domain");
	public final static Key GRO_COOKIE_KEY = Key.newKey("gro.cookie.key", true);
	public final static Key NOUS_KEY = Key.newKey("nous.key", true);
	public static final Key LOGIN_URL = Key.newKey("login.url");
	public static final Key GRO_ENV = Key.newKey("gro.env");
	public static final Key VERSION = Key.newKey("version");
	public static final Key KYLIN_URL = Key.newKey("kylin.url");
	public static final Key DSSONE_INIT_URL = Key.newKey("dssinit.url");
	public static final Key USER_NAME = Key.newKey("build.user.name");
	public static final Key TIMESTAMP = Key.newKey("build.ts");
	
	
	@Autowired
	private Environment env;
	
	
	public String getGroCookieDomain(){
		return env.getProperty(GRO_COOKIE_DOMAIN.getKey()); //groCookieDomain;
	}

	public String getDssOneInitURL(){
		return env.getProperty(DSSONE_INIT_URL.getKey()); //dssinit.url;
	}
	
	public String getGroCookieKey(){
		return env.getProperty(GRO_COOKIE_KEY.getKey()); //groCookieKey;
	}
	
	public String getNousKey(){
		return env.getProperty(NOUS_KEY.getKey()); //nousKey;
	}
	
	public String getKylinUrl(){
		return env.getProperty(KYLIN_URL.getKey()); //Kylin url
	}
	
	public String getValue(Key key){
		return env.getProperty(key.getKey());
	}
	
	public String getValueForDisplay(Key key){
		if ( key.isSecure ){
			return "***";
		}
		return getValue(key);
	}
	
	public static class Key implements Comparable{
		private String key;
		private boolean isSecure = false;
		
		private static List<Key> sList = new ArrayList<Key>();
		private Key(String key){
			this.key = key;
		}
		
		public static Key newKey(String key){
			Key newKey = new Key(key);
			sList.add(newKey);
			return newKey;
		}
		
		public static Key newKey(String key, boolean isSecure){
			Key newKey = new Key(key);
			newKey.isSecure = isSecure;
			sList.add(newKey);
			return newKey;
		}
		
		public String getKey(){
			return this.key;
		}
		
		public static List<Key> allKeys(){
			List<Key> ss = new ArrayList<Key>(sList);
			Collections.sort(ss);
			return Collections.unmodifiableList(ss);
		}

		@Override
		public int compareTo(Object o) {
			Key key2 = (Key)o;
			return this.key.compareToIgnoreCase(key2.key);
		}
	}
	
	/*
	 * publish as bean in spring to allow placeholder
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfig() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
