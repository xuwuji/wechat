package com.ebay.bis.gro.controller;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ebay.bis.gro.datamodel.db.PermissionDo;
import com.ebay.bis.gro.datamodel.pojo.RestResponse;
import com.ebay.bis.gro.exception.ApplicationException;
import com.ebay.bis.gro.service.PermissionService;
import com.ebay.bis.gro.utils.Constants;
import com.ebay.bis.gro.utils.GroConfig;
import com.ebay.bis.gro.utils.GroToken;
import com.ebay.bis.gro.utils.MapStringConvertor;
import com.ebay.bis.gro.utils.TrippleDes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.io.BaseEncoding;

@Controller
@RequestMapping("/auth")
public class LoginController {
	private static final String UTF8 = "UTF-8";
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired 
	private GroConfig config;

	@Autowired
	private PermissionService ps;
	
	@RequestMapping(path="/test", method=RequestMethod.GET)
	public ModelAndView test(){
		return new ModelAndView("auth/test");
	}
	
	@RequestMapping(path="/login", method=RequestMethod.GET)
	public ModelAndView login(@RequestParam("old_url") String oldUrl, Map<String, Object> model){
		model.put("login_url", config.getValue(GroConfig.LOGIN_URL));
		model.put("old_url", oldUrl);
		return new ModelAndView("auth/login", model); //call login.jsp
	}

	/**
	 * Used to return a JSON error object for service call auth checking, used by SErviceAuthCheckInterceptor
	 * @throws JsonProcessingException 
	 */
	@RequestMapping(path="/service-login-needed", method=RequestMethod.GET)
	@ResponseBody
	public RestResponse serviceLoginNeeded() throws JsonProcessingException{
		return RestResponse.LOGIN_ERROR;
	}
	
	@RequestMapping(path="/pre-login", method=RequestMethod.GET)
	public ModelAndView preLogin(Model model){
		return new ModelAndView("auth/pre-login"); //call login.jsp
	}
	
	@RequestMapping(path="/logout", method=RequestMethod.GET)
	public ModelAndView logout(HttpServletResponse resp, Model model){
		String domain = config.getGroCookieDomain();
		Cookie cookie = new Cookie(Constants.COOKIE_GRO_TOKEN,"");
		cookie.setPath("/");
		if ( !StringUtils.isEmpty(domain) ){
			cookie.setDomain(domain);
		}
		
		cookie.setMaxAge(0); //to remove cookie 
		resp.addCookie(cookie);
		
		return new ModelAndView("auth/logout"); //call login.jsp
	}
	
	@RequestMapping(path = "/verify", method = RequestMethod.GET)
	public ModelAndView verifyLogin(
			@RequestParam(value="token", defaultValue="", required=false) String token,
			@RequestParam(value="base64url", defaultValue="", required=false) String base64url,
			HttpServletResponse resp
			){
		String nousKey = config.getNousKey();
		TrippleDes td = new TrippleDes(nousKey);
		String decryptedToken = td.decrypt(token);
		Map<String, String> map = MapStringConvertor.toMap(decryptedToken);
		
		//encrypt token, "uid", "name", and "validto" could be fetched from token.
		String strValidTo = map.get("validto");
		if ( strValidTo == null ) strValidTo = "0";
		long validto = Long.parseLong(strValidTo);
		
		Map<String,String> model = new HashMap<String, String>();
		
		if ( System.currentTimeMillis() > validto ){
			model.put("msg", "login failed, token expired, debug info-[validto: " + strValidTo + "]");
			return new ModelAndView("auth/msg", model);
		}
		
		String uid = StringUtils.trimWhitespace(map.get("uid"));
		String name = StringUtils.trimWhitespace(map.get("name"));
		String l = StringUtils.trimWhitespace(map.get("l")); //user level		
		
		String groCookieValue = GroToken.buildTokenString(uid, name, l, config.getGroCookieKey());
		
		String domain = config.getGroCookieDomain();
		addGroTokenCookie(groCookieValue, domain, resp);
		
		//to set cookie for local box, to help debug.
		if ( !StringUtils.isEmpty(domain) ){
			addGroTokenCookie(groCookieValue, "", resp);
		}
		
		if ( !StringUtils.isEmpty(base64url) ){
			try {
				String url = new String(BaseEncoding.base64().decode(base64url), UTF8);
				return new ModelAndView("redirect:" + url);
			} catch (UnsupportedEncodingException e) {
				throw new ApplicationException("exception to decode", e);
			}
		}
		
		model.put("msg", "success");
		return new ModelAndView("auth/msg", model);
	}
	
	private void addGroTokenCookie(String cookieValue, String domain, HttpServletResponse resp){
		Cookie cookie = new Cookie(Constants.COOKIE_GRO_TOKEN,cookieValue);
		cookie.setPath("/");
		cookie.setMaxAge(-1);
		if ( !StringUtils.isEmpty(domain) ){
			cookie.setDomain(domain);
		}
		resp.addCookie(cookie);
	}

	@RequestMapping(path="/no-permission", method=RequestMethod.GET)
	public ModelAndView noPermission(HttpServletRequest req, Model model){
		String uid = (String)req.getAttribute(Constants.CURRENT_USER_ID);
		String accessPath = (String)req.getAttribute(Constants.REQUEST_PATH);
		
		if ( logger.isInfoEnabled() ){
			logger.info("accessPath: " + accessPath + ", uid: " + uid);
		}
		
		PermissionDo resource = ps.cacheGetPermission(accessPath);
		if ( null != resource ){
			model.addAttribute("resource_admin",resource.getAdminEmail());
		}

		model.addAttribute("path", accessPath);
		model.addAttribute("uid", uid);
		return new ModelAndView("auth/no-permission"); //forward to no-permission
	}
	
	@RequestMapping(path="/no-general-access", method=RequestMethod.GET)
	public ModelAndView noGeneralAccess(HttpServletRequest req, Model model) {
		String uid = (String)req.getAttribute(Constants.CURRENT_USER_ID);
		String accessPath = (String)req.getAttribute(Constants.REQUEST_PATH);
		
		if (logger.isInfoEnabled()){
			logger.info("accessPath: " + accessPath + ", uid: " + uid);
		}
		model.addAttribute("path", accessPath);
		model.addAttribute("uid", uid);
		return new ModelAndView("auth/no-general-access");
	}
}
