package com.ebay.bis.gro.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ebay.bis.gro.dao.TreeConfigDAO;
import com.ebay.bis.gro.datamodel.db.Item;
import com.ebay.bis.gro.datamodel.db.KeyValueDo;
import com.ebay.bis.gro.utils.JsonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import static com.google.common.base.Strings.nullToEmpty;
import static com.google.common.base.Strings.isNullOrEmpty;

@Component
@Service
public class TreeConfigService {

	private static final Logger logger = LoggerFactory.getLogger(TreeConfigService.class);
	@Autowired
	private TreeConfigDAO treeConfigDao;
	private  String[] attr1Set;
	private  String[] attr2Set;
	private  String[] fixSet;
	private  String[] booleanSet;
	private  String fields;

	@PostConstruct
	@Transactional(readOnly=true)
	public void init() {
		List<KeyValueDo> kvs = treeConfigDao.queryDictionary();
		for (KeyValueDo lookup : kvs) {
			String key = lookup.getKey();
			String[] values = lookup.getValue().split(",");
			switch (key) {
			case "tree_config.attr1":
				attr1Set = values;
				break;
			case "tree_config.attr2":
				attr2Set = values;
				break;
			case "tree_config.fix":
				fixSet = values;
				break;
			case "tree_config.boolean":
				booleanSet = values;
				break;
			}
		}
		String[] all = (String[]) ArrayUtils.addAll(ArrayUtils.addAll(fixSet, attr1Set), attr2Set);
		try {
			fields = "[" + JsonUtil.writeValueAsString(all) + "," + JsonUtil.writeValueAsString(booleanSet) + "]";
		} catch (JsonProcessingException e) {
			logger.warn("invalid array to build json", e);
		}
	}

	private String recursiveJson(Item cur, Map<String, List<Item>> map, TreeJsonBuilder jb) {
		StringBuilder sb = new StringBuilder();
		jb.buildAttrs(sb, cur);
		List<Item> list = map.get(cur.getId());
		if (list != null) {
			jb.buildChildren(sb);
			for (int i = 0; i < list.size(); i++) {
				sb.append(recursiveJson(list.get(i), map, jb));
				if (i != list.size() - 1) {
					sb.append(",");
				}
			}
			sb.append("]");
		}
		sb.append("}");
		return sb.toString();
	}

	private Map<String, List<Item>> buildMap(List<Item> items) {
		Map<String, List<Item>> map = new HashMap<>();
		for (Item it : items) {
			String pid = it.getPid();
			if (map.containsKey(pid)) {
				map.get(pid).add(it);
			} else {
				List<Item> list = new ArrayList<>();
				list.add(it);
				map.put(pid, list);
			}
		}
		return map;
	}

	@Transactional
	public int deleteItems(String ids) {
		return treeConfigDao.deleteItems(ids.split(","));
	}
	
	@Transactional(readOnly=true)
	public String getTreeJson() {
		List<Item> items = treeConfigDao.queryItems( true);
		Map<String, List<Item>> map = buildMap(items);
		Item root = new Item();
		root.setId("-1");
		root.setPid("-1");
		root.setName("root");
		String json = recursiveJson(root, map, new TreeJsonBuilder() {
			@Override
			public void buildAttrs(StringBuilder sb, Item cur) {
				sb.append("{\"id\":\"" + cur.getId() + "\",\"name\":\"" + cur.getName() + "\"");
			}
			@Override
			public void buildChildren(StringBuilder sb) {
				sb.append(",\"children\":[");
			}
		});
		return json;
	}

	public String allTreeFields() {
		return fields;
	}

	@Transactional(readOnly=true)
	public String queryItem(String id) {
		Item item = treeConfigDao.queryItem(id);
		return item.toJsonString();
	}

	@Transactional
	public String publishTree( final String user) {
		StringBuilder json = new StringBuilder("{\"id_config\":{");
		List<Item> items = treeConfigDao.queryItems( false);
		for (int i = 0, len = items.size(); i < len; i++) {
			Item item = items.get(i);
			if (!isNullOrEmpty(item.getAttr2())) {
				json.append("\"" + item.getMenuId() + "\":{" + item.getAttr2() + "},");
			}
		}
		int last  = json.length() - 1;
		if(json.charAt(last)==','){
			json.deleteCharAt(last);
		}
		json.append("},\"menu\":");
		Map<String, List<Item>> map = buildMap(items);
		Item item = map.get("-1").get(0);
		String result = recursiveJson(item, map, new TreeJsonBuilder() {
			@Override
			public void buildAttrs(StringBuilder sb, Item cur) {
				sb.append("{\"id\":\"" + cur.getMenuId() + "\",\"text\":\"" + cur.getName() + "\"");
				sb.append(!isNullOrEmpty(cur.getAttr1())?(","+cur.getAttr1()):"");
			}
			@Override
			public void buildChildren(StringBuilder sb) {
				sb.append(",\"items\":[");
			}
		});
		String content = json.append(result + "}").toString();
		String version = treeConfigDao.queryVersion();
		String newVersion = null;
		if(isNullOrEmpty(version)){
			newVersion = "1";
		} else {
			long v = Long.parseLong(version);
			newVersion = String.valueOf(v + 1);
		}
		Map<String, String> store = new HashMap<String, String>(4);
		store.put("content", content);
		store.put("version", newVersion);
		store.put("editor", user);
		treeConfigDao.insertTree(store);
		return "1";
	}

	@Transactional
	public long updateItem(LinkedHashMap<String, String> map , String user) {
		Item it = new Item();
		it.setId(map.get("id"));
		it.setPid(map.get(fixSet[0]));
		it.setName(nullToEmpty(map.get(fixSet[1])));
		it.setMenuId(nullToEmpty(map.get(fixSet[2])));
		it.setAttr1(buildStr(attr1Set, map));
		it.setAttr2(buildStr(attr2Set, map));
		it.setEditor(user);
		return treeConfigDao.updateItem(it);
	}

	@Transactional
	public long addItem(LinkedHashMap<String, String> map , String user) {
		Item it = new Item();
		it.setPid(map.get(fixSet[0]));
		it.setName(nullToEmpty(map.get(fixSet[1])));
		it.setMenuId(nullToEmpty(map.get(fixSet[2])));
		it.setAttr1(buildStr(attr1Set, map));
		it.setAttr2(buildStr(attr2Set, map));
		it.setEditor(user);
		return treeConfigDao.addItem(it);
	}

	@Transactional(readOnly=true)
	@Cacheable(value={"navigationTreeCache"})
	public String queryTree(String version) {
		if(isNullOrEmpty(version)){
			return treeConfigDao.queryTree();
		} else {
			return treeConfigDao.queryTree(version);
		}
	}

	/*
	 * build a String format like below:
	 * "attr1":"value1","attr2":"value2","attr3":"value3" all the keys and
	 * values are in the map
	 */
	private String buildStr(String[] set, LinkedHashMap<String, String> map) {
		StringBuffer sb = new StringBuffer();
		boolean first = true;
		for (int i = 0 , len = set.length; i < len ; i++) {
			String key = set[i];
			if (map.containsKey(key)) {
				if (first) {
					first = false;
				} else {
					sb.append(",");
				}
				sb.append(addQuotes(key) + ":" + addQuotes(map.get(key)));
			}
		}
		return sb.toString();
	}

	private String addQuotes(String content) {
		if ("true".equals(content) || "false".equals(content)) {
			return content;
		}
		return "\"" + content + "\"";
	}

}
