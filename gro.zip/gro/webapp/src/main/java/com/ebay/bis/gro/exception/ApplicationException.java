package com.ebay.bis.gro.exception;

public class ApplicationException extends RuntimeException {
	private static final long serialVersionUID = 1922955215008755603L;
	
	public ApplicationException(String cause){
		super(cause);
	}
	
	public ApplicationException(String msg, Throwable e){
		super(msg, e);
	}
}
