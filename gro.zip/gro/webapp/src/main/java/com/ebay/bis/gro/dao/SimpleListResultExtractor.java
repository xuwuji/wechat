package com.ebay.bis.gro.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

public class SimpleListResultExtractor<T> implements ResultSetExtractor<List<T>> {
	private Class<T> type;
	
	public SimpleListResultExtractor(Class<T> type){
		this.type = type;
	}

	@Override
	public List<T> extractData(ResultSet rs) throws SQLException, DataAccessException {
		return DBUtils.toBeanList(rs, this.type);
	}
}
