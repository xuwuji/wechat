package com.ebay.bis.gro.datamodel.db;

import java.sql.Timestamp;

/**
 * Data object of permission. DB table: permission
 * @author wenliu2
 *
 */
public class PermissionDo {
	private int id;
	private String path;
	private String admin_email;
	private String users;
	private Timestamp create_dt;
	private Timestamp last_mod_dt;

	public PermissionDo(){
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getAdminEmail() {
		return admin_email;
	}

	public void setAdminEmail(String adminEmail) {
		this.admin_email = adminEmail;
	}

	public String getUsers() {
		return users;
	}

	public void setUsers(String users) {
		this.users = users;
	}

	public Timestamp getCreateDt() {
		return create_dt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.create_dt = createDt;
	}

	public Timestamp getLastModDt() {
		return last_mod_dt;
	}

	public void setLastModDt(Timestamp lastModDt) {
		this.last_mod_dt = lastModDt;
	}
}
