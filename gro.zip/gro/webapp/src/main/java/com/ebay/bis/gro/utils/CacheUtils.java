package com.ebay.bis.gro.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component("CacheUtils")

public class CacheUtils {
	private final static Logger logger = LoggerFactory.getLogger(CacheUtils.class);
	
	@Cacheable(cacheNames="dynamicresource", condition="!#debug") //cache only when debug = false
	public String getTextWithReplacement(String path, String env, String variable, boolean debug) throws IOException{
		if ( logger.isInfoEnabled() ){
			//logger.info("textWithEnv is called.");
		}
		
		InputStream is = new FileInputStream(path);
		try{
			String text = IOUtils.toString(is, Constants.UTF8);
			return text.replace(variable, env);
		}finally{
			IOUtils.closeQuietly(is);
		}
	}
	
	
	public String getPermissionResourceName(){
		return "/permission.json";
	}

}