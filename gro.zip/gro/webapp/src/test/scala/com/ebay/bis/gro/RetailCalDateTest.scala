package com.ebay.bis.gro

import java.text.SimpleDateFormat

import com.ebay.bis.gro.utils.CalDate
import org.elasticsearch.common.joda.time.DateTime
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.{FunSuite, Matchers, FlatSpec}

/**
  * Created by yangzhou on 12/2/15.
  */
@RunWith(classOf[JUnitRunner])
class RetailCalDateTest extends FunSuite  {

  test("CalDate provides correct isInCrssYrWk") {
    val date = new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2018/12/30"))
    assert(CalDate.isInCrssYrWk(date))
  }

  test("CalDate should be able to calculate retail information correctly") {
    var cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2015/11/30")))
    assert(cdt.current.isEqual(new DateTime(2015, 11, 30, 0, 0)))
    assert(cdt.rtlYr == 2015)
    assert(cdt.rtlWk == 48)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2015, 1,4, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2015, 11,29, 0, 0)))

    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2015/01/01")))
    assert(cdt.current.isEqual(new DateTime(2015, 1, 1, 0, 0)))
    assert(cdt.rtlYr == 2014)
    assert(cdt.rtlWk == 53)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2013, 12,29, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2014, 12,28, 0, 0)))

    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2016/01/01")))
    assert(cdt.current.isEqual(new DateTime(2016, 1, 1, 0, 0)))
    assert(cdt.rtlYr == 2015)
    assert(cdt.rtlWk == 52)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2015, 1,4, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2015, 12,27, 0, 0)))

    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2016/01/03")))
    assert(cdt.current.isEqual(new DateTime(2016, 1, 3, 0, 0)))
    assert(cdt.rtlYr == 2016)
    assert(cdt.rtlWk == 1)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2016, 1,3, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2016, 1,3, 0, 0)))

    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2017/01/01")))
    assert(cdt.current.isEqual(new DateTime(2017, 1, 1, 0, 0)))
    assert(cdt.rtlYr == 2017)
    assert(cdt.rtlWk == 1)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2017, 1,1, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2017, 1,1, 0, 0)))


    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2016/12/31")))
    assert(cdt.current.isEqual(new DateTime(2016, 12, 31, 0, 0)))
    assert(cdt.rtlYr == 2016)
    assert(cdt.rtlWk == 52)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2016, 1,3, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2016, 12,25, 0, 0)))

    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2018/12/30")))
    assert(cdt.current.isEqual(new DateTime(2018, 12, 30, 0, 0)))
    assert(cdt.rtlYr == 2019)
    assert(cdt.rtlWk == 1)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2018, 12,30, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2018, 12,30, 0, 0)))

    cdt = new CalDate(new DateTime(new SimpleDateFormat("yyyy/MM/dd").parse("2018/12/31")))
    assert(cdt.current.isEqual(new DateTime(2018, 12, 31, 0, 0)))
    assert(cdt.rtlYr == 2019)
    assert(cdt.rtlWk == 1)
    assert(cdt.rtlYrBgnDt.isEqual(new DateTime(2018, 12,30, 0, 0)))
    assert(cdt.rtlWkBgnDt.isEqual(new DateTime(2018, 12,30, 0, 0)))

  }

}