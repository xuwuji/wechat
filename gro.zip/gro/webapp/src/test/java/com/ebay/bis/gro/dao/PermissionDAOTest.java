package com.ebay.bis.gro.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ebay.bis.gro.datamodel.db.PermissionDo;

@ContextConfiguration(locations = {"classpath:test-db-context.xml"})
@RunWith(SpringJUnit4ClassRunner.class)

public class PermissionDAOTest {

	@Autowired
	private PermissionDAO dao;

	@Test
	public void testGetPermissionByPath() {
		PermissionDo p = dao.getPermissionByPath("/permission/adduser");
		Assert.assertEquals(p.getAdminEmail(), "wenliu2@ebay.com");
		Assert.assertEquals(p.getPath(), "/permission/adduser");
		Assert.assertEquals(p.getUsers(), "wenliu2,lichzhou,dazhao");
	}

	@Test
	public void testCacheGetPermissionByPath() {
		PermissionDo p = dao.getPermissionByPath("/permission/adduser");
		Assert.assertEquals(p.getAdminEmail(), "wenliu2@ebay.com");
		Assert.assertEquals(p.getPath(), "/permission/adduser");
		Assert.assertEquals(p.getUsers(), "wenliu2,lichzhou,dazhao");
	}

	@Test
	public void testUpdatePermissionUsers() {
		PermissionDo p = dao.getPermissionByPath("/permission/adduser");
		String oldUsers = p.getUsers();
		p.setUsers("test");
		dao.updatePermissionUsers(p);

		p = dao.getPermissionByPath("/permission/adduser");
		Assert.assertEquals(p.getUsers(), "test");

		p.setUsers(oldUsers);
		dao.updatePermissionUsers(p);
	}
}
