package com.ebay.bis.gro.utils;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TrippleDesTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEncryptDecrypt() {
		TrippleDes td = new TrippleDes();
		String text1 = "ThisIsATestStringToBeEncrypted";
		String text2 = "ADifferentString";

		String encrypted1 = td.encrypt(text1);
		String decryptedText1 = td.decrypt(encrypted1);

		assertEquals(text1, decryptedText1);

		String encrypted2 = td.encrypt(text2);
		String decryptedText2 = td.decrypt(encrypted2);

		assertEquals(decryptedText2, text2);
	}
}
