package com.ebay.bis.gro.utils;

import javax.servlet.http.Cookie;

import org.junit.Assert;

import org.junit.Test;

public class CookieUtilsTest {

	@Test
	public void testGetCookieByName() {
		Cookie[] cookies = new Cookie[0];
		String result = CookieUtils.getCookieByName(cookies, Constants.COOKIE_GRO_TOKEN, "");
		Assert.assertEquals("", result);
		
		cookies = new Cookie[1];
		cookies[0] = new Cookie(Constants.COOKIE_GRO_TOKEN, "token-value");
		
		result = CookieUtils.getCookieByName(cookies, Constants.COOKIE_GRO_TOKEN, "");
		Assert.assertEquals("token-value", result);
		
		
		
	}

}
