package com.ebay.bis.gro.utils;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.common.collect.MapDifference.ValueDifference;

public class MapStringConvertorTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIt() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("m1", "abc 12");
		map.put("k", "%=+@&");
		map.put("ab", null);

		String encodedStr = MapStringConvertor.toStr(map);
		Map<String, String> encodedMap = MapStringConvertor.toMap(encodedStr);

		MapDifference<String, String> diff = Maps.difference(map, encodedMap);
		System.out.println(diff);

		Map<String, ValueDifference<String>> diffDetail = diff.entriesDiffering();

		// ab entry should be different, old value is null, and new value is ""
		ValueDifference<String> diffValues = diffDetail.get("ab");

		assertNotNull("ab entry should be different", diffValues);
		assertEquals("left value should be null", null, diffValues.leftValue());
		assertEquals("right value should be empty", "", diffValues.rightValue());

	}

}
