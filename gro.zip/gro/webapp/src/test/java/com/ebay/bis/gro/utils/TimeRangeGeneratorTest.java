package com.ebay.bis.gro.utils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

import com.ebay.bis.gro.utils.TimeRangeGenerator.TimeRangeIdType;

public class TimeRangeGeneratorTest {

	@Test
	public void testGetRecentWeek() throws Exception {
		ArrayList<String> result = TimeRangeGenerator.getRecentWeekQuarterYearID("2015-01-03", 4,
				TimeRangeIdType.RTL_WEEK_BEG_DT);
		assertEquals("[2014-12-28, 2014-12-21, 2014-12-14, 2014-12-07]", result.toString());

		ArrayList<String> result2 = TimeRangeGenerator.getRecentWeekQuarterYearID("2015-10-09", 4,
				TimeRangeIdType.RTL_WEEK_BEG_DT);
		assertEquals("[2015-09-27, 2015-09-20, 2015-09-13, 2015-09-06]", result2.toString());

		ArrayList<String> result3 = TimeRangeGenerator.getRecentWeekQuarterYearID("2015-10-04", 4,
				TimeRangeIdType.RTL_WEEK_BEG_DT);
		assertEquals("[2015-09-27, 2015-09-20, 2015-09-13, 2015-09-06]", result3.toString());
	}

	@Test
	public void testGetRecentQuarter() throws Exception {
		ArrayList<String> result = TimeRangeGenerator.getRecentWeekQuarterYearID("2015-01-03", 4,
				TimeRangeIdType.QTR_ID);
		assertEquals("[2015Q01, 2014Q04, 2014Q03, 2014Q02]", result.toString());
	}

	@Test
	public void testGetRecentYear() throws Exception {
		ArrayList<String> result = TimeRangeGenerator.getRecentWeekQuarterYearID("2015-01-03", 4,
				TimeRangeIdType.YEAR_ID);
		assertEquals("[2015, 2014, 2013, 2012]", result.toString());
	}

	@Test
	public void testGetYoYWeekQuarterYearID() throws Exception {
		String input1 = "2015";
		String input2 = "2015Q03";
		String input3 = "2014-12-28";

		String result1 = TimeRangeGenerator.getYoYWeekQuarterYearID(input1);
		assertEquals("2014", result1);

		String result2 = TimeRangeGenerator.getYoYWeekQuarterYearID(input2);
		assertEquals("2014Q03", result2);

		String result3 = TimeRangeGenerator.getYoYWeekQuarterYearID(input3);
		assertEquals("2013-12-29", result3);
	}

	@Test
	public void testGetWeekQuarterYearDays() throws Exception {
		String input1 = "2014";
		String input2 = "2014Q02";

		int result1 = TimeRangeGenerator.getQuarterYearDays(input1);
		assertEquals(365, result1);

		int result2 = TimeRangeGenerator.getQuarterYearDays(input2);
		assertEquals(91, result2);
	}

	@Test
	public void testGetWeekQuarterYearDays2() throws Exception {
		// TimeRangeGenerator generator = new TimeRangeGenerator("2015-09-11");
		//
		// String input1 = "2015";
		// String input2 = "2015Q03";
		//
		// DateTime d1 = DateTime.parse("2015-01-11");
		// DateTime d2 = DateTime.parse("2015-01-01");
		// int days = Days.daysBetween(d1, d2).getDays();
		//
		// int result1 = generator.getQuarterYearDays(input1);
		// assertEquals(365, result1);
		//
		// int result2 = generator.getQuarterYearDays(input2);
		// assertEquals(92, result2);
	}
}
