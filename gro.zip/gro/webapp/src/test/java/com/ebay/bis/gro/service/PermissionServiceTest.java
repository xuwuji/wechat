package com.ebay.bis.gro.service;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ebay.bis.gro.datamodel.db.PermissionDo;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("/test-config.xml")

@ContextConfiguration(locations = {"classpath:test-db-context.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
//@RunWith(MockitoJUnitRunner.class)
public class PermissionServiceTest {
	//@Mock private CacheUtils utils;
	//@InjectMocks private PermissionService ps;
	@Autowired
	private PermissionService ps;
	
	@Before
    public void init() {
    }
	
	@Test 
	public void testHasPermissions(){
		Assert.assertTrue(ps.hasPermission("/permission/adduser", "wenliu2"));
		Assert.assertFalse(ps.hasPermission("/permission/adduser", "baduser"));
		
		//if there is no configuration, then return true
		Assert.assertTrue(ps.hasPermission("/permission/badpath", "baduser"));

		//if * is defined in users, then return true
		Assert.assertTrue(ps.hasPermission("/startest", "baduser"));
	}

	@Test
	public void testAddOrRemoveUser() throws JsonParseException, JsonMappingException, IOException {
		PermissionDo p = ps.addUserToPath("/permission/adduser", "tt");
		Assert.assertTrue(p.getUsers().contains("tt"));

		p = ps.removeUserFromPath("/permission/adduser", "tt");
		Assert.assertFalse(p.getUsers().contains("tt"));
		
		/*
        Mockito.when(utils.getPermissions()).thenReturn(getPermissions("/permission-test.json"));
		Assert.assertTrue(ps.hasPermission("/home/t/landing1", "wenliu2"));	 //if there is no resource, consider it's true
		Assert.assertTrue(ps.hasPermission("/home/t/landing", "wenliu2"));
		Assert.assertFalse(ps.hasPermission("/home/t/landing", "zhangsan"));
		*/
	}

	/*
	private Permissions getPermissions(String resource) throws IOException{
		return CacheUtils.getPermissionsHelper(resource);
	}
	*/
}
