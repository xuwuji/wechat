insert into permission(path, admin_email, users, create_dt, last_mod_dt)
values ('/permission/adduser', 'wenliu2@ebay.com', 'wenliu2,lichzhou,dazhao', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

insert into permission(path, admin_email, users, create_dt, last_mod_dt)
values ('/startest', 'wenliu2@ebay.com', '*,wenliu2,lichzhou,dazhao', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
