CREATE TABLE dictionary (
  id INT NOT NULL AUTO_INCREMENT,
  key VARCHAR(100) DEFAULT NULL,
  value VARCHAR(1000) DEFAULT NULL,
  PRIMARY KEY (id));

/*INDEX dictionary_idx01 (key ASC)); */
  create index dictionary_idx01 on dictionary (key asc);
