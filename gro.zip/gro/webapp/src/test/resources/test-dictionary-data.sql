INSERT INTO dictionary(key,value) VALUES ('tree_config.attr1','href,disabled,img,borderColor,show_profile,applogo,dsslogo');
INSERT INTO dictionary(key,value) VALUES ('tree_config.attr2','wiki,dl,breadcrumb,title');
INSERT INTO dictionary(key,value) VALUES ('tree_config.fix','pid,name,menuId,env');
INSERT INTO dictionary(key,value) VALUES ('tree_config.boolean','disabled,show_profile');
