CREATE TABLE PERMISSION (
  id INT NOT NULL AUTO_INCREMENT,
  path VARCHAR(1024) NOT NULL,
  admin_email VARCHAR(80) NOT NULL,
  users TEXT NULL,
  create_dt TIMESTAMP NOT NULL,
  last_mod_dt TIMESTAMP NOT NULL,
  PRIMARY KEY (id));

/*INDEX PERMISSION_IDX01 (path ASC)); */
  create index permission_idx01 on permission (path asc);

