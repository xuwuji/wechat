GRO Event monitor project
=========================

* [project wiki](https://wiki.vip.corp.ebay.com/display/DataServicesandSolutions/4.+Event+Monitor) 
* [service details](../documents/README.md)
...

#### Setup Development Environment

...

#### Start Server and Debug
1) Before staring server, you need to create a folder named .gro under user home directory($HOME for MacOS and Linux system, %USERPROFILE% for windows), and create gro-config.properties under that directory.

2)

#### Compile and Package

```
# for product
$ mvn clean scala:compile package -Pprod

# for qa
$ mvn clean scala:compile package -Pqa
```
