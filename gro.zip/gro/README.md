# gro
## Read below instructions before starting your development:
[Development workflow](https://github.corp.ebay.com/BIS/gro/wiki/Development-workflow-with-GIT)  
[Code merge flow] (https://github.corp.ebay.com/BIS/gro/wiki/Code-merge-flow)  

Active Branch List:
A branch list is maintained for development/build/release,  
* CURRENT branch is the one running in production, accepting production bug fix and urgent enhancement.  
* NEXT branch is the one to be release next, accepting feature changes for next code release.  
[The maintained branch list](https://wiki.vip.corp.ebay.com/display/DataServicesandSolutions/Build+and+Release+process)  


## IDEs
### Some team members are using Eclipse and the others are using Intellij IDEA.

## Eclipse Setup
#### Suggested version
  Version: Mars.1 Release (4.5.1)

#### Install Eclipse Plugins
  Scala IDE 4.2.x  
  Maven Integration for Eclipse(Luna)1.5.0  

## Local Maven Dependencies
  https://github.corp.ebay.com/BIS/storm-meter  
  https://github.corp.ebay.com/bishao/storm-cassandra-cql  
  https://github.corp.ebay.com/ysong1/hadoop-mini-clusters (Branch: ebay_version)
  
  
  
  
  




