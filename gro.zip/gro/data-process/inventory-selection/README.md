# Inventory Selection Data Process Job

## Compile and Package

```shell
$ cd data-process/inventory-selection/
$ mvn clean scala:compile package -Pprod
[INFO] Scanning for projects...
[WARNING] 
[WARNING] Some problems were encountered while building the effective model for com.ebay.bis.groem:inventory-selection:jar:0.1
[WARNING] 'build.plugins.plugin.version' for org.apache.maven.plugins:maven-jar-plugin is missing. @ line 96, column 12
[WARNING] 'build.plugins.plugin.version' for net.alchim31.maven:scala-maven-plugin is missing. @ com.ebay.bis.groem:gro-parent:0.1, gro/pom.xml, line 69, column 12
...
[INFO] Building zip: gro/data-process/inventory-selection/target/inventory-selection-0.1-binary.zip
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 20.217 s
[INFO] Finished at: 2015-12-03T14:42:00-08:00
[INFO] Final Memory: 27M/192M
[INFO] ------------------------------------------------------------------------
$
```


## Deploy

Deploy script

```shell
$ rsync -zvP target/inventory-selection-0.1-binary.zip [YOUR_NT_NAME]@phxdpeba008.phx.ebay.com:~
$ rsync -zvP target/inventory-selection-0.1-binary.zip [YOUR_NT_NAME]@phxdpeba007.phx.ebay.com:~

# do following steps on both phxdpeba007 and phxdpeba008

$ sudob_bis
$ cd /projects/GRO/inventory-selection-0.1
$ unzip /home/[YOUR_NT_NAME]/inventory-selection-0.1-binary.zip
Archive:  /home/yangzhou/inventory-selection-0.1-binary.zip
replace conf/index_schema.json? [y]es, [n]o, [A]ll, [N]one, [r]ename: A
...
$
```

Production job enviroment

```shell
.
├── InventorySelection -> inventory-selection-0.1/
├── inventory-selection-0.1
    ├── bin
    │   ├── iis.sh
    │   └── run.sh
    ├── conf
    │   └── index_schema.json
    ├── datas
    │   └── folder_file
    ├── inventory-selection-0.1.jar
    ├── lib
    │   ├── akka-actor_2.11-2.3.13.jar
    │   ├── antlr-runtime-3.5.jar
    │   ├── asm-4.1.jar
    │   ├── asm-commons-4.1.jar
    │   ├── config-1.2.1.jar
    │   ├── elasticsearch-1.5.2.jar
    │   ├── gson-2.2.4.jar
    │   ├── guava-15.0.jar
    │   ├── jackson-annotations-2.6.0.jar
    │   ├── jackson-core-2.6.1.jar
    │   ├── jackson-databind-2.6.1.jar
    │   ├── javax.ws.rs-api-2.0.1.jar
    │   ├── jcl-over-slf4j-1.7.9.jar
    │   ├── jersey-bundle-1.8.jar
    │   ├── jersey-client-1.8.jar
    │   ├── jersey-core-1.8.jar
    │   ├── jsr311-api-1.1.1.jar
    │   ├── log4j-api-2.4.1.jar
    │   ├── log4j-core-2.4.1.jar
    │   ├── log4j-slf4j-impl-2.4.1.jar
    │   ├── lucene-analyzers-common-4.10.4.jar
    │   ├── lucene-core-4.10.4.jar
    │   ├── lucene-grouping-4.10.4.jar
    │   ├── lucene-highlighter-4.10.4.jar
    │   ├── lucene-join-4.10.4.jar
    │   ├── lucene-memory-4.10.4.jar
    │   ├── lucene-misc-4.10.4.jar
    │   ├── lucene-queries-4.10.4.jar
    │   ├── lucene-queryparser-4.10.4.jar
    │   ├── lucene-sandbox-4.10.4.jar
    │   ├── lucene-spatial-4.10.4.jar
    │   ├── lucene-suggest-4.10.4.jar
    │   ├── scala-library-2.11.7.jar
    │   ├── scala-parser-combinators_2.11-1.0.4.jar
    │   ├── scala-reflect-2.11.7.jar
    │   ├── scala-xml_2.11-1.0.2.jar
    │   ├── scalaz-core_2.11-7.1.3.jar
    │   ├── slf4j-api-1.7.9.jar
    │   └── spatial4j-0.4.1.jar
    └── pigs
        ├── invSelClean.pig
        └── invSelEPID.pig
```


## Execution

Daily data job execution is configured as a UC4 job.

| Property   | Value   |
|------------|---------|
| Start Time | 2:00 am |
| UC4 Client | 1400 |
| UC4 Folder | /BPE/JOBPLANS/GRO.RETAIL/ |
| UC4 Job Name | GRO.INVSEL.PROD.DATA.JOB |
