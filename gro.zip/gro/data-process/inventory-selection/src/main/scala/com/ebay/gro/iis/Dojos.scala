package com.ebay.gro.iis

/**
 * Created by yangzhou on 9/11/15.
 */
object Dojos {
  case class Item(site: Int, id: Long, price: Double, epid: String)
  case class EPID(site: Int, epid: String, items: List[Item])
}
