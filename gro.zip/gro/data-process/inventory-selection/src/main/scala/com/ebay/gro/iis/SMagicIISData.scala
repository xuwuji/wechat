package com.ebay.gro.iis

import java.io._
import java.util
import java.util.zip.GZIPInputStream

import akka.actor.{Actor, ActorSystem, Props, ActorRef, Terminated}
import akka.routing.RoundRobinRouter
import akka.routing.Broadcast
import akka.actor.PoisonPill
import com.ebay.app.raptor.invinssvc.`type`.{IISListingResponse, IISProductResponse}
import com.ebay.gro.iis.Dojos.{Item, EPID}
import com.google.gson.Gson
import com.sun.jersey.api.client.{Client, ClientResponse, WebResource}

import scala.collection.JavaConversions._
import scalaz.Scalaz._
import scala.collection.mutable.ArrayBuffer
import com.ebay.gro.DataLoader._

/**
 * Created by yangzhou on 9/11/15.
 */
object SMagicIISData extends App {

//  System.setProperty("http.proxyHost", "httpproxy.vip.ebay.com");
//  System.setProperty("http.proxyPort", "80");

  val IIS_ITEM_SERVICE_BULKSIZE = 50
  val IIS_EPID_SERVICE_BULKSIZE = 20

  //val IIS_SERVICE_HOST = "10.102.196.160"
  val IIS_SERVICE_HOST = "iis.vip.stratus.ebay.com"

  val WORKER_NUM = 50

  val inputFile = args(0)
  val outputFile = args(1)


  sealed trait SMMessage
  case object SMJobStart extends SMMessage

  case class SMTask(epids: List[EPID]) extends SMMessage
  case class SMTaskDone(epidCnt: Int, serviceCnt: Int, outputs: List[String]) extends SMMessage
  case class SMRequestWorkerDead() extends SMMessage
  case class SMWorkerDead() extends SMMessage


  class Master(nrOfWorkers: Int, inputFile: String, outputFile: String) extends Actor {
    var deadWorker: Int = 0

    lazy val files: Array[File] = Array(new File(inputFile))
    val workerRouter = context.actorOf(Props[Worker].withRouter(RoundRobinRouter(nrOfWorkers)), name = "workerRouter")
   
    val reaper = system.actorOf(Props(new ProductionReaper(self)))
    
    import Reaper._
    reaper! WatchMe(workerRouter)

    var console_count = 0

    var EPID_NUM = 0
    var ITEM_NUM = 0
    var SKIP_NUM = 0
    var SERVICE_CALL_NUM = 0
    var OUTPUT_NUM = 0


    val writer: PrintWriter = new PrintWriter(new BufferedWriter(new FileWriter(outputFile)));

    override def receive: Receive = {
      case SMJobStart =>
        for (file <- files) {

          var serviceCallCnt = 0
          var epid: String = null
          var epidSite: Int = 0
          var items: List[Item] = Nil
          var epids: List[EPID] = Nil

          val content = GzFileIterator(openFileStream(file))
          content.foreach(line => {
            if(line != null) {
              ITEM_NUM += 1
                val splits = line.split("\t", 7)
                if(splits.length < 5) {
                  SKIP_NUM += 1
                } else {
                  val itm = Item(splits(0).toInt, splits(2).toLong, splits(3).toDouble, splits(1))
                  if(splits(1) != epid) {
                    val preEPID = epid
                    val preEPIDSite = epidSite
                    val preItems = items
                    if(preEPID != null) {
                      EPID_NUM += 1
                      epids = EPID(preEPIDSite, preEPID, preItems) :: epids
                      if(epids.size == IIS_EPID_SERVICE_BULKSIZE) {
                        workerRouter ! SMTask(epids)
                        epids = Nil
                      }
                    }
                    epidSite = if(splits(0).toInt == 100) 0 else splits(0).toInt
                    epid = splits(1)
                    items = List(itm)
                  } else {
                    items = itm :: items
                  }
              }
            }
          })
          if(epid != null && epids.length > 0) {
            workerRouter ! SMTask(epids)
          }

          println(s"${inputFile} scan finish!")
          workerRouter ! Broadcast(PoisonPill) // append poisonpill at the end of message queue
        }
      case SMTaskDone(epidCnt, serviceCnt, outputs) =>
        console_count += epidCnt
        SERVICE_CALL_NUM += serviceCnt
        OUTPUT_NUM += outputs.size
        outputs.foreach(writer.println(_))
        if(console_count % 100000 == 0) {
          println("EPID processed " + console_count)
          writer.flush()
        }

      case SMWorkerDead() =>
          println()
          println(s"summary:")
          println(s"Load Items: ${ITEM_NUM}")
          println(s"Skip Items: ${SKIP_NUM}")
          println(s"EPID Num: ${EPID_NUM}")
          println(s"Service Call Made: ${SERVICE_CALL_NUM}")
          println(s"Output Items: ${OUTPUT_NUM}")

          writer.close()

          context.stop(self)
          context.system.shutdown()
    }
  }


  class Worker extends Actor {
    val gson = new Gson;

    override def receive: Receive = {
      case SMTask(epids) => sender ! getIISData(epids)
    }

    override def postStop(): Unit = {
      println("worker dead! " + Thread.currentThread().getName)
    }

    def callProductService(resourceUrl: String): ClientResponse = {
      val client: Client = Client.create
      val webResource: WebResource = client.resource(resourceUrl)
      webResource.accept("application/json").get(classOf[ClientResponse])
    }

    private def processListings(jsonRes: String): List[(String, java.util.Map[String, java.lang.Double])] = {
      var repEpids = List[(String, java.util.Map[String, java.lang.Double])]()

      val result: IISProductResponse = gson.fromJson(jsonRes, classOf[IISProductResponse])
      if (result.getProducts != null && !result.getProducts.isEmpty) {
        import scala.collection.JavaConversions._
        for (product <- result.getProducts) {
          if(product.getExternal != null && !product.getExternal.isEmpty) {
            val cprices = new util.HashMap[String, java.lang.Double]()
            product.getExternal.foreach(external =>{
              if(external.getExternalName != null && external.getExternalPrice != null) {
                cprices.put(external.getExternalName, external.getExternalPrice.getValue)
              }
            })
            if(cprices.size > 0) {
              val x = (product.getProductReferenceId, cprices)
              repEpids = x :: repEpids
            }
          }
        }
      }
      repEpids
    }

    def callItemService(itemIds: List[String]): Map[String, (String, String)] = {
      val postContent = "{itemids: [" + itemIds.mkString(",") + "]}"
      val url = s"http://${IIS_SERVICE_HOST}/marketing/insights/v1/get_bulk_listing_metrics"

      val client: Client = Client.create
      val webResource: WebResource = client.resource(url)
      val response: ClientResponse = webResource
        .accept("application/json")
        .`type`("application/json")
        .post(classOf[ClientResponse], postContent)

      var itemMap = Map[String, (String, String)]()
      if (response.getClientResponseStatus ==  ClientResponse.Status.OK) {
        val jsonRes: String = response.getEntity(classOf[String])
        val result: IISListingResponse = gson.fromJson(jsonRes, classOf[IISListingResponse])

        if(result.getListings != null && !result.getListings.isEmpty) {
          result.getListings.foreach(list => {
            if(list.getDeals != null && !list.getDeals.isEmpty) {
              val deals = list.getDeals.map(_.getDealType.name()).mkString(",")
              val amazonDeal = list.getDeals.find(deal => {deal.getDealReference != null && deal.getDealReference.getURL != null && deal.getDealReference.getURL.contains("amazon")})
              val amazonUrl = if(amazonDeal.isDefined) amazonDeal.get.getDealReference.getURL else ""

              itemMap += (list.getListingId -> (deals, amazonUrl))
            }
          })
        }
      } else {
        System.err.println("Failed to get item resource : " + response.getStatus)
        System.err.println(response.getEntity(classOf[String]))
      }

      itemMap
    }

    def getIISData(epids: List[EPID]): SMTaskDone = {
      val epidlist = epids.map(_.epid).mkString(",")
      val epidSite = epids(0).site
      val URL = s"http://${IIS_SERVICE_HOST}/marketing/insights/v1/product_info?ProductReferenceId=${epidlist}&marketplaceId=${epidSite}&fields=EXTERNAL.CompetitorPrice&fieldgroups=default"

      val epidMap = epids.map(e => (e.epid -> e)).toMap

      var serviceCnt = 0
      var outputs = List[String]()
      try {
        val response: ClientResponse = callProductService(URL)
        if (response.getClientResponseStatus ==  ClientResponse.Status.OK) {
          val jsonRes: String = response.getEntity(classOf[String])
          val repEpids = processListings(jsonRes)

          var dealCandidates = repEpids.map(e => (e._1, e._2.values().min)).flatMap(e =>{
            val sourceEpid = epidMap.get(e._1)
            if (sourceEpid.isDefined) {
              sourceEpid.get.items.filter(item => item.price < e._2).map(_.id.toString)
            } else None
          })

          var itemDeals = Map[String, (String, String)]()

          if(dealCandidates.size > 0) {
            if(dealCandidates.size <= IIS_ITEM_SERVICE_BULKSIZE) {
              itemDeals = itemDeals |+| callItemService(dealCandidates)
              serviceCnt += 1
            } else {
              while(dealCandidates.size > IIS_ITEM_SERVICE_BULKSIZE) {
                val (top50, tails) = dealCandidates.splitAt(IIS_ITEM_SERVICE_BULKSIZE)
                itemDeals = itemDeals |+| callItemService(top50)
                dealCandidates = tails
                serviceCnt += 1
              }
              if(dealCandidates.size > 0) {
                itemDeals = itemDeals |+| callItemService(dealCandidates)
                serviceCnt += 1
              }
            }
          }


          repEpids.foreach(e => {
            val sourceEpid = epidMap.get(e._1)
            if (sourceEpid.isDefined) {
              sourceEpid.get.items.foreach(itm => {
                val dealInfo = itemDeals.get(itm.id.toString).getOrElse(("", ""))
                outputs = List(
                  itm.site,
                  itm.epid,
                  itm.id,
                  itm.price,
                  gson.toJson(e._2),
                  dealInfo._1,
                  dealInfo._2
                ).mkString("\t") :: outputs
              })
            }
          })

        } else {
          System.err.println("Failed to get product resource : " + response.getStatus)
        }
      } catch {
        case e: Throwable => e.printStackTrace()//ignore
      }

      SMTaskDone(epids.size, serviceCnt + 1, outputs)
    }
  }
  
  object Reaper {
    case class WatchMe(ref: ActorRef)
  }

  abstract class Reaper extends Actor {
    import Reaper._
    // Keep track of what we're watching
    val watched = ArrayBuffer.empty[ActorRef]

    // Derivations need to implement this method.  It's the
    // hook that's called when everything's dead
    def allSoulsReaped(): Unit

    // Watch and check for termination
    final def receive = {
      case WatchMe(ref) =>
        context.watch(ref)
        watched += ref
      case Terminated(ref) =>
        watched -= ref
        if (watched.isEmpty) allSoulsReaped()
    }
  }


  class ProductionReaper(master: ActorRef) extends Reaper {
    def allSoulsReaped(): Unit = {
      println("workerRouter stopped")
      master ! SMWorkerDead()
    }
}

  val system = ActorSystem("IISSystem")

  val master = system.actorOf(Props(new Master(WORKER_NUM, inputFile, outputFile)), name = "master")

  master ! SMJobStart
}



