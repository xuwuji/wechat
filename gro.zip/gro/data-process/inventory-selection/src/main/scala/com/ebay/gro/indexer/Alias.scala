package com.ebay.gro.indexer

/**
 * Created by yangzhou on 5/25/15.
 */

import com.ebay.gro.indexer.Constants._
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest

object Alias {

  def main(args: Array[String]): Unit = {
    val aliasName = args(0)
    val idxName = args(1)

    val aliases = getAlias()

    println(aliases)

    if(!aliases.containsKey(aliasName)) {
      createAlias(aliasName, idxName)
    } else {
      val oldIdx = aliases.get(aliasName).keys().toArray()(0).toString
      replaceAlias(aliasName, oldIdx, idxName)
      deleteIndex(oldIdx)
    }

  }

  def getAlias() = {
    client.admin().cluster()
      .prepareState().execute()
      .actionGet().getState()
      .getMetaData().getAliases()
  }

  def createAlias(aliasName: String, indexName: String): Unit = {
    println(">> create alias " + aliasName + " on index " + indexName)
    client.admin().indices().prepareAliases()
      .addAlias(indexName, aliasName)
      .execute().actionGet();
  }

  def replaceAlias(aliasName: String, oldIndexName: String, newIndexName: String): Unit = {
    println(">> replace alias " + aliasName + " old index " + oldIndexName + " with new index " + newIndexName)
    client.admin().indices().prepareAliases()
      .removeAlias(oldIndexName, aliasName)
      .addAlias(newIndexName, aliasName)
      .execute().actionGet();
  }

  def deleteIndex(idxName: String): Unit = {
    val delete = client.admin().indices().delete(new DeleteIndexRequest(idxName)).actionGet()
    if (!delete.isAcknowledged) {
      println("ERROR: Index wasn't deleted")
    } else {
      println("SUCCEED: Index was deleted")
    }
  }

}
