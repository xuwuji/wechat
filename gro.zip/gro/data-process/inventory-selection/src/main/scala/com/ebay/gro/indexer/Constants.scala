package com.ebay.gro.indexer

import org.elasticsearch.client.Client
import org.elasticsearch.client.transport.TransportClient
import org.elasticsearch.common.settings.ImmutableSettings
import org.elasticsearch.common.transport.InetSocketTransportAddress

import com.typesafe.config.ConfigFactory
/**
 * Created by yangzhou on 5/22/15.
 */
object Constants {

  val config = ConfigFactory.load("application.conf")

  val clusterName = config.getString("bpe.es.cluster.name")

  val hosts = config.getString("bpe.es.hosts").split(",")

  val port = config.getInt("bpe.es.port")

  val proxyURL = config.getString("bpe.hdfs.proxy.url")

  val settings = ImmutableSettings.settingsBuilder().put("cluster.name", clusterName).build()

  val client: Client = {
    var client: TransportClient = new TransportClient(settings)
    hosts.foreach(host => {
      client = client.addTransportAddress(new InetSocketTransportAddress(host, port))
    })
    client
  }

  val FIELDS = config.getString("index.schema").split(",").filter(!_.isEmpty).map((_, "String"))

  val sites = config.getString("index.sites").split(",").toList

  val SITE_COMP_COLUMNS = sites.map(site => {
    (site, config.getString(s"index.${site}.comp.columns").split(",").filter(!_.isEmpty).toList)
  }).toMap

}
