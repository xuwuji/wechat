package com.ebay.gro

import java.io._
import java.net.URL
import java.util.zip.GZIPInputStream

/**
 * Created by yangzhou on 10/27/15.
 */
object DataLoader {

  case class BufferedReaderIterator(reader: BufferedReader) extends Iterator[String] {
    override def hasNext() = reader.ready
    override def next() = reader.readLine()
  }

  object GzFileIterator {
    def apply(input: InputStream, encoding: String = "UTF-8") = {
      new BufferedReaderIterator(
        new BufferedReader(
          new InputStreamReader(
            new GZIPInputStream(input), encoding)))
    }
  }

  def openURLStream(url: String): InputStream = new URL(url).openStream()

  def openFileStream(file: File): InputStream = new FileInputStream(file)

}
