package com.ebay.gro.indexer

/**
 * Created by yangzhou on 5/22/15.
 */

import java.io.{File, PrintWriter}
import java.util.Date
import java.util.concurrent.TimeUnit

import com.ebay.gro.indexer.Constants._
import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.elasticsearch.action.bulk.{BulkProcessor, BulkRequest, BulkResponse}
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.common.unit.{ByteSizeUnit, ByteSizeValue, TimeValue}
import org.elasticsearch.common.xcontent.XContentFactory

import scala.collection.JavaConversions._
import com.ebay.gro.DataLoader._


object Indexer {

  def str2json(line: String): Option[(String,String)] = {
    try {
      val columns = line.split("\t", Constants.FIELDS.length)
      if(columns.length != Constants.FIELDS.length) {
        println("ignore: " + line)
        None
      } else {
        var jsonObj = XContentFactory.jsonBuilder().startObject()
        var itm = columns(0)
        var site = columns(3)
        columns.zip(Constants.FIELDS).foreach(pair => {
          val v = if(pair._1.equalsIgnoreCase("null")) {
            ""
          } else {
            pair._1
          }
          jsonObj = jsonObj.field(pair._2._1, v)
        })

        Option((itm, jsonObj.endObject().string()))
      }
    } catch {
      case _:Throwable => {
        println("ignore: " + line)
        None
      }
    }
  }


  def main(args: Array[String]): Unit = {
    val index = args(0)
    val URL = args(1)

    val filename1 = index + "_" + System.currentTimeMillis() + ".txt"
    println(s"Failed Index Output File ${filename1}")

    var fout = new PrintWriter(new File(filename1))

    var fail = 0L

    val bulkProcessor: BulkProcessor = BulkProcessor.builder(
      client,
      new BulkProcessor.Listener() {
        override def beforeBulk(executionId: Long, request: BulkRequest): Unit = {}

        override def afterBulk(executionId: Long, request: BulkRequest, response: BulkResponse): Unit = {
          if(response.hasFailures) {
            var ids = Set[String]()
            response.getItems.filter(_.isFailed).foreach(bulkItemResponse => {
              fail += 1
              ids += bulkItemResponse.getId
            })

            request.requests().foreach(r => {
              if(r.isInstanceOf[IndexRequest]) {
                val idxr = r.asInstanceOf[IndexRequest]
                if (ids.contains(idxr.id())) {
                  fout.println(idxr.source().toUtf8)
                }
              }
            })
          }
        }

        override def afterBulk(executionId: Long, request: BulkRequest, failure: Throwable): Unit = {
          fail += request.numberOfActions()
          request.requests().foreach(r => {
            if(r.isInstanceOf[IndexRequest]) {
              val idxr = r.asInstanceOf[IndexRequest]
              fout.println(idxr.source().toUtf8)
            }
          })
        }
      })
      .setBulkActions(1000)
      .setBulkSize(new ByteSizeValue(1, ByteSizeUnit.GB))
      .setFlushInterval(TimeValue.timeValueSeconds(5))
      .setConcurrentRequests(5)
      .build();

    val content = GzFileIterator(openURLStream(Constants.proxyURL + URL))

    var count = 0l
    var skip = 0l

    println("Start Time: " + new Date().toString)

    content.foreach(line => {
      val json = str2json(line)
      count = count + 1
      if(count % 50000 == 0) {
        print(".")
      }
      if(count % 1000000 == 0) {
        println()
      }
      if(json.isDefined) {
        bulkProcessor.add(new IndexRequest(index, "item", json.get._1).source(json.get._2))
      } else {
        skip += 1
      }
    })

    bulkProcessor.flush()

    println()
    println("> Total Load Records: " + count)
    println("> Total Ignore Records: " + skip)
    println("> Total Failed Index Records: " + fail)
    println()
    println("Finish Time: " + new Date().toString)

    println("Final Status: " + bulkProcessor.awaitClose(5, TimeUnit.MINUTES))

    fout.close()


    if(fail > 0) {
      println("start reindex failed records...")
      val bulkProc: BulkProcessor = BulkProcessor.builder(
        client,
        new BulkProcessor.Listener() {
          override def beforeBulk(executionId: Long, request: BulkRequest): Unit = {}

          override def afterBulk(executionId: Long, request: BulkRequest, response: BulkResponse): Unit = {
            if(response.hasFailures) {
              var ids = Set[String]()
              response.getItems.filter(_.isFailed).foreach(bulkItemResponse => {
                ids += bulkItemResponse.getId
              })

              request.requests().foreach(r => {
                if(r.isInstanceOf[IndexRequest]) {
                  val idxr = r.asInstanceOf[IndexRequest]
                  if (ids.contains(idxr.id())) {
                    println(s"ERROR: ${idxr.source()}")
                  }
                }
              })
            }
          }

          override def afterBulk(executionId: Long, request: BulkRequest, failure: Throwable): Unit = {
            request.requests().foreach(r => {
              if(r.isInstanceOf[IndexRequest]) {
                val idxr = r.asInstanceOf[IndexRequest]
                println(s"ERROR: ${idxr.source()}")
              }
            })
          }
        })
        .setBulkActions(100)
        .setBulkSize(new ByteSizeValue(1, ByteSizeUnit.GB))
        .setFlushInterval(TimeValue.timeValueSeconds(5))
        .setConcurrentRequests(5)
        .build();

      scala.io.Source.fromFile(filename1).getLines().foreach(line => {
        val mapper = new ObjectMapper()
        val obj: JsonNode = mapper.readTree(line)
        if(obj.has("ITEM_ID")) {
          val itm = obj.get("ITEM_ID").asText()
          bulkProc.add(new IndexRequest(index, "item", itm).source(line))
        }
      });

      bulkProc.flush();

      bulkProc.awaitClose(5, TimeUnit.MINUTES)
    }

  }

}
