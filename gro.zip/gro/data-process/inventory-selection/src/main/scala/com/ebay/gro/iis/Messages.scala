package com.ebay.gro.iis

import com.ebay.gro.iis.Dojos.EPID

import scala.concurrent.duration.Duration

/**
 * Created by yangzhou on 9/11/15.
 */
object Messages {
  sealed trait IISMessage
  case object IISStart extends IISMessage
  case class IISWork(epids: List[EPID]) extends IISMessage
  case class IISResult(file: String, processCnt: Long, skipCnt: Long, epidCnt: Long, serviceCallCnt: Long) extends IISMessage
  case class IISDone(duration: Duration, processCnt: Long, skipCnt: Long, epidCnt: Long, serviceCallCnt: Long)

}
