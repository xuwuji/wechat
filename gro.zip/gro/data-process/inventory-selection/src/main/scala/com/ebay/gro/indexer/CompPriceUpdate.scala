package com.ebay.gro.indexer

import java.lang.reflect.Type
import java.util.Date
import java.util.concurrent.TimeUnit

import com.ebay.gro.indexer.Constants._
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.elasticsearch.action.bulk.{BulkProcessor, BulkRequest, BulkResponse}
import org.elasticsearch.action.update.UpdateRequest
import org.elasticsearch.common.unit.{ByteSizeUnit, ByteSizeValue, TimeValue}
import org.elasticsearch.common.xcontent.{XContentBuilder, XContentFactory}

import scala.collection.JavaConversions._
import com.ebay.gro.DataLoader._
/**
 * Created by yangzhou on 9/13/15.
 */
object CompPriceUpdate {

  val gson = new Gson()
  val stringStringMap: Type = new TypeToken[java.util.Map[String, java.lang.Float]](){}.getType()

  def str2json(line: String): Option[(String,XContentBuilder)] = {
    val splits = line.split("\t", 7)
    if(splits.size != 7) {
      None
    } else {
      val itmId = splits(2)
      val itmPrice = splits(3).toFloat
      val compPrice = splits(4)
      val deals = splits(5)
      val amazonUrl = splits(6)

      val jsonObj = XContentFactory.jsonBuilder().startObject()

      var lessThanAmazonPrice = false

      jsonObj.startArray("COMP_PRICE");

      val map:java.util.Map[String, java.lang.Float] = gson.fromJson(compPrice, stringStringMap)
      map.entrySet().foreach(entry => {
        jsonObj.startObject()
        jsonObj.field("comp", entry.getKey)
        jsonObj.field("price", entry.getValue)
        if(entry.getValue > itmPrice) {
          val discount: java.lang.Float = (itmPrice/entry.getValue).asInstanceOf[java.lang.Float]
          jsonObj.field("discount", discount)
        }
        jsonObj.endObject()
        if(entry.getKey.toLowerCase().startsWith("amazon") && itmPrice < entry.getValue) {
          lessThanAmazonPrice = true
        }
      })

      jsonObj.endArray()

      jsonObj.startArray("COMP_DEAL")
      if(!deals.trim.isEmpty) {
        deals.split(",").foreach(d => {
          jsonObj.startObject()
          jsonObj.field("type", d)
          jsonObj.endObject()
        })
      }
      jsonObj.endArray()

      if(lessThanAmazonPrice) {
        jsonObj.field("Comp_Price_Status", "Priced better than Amazon")
      }

      jsonObj.field("AmazonURL", amazonUrl)

      jsonObj.endObject()

      Option((itmId, jsonObj))
    }
  }

  def main(args: Array[String]): Unit = {
    val idxName = args(0)
    val URL = args(1)

    val content = GzFileIterator(openURLStream(Constants.proxyURL + URL))

    var count = 0l

    val bulkProcessor: BulkProcessor = BulkProcessor.builder(
      client,
      new BulkProcessor.Listener() {
        override def beforeBulk(executionId: Long, request: BulkRequest): Unit = {}

        override def afterBulk(executionId: Long, request: BulkRequest, response: BulkResponse): Unit = {
          if(response.hasFailures) {
            println(response.getItems.filter(_.getFailureMessage != null).map(_.getFailureMessage).mkString("\n"))
          }
          response.getItems.foreach(_.getFailure)
        }

        override def afterBulk(executionId: Long, request: BulkRequest, failure: Throwable): Unit = {
          failure.printStackTrace()
        }
      })
      .setBulkActions(10000)
      .setBulkSize(new ByteSizeValue(1, ByteSizeUnit.GB))
      .setFlushInterval(TimeValue.timeValueSeconds(5))
      .setConcurrentRequests(5)
      .build();

    def assembleUpdateRequest(itemId: String, json: XContentBuilder): UpdateRequest = {
      val updateRequest = new UpdateRequest()
      updateRequest.index(idxName)
      updateRequest.`type`("item")
      updateRequest.id(itemId)
      updateRequest.doc(json)
      updateRequest.detectNoop(true)
      updateRequest
    }

    println(new Date().toString)
    content.foreach(line => {
      val json = str2json(line)
      count = count + 1
      if(count % 10000 == 0) {
        print(".")
      }
      if(count % 100000 == 0) {
        println()
      }
      if(json.isDefined) {
        val updateRequest = assembleUpdateRequest(json.get._1, json.get._2)
        bulkProcessor.add(updateRequest)
      } else {
        println("skip: " + line)
      }
    })
    println()
    println(new Date().toString)
    bulkProcessor.flush()
    bulkProcessor.awaitClose(1, TimeUnit.MINUTES);
//    client.close()
  }

}
