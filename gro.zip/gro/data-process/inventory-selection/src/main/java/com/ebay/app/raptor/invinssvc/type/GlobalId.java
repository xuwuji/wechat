package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class GlobalId {
    String actualValue;
    String normalizedValue;

    public GlobalId(String actualValue, String normalizedValue) {
        this.actualValue = actualValue;
        this.normalizedValue = normalizedValue;
    }

    public String getActualValue() {
        return this.actualValue;
    }

    public void setActualValue(String actualValue) {
        this.actualValue = actualValue;
    }

    public String getNormalizedValue() {
        return this.normalizedValue;
    }

    public void setNormalizedValue(String normalizedValue) {
        this.normalizedValue = normalizedValue;
    }
}
