package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class IISListingResponse {
    private long serviceResponseTime;
    private List<IISListing> listings;

    public IISListingResponse() {
    }

    public long getServiceResponseTime() {
        return this.serviceResponseTime;
    }

    public void setServiceResponseTime(long serviceResponseTime) {
        this.serviceResponseTime = serviceResponseTime;
    }

    public List<IISListing> getListings() {
        return this.listings;
    }

    public void setListings(List<IISListing> listings) {
        this.listings = listings;
    }
}
