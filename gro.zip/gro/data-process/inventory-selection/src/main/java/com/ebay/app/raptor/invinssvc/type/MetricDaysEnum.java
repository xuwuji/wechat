package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.HashMap;
import java.util.Map;

@XmlRootElement
public enum MetricDaysEnum {
    NONE(0),
    ONE_DAY(1),
    THREE_DAY(3),
    SEVEN_DAY(7),
    FOURTEEN_DAY(14),
    THIRTY_DAY(30),
    NINETY_DAY(90);

    private static final Map<Integer, MetricDaysEnum> m_idActionMap;
    private final int m_id;

    private MetricDaysEnum(int id) {
        this.m_id = id;
    }

    public int getId() {
        return this.m_id;
    }

    public static MetricDaysEnum valueOf(int id) {
        return m_idActionMap.containsKey(Integer.valueOf(id))?(MetricDaysEnum)m_idActionMap.get(Integer.valueOf(id)):null;
    }

    @JsonCreator
    public static MetricDaysEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str);
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }

    static {
        m_idActionMap = new HashMap(values().length);
        MetricDaysEnum[] arr$ = values();
        int len$ = arr$.length;

        for(int i$ = 0; i$ < len$; ++i$) {
            MetricDaysEnum actionType = arr$[i$];
            m_idActionMap.put(Integer.valueOf(actionType.getId()), actionType);
        }

    }
}
