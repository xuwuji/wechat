package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlTransient;
import java.text.SimpleDateFormat;
import java.util.Date;

@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true,
        value = {"format"}
)
@XmlRootElement
public class DateTime {
    private Date value;
    @XmlTransient
    private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm a z");
    private String formattedValue;

    public DateTime() {
    }

    public DateTime(Date date) {
        this.value = date;
        if(date != null && this.format != null) {
            this.formattedValue = this.format.format(date);
        }

    }

    @JsonSerialize(
            using = JsonDateSerializer.class
    )
    @XmlSchemaType(
            name = "dateTime"
    )
    public Date getValue() {
        return this.value;
    }

    public void setValue(Date date) {
        this.value = date;
    }

    public String getFormattedValue() {
        if(this.value != null && this.formattedValue == null && this.format != null) {
            this.formattedValue = this.format.format(this.value);
        }

        return this.formattedValue;
    }

    public void setFormattedValue(String formattedValue) {
        this.formattedValue = formattedValue;
    }

    @XmlTransient
    public SimpleDateFormat getFormat() {
        return this.format;
    }

    public void setFormat(SimpleDateFormat format) {
        if(format != null) {
            this.format = format;
            if(this.value != null) {
                this.formattedValue = this.format.format(this.value);
            }
        }

    }
}
