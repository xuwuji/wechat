package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class IISProduct {
    private String productReferenceId;
    private Text productTitle;
    private MarketplaceIdEnum marketplaceId;
    private List<GlobalId> mappedGlobalIds = new ArrayList();
    private String productFlag;
    private String metricFormat;
    private String metricCondition;
    private ProductTypeEnum productType;
    private Long currentRank;
    private Long previousRank;
    private List<Metric> metrics = new ArrayList();
    private List<Rank> ranks = new ArrayList();
    private List<IISListing> listings = new ArrayList();
    private List<External> external = new ArrayList();
    private List<Trend> trends = new ArrayList();

    public IISProduct() {
    }

    public String getProductReferenceId() {
        return this.productReferenceId;
    }

    public void setProductReferenceId(String productReferenceId) {
        this.productReferenceId = productReferenceId;
    }

    public Text getProductTitle() {
        return this.productTitle;
    }

    public void setProductTitle(Text productTitle) {
        this.productTitle = productTitle;
    }

    public MarketplaceIdEnum getMarketplaceId() {
        return this.marketplaceId;
    }

    public void setMarketplaceId(MarketplaceIdEnum marketplaceId) {
        this.marketplaceId = marketplaceId;
    }

    public List<GlobalId> getMappedGlobalIds() {
        return this.mappedGlobalIds;
    }

    public void setMappedGlobalIds(List<GlobalId> mappedGlobalIds) {
        this.mappedGlobalIds = mappedGlobalIds;
    }

    public String getProductFlag() {
        return this.productFlag;
    }

    public void setProductFlag(String productFlag) {
        this.productFlag = productFlag;
    }

    public String getMetricFormat() {
        return this.metricFormat;
    }

    public void setMetricFormat(String metricFormat) {
        this.metricFormat = metricFormat;
    }

    public String getMetricCondition() {
        return this.metricCondition;
    }

    public void setMetricCondition(String metricCondition) {
        this.metricCondition = metricCondition;
    }

    public ProductTypeEnum getProductType() {
        return this.productType;
    }

    public void setProductType(ProductTypeEnum productType) {
        this.productType = productType;
    }

    public Long getCurrentRank() {
        return this.currentRank;
    }

    public void setCurrentRank(Long currentRank) {
        this.currentRank = currentRank;
    }

    public Long getPreviousRank() {
        return this.previousRank;
    }

    public void setPreviousRank(Long previousRank) {
        this.previousRank = previousRank;
    }

    public List<Metric> getMetrics() {
        return this.metrics;
    }

    public void setMetrics(List<Metric> metrics) {
        this.metrics = metrics;
    }

    public List<IISListing> getListings() {
        return this.listings;
    }

    public void setListings(List<IISListing> listings) {
        this.listings = listings;
    }

    public List<Rank> getRanks() {
        return this.ranks;
    }

    public void setRanks(List<Rank> ranks) {
        this.ranks = ranks;
    }

    public List<External> getExternal() {
        return this.external;
    }

    public void setExternal(List<External> external) {
        this.external = external;
    }

    public List<Trend> getTrends() {
        return this.trends;
    }

    public void setTrends(List<Trend> trends) {
        this.trends = trends;
    }
}