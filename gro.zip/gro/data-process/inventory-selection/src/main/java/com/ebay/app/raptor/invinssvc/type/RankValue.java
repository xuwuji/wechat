package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class RankValue {
    Long categoryId;
    Object metricValue;
    MetricDaysEnum days;
    MetricMappingTypeEnum metricMappedType;

    public RankValue() {
    }

    public MetricDaysEnum getDays() {
        return this.days;
    }

    public void setDays(MetricDaysEnum days) {
        this.days = days;
    }

    public Long getCategoryId() {
        return this.categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    @XmlAnyElement(
            lax = true
    )
    public Object getMetricValue() {
        return this.metricValue;
    }

    public void setMetricValue(Object metricValue) {
        this.metricValue = metricValue;
    }

    public MetricMappingTypeEnum getMetricMappedType() {
        return this.metricMappedType;
    }

    public void setMetricMappedType(MetricMappingTypeEnum metricMappedType) {
        this.metricMappedType = metricMappedType;
    }
}
