package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class IISProductResponse {
    private long serviceResponseTime;
    private List<IISProduct> products;

    public IISProductResponse() {
    }

    public long getServiceResponseTime() {
        return this.serviceResponseTime;
    }

    public void setServiceResponseTime(long serviceResponseTime) {
        this.serviceResponseTime = serviceResponseTime;
    }

    public List<IISProduct> getProducts() {
        return this.products;
    }

    public void setProducts(List<IISProduct> products) {
        this.products = products;
    }
}
