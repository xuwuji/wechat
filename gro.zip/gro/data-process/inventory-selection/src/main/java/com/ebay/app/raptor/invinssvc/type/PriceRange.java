package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class PriceRange {
    private Amount minimumPrice;
    private Amount maximumPrice;
    private Integer totalWithinRange;

    public PriceRange() {
    }

    public Amount getMinimumPrice() {
        return this.minimumPrice;
    }

    public void setMinimumPrice(Amount minimumPrice) {
        this.minimumPrice = minimumPrice;
    }

    public Amount getMaximumPrice() {
        return this.maximumPrice;
    }

    public void setMaximumPrice(Amount maximumPrice) {
        this.maximumPrice = maximumPrice;
    }

    public Integer getTotalWithinRange() {
        return this.totalWithinRange;
    }

    public void setTotalWithinRange(Integer totalWithinRange) {
        this.totalWithinRange = totalWithinRange;
    }
}
