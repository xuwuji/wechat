package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum DealTypeEnum {
    CPP,
    MD,
    VALUE_ITEM;

    private DealTypeEnum() {
    }

    @JsonCreator
    public static DealTypeEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str.toUpperCase());
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }
}
