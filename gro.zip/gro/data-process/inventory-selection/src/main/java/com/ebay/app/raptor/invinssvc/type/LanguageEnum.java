package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum LanguageEnum {
    hy("Armenian"),
    nl("Dutch"),
    en("English"),
    eo("Esperanto"),
    fr("French"),
    de("German"),
    el("Greek"),
    it("Italian"),
    ja("Japanese"),
    pt("Portuguese"),
    ru("Russian"),
    es("Spanish"),
    sv("Swedish"),
    tr("Turkish");

    private String language;

    private LanguageEnum(String language) {
        this.language = language;
    }

    public String getLanguage() {
        return this.language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    @JsonCreator
    public static LanguageEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str);
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }
}
