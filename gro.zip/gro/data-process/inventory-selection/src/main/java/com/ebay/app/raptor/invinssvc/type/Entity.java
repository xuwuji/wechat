package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class Entity {
    private Map<String, String> definition = new HashMap();
    private Long numberAspects;
    private String productType;
    private Long entitySiteId;
    private List<Metric> metrics = new ArrayList();

    public Entity() {
    }

    public Map<String, String> getDefinition() {
        return this.definition;
    }

    public void setDefinition(Map<String, String> definition) {
        this.definition = definition;
    }

    public Long getNumberAspects() {
        return this.numberAspects;
    }

    public void setNumberAspects(Long numberAspects) {
        this.numberAspects = numberAspects;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Long getEntitySiteId() {
        return this.entitySiteId;
    }

    public void setEntitySiteId(Long entitySiteId) {
        this.entitySiteId = entitySiteId;
    }

    public List<Metric> getMetrics() {
        return this.metrics;
    }

    public void setMetrics(List<Metric> entityMetrics) {
        this.metrics = entityMetrics;
    }
}