package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum CurrencyCodeEnum {
    AED("United Arab Emirates Dirham", "784"),
    AFN("Afghan Afghani", "971"),
    ALL("Albanian Lek", "008"),
    AMD("Armenian Dram", "051"),
    AOA("Angolan Kwanza", "973"),
    ARS("Argentine Peso", "032"),
    AWG("Aruban Florin", "533"),
    AZN("Azerbaijani Manat", "944"),
    BAM("Bosnia-Herzegovina Convertible Mark", "977"),
    BBD("Barbadian Dollar", "052"),
    BDT("Bangladeshi Taka", "050"),
    BGN("Bulgarian Lev", "975"),
    BHD("Bahraini Dinar", "048"),
    BIF("Burundian Franc", "108"),
    BMD("Bermudan Dollar", "060"),
    BND("Brunei Dollar", "096"),
    BOB("Bolivian Boliviano", "068"),
    BRL("Brazilian Real", "986"),
    BSD("Bahamian Dollar", "044"),
    BTN("Bhutanese Ngultrum", "064"),
    BWP("Botswanan Pula", "072"),
    BYR("Belarusian Ruble", "974"),
    BZD("Belize Dollar", "084"),
    CAD("Canadian Dollar", "124"),
    CDF("Congolese Franc", "976"),
    CLP("Chilean Peso", "152"),
    CNY("Chinese Yuan", "156"),
    COP("Colombian Peso", "170"),
    CRC("Costa Rican Colón", "188"),
    CUP("Cuban Peso", "192"),
    CVE("Cape Verdean Escudo", "132"),
    CZK("Czech Republic Koruna", "203"),
    DJF("Djiboutian Franc", "262"),
    DOP("Dominican Peso", "214"),
    DZD("Algerian Dinar", "012"),
    EGP("Egyptian Pound", "818"),
    ERN("Eritrean Nakfa", "232"),
    ETB("Ethiopian Birr", "230"),
    FJD("Fijian Dollar", "242"),
    FKP("Falkland Islands Pound", "238"),
    GEL("Georgian Lari", "981"),
    GHS("Ghanaian Cedi", "936"),
    GIP("Gibraltar Pound", "292"),
    DKK("Danish Krone", "208"),
    GMD("Gambian Dalasi", "270"),
    GNF("Guinean Franc", "324"),
    GTQ("Guatemalan Quetzal", "320"),
    GYD("Guyanaese Dollar", "328"),
    HKD("Hong Kong Dollar", "344"),
    HNL("Honduran Lempira", "340"),
    HRK("Croatian Kuna", "191"),
    HTG("Haitian Gourde", "332"),
    HUF("Hungarian Forint", "348"),
    IDR("Indonesian Rupiah", "360"),
    INR("Indian Rupee", "356"),
    IQD("Iraqi Dinar", "368"),
    IRR("Iranian Rial", "364"),
    ISK("Icelandic Króna", "352"),
    GBP("British Pound Sterling", "826"),
    JMD("Jamaican Dollar", "388"),
    JOD("Jordanian Dinar", "400"),
    JPY("Japanese Yen", "392"),
    KES("Kenyan Shilling", "404"),
    KGS("Kyrgystani Som", "417"),
    KHR("Cambodian Riel", "116"),
    KMF("Comorian Franc", "174"),
    KPW("North Korean Won", "408"),
    KRW("South Korean Won", "410"),
    KWD("Kuwaiti Dinar", "414"),
    KYD("Cayman Islands Dollar", "136"),
    KZT("Kazakhstani Tenge", "398"),
    LAK("Laotian Kip", "418"),
    LBP("Lebanese Pound", "422"),
    CHF("Swiss Franc", "756"),
    LKR("Sri Lankan Rupee", "144"),
    LRD("Liberian Dollar", "430"),
    LSL("Lesotho Loti", "426"),
    LTL("Lithuanian Litas", "440"),
    LYD("Libyan Dinar", "434"),
    MAD("Moroccan Dirham", "504"),
    MDL("Moldovan Leu", "498"),
    MGA("Malagasy Ariary", "969"),
    MKD("Macedonian Denar", "807"),
    MMK("Myanma Kyat", "104"),
    MNT("Mongolian Tugrik", "496"),
    MOP("Macanese Pataca", "446"),
    MRO("Mauritanian Ouguiya", "478"),
    XCD("East Caribbean Dollar", "951"),
    MUR("Mauritian Rupee", "480"),
    MVR("Maldivian Rufiyaa", "462"),
    MWK("Malawian Kwacha", "454"),
    MXN("Mexican Peso", "484"),
    MYR("Malaysian Ringgit", "458"),
    MZN("Mozambican Metical", "943"),
    NAD("Namibian Dollar", "516"),
    NGN("Nigerian Naira", "566"),
    NIO("Nicaraguan Córdoba", "558"),
    NPR("Nepalese Rupee", "524"),
    OMR("Omani Rial", "512"),
    PAB("Panamanian Balboa", "590"),
    PEN("Peruvian Nuevo Sol", "604"),
    XPF("CFP Franc", "953"),
    PGK("Papua New Guinean Kina", "598"),
    PHP("Philippine Peso", "608"),
    PKR("Pakistani Rupee", "586"),
    PLN("Polish Zloty", "985"),
    ILS("Israeli New Sheqel", "376"),
    PYG("Paraguayan Guarani", "600"),
    QAR("Qatari Rial", "634"),
    RON("Romanian Leu", "946"),
    RSD("Serbian Dinar", "941"),
    RUB("Russian Ruble", "643"),
    RWF("Rwandan Franc", "646"),
    SAR("Saudi Riyal", "682"),
    SBD("Solomon Islands Dollar", "090"),
    SCR("Seychellois Rupee", "690"),
    SDG("Sudanese Pound", "938"),
    SEK("Swedish Krona", "752"),
    SGD("Singapore Dollar", "702"),
    SHP("Saint Helena Pound", "654"),
    NOK("Norwegian Krone", "578"),
    SLL("Sierra Leonean Leone", "694"),
    SOS("Somali Shilling", "706"),
    SRD("Surinamese Dollar", "968"),
    STD("São Tomé and Príncipe Dobra", "678"),
    ANG("Netherlands Antillean Guilder", "532"),
    SYP("Syrian Pound", "760"),
    SZL("Swazi Lilangeni", "748"),
    XAF("CFA Franc BEAC", "950"),
    XOF("CFA Franc BCEAO", "952"),
    THB("Thai Baht", "764"),
    TJS("Tajikistani Somoni", "972"),
    NZD("New Zealand Dollar", "554"),
    TMT("Turkmenistani Manat", "934"),
    TND("Tunisian Dinar", "788"),
    TOP("Tongan Pa?anga", "776"),
    TRY("Turkish Lira", "949"),
    TTD("Trinidad and Tobago Dollar", "780"),
    AUD("Australian Dollar", "036"),
    TWD("New Taiwan Dollar", "901"),
    TZS("Tanzanian Shilling", "834"),
    UAH("Ukrainian Hryvnia", "980"),
    UGX("Ugandan Shilling", "800"),
    USD("United States dollar", "840"),
    UYU("Uruguayan Peso", "858"),
    UZS("Uzbekistan Som", "860"),
    VEF("Venezuelan Bolívar", "937"),
    VND("Vietnamese Dong", "704"),
    VUV("Vanuatu Vatu", "548"),
    WST("Samoan Tala", "882"),
    YER("Yemeni Rial", "886"),
    EUR("Euro", "978"),
    ZAR("South African Rand", "710"),
    ZMW("Zambian Kwacha", "967"),
    ZWL("Zimbabwean Dollar (2009)", "932");

    private String currencyName;
    private String currencyNumber;

    @JsonCreator
    public static CurrencyCodeEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str);
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }

    public String getCurrencyName() {
        return this.currencyName;
    }

    public static CurrencyCodeEnum findById(int iso4217Code) {
        String iso4217 = iso4217Code + "";
        StringBuilder result = new StringBuilder();
        if(iso4217.length() == 2) {
            result.append('0');
            result.append(iso4217);
        } else if(iso4217.length() == 1) {
            result.append('0');
            result.append('0');
            result.append(iso4217);
        } else if(iso4217.length() == 3) {
            result.append(iso4217);
        }

        CurrencyCodeEnum[] arr$ = values();
        int len$ = arr$.length;

        for(int i$ = 0; i$ < len$; ++i$) {
            CurrencyCodeEnum currencyEnum = arr$[i$];
            if(currencyEnum.getCurrencyNumber().equals(result)) {
                return currencyEnum;
            }
        }

        return null;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getCurrencyNumber() {
        return this.currencyNumber;
    }

    public void setCurrencyNumber(String currencyNumber) {
        this.currencyNumber = currencyNumber;
    }

    private CurrencyCodeEnum(String currencyName, String currencyNumber) {
        this.currencyName = currencyName;
        this.currencyNumber = currencyNumber;
    }
}
