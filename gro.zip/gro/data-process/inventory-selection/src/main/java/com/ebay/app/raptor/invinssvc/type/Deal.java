package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;


@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class Deal {
    private DealTypeEnum dealType;
    private Double dealSavingPercentage;
    private DealReference dealReference;
    private List<DealLevelEnum> dealLevel;
    private Amount shippingCost;

    public Deal() {
    }

    public DealTypeEnum getDealType() {
        return this.dealType;
    }

    public void setDealType(DealTypeEnum dealType) {
        this.dealType = dealType;
    }

    public Double getDealSavingPercentage() {
        return this.dealSavingPercentage;
    }

    public void setDealSavingPercentage(Double dealSavingPercentage) {
        this.dealSavingPercentage = dealSavingPercentage;
    }

    public DealReference getDealReference() {
        return this.dealReference;
    }

    public void setDealReference(DealReference dealReference) {
        this.dealReference = dealReference;
    }

    public List<DealLevelEnum> getDealLevel() {
        return this.dealLevel;
    }

    public void setDealLevel(List<DealLevelEnum> dealLevel) {
        this.dealLevel = dealLevel;
    }

    public Amount getShippingCost() {
        return this.shippingCost;
    }

    public void setShippingCost(Amount shippingCost) {
        this.shippingCost = shippingCost;
    }
}
