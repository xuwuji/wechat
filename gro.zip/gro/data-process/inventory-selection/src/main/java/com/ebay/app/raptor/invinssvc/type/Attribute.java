package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.HashMap;
import java.util.Map;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class Attribute {
    String attributeName;
    Object attributeValue;
    String attributeValueType;
    Map<String, Metadata> attributeMetadata = new HashMap();

    public Attribute() {
    }

    public String getAttributeName() {
        return this.attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeValueType() {
        return this.attributeValueType;
    }

    public void setAttributeValueType(String attributeType) {
        this.attributeValueType = attributeType;
    }

    public Object getAttributeValue() {
        return this.attributeValue;
    }

    public void setAttributeValue(Object attributeValue) {
        this.attributeValue = attributeValue;
    }

    public Map<String, Metadata> getAttributeMetadata() {
        return this.attributeMetadata;
    }

    public void setAttributeMetadata(Map<String, Metadata> attributeMetadata) {
        this.attributeMetadata = attributeMetadata;
    }
}
