package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class IISListing {
    private List<Long> allCategoryId = new ArrayList();
    private String productReferenceId;
    private List<Metric> metrics = new ArrayList();
    private List<Deal> deals = new ArrayList();
    private List<External> external = new ArrayList();
    private List<Entity> entity = new ArrayList();

    private String listingId;
    private Text title;
    private String imageURL;
    private MarketplaceIdEnum marketplaceListedOn;

    public String getListingId() {
        return listingId;
    }

    public void setListingId(String listingId) {
        this.listingId = listingId;
    }

    public Text getTitle() {
        return title;
    }

    public void setTitle(Text title) {
        this.title = title;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public MarketplaceIdEnum getMarketplaceListedOn() {
        return marketplaceListedOn;
    }

    public void setMarketplaceListedOn(MarketplaceIdEnum marketplaceListedOn) {
        this.marketplaceListedOn = marketplaceListedOn;
    }

    public IISListing() {
    }

    public List<Metric> getMetrics() {
        return this.metrics;
    }

    public void setMetrics(List<Metric> metrics) {
        this.metrics = metrics;
    }

    public List<Deal> getDeals() {
        return this.deals;
    }

    public void setDeals(List<Deal> deals) {
        this.deals = deals;
    }

    public List<External> getExternal() {
        return this.external;
    }

    public void setExternal(List<External> external) {
        this.external = external;
    }

    public List<Long> getAllCategoryId() {
        return this.allCategoryId;
    }

    public void setAllCategoryId(List<Long> allCategoryId) {
        this.allCategoryId = allCategoryId;
    }

    public String getProductReferenceId() {
        return this.productReferenceId;
    }

    public void setProductReferenceId(String productReferenceId) {
        this.productReferenceId = productReferenceId;
    }

    public List<Entity> getEntity() {
        return this.entity;
    }

    public void setEntity(List<Entity> entity) {
        this.entity = entity;
    }
}
