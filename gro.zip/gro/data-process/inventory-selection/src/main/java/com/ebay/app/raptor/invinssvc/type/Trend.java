package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class Trend {
    String trendId;
    MetricMappingTypeEnum trendMappedType;
    List<TrendDataPoint> trendDataPoints = new ArrayList();

    public Trend() {
    }

    public String getTrendId() {
        return this.trendId;
    }

    public void setTrendId(String trendId) {
        this.trendId = trendId;
    }

    public MetricMappingTypeEnum getTrendMappedType() {
        return this.trendMappedType;
    }

    public void setTrendMappedType(MetricMappingTypeEnum trendMappedType) {
        this.trendMappedType = trendMappedType;
    }

    public List<TrendDataPoint> getTrendDataPoints() {
        return this.trendDataPoints;
    }

    public void setTrendDataPoints(List<TrendDataPoint> trendDataPoints) {
        this.trendDataPoints = trendDataPoints;
    }
}
