package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class TrendDataPoint {
    DateTime trendDate;
    Amount trendValue;
    Long trendCardinalValue;

    public TrendDataPoint() {
    }

    public DateTime getTrendDate() {
        return this.trendDate;
    }

    public void setTrendDate(DateTime trendDate) {
        this.trendDate = trendDate;
    }

    public Amount getTrendValue() {
        return this.trendValue;
    }

    public void setTrendValue(Amount trendValue) {
        this.trendValue = trendValue;
    }

    public Long getTrendCardinalValue() {
        return this.trendCardinalValue;
    }

    public void setTrendCardinalValue(Long trendCardinalValue) {
        this.trendCardinalValue = trendCardinalValue;
    }
}
