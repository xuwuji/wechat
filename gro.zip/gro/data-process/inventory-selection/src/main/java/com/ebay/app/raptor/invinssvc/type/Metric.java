package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class Metric {
    String metricId;
    Object metricValue;
    MetricDaysEnum days;
    DateTime updatedOn;
    MetricMappingTypeEnum metricMappedType;
    Boolean hasPriceRange;
    PriceRange priceRange;

    public Metric() {
    }

    public MetricDaysEnum getDays() {
        return this.days;
    }

    public void setDays(MetricDaysEnum days) {
        this.days = days;
    }

    public DateTime getUpdatedOn() {
        return this.updatedOn;
    }

    public void setUpdatedOn(DateTime updatedOn) {
        this.updatedOn = updatedOn;
    }

    public String getMetricId() {
        return this.metricId;
    }

    public void setMetricId(String metricId) {
        this.metricId = metricId;
    }

    public Object getMetricValue() {
        return this.metricValue;
    }

    public void setMetricValue(Object metricValue) {
        this.metricValue = metricValue;
    }

    public MetricMappingTypeEnum getMetricMappedType() {
        return this.metricMappedType;
    }

    public void setMetricMappedType(MetricMappingTypeEnum metricMappedType) {
        this.metricMappedType = metricMappedType;
    }

    public Boolean getHasPriceRange() {
        return this.hasPriceRange;
    }

    public void setHasPriceRange(Boolean hasPriceRange) {
        this.hasPriceRange = hasPriceRange;
    }

    public PriceRange getPriceRange() {
        return this.priceRange;
    }

    public void setPriceRange(PriceRange priceRange) {
        this.priceRange = priceRange;
    }

    @JsonIgnore
    public Amount getAmountData() {
        if(this.metricValue instanceof Amount) {
            return (Amount)this.metricValue;
        } else {
            Amount amount = new Amount();
            amount.setValue(Double.valueOf(0.0D));
            amount.setCurrency(CurrencyCodeEnum.USD);
            return amount;
        }
    }

    @JsonIgnore
    public Double getDoubleData() {
        return this.metricValue instanceof Double?(Double)this.metricValue:new Double(0.0D);
    }

    @JsonIgnore
    public Long getLongData() {
        if(!(this.metricValue instanceof Long) && !(this.metricValue instanceof Integer)) {
            return new Long(0L);
        } else {
            Long value = Long.valueOf(((Number)this.metricValue).longValue());
            return value;
        }
    }
}
