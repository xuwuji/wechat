package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class Metadata {
    String metadataName;
    List<Object> metadataValue = new ArrayList();
    String metadataValueType;

    public Metadata() {
    }

    public String getMetadataName() {
        return this.metadataName;
    }

    public void setMetadataName(String metadataName) {
        this.metadataName = metadataName;
    }

    public String getMetadataValueType() {
        return this.metadataValueType;
    }

    public void setMetadataValueType(String metadataType) {
        this.metadataValueType = metadataType;
    }

    public List<Object> getMetadataValue() {
        return this.metadataValue;
    }

    public void setMetadataValue(List<Object> metadataValue) {
        String type = this.metadataValueType;
        if((metadataValue == null || type == null || !type.equalsIgnoreCase(Long.TYPE.getName())) && !type.equalsIgnoreCase(Integer.TYPE.getName())) {
            this.metadataValue = metadataValue;
        } else {
            this.metadataValue = this.handleDecimals(metadataValue);
        }

    }

    private List<Object> handleDecimals(List<Object> metadataValue) {
        ArrayList objects = new ArrayList();
        Iterator i$ = metadataValue.iterator();

        while(i$.hasNext()) {
            Object objValue = i$.next();
            Long l = Long.valueOf(((Number)objValue).longValue());
            objects.add(l);
        }

        return objects;
    }
}
