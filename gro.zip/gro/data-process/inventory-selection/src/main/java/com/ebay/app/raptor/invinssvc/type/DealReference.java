package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class DealReference {
    private Amount benchmarkPrice;
    private String url;
    private DateTime updatedOn;
    private Long rank;

    public DealReference() {
    }

    public Amount getBenchmarkPrice() {
        return this.benchmarkPrice;
    }

    public void setBenchmarkPrice(Amount benchmarkPrice) {
        this.benchmarkPrice = benchmarkPrice;
    }

    public String getURL() {
        return this.url;
    }

    public void setURL(String uRL) {
        this.url = uRL;
    }

    public DateTime getUpdatedOn() {
        return this.updatedOn;
    }

    public void setUpdatedOn(DateTime updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Long getRank() {
        return this.rank;
    }

    public void setRank(Long rank) {
        this.rank = rank;
    }
}
