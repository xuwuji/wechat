package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;

@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
@XmlRootElement
public class Amount {
    private Double value;
    private Double convertedFromValue;
    private CurrencyCodeEnum convertedFromCurrency;
    private CurrencyCodeEnum currency;

    public Amount() {
    }

    public Amount(Double value, Double convertedFromValue, CurrencyCodeEnum convertedFromCurrency, CurrencyCodeEnum currency) {
        this.value = value;
        this.convertedFromValue = convertedFromValue;
        this.convertedFromCurrency = convertedFromCurrency;
        this.currency = currency;
    }

    public Double getValue() {
        return this.value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public Double getConvertedFromValue() {
        return this.convertedFromValue;
    }

    public void setConvertedFromValue(Double convertedFromValue) {
        this.convertedFromValue = convertedFromValue;
    }

    public CurrencyCodeEnum getConvertedFromCurrency() {
        return this.convertedFromCurrency;
    }

    public void setConvertedFromCurrency(CurrencyCodeEnum convertedFromCurrency) {
        this.convertedFromCurrency = convertedFromCurrency;
    }

    public CurrencyCodeEnum getCurrency() {
        return this.currency;
    }

    public void setCurrency(CurrencyCodeEnum currency) {
        this.currency = currency;
    }

    public int hashCode() {
        boolean prime = true;
        byte result = 1;
        int result1 = 31 * result + (this.currency == null?0:this.currency.hashCode());
        result1 = 31 * result1 + (this.value == null?0:this.value.hashCode());
        return result1;
    }

    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        } else if(obj == null) {
            return false;
        } else if(this.getClass() != obj.getClass()) {
            return false;
        } else {
            Amount other = (Amount)obj;
            if(this.currency != other.currency) {
                return false;
            } else {
                if(this.value == null) {
                    if(other.value != null) {
                        return false;
                    }
                } else if(!this.value.equals(other.value)) {
                    return false;
                }

                return true;
            }
        }
    }
}
