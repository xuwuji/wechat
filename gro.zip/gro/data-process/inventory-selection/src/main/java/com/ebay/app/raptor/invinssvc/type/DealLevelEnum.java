package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum DealLevelEnum {
    LEVEL1,
    LEVEL2,
    LEVEL3,
    LEVEL4,
    LEVEL5;

    private DealLevelEnum() {
    }

    @JsonCreator
    public static DealLevelEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str);
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }
}
