package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum MarketplaceIdEnum {
    EBAY_US,
    EBAY_CA,
    EBAY_GB,
    EBAY_AU,
    EBAY_AT,
    EBAY_BE,
    EBAY_DE,
    EBAY_IT,
    EBAY_NL,
    EBAY_ES,
    EBAY_CH,
    EBAY_TW,
    EBAY_CZ,
    EBAY_DK,
    EBAY_FI,
    EBAY_FR,
    EBAY_GR,
    EBAY_HK,
    EBAY_HU,
    EBAY_IN,
    EBAY_ID,
    EBAY_IE,
    EBAY_IL,
    EBAY_MY,
    EBAY_NZ,
    EBAY_NO,
    EBAY_PH,
    EBAY_PL,
    EBAY_PT,
    EBAY_PR,
    EBAY_RU,
    EBAY_SG,
    EBAY_ZA,
    EBAY_SE,
    EBAY_TH,
    EBAY_VN,
    EBAY_CN,
    EBAY_JP,
    EBAY_PE,
    EBAY_HALF_US,
    EBAY_MOTORS_US,
    EBAY_MOTORS_CA,
    EBAY_MOTORS_DE,
    EBAY_MOTORS_UK,
    EBAY_MOTORS_AU;

    private MarketplaceIdEnum() {
    }

    @JsonCreator
    public static MarketplaceIdEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str);
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }
}