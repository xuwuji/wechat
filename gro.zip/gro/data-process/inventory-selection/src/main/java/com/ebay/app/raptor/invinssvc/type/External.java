package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@XmlRootElement
@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_EMPTY
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
public class External {
    private String externalId;
    private String externalName;
    private String externalURL;
    private Amount externalPrice;
    private DateTime updatedOn;
    private List<String> mappedProductReferenceIds = new ArrayList();
    private List<GlobalId> mappedGlobalIds = new ArrayList();
    private Map<String, List<ExternalRank>> externalRanks = new HashMap();
    private Map<String, List<Attribute>> externalAttributes = new HashMap();

    public External() {
    }

    public String getExternalId() {
        return this.externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getExternalName() {
        return this.externalName;
    }

    public void setExternalName(String externalName) {
        this.externalName = externalName;
    }

    public String getExternalURL() {
        return this.externalURL;
    }

    public void setExternalURL(String externalURL) {
        this.externalURL = externalURL;
    }

    public Amount getExternalPrice() {
        return this.externalPrice;
    }

    public void setExternalPrice(Amount externalPrice) {
        this.externalPrice = externalPrice;
    }

    public DateTime getUpdatedOn() {
        return this.updatedOn;
    }

    public void setUpdatedOn(DateTime updatedOn) {
        this.updatedOn = updatedOn;
    }

    public List<String> getMappedProductReferenceIds() {
        return this.mappedProductReferenceIds;
    }

    public void setMappedProductReferenceIds(List<String> mappedProductReferenceIds) {
        this.mappedProductReferenceIds = mappedProductReferenceIds;
    }

    public List<GlobalId> getMappedGlobalIds() {
        return this.mappedGlobalIds;
    }

    public void setMappedGlobalIds(List<GlobalId> mappedGlobalIds) {
        this.mappedGlobalIds = mappedGlobalIds;
    }

    public Map<String, List<ExternalRank>> getExternalRanks() {
        return this.externalRanks;
    }

    public void setExternalRanks(Map<String, List<ExternalRank>> externalRanks) {
        this.externalRanks = externalRanks;
    }

    public Map<String, List<Attribute>> getExternalAttributes() {
        return this.externalAttributes;
    }

    public void setExternalAttributes(Map<String, List<Attribute>> externalAttributes) {
        this.externalAttributes = externalAttributes;
    }
}