package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;

@JsonSerialize(
        include = JsonSerialize.Inclusion.NON_NULL
)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
@XmlRootElement
public class Text {
    private String content;
    private LanguageEnum language;
    private String translatedFromContent;
    private LanguageEnum translatedFromLanguage;

    public Text() {
    }

    public Text(String content, LanguageEnum language, String translatedFromContent, LanguageEnum translatedFromLanguage) {
        this.content = content;
        this.language = language;
        this.translatedFromContent = translatedFromContent;
        this.translatedFromLanguage = translatedFromLanguage;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LanguageEnum getLanguage() {
        return this.language;
    }

    public void setLanguage(LanguageEnum language) {
        this.language = language;
    }

    public String getTranslatedFromContent() {
        return this.translatedFromContent;
    }

    public void setTranslatedFromContent(String translatedFromContent) {
        this.translatedFromContent = translatedFromContent;
    }

    public LanguageEnum getTranslatedFromLanguage() {
        return this.translatedFromLanguage;
    }

    public void setTranslatedFromLanguage(LanguageEnum translatedFromLanguage) {
        this.translatedFromLanguage = translatedFromLanguage;
    }

    public int hashCode() {
        boolean prime = true;
        byte result = 1;
        int result1 = 31 * result + (this.content == null?0:this.content.hashCode());
        result1 = 31 * result1 + (this.language == null?0:this.language.hashCode());
        return result1;
    }

    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        } else if(obj == null) {
            return false;
        } else if(this.getClass() != obj.getClass()) {
            return false;
        } else {
            Text other = (Text)obj;
            if(this.content == null) {
                if(other.content != null) {
                    return false;
                }
            } else if(!this.content.equals(other.content)) {
                return false;
            }

            return this.language == other.language;
        }
    }
}
