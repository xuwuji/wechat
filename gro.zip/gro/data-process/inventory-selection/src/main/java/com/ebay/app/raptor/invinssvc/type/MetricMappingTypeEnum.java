package com.ebay.app.raptor.invinssvc.type;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum MetricMappingTypeEnum {
    LISTING,
    PRODUCT_AGGREGATE,
    ENTITY_AGGREGATE;

    private MetricMappingTypeEnum() {
    }

    @JsonCreator
    public static MetricMappingTypeEnum fromValue(String str) {
        if(str != null && str.trim().length() > 0) {
            try {
                return valueOf(str);
            } catch (IllegalArgumentException var2) {
                return null;
            }
        } else {
            return null;
        }
    }
}
