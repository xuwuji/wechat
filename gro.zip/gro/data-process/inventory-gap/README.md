# Inventory Gap Data Process Job

## Compile and Package

```shell
$ cd Projects/gro/data-process/inventory-gap/
$ mvn clean package -Pprod
[INFO] Scanning for projects...
[WARNING]
...
[INFO] Building zip: gro/data-process/inventory-gap/target/inventory-gap-0.1-binary.zip
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 1.495 s
[INFO] Finished at: 2015-12-03T15:24:11-08:00
[INFO] Final Memory: 12M/325M
[INFO] ------------------------------------------------------------------------
$
```

## Deploy

```shell
$ scp target/inventory-gap-0.1-binary.zip [YOUR_NT_NAME]@phxdpeba007.phx.ebay.com:~

# do following steps on phxdpeba007

$ sudob_bis
$ cd /projects/inventorygap/
$ unzip /home/[YOUR_NT_NAME]/inventory-gap-0.1-binary.zip
Archive:  /home/yangzhou/inventory-gap-0.1-binary.zip
replace downloads/qa/download.2prod.hive? [y]es, [n]o, [A]ll, [N]one, [r]ename: A
...
$ 
```

Production job folder structure

```shell
$ tree
.
├── downloads
│   ├── prod
│   └── qa
│       ├── download.2prod.hive
│       ├── download.hive
│       └── download.pig
├── script
│   ├── appenddate.sh
│   ├── cleanenv.sh
│   ├── createdb.sh
│   ├── load2table.sh
│   ├── qa_download.2prod.sh
│   ├── qa_download.sh
│   ├── refreshview.sh
│   └── util.sh
└── sqls
    ├── dw_category_groupings.sql
    ├── gap_cat_aspect_or.sql
    ├── sdt_all_cats_metric.sql
    ├── sdt_cluster_metric2.sql
    └── sdt_top_asp_cluster_metric.sql
```

## Execution

***NOTICE** Although inventory gap job is configured in UC4, it's still not a cron job. Everyweek, we need to manually trigger the job in UC4 after up-stream data ready on HDFS.

| Property   | Value   |
|------------|---------|
| Start Time | 2:00 am |
| UC4 Client | 1400 |
| UC4 Folder | /BPE/JOBPLANS/GRO.RETAIL/ |
| UC4 Job Name | GRO.INVGAP.QA.DATA.JOB |
