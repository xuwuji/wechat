#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

MYSQL_HOME="/usr/local/mysql/"
HADOOP_HOME="/apache/hadoop/hadoop"

TABLE=${1}
DB=${2}
SOURCE_HDFS_FOLDER=${3}


$HADOOP_HOME/bin/hadoop fs -text $SOURCE_HDFS_FOLDER/part* > $TABLE.txt
status=$?
if [ $status -ne 0 ]; then
   echo "error with $1"
   exit $status
fi

$MYSQL_HOME/bin/mysql -u root --database=$DB --show-warnings < /projects/inventorygap/sqls/${TABLE}.sql
status=$?
if [ $status -ne 0 ]; then
   echo "error with $1"
   exit $status
fi
