#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

MYSQL_HOME="/usr/local/mysql/"
HADOOP_HOME="/apache/hadoop/hadoop"

DB=${1}

REF_DB="inventory_gap_template_db"

texec $MYSQL_HOME/bin/mysql -v -u root -e "CREATE DATABASE IF NOT EXISTS $DB CHARACTER SET utf8 COLLATE utf8_general_ci;"
$MYSQL_HOME/bin/mysqldump -u root -d $REF_DB | $MYSQL_HOME/bin/mysql -u root -D $DB
status=$?
if [ $status -ne 0 ]; then
   echo "error with $1"
   exit $status
fi
texec $MYSQL_HOME/bin/mysql -v -u root -e "GRANT ALL ON ${DB}.* TO 'root'@'%';"



