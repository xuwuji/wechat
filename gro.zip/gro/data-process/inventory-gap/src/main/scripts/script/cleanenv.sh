#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

rm dw_category_groupings.txt
rm gap_cat_aspect_or.txt
rm sdt_all_cats_metric.txt
rm sdt_cluster_metric2.txt
rm sdt_top_asp_cluster_metric.txt

