#/bin/bash/

check_success() {
  echo "check file ready for $1"
  hdfs dfs -test -e $1/_SUCCESS
  STATUS=$?
  if [ $STATUS -eq 0 ]
  then
    echo "Found _SUCCESS" 
    return 0
  else
    echo "Couldn't find _SUCCESS"
    return 1
  fi
}

check_hive_success() {
  echo "check file ready for $1"
  hdfs dfs -test -e $1/_HIVESUCCESS
  STATUS=$?
  if [ $STATUS -eq 0 ]
  then
    echo "Found _HIVESUCCESS"
    return 0
  else
    echo "Couldn't find _HIVESUCCESS"
    return 1
  fi
}

ubicontainer_path(){
  DATE=`date -d $1 +%Y/%m/%d`
  echo "/sys/soj/ubi_bi_session_hdp/$DATE/00"
}

sessioncontainer_path(){
  DATE=`date -d $1 +%Y/%m/%d`
  echo "/sys/soj/sessioncontainer/$DATE/same_day"
}

dated_path(){
  DATE=`date -d $1 +%Y/%m/%d`
  printf $2 $DATE
}

block_while_notready(){
  DUR=${2-"30m"}
  CHECK=${3-check_success}
  echo "sleep 10 iteration for $DUR if $1 is not ready..."
  for i in {1..10};
  do
    echo $CHECK
    $CHECK $1
    if [ $? -eq 0 ]
    then
        echo "$1 is ready to consume"
        return 0
    else
	echo "$1 is not ready sleep for $DUR"
        sleep $DUR
    fi
  done
  return 1
}

function texec {
    echo "$@"
    "$@"
    local status=$?
    if [ $status -ne 0 ]; then
        echo "error with $1"
        exit $status
    fi
    return $status
}
