#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

MYSQL_HOME="/usr/local/mysql/"
HADOOP_HOME="/apache/hadoop/hadoop"

DB=${1}
DATE=${2}

texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "INSERT INTO sdt_refresh_log (refresh_date) values('${DATE}');"
