#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

MYSQL_HOME="/usr/local/mysql/"
HADOOP_HOME="/apache/hadoop/hadoop"

DATADB=${1}
TYPE=${2}

VIEWDB="inventory_gap_${TYPE}"


texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "CREATE OR REPLACE VIEW ${VIEWDB}.dw_category_groupings AS SELECT * FROM ${DATADB}.dw_category_groupings;"
texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "CREATE OR REPLACE VIEW ${VIEWDB}.sdt_all_cats_metric AS SELECT * FROM ${DATADB}.sdt_all_cats_metric;"
texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "CREATE OR REPLACE VIEW ${VIEWDB}.gap_cat_aspect_or AS SELECT * FROM ${DATADB}.gap_cat_aspect_or;"
texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "CREATE OR REPLACE VIEW ${VIEWDB}.sdt_top_asp_cluster_metric AS SELECT * FROM ${DATADB}.sdt_top_asp_cluster_metric;"
texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "CREATE OR REPLACE VIEW ${VIEWDB}.sdt_cluster_metric2 AS SELECT * FROM ${DATADB}.sdt_cluster_metric2;"
texec $MYSQL_HOME/bin/mysql -u root --database=${DB} --show-warnings -vve "CREATE OR REPLACE VIEW ${VIEWDB}.sdt_refresh_log AS SELECT * FROM ${DATADB}.sdt_refresh_log;"
