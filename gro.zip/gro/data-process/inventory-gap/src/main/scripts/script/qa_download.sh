#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

SM_DUMP=`hadoop fs -ls /apps/hdmi-technology/b_app_buyer/P_ACCT_LISTING_DETAIL_AGG/ | head -n2 | tail -1 | awk '{print $8}'`

pig -f downloads/qa/download.pig -param OUTPUT=/apps/hdmi-prod/b_bis/supplydemand/TEST/es_data -param SM_DUMP=$SM_DUMP -param GAP_DUMP=/user/veeb/inventory_gap
status=$?
if [ $status -ne 0 ]; then
   echo "error with $1"
   exit $status
fi

hive --auxpath `hbase classpath | awk 'BEGIN {RS=":"} {if(length($0) != 0 && index($0, "jar") > 0 && !index($0, "*") > 0) print}' | sed '/^$/d' | tr '\n' ','`/apache/hadoop/hbase/conf --hiveconf hbase.master=phxaishdc9en0014-be.phx.ebay.com:60000 -f downloads/qa/download.hive --hiveconf HBASE_DB=dss_ret_igaps_download_qa --hiveconf DOWNLOAD_FOLDER=/apps/hdmi-prod/b_bis/supplydemand/TEST/es_data
status=$?
if [ $status -ne 0 ]; then
   echo "error with $1"
   exit $status
fi

