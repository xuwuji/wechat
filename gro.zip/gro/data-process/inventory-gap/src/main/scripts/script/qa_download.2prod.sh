#!/bin/bash

source ~/.bash_profile
source /projects/inventorygap/script/util.sh

hive --auxpath `hbase classpath | awk 'BEGIN {RS=":"} {if(length($0) != 0 && index($0, "jar") > 0 && !index($0, "*") > 0) print}' | sed '/^$/d' | tr '\n' ','`/apache/hadoop/hbase/conf --hiveconf hbase.master=phxaishdc9en0014-be.phx.ebay.com:60000 -f downloads/qa/download.2prod.hive --hiveconf HBASE_DB=dss_ret_igaps_download --hiveconf DOWNLOAD_FOLDER=/apps/hdmi-prod/b_bis/supplydemand/TEST/es_data
status=$?
if [ $status -ne 0 ]; then
   echo "error with $1"
   exit $status
fi

