delete from dw_category_groupings;

LOAD DATA LOCAL INFILE 'dw_category_groupings.txt' 
INTO TABLE dw_category_groupings 
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '\r' 
ESCAPED BY '\r'
LINES TERMINATED BY '\n' 
IGNORE 0 ROWS (
  site_id,
  leaf_categ_id,
  leaf_categ_name,
  meta_categ_id,
  meta_categ_name,
  categ_lvl2_id, 
  categ_lvl2_name,
  categ_lvl3_id, 
  categ_lvl3_name,
  categ_lvl4_id, 
  categ_lvl4_name,
  categ_lvl5_id, 
  categ_lvl5_name,
  categ_lvl6_id, 
  categ_lvl6_name,
  categ_lvl7_id, 
  categ_lvl7_name,
  bsns_vrtcl_name
);
UPDATE dw_category_groupings SET enabled = 1;
