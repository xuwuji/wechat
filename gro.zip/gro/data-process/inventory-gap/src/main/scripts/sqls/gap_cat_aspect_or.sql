delete from gap_cat_aspect_or;

LOAD DATA LOCAL INFILE 'gap_cat_aspect_or.txt' 
INTO TABLE gap_cat_aspect_or 
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '\r' 
ESCAPED BY '\r'
LINES TERMINATED BY '\n' 
IGNORE 0 ROWS (
  SITE_ID,
  LEAF_CATEG_ID,
  IS_NEW_YN,
  ASPECT_COVERAGE_FLAGS,
  nbr_lstg,
  nbr_lstg_total
);
