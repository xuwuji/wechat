DROP TABLE if exists sdt_load_tmp;
 
CREATE TABLE `sdt_load_tmp` (
  `SITE_ID` int(11),
  `LEAF_CATEG_ID` bigint(20),
  `ASPECT_VALUE_1` varchar(255),
  `ASPECT_VALUE_2` varchar(255),
  `ASPECT_VALUE_3` varchar(255),
  `ASPECT_VALUE_4` varchar(255),
  `ASPECT_VALUE_5` varchar(255),
  `IS_NEW_YN` varchar(1),
  `qty_sold_10_full_window` bigint(20),
  `qty_avail_full_window` bigint(20),
  `qty_sold_cluster` bigint(20),
  `qty_avail_cluster` bigint(20),
  `nbr_lstg` bigint(20),
  `nbr_lstg_live_etrs` bigint(20),
  `nbr_lstg_live_b2c` bigint(20),
  `nbr_lstg_live_managed` bigint(20),
  `qty_live_new` bigint(20),
  `avg_lstg_price` double,
  `sell_rate_cluster` double,
  `gmv_cluster` double,
  `PROD_CLUST_ID` bigint(20) NOT NULL,
  `sell_rate_cat` double,
  `nbr_lstg_live` bigint(20),
  `nbr_lstg_live_new` bigint(20),
  `sell_rate_higher_cat` double,
  `nbr_items_to_add` bigint(20),
  `opportunity` double,
  `has_download_lstg` varchar(1)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
 
ALTER TABLE sdt_load_tmp ROW_FORMAT=Fixed;
ALTER TABLE sdt_load_tmp DISABLE KEYS;
 
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
SET SESSION tx_isolation='READ-UNCOMMITTED';
SET sql_log_bin = 0;
 
LOAD DATA LOCAL INFILE 'sdt_cluster_metric2.txt' INTO TABLE sdt_load_tmp
      FIELDS TERMINATED BY '\t'
      OPTIONALLY ENCLOSED BY '\r'
      ESCAPED BY '\r'
      LINES TERMINATED BY '\n'
      IGNORE 0 ROWS
(SITE_ID,LEAF_CATEG_ID,ASPECT_VALUE_1,ASPECT_VALUE_2,ASPECT_VALUE_3,ASPECT_VALUE_4,ASPECT_VALUE_5,IS_NEW_YN,qty_sold_10_full_window,qty_avail_full_window,qty_sold_cluster,qty_avail_cluster,nbr_lstg,nbr_lstg_live_etrs,nbr_lstg_live_b2c,nbr_lstg_live_managed,qty_live_new,avg_lstg_price,sell_rate_cluster,gmv_cluster,PROD_CLUST_ID,nbr_lstg_live,nbr_lstg_live_new,sell_rate_cat, sell_rate_higher_cat,nbr_items_to_add,opportunity,has_download_lstg) ;
 
 
 
 
ALTER TABLE sdt_cluster_metric2 DISABLE KEYS;
 
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
SET SESSION tx_isolation='READ-UNCOMMITTED';
SET sql_log_bin = 0;
 
truncate sdt_cluster_metric2;
 
Insert into sdt_cluster_metric2 select * from sdt_load_tmp;
 
ALTER TABLE sdt_cluster_metric2 ENABLE KEYS;
 
truncate sdt_load_tmp;
 

