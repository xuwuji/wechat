delete from sdt_all_cats_metric;

LOAD DATA LOCAL INFILE 'sdt_all_cats_metric.txt' 
INTO TABLE sdt_all_cats_metric 
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '\r' 
ESCAPED BY '\r'
LINES TERMINATED BY '\n' 
IGNORE 0 ROWS (
  SITE_ID,
  LEAF_CATEG_ID,
  IS_NEW_YN,
  qty_sold_sell_rate,
  qty_avail_sell_rate,
  qty_sold_cat,
  qty_avail_cat,
  nbr_lstg,
  nbr_lstg_live_etrs,
  nbr_lstg_live_b2c,
  nbr_lstg_live_managed,
  qty_live,
  avg_lstg_price,
  sell_rate_cat,
  gmv_cat,
  avg_sale_price,
  nbr_lstg_live,
  nbr_lstg_live_new,
  sell_rate_higher_cat,
  IS_LEAF_YN,
  LEAF_CATEG_LVL,
  NXT_LEVEL_CATEG_ID,
  BSNS_VRTCL_NAME,
  LEAF_CATEG_NAME,
  nbr_items_to_add,
  opportunity,
  ASPECT_NAME_1,
  ASPECT_NAME_2,
  ASPECT_NAME_3,
  ASPECT_NAME_4,
  ASPECT_NAME_5);

UPDATE sdt_all_cats_metric SET NXT_LEVEL_CATEG_ID = NULL where NXT_LEVEL_CATEG_ID=0;
