
DROP TABLE if exists sdt_top_cluster_load_tmp;
 
CREATE TABLE `sdt_top_cluster_load_tmp` (
  `SITE_ID` int(11) ,
  `LEAF_CATEG_ID` bigint(20) ,
  `BSNS_VRTCL_NAME` varchar(50) ,
  `IS_LEAF_YN` varchar(1) ,
  `IS_NEW_YN` varchar(1) ,
  `PROD_CLUST_LEAF_CATEG_ID` bigint(20) ,
  `ASPECT_VALUE_1` varchar(255) ,
  `ASPECT_VALUE_2` varchar(255) ,
  `ASPECT_VALUE_3` varchar(255) ,
  `ASPECT_VALUE_4` varchar(255) ,
  `ASPECT_VALUE_5` varchar(255) ,
  `PROD_CLUST_IS_NEW_YN` varchar(1) ,
  `incr_gmb_score` double ,
  `conversion_rate` double ,
  `avg_selling_price` double ,
  `items_sold` bigint(20) ,
  `items_available` bigint(20) ,
  `estimated_items_to_source` bigint(20) ,
  `estimated_gmb_opportunity` double ,
  `pct_lstg_live_etrs` double ,
  `pct_lstg_live_b2c` double ,
  `pct_lstg_live_managed` double ,
  `pct_lstg_live_new` double ,
  `nbr_lstg` bigint(20) ,
  `ASPECT_COVERAGE_FLAGS` int(10) ,
  `PROD_CLUST_ID_ASP` varchar(38) ,
  `CLUSTER_RANK` int(11) ,
  `RANKING_METHOD` varchar(10) ,
  `ASPECT_NAME_1` varchar(255) ,
  `ASPECT_NAME_2` varchar(255) ,
  `ASPECT_NAME_3` varchar(255) ,
  `ASPECT_NAME_4` varchar(255) ,
  `ASPECT_NAME_5` varchar(255) ,
  `LEAF_CATEG_NAME` varchar(255)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

ALTER TABLE sdt_top_cluster_load_tmp ROW_FORMAT=Fixed;
ALTER TABLE sdt_top_cluster_load_tmp DISABLE KEYS;
 
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
SET SESSION tx_isolation='READ-UNCOMMITTED';
SET sql_log_bin = 0;
 
LOAD DATA LOCAL INFILE 'sdt_top_asp_cluster_metric.txt' INTO TABLE sdt_top_cluster_load_tmp
      FIELDS TERMINATED BY '\t'
      OPTIONALLY ENCLOSED BY '\r'
      ESCAPED BY '\r'
      LINES TERMINATED BY '\n'
      IGNORE 0 ROWS
(SITE_ID,LEAF_CATEG_ID,BSNS_VRTCL_NAME,IS_LEAF_YN,IS_NEW_YN,PROD_CLUST_LEAF_CATEG_ID,ASPECT_VALUE_1,ASPECT_VALUE_2,ASPECT_VALUE_3,ASPECT_VALUE_4,ASPECT_VALUE_5,PROD_CLUST_IS_NEW_YN,incr_gmb_score,conversion_rate,avg_selling_price,items_sold,items_available,estimated_items_to_source,estimated_gmb_opportunity,pct_lstg_live_etrs,pct_lstg_live_b2c,pct_lstg_live_managed,pct_lstg_live_new,nbr_lstg,ASPECT_COVERAGE_FLAGS,PROD_CLUST_ID_ASP,CLUSTER_RANK,RANKING_METHOD,ASPECT_NAME_1,ASPECT_NAME_2,ASPECT_NAME_3,ASPECT_NAME_4,ASPECT_NAME_5,LEAF_CATEG_NAME);
 
ALTER TABLE sdt_top_asp_cluster_metric DISABLE KEYS;
 
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
SET SESSION tx_isolation='READ-UNCOMMITTED';
SET sql_log_bin = 0;
 
truncate sdt_top_asp_cluster_metric;
 
Insert into sdt_top_asp_cluster_metric select * from sdt_top_cluster_load_tmp;
 
ALTER TABLE sdt_top_cluster_load_tmp ENABLE KEYS;
 
truncate sdt_top_cluster_load_tmp;
 

