package com.ebay.bis.gro.kafka;

import com.ebay.dss.bpe.BehaviorFields;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import org.json.simple.JSONValue;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

/**
 * Created by bishao on 11/4/14.
 */
public class PVEventProducer {

    public static void main(String[] args)
            throws InterruptedException {

        Properties props = new Properties();
        props.put("metadata.broker.list", "localhost:9092");
        props.put("zk.connect", "localhost:2181");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("request.required.acks", "1");

        String TOPIC = "behavioral.event";
        ProducerConfig config = new ProducerConfig(props);

        Producer<String, String> producer = new Producer<String, String>(config);

        int evtCnt = 1;
        String[] sites = {"0"};
        String[] pages = {"2309692","2309693","2309694","2309695","2309696","2309743","2309744","2309745","2065262"};
        String[] sids = {
                "p2309692.m3940.l2",
                "p2065262.m2735.l5"
        };
        String[] items = { "170008122200" };
        String[] guids = {"guid1", "guid2"};
        String[] users = {"1279867537", "1257388072"};

        Random random = new Random();
        
        for (int i = 0; i < evtCnt; i ++) {
            Map<String, Object> event = new HashMap<String, Object>();
            event.put(BehaviorFields.SITE, sites[random.nextInt(sites.length)]);
            event.put(BehaviorFields.PAGE, pages[random.nextInt(pages.length)]);
            event.put(BehaviorFields.SOURCE, sids[random.nextInt(sids.length)]);
            event.put(BehaviorFields.ITEM, items[random.nextInt(items.length)]);
            event.put(BehaviorFields.GUID, guids[random.nextInt(guids.length)]);
            if(random.nextBoolean()) {
                event.put(BehaviorFields.USER, users[random.nextInt(users.length)]);
            }
            if(random.nextBoolean()) {
                event.put(BehaviorFields.BEST_USER, users[random.nextInt(users.length)]);
            }

            event.put(BehaviorFields.TIMESTAMP, System.currentTimeMillis());

            KeyedMessage<String, String> msg = new KeyedMessage<String, String>(TOPIC, JSONValue.toJSONString(event));
            producer.send(msg);
            System.out.println(event);
            Thread.sleep(10000);

        }
        producer.close();
    }
}
