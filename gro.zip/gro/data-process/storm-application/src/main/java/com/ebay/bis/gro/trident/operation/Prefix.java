package com.ebay.bis.gro.trident.operation;

import backtype.storm.tuple.Values;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 11/19/15.
 */
@SuppressWarnings("serial")
public class Prefix extends BaseFunction {
	private String prefix;

	public Prefix(String p) {
		this.prefix = p;
	}

	@Override
	public void execute(TridentTuple tuple, TridentCollector collector) {
		collector.emit(new Values(this.prefix + tuple.get(0)));
	}
}
