package com.ebay.bis.gro.trident;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.generated.StormTopology;
import backtype.storm.tuple.Fields;
import com.datastax.driver.core.ConsistencyLevel;
import com.ebay.bis.gro.trident.operation.Prefix;
import com.ebay.dss.bpe.BaseTopology;
import com.ebay.dss.bpe.BehaviorFields;
import com.ebay.dss.bpe.TransactionFields;
import com.ebay.dss.bpe.attribution.GmvQtyMapper;
import com.ebay.dss.bpe.attribution.GmvQtySum;
import com.ebay.dss.bpe.cassandra.IntValueMapper;
import com.ebay.dss.bpe.cassandra.PersistenceManager;
import com.ebay.dss.bpe.kafka.KafkaMapper;
import com.ebay.dss.bpe.kafka.SpoutCreator;
import com.ebay.dss.bpe.trident.operation.*;
import com.hmsonline.trident.cql.CassandraCqlMapState;
import com.hmsonline.trident.cql.CassandraCqlMapStateFactory;
import com.hmsonline.trident.cql.CassandraCqlStateFactory;
import com.hmsonline.trident.cql.mappers.CqlRowMapper;
import storm.kafka.trident.TridentKafkaState;
import storm.kafka.trident.TridentKafkaStateFactory;
import storm.kafka.trident.TridentKafkaUpdater;
import storm.kafka.trident.selector.DefaultTopicSelector;
import storm.trident.Stream;
import storm.trident.TridentTopology;
import storm.trident.operation.builtin.FilterNull;
import storm.trident.state.StateFactory;
import storm.trident.state.StateType;

import java.util.Calendar;
import java.util.Map;
import java.util.Properties;
import static com.ebay.bis.gro.trident.DealsTopology.TYPE.ALL;
import static com.ebay.bis.gro.trident.DealsTopology.TYPE.valueOf;

public class DealsTopology extends BaseTopology {

	enum TYPE {
		CLICK, TRANS, IMPR, ALL
	}

	;

	private PersistenceManager persistence;
	private Map<String, Object> cassandraConf;
	private Map<String, Object> attributionConf;
	private SpoutCreator spoutCreator;

	private static Fields COUNT = new Fields(BehaviorFields.COUNT);
	private static String TS = "ts";
	private static String TYPE = "type";

	public DealsTopology(String env) {
		super(env);
		init();
	}

	public DealsTopology(String env, String config) {
		super(env, config);
		init();
	}

	private void init() {
		cassandraConf = (Map<String, Object>) getConfig("persistence.cassandra");

		persistence = new PersistenceManager(cassandraConf);

		attributionConf = (Map<String, Object>) getConfig("app.attribution");

		spoutCreator = new SpoutCreator(getConfigString("kafka.zookeeper"), getConfigString("kafka.zkroot"));
	}

	private StateFactory createState(CqlRowMapper mapper) {
		CassandraCqlMapState.Options options = new CassandraCqlMapState.Options();
		options.keyspace = getConfigString("cassandra.keyspace");
		return new CassandraCqlMapStateFactory(mapper, StateType.NON_TRANSACTIONAL, options, ConsistencyLevel.ONE);
	}

	private void transactionStream(TridentTopology topology) {
		transactionStreamMin(topology);
		transactionStreamHD(topology);
	}

	private void transactionStreamHD(TridentTopology topology) {
		Stream stream = topology.newStream(getConfigString("storm.spout.transactional.hd"),
				spoutCreator.createTridentSpout(getConfigString("kafka.topic.output.transactional"),
						getConfigString("storm.kafka.client.transactional.hd")));

		Stream parsedStream = stream.name("t").each(new Fields("str"), new JsonParser(TYPE), new Fields(TYPE));

		String[] names = { TransactionFields.SITE, TransactionFields.TIMESTAMP, TransactionFields.ITEM,
				TransactionFields.GMV, TransactionFields.USER, TransactionFields.QUANTITY };
		Fields fields = new Fields(names);
		Stream transParsedStream = parsedStream.name("t1").each(new Fields(TYPE), new In("trans")) // keep
																									// only
																									// "trans"
																									// type
				.each(new Fields("str"), new JsonParser(names), fields);
				// so far, we get all deals items purchase events

		// step 1.
		StateFactory gmvQtyStateHour = persistence.getState(new String[] { "gmv", "qty" }, false, GmvQtyMapper.class,
				PersistenceManager.FREQ.HOUR);
		StateFactory gmvQtyStateDtlHour = persistence.getState(new String[] { "gmv", "qty" }, true, GmvQtyMapper.class,
				PersistenceManager.FREQ.HOUR);
		StateFactory gmvQtyStateDate = persistence.getState(new String[] { "gmv", "qty" }, false, GmvQtyMapper.class,
				PersistenceManager.FREQ.DAY);
		StateFactory gmvQtyStateDtlDate = persistence.getState(new String[] { "gmv", "qty" }, true, GmvQtyMapper.class,
				PersistenceManager.FREQ.DAY);

		// step1 for hour/date
		transStreamStep1(transParsedStream, Calendar.HOUR, gmvQtyStateHour, "h");
		transStreamStep1(transParsedStream, Calendar.DATE, gmvQtyStateDate, "d");

		String[] names2 = { TransactionFields.SITE, TransactionFields.TIMESTAMP, TransactionFields.ITEM,
				TransactionFields.GMV, TransactionFields.USER, TransactionFields.QUANTITY, BehaviorFields.SOURCE,
				BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE };
		Fields fields2 = new Fields(names2);
		Stream as = parsedStream.name("a").each(new Fields(TYPE), new In("trans_attributed")) // keep
																								// only
																								// "trans_attr"
																								// type
				.each(new Fields("str"), new JsonParser(names2), fields2);

		// step 2
		transStreamStep2(as, Calendar.HOUR, gmvQtyStateHour, gmvQtyStateDtlHour, "h");
		transStreamStep2(as, Calendar.DATE, gmvQtyStateDate, gmvQtyStateDtlDate, "d");
	}

	private void transactionStreamMin(TridentTopology topology) {
		Stream stream = topology.newStream(getConfigString("storm.spout.transactional"),
				spoutCreator.createTridentSpout(getConfigString("kafka.topic.transactional"),
						getConfigString("storm.kafka.client.transactional")));

		String[] names = { TransactionFields.SITE, TransactionFields.TIMESTAMP, TransactionFields.ITEM,
				TransactionFields.GMV, TransactionFields.USER, TransactionFields.QUANTITY };
		Fields fields = new Fields(names);
		Stream parsedStream = stream.name("t").each(new Fields("str"), new TransEventParser(names), fields)
				.each(new Fields(TransactionFields.ITEM), new ItemFilter((Map<String, Object>) getConfig("app.cache")));

		// so far, we get all deals items purchase events

		// step 1.
		StateFactory gmvQtyState = persistence.getState(new String[] { "gmv", "qty" }, false, GmvQtyMapper.class);
		StateFactory gmvQtyStateDtl = persistence.getState(new String[] { "gmv", "qty" }, true, GmvQtyMapper.class);

		// step1 for minute/hour/date
		transStreamStep1(parsedStream, Calendar.MINUTE, gmvQtyState, "m");

		String[] names1 = { TransactionFields.SITE, TransactionFields.TIMESTAMP, TransactionFields.ITEM,
				TransactionFields.GMV, TransactionFields.USER, TransactionFields.QUANTITY, TYPE };
		Stream streamTrans = parsedStream.name("kt").each(new Constant("trans"), new Fields(TYPE));
		populateMsgToKafka(streamTrans, "kafka.topic.output.transactional", "n", names1);

		Stream attributed = parsedStream.name("a")
				.each(new Fields(TransactionFields.ITEM, TransactionFields.USER, TransactionFields.TIMESTAMP),
						new Attribution(attributionConf, cassandraConf), new Fields(BehaviorFields.SOURCE))
				.each(new Fields(BehaviorFields.SOURCE), new SidParser(),
						new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE))
				.each(new Constant("trans_attributed"), new Fields(TYPE));

		String[] names2 = { TransactionFields.SITE, TransactionFields.TIMESTAMP, TransactionFields.ITEM,
				TransactionFields.GMV, TransactionFields.USER, TransactionFields.QUANTITY, BehaviorFields.SOURCE,
				BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE, TYPE };

		populateMsgToKafka(attributed, "kafka.topic.output.transactional", "a", names2);

		// step 2
		transStreamStep2(attributed, Calendar.MINUTE, gmvQtyState, gmvQtyStateDtl, "m");
	}

	/**
	 * step1 of transaction stream, group by item+site+ts, count quantity and
	 * gmv, logged to summary table.
	 *
	 * @param head,
	 *            stream head
	 * @param roundUnit,
	 *            round time unit, could be minute/hour/date
	 * @param state,
	 *            persistent state
	 * @param ns,
	 *            name suffix to avoid bolt duplication
	 */
	private void transStreamStep1(Stream head, int roundUnit, StateFactory state, String ns) {
		Fields sum = new Fields(TransactionFields.SUM);
		Fields gmvQty = new Fields(TransactionFields.GMV, TransactionFields.QUANTITY);

		head.name("s1" + ns)// group by item+site, ts
				.each(new Fields(TransactionFields.TIMESTAMP), new RoundTimestamp(roundUnit), new Fields(TS))
				.groupBy(new Fields(TransactionFields.ITEM, TransactionFields.SITE, TS))
				.persistentAggregate(state, gmvQty, new GmvQtySum(), sum)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
	}

	private void transStreamStep2(Stream head, int roundUnit, StateFactory sumState, StateFactory dtlState, String ns) {
		Fields sum = new Fields(TransactionFields.SUM);
		Fields gmvQty = new Fields(TransactionFields.GMV, TransactionFields.QUANTITY);

		Stream attributedWithTS = head.name("a1" + ns).each(new Fields(TransactionFields.TIMESTAMP),
				new RoundTimestamp(roundUnit), new Fields(TS));

		// step2.2 group by p, ts, count() -- page summary
		attributedWithTS.name("s2" + ns).groupBy(new Fields(BehaviorFields.SOURCE_PAGE, TransactionFields.SITE, TS))
				.persistentAggregate(sumState, gmvQty, new GmvQtySum(), sum)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.3 group by sid, ts, gmv+qty -- module+site summary
		attributedWithTS.name("s3" + ns).groupBy(new Fields(BehaviorFields.SOURCE, TransactionFields.SITE, TS))
				.persistentAggregate(sumState, gmvQty, new GmvQtySum(), sum)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.4 group by p+site ts, itm, gmv+qty -- page+site, item detail ()
		attributedWithTS.name("d1" + ns)
				.groupBy(new Fields(BehaviorFields.SOURCE_PAGE, TransactionFields.SITE, TS, TransactionFields.ITEM))
				.persistentAggregate(dtlState, gmvQty, new GmvQtySum(), sum)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.5 group by sid+site, ts, itm, count() -- module, item detail ()
		attributedWithTS.name("d2" + ns)
				.groupBy(new Fields(BehaviorFields.SOURCE, TransactionFields.SITE, TS, TransactionFields.ITEM))
				.persistentAggregate(dtlState, gmvQty, new GmvQtySum(), sum)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.6 group by itm+site, ts, sid, count() -- item, module detail ()
		attributedWithTS.name("d3" + ns)
				.groupBy(new Fields(TransactionFields.ITEM, TransactionFields.SITE, TS, BehaviorFields.SOURCE))
				.persistentAggregate(dtlState, gmvQty, new GmvQtySum(), sum)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
	}

	private void clickStream(TridentTopology topology) {
		clickStreamMin(topology);
		clickStreamHD(topology);
	}

	private void clickStreamHD(TridentTopology topology) {
		Stream stream = topology.newStream(getConfigString("storm.spout.behavioral.hd"),
				spoutCreator.createTridentSpout(getConfigString("kafka.topic.output.behavioral"),
						getConfigString("storm.kafka.client.behavioral.hd")));

		Stream typedStream = stream.name("t").each(new Fields("str"), new JsonParser(TYPE), new Fields(TYPE));

		viBranchHD(typedStream);
		pvBranchHD(typedStream);
	}

	/**
	 * Get message from output.behavioral topic, keep event with "vi" type,
	 * calcuate hourly and daily data and persist to DB.
	 */
	private void viBranchHD(Stream stream) {
		String[] names = { BehaviorFields.TIMESTAMP, BehaviorFields.SITE, BehaviorFields.PAGE, BehaviorFields.SOURCE,
				BehaviorFields.ITEM, BehaviorFields.GUID, BehaviorFields.USER, BehaviorFields.BEST_USER };
		Fields fields = new Fields(names);
		Stream parsedStream = stream.name("vi").each(new Fields(TYPE), new In("vi")) // keep
																						// only
																						// vi
																						// type
				.parallelismHint(getConfigInt("topology.parallelismHint.parseAndFilter"))
				.each(new Fields("str"), new JsonParser(names), fields);

		String[] dealsPageIds = getConfigString("app.filters.deal").split(",");
		String[] sourcePageIds = new String[dealsPageIds.length];
		for (int i = 0; i < dealsPageIds.length; i++) {
			sourcePageIds[i] = "p" + dealsPageIds[i];
		}

		// so far, we get all deals items vi events
		StateFactory clickSumStateHour = persistence.getState(new String[] { "click" }, false, IntValueMapper.class,
				PersistenceManager.FREQ.HOUR);
		StateFactory clickDtlStateHour = persistence.getState(new String[] { "click" }, true, IntValueMapper.class,
				PersistenceManager.FREQ.HOUR);
		StateFactory clickSumStateDate = persistence.getState(new String[] { "click" }, false, IntValueMapper.class,
				PersistenceManager.FREQ.DAY);
		StateFactory clickDtlStateDate = persistence.getState(new String[] { "click" }, true, IntValueMapper.class,
				PersistenceManager.FREQ.DAY);

		// step 1. group by itm+site, ts, count() -- item+site summary
		itemSiteSummary(parsedStream, Calendar.HOUR, clickSumStateHour, "h"); // minute
		itemSiteSummary(parsedStream, Calendar.DATE, clickSumStateDate, "d"); // minute

		// step2. filter deals pages
		Stream dealsVIStream = parsedStream.name("f2").each(new Fields(BehaviorFields.SOURCE), new FilterNull())
				.each(new Fields(BehaviorFields.SOURCE), new SidParser(),
						new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE))
				.each(new Fields(BehaviorFields.SOURCE_PAGE), new In(sourcePageIds));

		// hourly
		viClickSumDtl(dealsVIStream, Calendar.HOUR, clickSumStateHour, clickDtlStateHour, "h");
		// daily
		viClickSumDtl(dealsVIStream, Calendar.DATE, clickSumStateDate, clickDtlStateDate, "d");
	}

	private void pvBranchHD(Stream stream) {
		String[] names = { BehaviorFields.TIMESTAMP, BehaviorFields.SITE, BehaviorFields.PAGE, "page" };
		Fields fields = new Fields(names);

		Stream parsedStream = stream.name("pv").each(new Fields(TYPE), new In("pv")) // keep
																						// only
																						// pv
																						// type
				.parallelismHint(getConfigInt("topology.parallelismHint.parseAndFilter"))
				.each(new Fields("str"), new JsonParser(names), fields);

		StateFactory pvSumStateHour = persistence.getState(new String[] { "pv" }, false, IntValueMapper.class,
				PersistenceManager.FREQ.HOUR);
		StateFactory pvSumStateDay = persistence.getState(new String[] { "pv" }, false, IntValueMapper.class,
				PersistenceManager.FREQ.DAY);

		// hourly data handling
		pvBranchInternal(parsedStream, Calendar.HOUR, pvSumStateHour, "h");
		// daily data handling
		pvBranchInternal(parsedStream, Calendar.DATE, pvSumStateDay, "d");
	}

	private void clickStreamMin(TridentTopology topology) {
		Stream stream = topology.newStream(getConfigString("storm.spout.behavioral"), spoutCreator.createTridentSpout(
				getConfigString("kafka.topic.behavioral"), getConfigString("storm.kafka.client.behavioral")));

		String[] names = { BehaviorFields.TIMESTAMP, BehaviorFields.SITE, BehaviorFields.PAGE, BehaviorFields.SOURCE,
				BehaviorFields.ITEM, BehaviorFields.GUID, BehaviorFields.USER, BehaviorFields.BEST_USER };
		Fields fields = new Fields(names);
		Stream parsedStream = stream.name("f1").parallelismHint(getConfigInt("topology.parallelismHint.parseAndFilter"))
				.each(new Fields("str"), new JsonParser(names), fields)
				.each(new Fields(BehaviorFields.PAGE, BehaviorFields.SITE), new FilterNull());

		viBranchMin(parsedStream);
		pvBranchMin(parsedStream);
	}

	/**
	 * populate message to the given topic
	 */
	private void populateMsgToKafka(Stream head, String topic, String ns, String... fields) {
		TridentKafkaStateFactory stateFactory = new TridentKafkaStateFactory()
				.withKafkaTopicSelector(new DefaultTopicSelector(getConfigString(topic)))
				.withTridentTupleToKafkaMapper(new KafkaMapper(fields));

		head.name("k" + ns).partitionPersist(stateFactory, new Fields(fields), new TridentKafkaUpdater(), new Fields());
	}

	private void viBranchMin(Stream head) {
		Stream vi = head.name("v")
				.each(new Fields(BehaviorFields.PAGE), new In(getConfigString("app.filters.vi").split(",")))// vi
																											// page
				.each(new Fields(BehaviorFields.ITEM), new FilterNull())// don't
																		// filter
																		// out
																		// sid
																		// is
																		// empty
				.each(new Fields(BehaviorFields.ITEM), new ItemFilter((Map<String, Object>) getConfig("app.cache")))
				.each(new Constant("vi"), new Fields(TYPE));

		String[] dealsPageIds = getConfigString("app.filters.deal").split(",");
		String[] sourcePageIds = new String[dealsPageIds.length];
		for (int i = 0; i < dealsPageIds.length; i++) {
			sourcePageIds[i] = "p" + dealsPageIds[i];
		}

		// so far, we get all deals items vi events
		StateFactory clickSumState = persistence.getState(new String[] { "click" }, false, IntValueMapper.class);
		StateFactory clickDtlState = persistence.getState(new String[] { "click" }, true, IntValueMapper.class);

		populateMsgToKafka(vi, "kafka.topic.output.behavioral", "vi", TYPE, BehaviorFields.PAGE, BehaviorFields.GUID,
				BehaviorFields.USER, BehaviorFields.BEST_USER, BehaviorFields.TIMESTAMP, BehaviorFields.SITE,
				BehaviorFields.SOURCE, BehaviorFields.ITEM);

		// step 1. group by itm+site, ts, count() -- item+site summary
		itemSiteSummary(vi, Calendar.MINUTE, clickSumState, "m"); // minute

		// step2. filter deals pages
		Stream dealsVIStream = vi.name("f2").each(new Fields(BehaviorFields.SOURCE), new FilterNull())
				.each(new Fields(BehaviorFields.SOURCE), new SidParser(),
						new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE))
				.each(new Fields(BehaviorFields.SOURCE_PAGE), new In(sourcePageIds));

		// step2.1
		// a. VI with uid: uid,itm,ts,sid, b. VI w/o uid: guid,ts,itm,sid
		dealsVIStream.name("i")
				.each(new Fields(BehaviorFields.TIMESTAMP, BehaviorFields.ITEM, BehaviorFields.USER,
						BehaviorFields.BEST_USER, BehaviorFields.GUID, BehaviorFields.SOURCE),
				new Contribution(attributionConf, cassandraConf));

		// minutely
		viClickSumDtl(dealsVIStream, Calendar.MINUTE, clickSumState, clickDtlState, "m");
	}

	/**
	 * Group by item+site, ts, calculate count
	 * 
	 * @param head
	 * @param roundUnit,
	 *            time unit to rount, MINUTE/HOUR/DATE
	 * @param state,
	 *            state to persist count
	 * @param nameSuffix,
	 *            flow name suffix to avoid duplication.
	 */
	private void itemSiteSummary(Stream head, int roundUnit, StateFactory state, String nameSuffix) {
		head.name("s1" + nameSuffix)
				.each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(roundUnit), new Fields(TS))
				.groupBy(new Fields(BehaviorFields.ITEM, BehaviorFields.SITE, TS))
				.persistentAggregate(state, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp") * 2);// heavier
																							// than
																							// others
	}

	/**
	 *
	 * @param head
	 *            - dealVIStream, filtered by common conditions, without TS
	 *            populated.
	 * @param roundUnit
	 *            - rount unit, could be minute/hour/date
	 * @param sumState
	 *            - for sum persistence
	 * @param dtlState
	 *            - for detail persistence
	 * @param ns
	 *            - flow name suffix to avoid duplication.
	 */
	private void viClickSumDtl(Stream head, int roundUnit, StateFactory sumState, StateFactory dtlState, String ns) {
		Stream dealsVIStreamTS = head.name("f3").each(new Fields(BehaviorFields.TIMESTAMP),
				new RoundTimestamp(roundUnit), new Fields(TS));
		// step2.2 group by p+site, ts, count() -- page+site summary
		dealsVIStreamTS.name("s2" + ns).groupBy(new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SITE, TS))
				.persistentAggregate(sumState, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
		//
		// // step2.3 group by sid+site, ts, count() -- source+site summary
		dealsVIStreamTS.name("s3" + ns).groupBy(new Fields(BehaviorFields.SOURCE, BehaviorFields.SITE, TS))
				.persistentAggregate(sumState, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.4 group by p+site, ts, itm, count() -- page+site, item detail
		// ()
		dealsVIStreamTS.name("d1" + ns)
				.groupBy(new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SITE, TS, BehaviorFields.ITEM))
				.persistentAggregate(dtlState, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.5 group by sid + site, ts, itm, count() -- module, item detail
		// ()
		dealsVIStreamTS.name("d2" + ns)
				.groupBy(new Fields(BehaviorFields.SOURCE, BehaviorFields.SITE, TS, BehaviorFields.ITEM))
				.persistentAggregate(dtlState, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

		// step2.6 group by itm + site, ts, sid, count() -- item, module detail
		// ()
		dealsVIStreamTS.name("d3" + ns)
				.groupBy(new Fields(BehaviorFields.ITEM, BehaviorFields.SITE, TS, BehaviorFields.SOURCE))
				.persistentAggregate(dtlState, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
	}

	private void pvBranchMin(Stream head) {
		Stream deal = head.name("d").each(new Fields(BehaviorFields.PAGE),
				new In(getConfigString("app.filters.deal").split(",")));// deal
																		// pages

		StateFactory pvSumStateDefault = persistence.getState(new String[] { "pv" }, false, IntValueMapper.class,
				PersistenceManager.FREQ.DEFAULT);
				// StateFactory pvSumStateHour = persistence.getState(new
				// String[]{"pv"}, false, IntValueMapper.class,
				// PersistenceManager.FREQ.HOUR);
				// StateFactory pvSumStateDay = persistence.getState(new
				// String[]{"pv"}, false, IntValueMapper.class,
				// PersistenceManager.FREQ.DAY);

		/*
		 * deal.name("p") .each(new Fields(BehaviorFields.TIMESTAMP), new
		 * RoundTimestamp(Calendar.MINUTE), new Fields(TS)) .each(new
		 * Fields(BehaviorFields.PAGE), new Prefix("p"), new Fields("page"))
		 * .groupBy(new Fields("page", BehaviorFields.SITE, TS))
		 * .persistentAggregate(pvSumState, new Count(), COUNT)
		 * .parallelismHint((Integer)
		 * getConfig("topology.parallelismHint.grp"));
		 */
		Stream deal_p = deal.name("p").each(new Fields(BehaviorFields.PAGE), new Prefix("p"), new Fields("page"))
				.each(new Constant("pv"), new Fields(TYPE));

		populateMsgToKafka(deal_p, "kafka.topic.output.behavioral", "pv", TYPE, BehaviorFields.TIMESTAMP,
				BehaviorFields.SITE, BehaviorFields.PAGE, "page");

		// default one (minute)
		pvBranchInternal(deal_p, Calendar.MINUTE, pvSumStateDefault, "m");
		// hourly data handling
		// pvBranchInternal(deal_p, Calendar.HOUR, pvSumStateHour, "h");
		// daily data handling
		// pvBranchInternal(deal_p, Calendar.DATE, pvSumStateDay, "d");

		// TODO: report itm tracking missing...
		// deal.name("mi")
		// .each(new Fields(BehaviorFields.MI), new FilterNull());

		// .each(new Fields(BehaviorFields.PGI, BehaviorFields.MI), new
		// FilterNull())
		// .each(new Fields(BehaviorFields.PGI, BehaviorFields.MI), new
		// UrlDecoder(), new Fields("decoded_pgi", "decoded_mi"))
		// .project(new Fields(BehaviorFields.USER_COUNTRY,
		// BehaviorFields.TIMESTAMP, BehaviorFields.SITE, "ts", "decoded_pgi",
		// "decoded_mi"))
		// .each(new Fields("decoded_pgi"), new PgiParser(), new Fields("eg_id",
		// "eid"))
		// .each(new Fields("eid"), new FilterNull());
	}

	private void pvBranchInternal(Stream head, int roundUnit, StateFactory state, String ns) {
		head.name("p" + ns).each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(roundUnit), new Fields(TS))
				.groupBy(new Fields("page", BehaviorFields.SITE, TS)).persistentAggregate(state, new Count(), COUNT)
				.parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
	}

	public StormTopology build() {
		return this.build(ALL);
	}

	StormTopology build(TYPE type) {
		TridentTopology topology = new TridentTopology();
		switch (type) {
		case CLICK:
			clickStream(topology);
			break;
		case TRANS:
			transactionStream(topology);
			break;
		// case IMPR:
		// imprStream(topology);
		// break;
		default:
			clickStream(topology);
			transactionStream(topology);
			// imprStream(topology);
		}
		return topology.build();
	}

	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException {
		String env = "dev";

		if (args != null && args.length >= 2) {
			env = args[0];
		}
		Config conf = new Config();
		Properties props = new Properties();

		props.put("request.required.acks", "0");
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("compression.codec", "snappy");
		props.put("producer.type", "async");
		props.put("message.send.max.retries", "2");
		props.put("retry.backoff.ms", "100");
		props.put("topic.metadata.refresh.interval.ms", "600000");
		props.put("queue.buffering.max.ms", "1000");
		props.put("queue.buffering.max.messages", "200000");
		props.put("queue.enqueue.timeout.ms", "0");
		props.put("batch.num.messages", "500");
		props.put("send.buffer.bytes", "4194304");
		props.put("request.timeout.ms", "5000");

		if ("dev".equals(env)) {
			LocalCluster cluster = new LocalCluster();
			DealsTopology topology = new DealsTopology("dev");

			props.put("metadata.broker.list", topology.getConfigString("kafka.broker.list"));
			conf.put(TridentKafkaState.KAFKA_BROKER_PROPERTIES, props);
			conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, topology.getConfigString("cassandra.hosts"));
			cluster.submitTopology(topology.getName(), conf, topology.build());
		} else {
			if (args.length != 4) {
				System.err.println("Usage: <env> <num_of_workers> <click|trans> <config file>");
				return;
			}
			DealsTopology topology = new DealsTopology(env, args[3]);
			props.put("metadata.broker.list", topology.getConfigString("kafka.broker.list"));
			conf.put(TridentKafkaState.KAFKA_BROKER_PROPERTIES, props);

			conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, topology.getConfigString("cassandra.hosts"));
			conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_USERNAME,
					topology.getConfigString("cassandra.username"));
			conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_PASSWORD,
					topology.getConfigString("cassandra.password"));
			conf.setNumWorkers(Integer.valueOf(args[1]));

			StormSubmitter.submitTopology(topology.getName() + args[2], conf,
					topology.build(valueOf(args[2].toUpperCase())));
		}

	}

}
