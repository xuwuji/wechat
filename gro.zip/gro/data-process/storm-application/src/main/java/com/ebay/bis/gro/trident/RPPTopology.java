package com.ebay.bis.gro.trident;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.generated.StormTopology;
import backtype.storm.tuple.Fields;

import com.ebay.bis.gro.kafka.OutFields;
import com.ebay.bis.gro.trident.operation.EventGroup;
import com.ebay.dss.bpe.BaseTopology;
import com.ebay.dss.bpe.BehaviorFields;
import com.ebay.dss.bpe.TransactionFields;
import com.ebay.dss.bpe.attribution.GmvQtyMapper;
import com.ebay.dss.bpe.attribution.GmvQtySum;
import com.ebay.dss.bpe.cassandra.IntValueMapper;
import com.ebay.dss.bpe.cassandra.PersistenceManager;
import com.ebay.dss.bpe.kafka.KafkaMapper;
import com.ebay.dss.bpe.kafka.SpoutCreator;
import com.ebay.dss.bpe.trident.operation.*;
import com.hmsonline.trident.cql.CassandraCqlStateFactory;
import storm.kafka.trident.TridentKafkaState;
import storm.kafka.trident.TridentKafkaStateFactory;
import storm.kafka.trident.TridentKafkaUpdater;
import storm.kafka.trident.selector.DefaultTopicSelector;
import storm.trident.Stream;
import storm.trident.TridentTopology;
import storm.trident.fluent.GroupedStream;
import storm.trident.operation.builtin.FilterNull;
import storm.trident.state.StateFactory;

import java.util.Calendar;
import java.util.Map;
import java.util.Properties;

/**
 * Created by bishao on 1/27/15.
 */
public class RPPTopology extends BaseTopology {

    final static Fields COUNT = new Fields(BehaviorFields.COUNT);

    private PersistenceManager persistence;
    
    private Map<String, Object> cassandraConf;
    private Map<String, Object> attributionConf;

    private SpoutCreator spoutCreator;
    
    private static final String HOUR = "ts";
    private static final String DAY = "dt";
    private static final Fields EVENTGROUP = new Fields("egid");
    private static final Fields EVENT = new Fields("eid");

    private StateFactory gmvState, gmvDetailState, clickState, clickDetailState, pvState,
            gmvStateDly, gmvDetailStateDly, clickStateDly,clickDetailStateDly, pvStateDly;
    
    public RPPTopology(String env) {
        super(env);
        init();
    }
    
    public RPPTopology(String env, String config) {
        super(env, config);
        init();
        gmvState = persistence.getState(new String[]{"gmv", "qty"}, false, GmvQtyMapper.class);
        gmvDetailState = persistence.getState(new String[]{"gmv", "qty"}, true, GmvQtyMapper.class);

        gmvStateDly = persistence.getState(new String[]{"gmv", "qty"}, false, GmvQtyMapper.class, PersistenceManager.FREQ.DAY);
        gmvDetailStateDly = persistence.getState(new String[]{"gmv", "qty"}, true, GmvQtyMapper.class, PersistenceManager.FREQ.DAY);

        clickState = persistence.getState(new String[]{"click"}, false, IntValueMapper.class);
        clickDetailState = persistence.getState(new String[]{"click"}, true, IntValueMapper.class);

        clickStateDly = persistence.getState(new String[]{"click"}, false, IntValueMapper.class, PersistenceManager.FREQ.DAY);
        clickDetailStateDly = persistence.getState(new String[]{"click"}, true, IntValueMapper.class, PersistenceManager.FREQ.DAY);

        pvState = persistence.getState(new String[]{"pv"}, false, IntValueMapper.class);
        
        pvStateDly = persistence.getState(new String[]{"pv"}, false, IntValueMapper.class, PersistenceManager.FREQ.DAY);
    }
    
    private void init() {
        cassandraConf = (Map<String, Object>)getConfig("persistence.cassandra");
        persistence = new PersistenceManager(cassandraConf);

        attributionConf = (Map<String, Object>)getConfig("app.attribution");

        spoutCreator = new SpoutCreator(getConfigString("kafka.zookeeper"), getConfigString("kafka.zkroot"));
    }

    @Override
    public StormTopology build() {
        return build(true, true, true);
    }

    StormTopology build(boolean click, boolean trans, boolean substream) {
        TridentTopology topology = new TridentTopology();
        if (click) {
            clickStream(topology);
        }
        if (trans) {
            transactionStream(topology);
        }
        if (substream) {
            subStream(topology);
        }
        

        return topology.build();
    }
    
    
    void transactionStream(TridentTopology topology) {
        Stream transStream = topology.newStream(getConfigString("storm.spout.transactional"),
                spoutCreator.createTridentSpout(getConfigString("kafka.topic.transactional"), getConfigString("storm.kafka.client.transactional"), true));

        String[] names = {TransactionFields.TIMESTAMP, TransactionFields.ITEM, TransactionFields.GMV, TransactionFields.USER, 
                TransactionFields.QUANTITY, TransactionFields.BYR_CNTRY};
        Fields fields = new Fields(names);
        Stream parsedStream = transStream.name("t")
                .each(new Fields("str"), new TransEventParser(names), fields)
                .each(new Fields(TransactionFields.ITEM), new ItemFilter((Map<String, Object>) getConfig("app.cache")))
                .each(new Fields(TransactionFields.TIMESTAMP), new RoundTimestamp(Calendar.HOUR), new Fields(HOUR))
                .each(new Fields(TransactionFields.TIMESTAMP), new RoundTimestamp(Calendar.DATE), new Fields(DAY));

        Fields sum = new Fields(TransactionFields.SUM);
        Fields gmvQty = new Fields(TransactionFields.GMV, TransactionFields.QUANTITY);

        // step 1.
        GroupedStream itmGrpStream = parsedStream.name("s1")
                .groupBy(new Fields(TransactionFields.ITEM, HOUR));
        itmGrpStream.persistentAggregate(gmvState, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        Stream attributed = parsedStream.name("a")
                .each(new Fields(TransactionFields.ITEM, TransactionFields.USER, TransactionFields.TIMESTAMP),
                        new Attribution(attributionConf, cassandraConf), EVENT)
                .each(EVENT, new Not(new In("")))
                .each(EVENT, new EventGroup((Map<String, Object>) getConfig("app.cache.event")), EVENTGROUP);

        GroupedStream evtStream = attributed.name("s2")
                .groupBy(new Fields("eid", HOUR));
        evtStream.persistentAggregate(gmvState, gmvQty, new GmvQtySum(), sum);
//                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        attributed.name("s2d")
                .groupBy(new Fields("eid", DAY))
                .persistentAggregate(gmvStateDly, gmvQty, new GmvQtySum(), sum);

        GroupedStream dtlStream = attributed.name("d1")
                .groupBy(new Fields("eid", HOUR, TransactionFields.ITEM));
        dtlStream.persistentAggregate(gmvDetailState, gmvQty, new GmvQtySum(), sum);
//                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        GroupedStream dtlStream2 = attributed.name("d2")
                .groupBy(new Fields(TransactionFields.ITEM, HOUR, "eid"));
        dtlStream2.persistentAggregate(gmvDetailState, gmvQty, new GmvQtySum(), sum);
//                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));


        Stream evtGrpStream = attributed.name("s3")
                .each(EVENTGROUP, new FilterNull());
        evtGrpStream.name("g")
                .groupBy(new Fields("egid", HOUR))
                .persistentAggregate(gmvState, gmvQty, new GmvQtySum(), sum);

        evtGrpStream.name("gb")
                .groupBy(new Fields("egid", TransactionFields.BYR_CNTRY, HOUR))
                .persistentAggregate(gmvState, gmvQty, new GmvQtySum(), sum);
//                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        Stream evtGrpDtlStream = attributed.name("d3")
                .each(EVENTGROUP, new FilterNull());
        evtGrpDtlStream.name("g")
                .groupBy(new Fields("egid", HOUR, TransactionFields.ITEM))
                .persistentAggregate(gmvDetailState, gmvQty, new GmvQtySum(), sum);

        evtGrpDtlStream.name("gb")
                .groupBy(new Fields("egid", TransactionFields.BYR_CNTRY, HOUR, TransactionFields.ITEM))
                .persistentAggregate(gmvDetailState, gmvQty, new GmvQtySum(), sum);

        GroupedStream evtbyrCntryStream = attributed.name("s4")
                .groupBy(new Fields("eid",TransactionFields.BYR_CNTRY, HOUR));
        evtbyrCntryStream.persistentAggregate(gmvState, gmvQty, new GmvQtySum(), sum);
//                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        GroupedStream evtbyrCntryDtlStream = attributed.name("d4")
                .groupBy(new Fields("eid", TransactionFields.BYR_CNTRY, HOUR, TransactionFields.ITEM));
        evtbyrCntryDtlStream.persistentAggregate(gmvDetailState, gmvQty, new GmvQtySum(), sum);
//                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
        
    }
    
    void clickStream(TridentTopology topology) {
        Stream behavioralStream = topology.newStream(getConfigString("storm.spout.behavioral"),
                spoutCreator.createTridentSpout(getConfigString("kafka.topic.behavioral"), getConfigString("storm.kafka.client.behavioral"), true));

        String[] names = {BehaviorFields.TIMESTAMP, BehaviorFields.PGI, BehaviorFields.MI, BehaviorFields.TRKP, 
                BehaviorFields.SITE, BehaviorFields.PAGE, BehaviorFields.SOURCE, BehaviorFields.ITEM, BehaviorFields.GUID, 
                BehaviorFields.USER, BehaviorFields.BEST_USER, BehaviorFields.USER_COUNTRY};
        Fields fields = new Fields(names);

        Stream head = behavioralStream.name("p")//parsing,
                .parallelismHint((Integer) getConfig("topology.parallelismHint.parseAndFilter"))
                .each(new Fields("str"), new JsonParser(names), fields);

        rppBranch(head);// calculate event click & item impression from pgi & mi on event page

        viBranch(head);
    }
    
    void viBranch(Stream stream) {
        //calculate item click, attribute to event from trkp
        Stream vi = stream.name("vi")
                .each(new Fields(BehaviorFields.PAGE), new In(getConfigString("app.filters.vi").split(",")))//vi page
                .each(new Fields(BehaviorFields.ITEM), new FilterNull())
                .each(new Fields(BehaviorFields.ITEM), new ItemFilter((Map<String, Object>) getConfig("app.cache")))
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.HOUR), new Fields(HOUR))
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.DATE), new Fields(DAY));

        
        vi.name("ic")
                .groupBy(new Fields(BehaviorFields.ITEM, HOUR))
                .persistentAggregate(clickState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp") * 2);//heavier than others

        String[] rppPageIds = getConfigString("app.filters.rpp").split(",");
        String[] sourcePageIds = new String[rppPageIds.length];
        for (int i = 0; i < rppPageIds.length; i++) {
            sourcePageIds[i] = "p" + rppPageIds[i];
        }
        
        Stream rppVI = vi.name("r")
                .each(new Fields(BehaviorFields.SOURCE), new SidParser(), new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE))
                .each(new Fields(BehaviorFields.SOURCE_PAGE), new In(sourcePageIds))
                .each(new Fields(BehaviorFields.TRKP), new FilterNull())
                .each(new Fields(BehaviorFields.TRKP), new UrlDecoder(), new Fields("decoded_trkp"))
                .each(new Fields("decoded_trkp"), new TrkpParser("rpp_cid"), EVENT)
                .each(EVENT, new FilterNull());//rpp_cid could be missing

        rppVI.name("a")//attribution
                .each(new Fields(BehaviorFields.TIMESTAMP, BehaviorFields.ITEM, BehaviorFields.USER, BehaviorFields.BEST_USER, BehaviorFields.GUID, "eid"),
                        new Contribution(attributionConf, cassandraConf));

        rppVI.name("ec").groupBy(new Fields("eid", HOUR))//agg click to event level
                .persistentAggregate(clickState, new Count(), COUNT);


        rppVI.name("ecd").groupBy(new Fields("eid", DAY))//agg click to event level
                .persistentAggregate(clickStateDly, new Count(), COUNT);
        

        rppVI.name("iec").groupBy(new Fields(BehaviorFields.ITEM, HOUR, "eid"))
                .persistentAggregate(clickDetailState, new Count(), COUNT);
        rppVI.name("eic").groupBy(new Fields("eid", HOUR, BehaviorFields.ITEM))
                .persistentAggregate(clickDetailState, new Count(), COUNT);

        rppVI.name("eicd").groupBy(new Fields("eid", DAY, BehaviorFields.ITEM))
                .persistentAggregate(clickDetailStateDly, new Count(), COUNT);


        //event, buyer cntry
        rppVI.name("ebc").groupBy(new Fields("eid", BehaviorFields.USER_COUNTRY, HOUR))
                .persistentAggregate(clickState, new Count(), COUNT);
        
        //event, buyer cntry, item
        rppVI.name("ebic").groupBy(new Fields("eid", BehaviorFields.USER_COUNTRY, HOUR, BehaviorFields.ITEM))
                .persistentAggregate(clickDetailState, new Count(), COUNT);

        Stream evtGrp = rppVI.name("eg")
                .each(EVENT, new EventGroup((Map<String, Object>) getConfig("app.cache.event")), EVENTGROUP)
                .each(EVENTGROUP, new FilterNull());

        evtGrp.name("g").groupBy(new Fields("egid", HOUR))//agg click to event group level
                .persistentAggregate(clickState, new Count(), COUNT);

        evtGrp.name("gi").groupBy(new Fields("egid", HOUR, BehaviorFields.ITEM))
                .persistentAggregate(clickDetailState, new Count(), COUNT);

        evtGrp.name("gb").groupBy(new Fields("egid", BehaviorFields.USER_COUNTRY, HOUR))//agg click to event group level
                .persistentAggregate(clickState, new Count(), COUNT);

        evtGrp.name("gbi").groupBy(new Fields("egid", BehaviorFields.USER_COUNTRY, HOUR, BehaviorFields.ITEM))
                .persistentAggregate(clickDetailState, new Count(), COUNT);
        
    }

    void rppBranch(Stream stream) {
        Stream rpp = stream.name("rpp")//event page
                .each(new Fields(BehaviorFields.PAGE), new In(getConfigString("app.filters.rpp").split(",")))//rpp page
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.HOUR), new Fields(HOUR))
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.DATE), new Fields(DAY))
                .each(new Fields(BehaviorFields.PGI, BehaviorFields.MI), new FilterNull())
                .each(new Fields(BehaviorFields.PGI, BehaviorFields.MI), new UrlDecoder(), new Fields("decoded_pgi", "decoded_mi"))
                .project(new Fields(BehaviorFields.USER_COUNTRY, BehaviorFields.TIMESTAMP, BehaviorFields.SITE, HOUR, DAY, "decoded_pgi", "decoded_mi"))
                .each(new Fields("decoded_pgi"), new PgiParser(), new Fields("eg_id", "eid"))
                .each(EVENT, new FilterNull());
        //event impression
        Fields ets = new Fields("eid", HOUR);
        rpp.name("pv")
                .project(ets).groupBy(ets)
                .persistentAggregate(pvState, new Count(), COUNT);

        rpp.name("pvd")
                .groupBy(new Fields("eid", DAY))
                .persistentAggregate(pvStateDly, new Count(), COUNT);

        rpp.name("bpv")
                .groupBy(new Fields("eid", BehaviorFields.USER_COUNTRY, HOUR))
                .persistentAggregate(pvState, new Count(), COUNT);


        Stream evtGrp = rpp.name("g")//pv at event group level summary
                .each(EVENT, new EventGroup((Map<String, Object>) getConfig("app.cache.event")), EVENTGROUP)
                .each(EVENTGROUP, new FilterNull());

        evtGrp.name("gp").groupBy(new Fields("egid", HOUR))
                .persistentAggregate(pvState, new Count(), COUNT);

        evtGrp.name("gbp").groupBy(new Fields("egid", BehaviorFields.USER_COUNTRY, HOUR))
                .persistentAggregate(pvState, new Count(), COUNT);


        TridentKafkaStateFactory stateFactory = new TridentKafkaStateFactory()
                .withKafkaTopicSelector(new DefaultTopicSelector(getConfigString("kafka.topic.output")))
                .withTridentTupleToKafkaMapper(
                        new KafkaMapper(OutFields.TIMESTAMP, OutFields.SITE, OutFields.EVENT, OutFields.ITEM, OutFields.IMPR));

        rpp.name("ii")
                .each(new Fields("decoded_mi"), new MiItemExtractor(), new Fields("itm"))
                .project(new Fields(BehaviorFields.TIMESTAMP, BehaviorFields.SITE, BehaviorFields.ITEM, "eid"))
                .each(new One(), new Fields(OutFields.IMPR))
                .partitionPersist(stateFactory, new Fields(BehaviorFields.TIMESTAMP, BehaviorFields.SITE, "eid", BehaviorFields.ITEM, OutFields.IMPR), new TridentKafkaUpdater(), new Fields());
    }
    
    //impression
    void subStream(TridentTopology topology) {
        Stream subStream = topology.newStream(getConfigString("storm.spout.substream"),
                spoutCreator.createTridentSpout(getConfigString("kafka.topic.output"), getConfigString("storm.kafka.client.substream"), true));

        String[] names = {OutFields.TIMESTAMP, OutFields.ITEM};
        Fields fields = new Fields(names);

        Fields its = new Fields("itm", HOUR);
        subStream.name("parse")
                .each(new Fields("str"), new JsonParser(names), fields)
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.HOUR), new Fields(HOUR))
                .parallelismHint(3)
                .partitionBy(its)
                .groupBy(its)
                .name("persist")
                .persistentAggregate(persistence.getState("impr", false), new Count(), COUNT)
                .parallelismHint(9);
    }


    public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException {
        String env = "dev";
        if (args != null && args.length >= 2) {
            env = args[0];
        }
        RPPTopology topology;

        Config conf = new Config();
        //cassandra cql state factory needs this config at runtime!!!
       
        Properties props = new Properties();
        
        props.put("request.required.acks", "0");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("compression.codec", "snappy");
        props.put("producer.type", "async");
        props.put("message.send.max.retries", "2");
        props.put("retry.backoff.ms", "100");
        props.put("topic.metadata.refresh.interval.ms", "600000");
        props.put("queue.buffering.max.ms", "1000");
        props.put("queue.buffering.max.messages", "200000");
        props.put("queue.enqueue.timeout.ms", "0");
        props.put("batch.num.messages", "500");
        props.put("send.buffer.bytes", "4194304");
        props.put("request.timeout.ms", "5000");
        
        
        if ("dev".equals(env)) {
            LocalCluster cluster = new LocalCluster();
            topology = new RPPTopology(env);
            props.put("metadata.broker.list", topology.getConfigString("kafka.broker.list"));
            conf.put(TridentKafkaState.KAFKA_BROKER_PROPERTIES, props);
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, topology.getConfigString("cassandra.hosts"));
            cluster.submitTopology(topology.getName(), conf, topology.build());
        } else {
            if (args.length != 4) {
                System.err.println("Usage: <env> <num_of_workers> <click|trans|impr> <config file>");
                return;
            }
            
            topology = new RPPTopology(env, args[3]);
            
            props.put("metadata.broker.list", topology.getConfigString("kafka.broker.list"));
            conf.put(TridentKafkaState.KAFKA_BROKER_PROPERTIES, props);
            
            conf.setNumWorkers(Integer.valueOf(args[1]));
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, topology.getConfigString("cassandra.hosts"));
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_USERNAME, topology.getConfigString("cassandra.username"));
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_PASSWORD, topology.getConfigString("cassandra.password"));

            if ("click".equals(args[2])) {
                StormSubmitter.submitTopology(topology.getName() + "-click", conf, topology.build(true, false, false));
            } else if ("trans".equals(args[2])) {
                StormSubmitter.submitTopology(topology.getName() + "-trans", conf, topology.build(false, true, false));
            } else if ("impr".equals(args[2])) {
                StormSubmitter.submitTopology(topology.getName() + "-impr", conf, topology.build(false, false, true));
            }

        }

    }
}
