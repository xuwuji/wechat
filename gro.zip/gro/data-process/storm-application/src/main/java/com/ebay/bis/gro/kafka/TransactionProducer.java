package com.ebay.bis.gro.kafka;

import com.ebay.dss.bpe.TransactionFields;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by bishao on 2/13/15.
 *
 *
 * totalAmount=112.77|itemId=290010142355|userId=1279867537|sellerId=1252068229|buyerId=1279867537|m_transactionId=8851454019|useTransactionId=true|transactionSiteID=77|listingSiteID=77|gmv=111.38|transQuantity=1|transFlags=213010|sellercntry=77|productId=0|categoryOne=171275|categoryTwo=0|quantity=1|createdDT=2015-02-13 17:12:45|transactionType=9|transactionId=8851454019|lstgStartDt=2015-02-13 17:12:37|lstgEndDt=2015-02-13 17:12:46|lstgTypeCd=9|buyerCntry=77|shpngAmt=1.00|shpngMthdId=1|ckAppId=182|lstgVrtnId=0|expdtdShpngYNInd=N|gmvLstgAmt=80.00
 * totalAmount=6.53|itemId=270004752017|userId=1257388072|sellerId=1257387908|buyerId=1257388072|m_transactionId=8512690017|useTransactionId=true|transactionSiteID=15|listingSiteID=15|gmv=4.67|transQuantity=1|transFlags=69353498|sellercntry=15|productId=0|categoryOne=12|categoryTwo=0|quantity=1|createdDT=2015-02-13 17:13:28|transactionType=9|transactionId=8512690017|lstgStartDt=2015-02-13 17:08:57|lstgEndDt=2015-02-13 17:13:28|lstgTypeCd=9|buyerCntry=15|shpngAmt=2.00|shpngMthdId=1|ckAppId=32516|lstgVrtnId=0|expdtdShpngYNInd=N|gmvLstgAmt=5.00

 */
public class TransactionProducer {
    public static void main(String[] args) throws InterruptedException {
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        DecimalFormat df = new DecimalFormat("##.00");

        Properties props = new Properties();
        props.put("metadata.broker.list", "localhost:9092");
        props.put("zk.connect", "localhost:2181");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("request.required.acks", "1");

        String TOPIC = "transaction.new";
        ProducerConfig config = new ProducerConfig(props);

        Producer<String, String> producer = new Producer<String, String>(config);

        int evtCnt = 10000;
        String[] items = {"110007826928", "110007826929","110007826930", "110007826931"
//                , "123456789"
        };

        String[] sites = {"0"
//                , "1"
        };

        String[] users = {"1279867537", "1257388072"};

        Random random = new Random();
        Map<String, Object> event = new HashMap<String, Object>();
        for (int i = 0; i < evtCnt; i ++) {
            event.put(TransactionFields.GMV, df.format(random.nextInt(100) + random.nextDouble()));
            event.put(TransactionFields.QUANTITY, random.nextInt(3));
            event.put(TransactionFields.ITEM, items[random.nextInt(items.length)]);
            event.put(TransactionFields.TIMESTAMP, sdf.format(new Date()));
            event.put(TransactionFields.USER, users[random.nextInt(users.length)]);
            event.put(TransactionFields.SITE, sites[random.nextInt(sites.length)]);
            KeyedMessage<String, String> msg = new KeyedMessage<String, String>(TOPIC, mapToString(event));
            producer.send(msg);
            System.out.println(event);
            Thread.sleep(10000);
        }
        producer.close();

    }

    private static String mapToString(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (sb.length() > 0) {
                sb.append("|");
            }
            sb.append(entry.getKey()).append("=").append(entry.getValue());
        }
        return sb.toString();

    }
}
