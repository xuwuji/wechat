package com.ebay.bis.gro.it.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.joda.time.DateTime;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ebay.dss.bpe.BehaviorFields;

import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public abstract class EventKafkaMessageProducer {

	private static final Logger LOG = LoggerFactory.getLogger(EventKafkaMessageProducer.class);

	protected static final String TOPIC = "behavioral.event";

	protected final ProducerConfig producerConfig;
	protected final DateTime baseTime;

	public EventKafkaMessageProducer(DateTime baseTime, String kafkaBrokersString, String zkString) {
		Properties props = new Properties();
		props.put("metadata.broker.list", kafkaBrokersString);
		props.put("zk.connect", zkString);
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("request.required.acks", "1");
		this.producerConfig = new ProducerConfig(props);

		this.baseTime = baseTime;
	}

	protected KeyedMessage<String, String> createKafkaMessage(String siteId, String pageId, String sid, String itemId, String guid, String userId, String bestUserId, long timestamp) {
		Map<String, Object> event = new HashMap<String, Object>();
		event.put(BehaviorFields.SITE, siteId);
		event.put(BehaviorFields.PAGE, pageId);
		event.put(BehaviorFields.SOURCE, sid);
		event.put(BehaviorFields.ITEM, itemId);
		event.put(BehaviorFields.GUID, guid);
		if (userId != null && !("").equals(userId)) {
			event.put(BehaviorFields.USER, userId);
		}
		if (bestUserId != null && !("").equals(bestUserId)) {
			event.put(BehaviorFields.BEST_USER, bestUserId);
		}
		event.put(BehaviorFields.TIMESTAMP, timestamp);
		LOG.info(event.toString());
		KeyedMessage<String, String> msg = new KeyedMessage<String, String>(TOPIC, JSONValue.toJSONString(event));
		return msg;
	}

	abstract public void produceData() throws Exception;
}
