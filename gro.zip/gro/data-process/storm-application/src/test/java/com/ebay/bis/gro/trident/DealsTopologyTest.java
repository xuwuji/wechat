package com.ebay.bis.gro.trident;

import java.io.File;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.exec.util.StringUtils;
import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ebay.bis.gro.it.utils.CassandraClient;
import com.ebay.bis.gro.it.utils.Clusters;
import com.ebay.bis.gro.it.utils.DealsPvEventKafkaMessageProducer;
import com.ebay.bis.gro.it.utils.KafkaTestConsumer;
import com.ebay.bis.gro.it.utils.TransactionKafkaMessageProducer;
import com.ebay.bis.gro.it.utils.VIEventKafkaMessageProducer;
import com.ebay.bis.gro.utils.FileUtil;
import com.esotericsoftware.minlog.Log;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

public class DealsTopologyTest {

	Clusters testClusters = new Clusters();

	private void prepareKafkaSourceData(DateTime baseTime) throws Exception {
		// pv event 2 min ago
		DealsPvEventKafkaMessageProducer dealsPvProducer = new DealsPvEventKafkaMessageProducer(baseTime.plusMinutes(-2), testClusters.getKafkaBrokersConnectionString(),
				testClusters.getZooKeeperConnectionString());

		// vi event 1 min ago
		VIEventKafkaMessageProducer viEventProducer = new VIEventKafkaMessageProducer(baseTime.plusMinutes(-1), testClusters.getKafkaBrokersConnectionString(),
				testClusters.getZooKeeperConnectionString());

		// transaction happen
		TransactionKafkaMessageProducer traxProduer = new TransactionKafkaMessageProducer(baseTime, testClusters.getKafkaBrokersConnectionString(), testClusters.getZooKeeperConnectionString());

		dealsPvProducer.produceData();
		viEventProducer.produceData();
		traxProduer.produceData();
	}

	private void prepareCassandraSchema() throws Exception {
		CassandraClient cassandraClient = new CassandraClient(testClusters.getCassandraHost(), testClusters.getCassandraNativePort());
		try {
			String cqlScript = FileUtil.getTextFromFile(new File("src/test/resources/Deals.cql"));
			String[] cqls = StringUtils.split(cqlScript, ";");
			cassandraClient.connect();
			for (String cql : cqls) {
				cql = cql.trim();
				if ("".equals(cql)) {
					continue;
				}
				cassandraClient.executeCql(cql + ";");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			cassandraClient.close();
		}
	}

	private void prepareMongoData() throws UnknownHostException {
		MongoClient mongoClient = new MongoClient(testClusters.getMongoHost(), testClusters.getMongoPort());
		DB db = mongoClient.getDB("deals");
		DBCollection coll = db.getCollection("items");
		BasicDBObject item1 = new BasicDBObject("_id", 11111L).append("fetch_time", new Date());
		BasicDBObject item2 = new BasicDBObject("_id", 22222L).append("fetch_time", new Date());
		BasicDBObject item3 = new BasicDBObject("_id", 33333L).append("fetch_time", new Date());
		BasicDBObject item4 = new BasicDBObject("_id", 44444L).append("fetch_time", new Date());

		coll.insert(item1);
		coll.insert(item2);
		coll.insert(item3);
		coll.insert(item4);
	}

	private void verifyResult() throws Exception {
		CassandraClient cassandraClient = new CassandraClient(testClusters.getCassandraHost(), testClusters.getCassandraNativePort());
		try {
			cassandraClient.connect();
			String cql1 = "select grp,ts,gmv,qty,click,pv,impr from nousks.deals2_summary;";
			List<String> r1 = cassandraClient.executeCql(cql1);
			Assert.assertEquals(11, r1.size());
			Assert.assertTrue(r1.contains("Row[11111_0, Thu Dec 31 23:11:00 CST 2015, 300.2, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[11111_0, Thu Dec 31 23:10:00 CST 2015, NULL, NULL, 2, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[p2309692_0, Thu Dec 31 23:11:00 CST 2015, 1000.4, 10, NULL, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[p2309692_0, Thu Dec 31 23:10:00 CST 2015, NULL, NULL, 6, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[p2309692_0, Thu Dec 31 23:09:00 CST 2015, NULL, NULL, NULL, 3, NULL]"));
			Assert.assertTrue(r1.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:11:00 CST 2015, 1000.4, 10, NULL, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:10:00 CST 2015, NULL, NULL, 6, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[33333_0, Thu Dec 31 23:11:00 CST 2015, 400.1, 4, NULL, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[33333_0, Thu Dec 31 23:10:00 CST 2015, NULL, NULL, 1, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[22222_0, Thu Dec 31 23:11:00 CST 2015, 300.1, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r1.contains("Row[22222_0, Thu Dec 31 23:10:00 CST 2015, NULL, NULL, 3, NULL, NULL]"));

			String cql2 = "select grp,ts,gmv,qty,click,pv,impr from nousks.deals2_summary_hly;";
			List<String> r2 = cassandraClient.executeCql(cql2);
			Assert.assertEquals(5, r2.size());
			Assert.assertTrue(r2.contains("Row[11111_0, Thu Dec 31 23:00:00 CST 2015, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r2.contains("Row[p2309692_0, Thu Dec 31 23:00:00 CST 2015, 1000.4, 10, 6, 3, NULL]"));
			Assert.assertTrue(r2.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:00:00 CST 2015, 1000.4, 10, 6, NULL, NULL]"));
			Assert.assertTrue(r2.contains("Row[33333_0, Thu Dec 31 23:00:00 CST 2015, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r2.contains("Row[22222_0, Thu Dec 31 23:00:00 CST 2015, 300.1, 3, 3, NULL, NULL]"));

			String cql3 = "select grp,ts,gmv,qty,click,pv,impr from nousks.deals2_summary_dly;";
			List<String> r3 = cassandraClient.executeCql(cql3);
			Assert.assertEquals(5, r3.size());
			Assert.assertTrue(r3.contains("Row[11111_0, Thu Dec 31 00:00:00 CST 2015, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r3.contains("Row[p2309692_0, Thu Dec 31 00:00:00 CST 2015, 1000.4, 10, 6, 3, NULL]"));
			Assert.assertTrue(r3.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 00:00:00 CST 2015, 1000.4, 10, 6, NULL, NULL]"));
			Assert.assertTrue(r3.contains("Row[33333_0, Thu Dec 31 00:00:00 CST 2015, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r3.contains("Row[22222_0, Thu Dec 31 00:00:00 CST 2015, 300.1, 3, 3, NULL, NULL]"));

			String cql4 = "select grp1,ts,grp2,gmv,qty,click,pv,impr from nousks.deals2_detail;";
			List<String> r4 = cassandraClient.executeCql(cql4);
			Assert.assertEquals(18, r4.size());
			Assert.assertTrue(r4.contains("Row[11111_0, Thu Dec 31 23:11:00 CST 2015, p2309692.m3940.l2, 300.2, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[11111_0, Thu Dec 31 23:10:00 CST 2015, p2309692.m3940.l2, NULL, NULL, 2, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692_0, Thu Dec 31 23:11:00 CST 2015, 11111, 300.2, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692_0, Thu Dec 31 23:11:00 CST 2015, 22222, 300.1, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692_0, Thu Dec 31 23:11:00 CST 2015, 33333, 400.1, 4, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692_0, Thu Dec 31 23:10:00 CST 2015, 11111, NULL, NULL, 2, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692_0, Thu Dec 31 23:10:00 CST 2015, 22222, NULL, NULL, 3, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692_0, Thu Dec 31 23:10:00 CST 2015, 33333, NULL, NULL, 1, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:11:00 CST 2015, 11111, 300.2, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:11:00 CST 2015, 22222, 300.1, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:11:00 CST 2015, 33333, 400.1, 4, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:10:00 CST 2015, 11111, NULL, NULL, 2, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:10:00 CST 2015, 22222, NULL, NULL, 3, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:10:00 CST 2015, 33333, NULL, NULL, 1, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[33333_0, Thu Dec 31 23:11:00 CST 2015, p2309692.m3940.l2, 400.1, 4, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[33333_0, Thu Dec 31 23:10:00 CST 2015, p2309692.m3940.l2, NULL, NULL, 1, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[22222_0, Thu Dec 31 23:11:00 CST 2015, p2309692.m3940.l2, 300.1, 3, NULL, NULL, NULL]"));
			Assert.assertTrue(r4.contains("Row[22222_0, Thu Dec 31 23:10:00 CST 2015, p2309692.m3940.l2, NULL, NULL, 3, NULL, NULL]"));

			String cql5 = "select grp1,ts,grp2,gmv,qty,click,pv,impr from nousks.deals2_detail_hly;";
			List<String> r5 = cassandraClient.executeCql(cql5);
			Assert.assertEquals(9, r5.size());
			Assert.assertTrue(r5.contains("Row[11111_0, Thu Dec 31 23:00:00 CST 2015, p2309692.m3940.l2, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[p2309692_0, Thu Dec 31 23:00:00 CST 2015, 11111, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[p2309692_0, Thu Dec 31 23:00:00 CST 2015, 22222, 300.1, 3, 3, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[p2309692_0, Thu Dec 31 23:00:00 CST 2015, 33333, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:00:00 CST 2015, 11111, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:00:00 CST 2015, 22222, 300.1, 3, 3, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 23:00:00 CST 2015, 33333, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[33333_0, Thu Dec 31 23:00:00 CST 2015, p2309692.m3940.l2, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r5.contains("Row[22222_0, Thu Dec 31 23:00:00 CST 2015, p2309692.m3940.l2, 300.1, 3, 3, NULL, NULL]"));

			String cql6 = "select grp1,ts,grp2,gmv,qty,click,pv,impr from nousks.deals2_detail_dly;";
			List<String> r6 = cassandraClient.executeCql(cql6);
			Assert.assertEquals(9, r6.size());
			Assert.assertTrue(r6.contains("Row[11111_0, Thu Dec 31 00:00:00 CST 2015, p2309692.m3940.l2, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[p2309692_0, Thu Dec 31 00:00:00 CST 2015, 11111, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[p2309692_0, Thu Dec 31 00:00:00 CST 2015, 22222, 300.1, 3, 3, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[p2309692_0, Thu Dec 31 00:00:00 CST 2015, 33333, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 00:00:00 CST 2015, 11111, 300.2, 3, 2, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 00:00:00 CST 2015, 22222, 300.1, 3, 3, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[p2309692.m3940.l2_0, Thu Dec 31 00:00:00 CST 2015, 33333, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[33333_0, Thu Dec 31 00:00:00 CST 2015, p2309692.m3940.l2, 400.1, 4, 1, NULL, NULL]"));
			Assert.assertTrue(r6.contains("Row[22222_0, Thu Dec 31 00:00:00 CST 2015, p2309692.m3940.l2, 300.1, 3, 3, NULL, NULL]"));

			String cql7 = "select id,ts,ref from nousks.deals2_fact;";
			List<String> r7 = cassandraClient.executeCql(cql7);
			Assert.assertEquals(4, r7.size());
			Assert.assertTrue(r7.contains("Row[22222_user1, Thu Dec 31 23:10:55 CST 2015, p2309692.m3940.l2]"));
			Assert.assertTrue(r7.contains("Row[22222_user2, Thu Dec 31 23:10:55 CST 2015, p2309692.m3940.l2]"));
			Assert.assertTrue(r7.contains("Row[11111_user1, Thu Dec 31 23:10:55 CST 2015, p2309692.m3940.l2]"));
			Assert.assertTrue(r7.contains("Row[33333_user2, Thu Dec 31 23:10:55 CST 2015, p2309692.m3940.l2]"));

			// Consumer for test
			List<String> seeds = new ArrayList<String>();
			seeds.add(testClusters.getKafkaHostname());
			KafkaTestConsumer kafkaTestConsumer = new KafkaTestConsumer();

			List<String> behavioralMessages = kafkaTestConsumer.getAllMessagesAsString(1, "bpe.deals.behavioral", 0, seeds, testClusters.getKafkaPort());
			Assert.assertEquals(9, behavioralMessages.size());
			Assert.assertTrue(behavioralMessages.contains(
					"{\"timestamp\":1451574655000,\"itm\":\"11111\",\"sid\":\"p2309692.m3940.l2\",\"g\":\"guid1\",\"u\":\"user1\",\"t\":\"0\",\"p\":\"2047675\",\"type\":\"vi\",\"bu\":null}"));
			Assert.assertTrue(behavioralMessages.contains(
					"{\"timestamp\":1451574655000,\"itm\":\"22222\",\"sid\":\"p2309692.m3940.l2\",\"g\":\"guid1\",\"u\":\"user1\",\"t\":\"0\",\"p\":\"2047675\",\"type\":\"vi\",\"bu\":\"bu1\"}"));
			Assert.assertTrue(behavioralMessages.contains(
					"{\"timestamp\":1451574655000,\"itm\":\"11111\",\"sid\":\"p2309692.m3940.l2\",\"g\":\"guid1\",\"u\":\"user1\",\"t\":\"0\",\"p\":\"2047675\",\"type\":\"vi\",\"bu\":null}"));
			Assert.assertTrue(behavioralMessages.contains("{\"type\":\"pv\",\"timestamp\":1451574595000,\"page\":\"p2309692\",\"p\":\"2309692\",\"t\":\"0\"}"));
			Assert.assertTrue(behavioralMessages.contains("{\"timestamp\":1451574595000,\"t\":\"0\",\"type\":\"pv\",\"page\":\"p2309692\",\"p\":\"2309692\"}"));
			Assert.assertTrue(behavioralMessages.contains("{\"timestamp\":1451574595000,\"t\":\"0\",\"type\":\"pv\",\"page\":\"p2309692\",\"p\":\"2309692\"}"));
			Assert.assertTrue(behavioralMessages.contains(
					"{\"timestamp\":1451574655000,\"itm\":\"22222\",\"sid\":\"p2309692.m3940.l2\",\"g\":\"guid2\",\"u\":\"user2\",\"t\":\"0\",\"p\":\"2047675\",\"type\":\"vi\",\"bu\":null}"));
			Assert.assertTrue(behavioralMessages.contains(
					"{\"timestamp\":1451574655000,\"itm\":\"22222\",\"sid\":\"p2309692.m3940.l2\",\"g\":\"guid2\",\"u\":\"user2\",\"t\":\"0\",\"p\":\"2047675\",\"type\":\"vi\",\"bu\":null}"));
			Assert.assertTrue(behavioralMessages.contains(
					"{\"timestamp\":1451574655000,\"itm\":\"33333\",\"sid\":\"p2309692.m3940.l2\",\"g\":\"guid2\",\"u\":\"user2\",\"t\":\"0\",\"p\":\"2047675\",\"type\":\"vi\",\"bu\":null}"));

			List<String> transactionalMessages = kafkaTestConsumer.getAllMessagesAsString(1, "bpe.deals.transactional", 0, seeds, testClusters.getKafkaPort());
			Assert.assertEquals(8, transactionalMessages.size());
			Assert.assertTrue(transactionalMessages
					.contains("{\"createdDT\":1451574715000,\"transactionSiteID\":\"0\",\"transQuantity\":1,\"type\":\"trans\",\"itemId\":\"11111\",\"gmv\":100.1,\"buyerId\":\"user1\"}"));
			Assert.assertTrue(transactionalMessages
					.contains("{\"createdDT\":1451574715000,\"transactionSiteID\":\"0\",\"transQuantity\":2,\"type\":\"trans\",\"itemId\":\"11111\",\"buyerId\":\"user1\",\"gmv\":200.1}"));
			Assert.assertTrue(transactionalMessages
					.contains("{\"createdDT\":1451574715000,\"transactionSiteID\":\"0\",\"transQuantity\":3,\"type\":\"trans\",\"itemId\":\"22222\",\"buyerId\":\"user2\",\"gmv\":300.1}"));
			Assert.assertTrue(transactionalMessages.contains(
					"{\"sid\":\"p2309692.m3940.l2\",\"createdDT\":1451574715000,\"s_p\":\"p2309692\",\"s_m\":\"m3940\",\"transactionSiteID\":\"0\",\"transQuantity\":1,\"type\":\"trans_attributed\",\"itemId\":\"11111\",\"gmv\":100.1,\"buyerId\":\"user1\"}"));
			Assert.assertTrue(transactionalMessages.contains(
					"{\"sid\":\"p2309692.m3940.l2\",\"createdDT\":1451574715000,\"s_p\":\"p2309692\",\"s_m\":\"m3940\",\"transactionSiteID\":\"0\",\"transQuantity\":2,\"type\":\"trans_attributed\",\"itemId\":\"11111\",\"buyerId\":\"user1\",\"gmv\":200.1}"));
			Assert.assertTrue(transactionalMessages.contains(
					"{\"sid\":\"p2309692.m3940.l2\",\"createdDT\":1451574715000,\"s_p\":\"p2309692\",\"s_m\":\"m3940\",\"transactionSiteID\":\"0\",\"transQuantity\":3,\"type\":\"trans_attributed\",\"itemId\":\"22222\",\"buyerId\":\"user2\",\"gmv\":300.1}"));
			Assert.assertTrue(transactionalMessages
					.contains("{\"createdDT\":1451574715000,\"transactionSiteID\":\"0\",\"transQuantity\":4,\"type\":\"trans\",\"itemId\":\"33333\",\"buyerId\":\"user2\",\"gmv\":400.1}"));
			Assert.assertTrue(transactionalMessages.contains(
					"{\"sid\":\"p2309692.m3940.l2\",\"createdDT\":1451574715000,\"s_p\":\"p2309692\",\"s_m\":\"m3940\",\"transactionSiteID\":\"0\",\"transQuantity\":4,\"type\":\"trans_attributed\",\"itemId\":\"33333\",\"buyerId\":\"user2\",\"gmv\":400.1}"));

		} catch (Exception e) {
			throw e;
		} finally {
			cassandraClient.close();
		}
	}

	@Before
	public void before() throws Exception {
		testClusters.startServers();

		// create kafka source topics
		testClusters.createKafkaTopic("behavioral.event");
		testClusters.createKafkaTopic("transaction.new");
		// create kafka output topics
		testClusters.createKafkaTopic("bpe.deals.behavioral");
		testClusters.createKafkaTopic("bpe.deals.transactional");

		this.prepareCassandraSchema();
		this.prepareMongoData();
	}

	@After
	public void after() throws Exception {
		testClusters.stopServers();
	}

	@Test
	public void testKafkaMongodbTopology() throws Exception {
		DealsTopology topology = new DealsTopology("dev");

		testClusters.submitStormTopology(topology.getName(), topology.build());
		long sleepSec1 = 40;
		Thread.sleep(sleepSec1 * 1000);
		Log.info("---------------------- Wait " + sleepSec1 + " seconds for the topology been fully prepared.");

		// produce kafka message
		this.prepareKafkaSourceData(new DateTime(2015, 12, 31, 23, 11, 55));

		long sleepSec2 = 20;
		Log.info("---------------------- Wait " + sleepSec2 + " seconds for the topology to process the message.");
		Thread.sleep(sleepSec2 * 1000);

		testClusters.killStormTopoloty(topology.getName());

		this.verifyResult();
	}
}
