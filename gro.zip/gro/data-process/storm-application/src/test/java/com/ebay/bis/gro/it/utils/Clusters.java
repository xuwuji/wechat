package com.ebay.bis.gro.it.utils;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ebay.bis.gro.kafka.ConfigVars;
import com.ebay.bis.gro.kafka.PropertyParser;
import com.github.sakserv.minicluster.impl.CassandraLocalServer;
import com.github.sakserv.minicluster.impl.KafkaLocalBroker;
import com.github.sakserv.minicluster.impl.MongodbLocalServer;
import com.github.sakserv.minicluster.impl.StormLocalCluster;
import com.github.sakserv.minicluster.impl.ZookeeperLocalCluster;
import com.github.sakserv.minicluster.util.FileUtils;
import com.hmsonline.trident.cql.CassandraCqlStateFactory;

import backtype.storm.Config;
import backtype.storm.generated.StormTopology;
import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import storm.kafka.trident.TridentKafkaState;

public class Clusters {

	private static final Logger LOG = LoggerFactory.getLogger(Clusters.class);

	private PropertyParser propertyParser;
	private static final String PROP_FILE = "local.properties";

	private ZookeeperLocalCluster zookeeperLocalCluster;
	private MongodbLocalServer mongodbLocalServer;
	private KafkaLocalBroker kafkaLocalBroker;
	private StormLocalCluster stormLocalCluster;
	private CassandraLocalServer cassandraLocalServer;

	public void startServers() throws Exception {
		LOG.info("------------------------------------- Starting clusters -------------------------------------");

		// Parse the properties file
		propertyParser = new PropertyParser();
		propertyParser.parsePropsFile(PROP_FILE);

		// clean up temp folders
		FileUtils.deleteFolder(propertyParser.getProperty(ConfigVars.ZOOKEEPER_TEMP_DIR_KEY));
		FileUtils.deleteFolder(propertyParser.getProperty(ConfigVars.KAFKA_TEST_TEMP_DIR_KEY));

		// Start Zookeeper
		zookeeperLocalCluster = new ZookeeperLocalCluster.Builder().setPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.ZOOKEEPER_PORT_KEY)))
				.setTempDir(propertyParser.getProperty(ConfigVars.ZOOKEEPER_TEMP_DIR_KEY)).setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY)).build();
		zookeeperLocalCluster.start();

		// Start Kafka
		kafkaLocalBroker = new KafkaLocalBroker.Builder().setKafkaHostname(propertyParser.getProperty(ConfigVars.KAFKA_HOSTNAME_KEY))
				.setKafkaPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_PORT_KEY)))
				.setKafkaBrokerId(Integer.parseInt(propertyParser.getProperty(ConfigVars.KAFKA_TEST_BROKER_ID_KEY))).setKafkaProperties(new Properties())
				.setKafkaTempDir(propertyParser.getProperty(ConfigVars.KAFKA_TEST_TEMP_DIR_KEY)).setZookeeperConnectionString(propertyParser.getProperty(ConfigVars.ZOOKEEPER_CONNECTION_STRING_KEY))
				.build();
		kafkaLocalBroker.start();

		// Start MongoDB
		mongodbLocalServer = new MongodbLocalServer.Builder().setIp(propertyParser.getProperty(ConfigVars.MONGO_IP_KEY))
				.setPort(Integer.parseInt(propertyParser.getProperty(ConfigVars.MONGO_PORT_KEY))).build();
		mongodbLocalServer.start();

		// Start Storm
		stormLocalCluster = new StormLocalCluster.Builder().setZookeeperHost(propertyParser.getProperty(ConfigVars.ZOOKEEPER_HOSTNAME_KEY))
				.setZookeeperPort(Long.parseLong(propertyParser.getProperty(ConfigVars.ZOOKEEPER_PORT_KEY)))
				.setEnableDebug(Boolean.parseBoolean(propertyParser.getProperty(ConfigVars.STORM_ENABLE_DEBUG_KEY)))
				.setNumWorkers(Integer.parseInt(propertyParser.getProperty(ConfigVars.STORM_NUM_WORKERS_KEY))).setStormConfig(new Config()).build();
		stormLocalCluster.start();

		// Start Cassandra
		cassandraLocalServer = new CassandraLocalServer();
		cassandraLocalServer.start();
	}

	public void stopServers() throws Exception {
		LOG.info("------------------------------------- Stopping clusters -------------------------------------");

		stormLocalCluster.stop(true);
		mongodbLocalServer.stop(true);
		kafkaLocalBroker.stop(true);
		cassandraLocalServer.stop(true);
		zookeeperLocalCluster.stop(true);
	}

	public String getKafkaBrokersConnectionString() {
		return kafkaLocalBroker.getKafkaHostname() + ":" + kafkaLocalBroker.getKafkaPort();
	}

	public String getZooKeeperConnectionString() {
		return zookeeperLocalCluster.getZookeeperConnectionString();
	}

	public String getCassandraHost() {
		return cassandraLocalServer.getHost();
	}

	public int getCassandraNativePort() {
		return cassandraLocalServer.getNativeTransportPort();
	}

	public String getMongoHost() {
		return mongodbLocalServer.getIp();
	}

	public int getMongoPort() {
		return mongodbLocalServer.getPort();
	}

	public String getKafkaHostname() {
		return kafkaLocalBroker.getKafkaHostname();
	}

	public int getKafkaPort() {
		return kafkaLocalBroker.getKafkaPort();
	}

	public void killStormTopoloty(String topologyName) {
		stormLocalCluster.killTopology(topologyName);
	}

	public void submitStormTopology(String topologyName, StormTopology topology) {
		Config conf = new Config();
		Properties props = new Properties();

		props.put("request.required.acks", "0");
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("compression.codec", "snappy");
		props.put("producer.type", "async");
		props.put("message.send.max.retries", "2");
		props.put("retry.backoff.ms", "100");
		props.put("topic.metadata.refresh.interval.ms", "600000");
		props.put("queue.buffering.max.ms", "1000");
		props.put("queue.buffering.max.messages", "200000");
		props.put("queue.enqueue.timeout.ms", "0");
		props.put("batch.num.messages", "500");
		props.put("send.buffer.bytes", "4194304");
		props.put("request.timeout.ms", "5000");
		props.put("metadata.broker.list", getKafkaBrokersConnectionString());
		conf.put(TridentKafkaState.KAFKA_BROKER_PROPERTIES, props);
		conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, getCassandraHost());

		stormLocalCluster.submitTopology(topologyName, conf, topology);
	}

	public void createKafkaTopic(String topicName) throws Exception {
		LOG.info("Creating topic " + topicName);
		// this method doesn't work. No partition is created for a topic, which
		// will cause exception.
		// ZkClient zkClient = new ZkClient(this.getZooKeeperConnectionString(),
		// 30000, 30000);
		// AdminUtils.createTopic(zkClient, topicName, 1, 1, new Properties());
		this.sendEmptyMessage(topicName);
		LOG.info("Topic " + topicName + " has been created.");
	}

	private void sendEmptyMessage(String topicName) throws Exception {
		Properties props = new Properties();
		props.put("metadata.broker.list", this.getKafkaBrokersConnectionString());
		props.put("zk.connect", this.getZooKeeperConnectionString());
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("request.required.acks", "1");
		ProducerConfig config = new ProducerConfig(props);
		Producer<String, String> producer = new Producer<String, String>(config);
		KeyedMessage<String, String> emptyMsg = new KeyedMessage<String, String>(topicName, "");
		try {
			producer.send(emptyMsg);
		} catch (Exception e) {
			LOG.error(e.getMessage());
			throw e;
		} finally {
			producer.close();
		}
	}
}
