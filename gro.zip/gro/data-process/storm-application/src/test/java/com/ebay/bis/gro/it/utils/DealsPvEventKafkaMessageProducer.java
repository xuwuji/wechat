package com.ebay.bis.gro.it.utils;

import org.joda.time.DateTime;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;

public class DealsPvEventKafkaMessageProducer extends EventKafkaMessageProducer {
	public DealsPvEventKafkaMessageProducer(DateTime baseTime, String kafkaBrokersString, String zkString) {
		super(baseTime, kafkaBrokersString, zkString);
	}

	@Override
	public void produceData() throws Exception {
		Producer<String, String> producer = new Producer<String, String>(producerConfig);
		KeyedMessage<String, String> msg1 = createKafkaMessage("0", "2309692", "p2065262.m2735.l5", "11111", "guid1", "user1", "", baseTime.getMillis());
		KeyedMessage<String, String> msg2 = createKafkaMessage("0", "2309692", "p2065262.m2735.l5", "22222", "guid2", "user1", "bu1", baseTime.getMillis());
		KeyedMessage<String, String> msg3 = createKafkaMessage("0", "2309692", "p2065262.m2735.l5", "11111", "guid3", "user2", "", baseTime.getMillis());
		try {
			producer.send(msg1);
			Thread.sleep(100);
			producer.send(msg2);
			Thread.sleep(100);
			producer.send(msg3);
		} catch (Exception e) {
			throw e;
		} finally {
			producer.close();
		}
	}

}
