package com.ebay.bis.gro.it.utils;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ebay.dss.bpe.TransactionFields;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class TransactionKafkaMessageProducer {
	private static final Logger LOG = LoggerFactory.getLogger(TransactionKafkaMessageProducer.class);

	private static DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static DecimalFormat df = new DecimalFormat("##.00");
	private static String TOPIC = "transaction.new";

	private final ProducerConfig producerConfig;
	private final DateTime baseTime;

	public TransactionKafkaMessageProducer(DateTime baseTime, String kafkaBrokersString, String zkString) {
		this.baseTime = baseTime;
		Properties props = new Properties();
		props.put("metadata.broker.list", kafkaBrokersString);
		props.put("zk.connect", zkString);
		props.put("serializer.class", "kafka.serializer.StringEncoder");
		props.put("request.required.acks", "1");
		this.producerConfig = new ProducerConfig(props);
	}

	public void produceData() throws Exception {
		Producer<String, String> producer = new Producer<String, String>(producerConfig);

		KeyedMessage<String, String> msg1 = createKafkaMessage(100.1, 1, "11111", baseTime.toDate(), "user1", "0");
		KeyedMessage<String, String> msg2 = createKafkaMessage(200.1, 2, "11111", baseTime.toDate(), "user1", "0");
		KeyedMessage<String, String> msg3 = createKafkaMessage(300.1, 3, "22222", baseTime.toDate(), "user2", "0");
		KeyedMessage<String, String> msg4 = createKafkaMessage(400.1, 4, "33333", baseTime.toDate(), "user2", "0");

		try {
			producer.send(msg1);
			Thread.sleep(100);
			producer.send(msg2);
			Thread.sleep(100);
			producer.send(msg3);
			Thread.sleep(100);
			producer.send(msg4);
		} catch (Exception e) {
			throw e;
		} finally {
			producer.close();
		}

	}

	private KeyedMessage<String, String> createKafkaMessage(double gmv, int quantity, String itemId, Date timestamp, String userId, String siteId) {
		Map<String, Object> event = new HashMap<String, Object>();
		event.put(TransactionFields.GMV, df.format(gmv));
		event.put(TransactionFields.QUANTITY, quantity);
		event.put(TransactionFields.ITEM, itemId);
		event.put(TransactionFields.TIMESTAMP, sdf.format(timestamp));
		event.put(TransactionFields.USER, userId);
		event.put(TransactionFields.SITE, siteId);
		LOG.info(event.toString());
		KeyedMessage<String, String> msg = new KeyedMessage<String, String>(TOPIC, mapToString(event));
		return msg;
	}

	private String mapToString(Map<String, Object> map) {
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			if (sb.length() > 0) {
				sb.append("|");
			}
			sb.append(entry.getKey()).append("=").append(entry.getValue());
		}
		return sb.toString();
	}
}
