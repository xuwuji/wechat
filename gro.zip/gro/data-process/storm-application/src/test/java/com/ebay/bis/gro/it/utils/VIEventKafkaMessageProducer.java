package com.ebay.bis.gro.it.utils;

import org.joda.time.DateTime;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;

public class VIEventKafkaMessageProducer extends EventKafkaMessageProducer {

	public VIEventKafkaMessageProducer(DateTime baseTime, String kafkaBrokersString, String zkString) {
		super(baseTime, kafkaBrokersString, zkString);
	}

	@Override
	public void produceData() throws Exception {
		Producer<String, String> producer = new Producer<String, String>(producerConfig);

		KeyedMessage<String, String> msg1 = createKafkaMessage("0", "2047675", "p2309692.m3940.l2", "11111", "guid1", "user1", "", baseTime.getMillis());
		KeyedMessage<String, String> msg2 = createKafkaMessage("0", "2047675", "p2309692.m3940.l2", "22222", "guid1", "user1", "bu1", baseTime.getMillis());
		KeyedMessage<String, String> msg3 = createKafkaMessage("0", "2047675", "p2309692.m3940.l2", "11111", "guid1", "user1", "", baseTime.getMillis());

		KeyedMessage<String, String> msg4 = createKafkaMessage("0", "2047675", "p2309692.m3940.l2", "22222", "guid2", "user2", "", baseTime.getMillis());
		KeyedMessage<String, String> msg5 = createKafkaMessage("0", "2047675", "p2309692.m3940.l2", "22222", "guid2", "user2", "", baseTime.getMillis());
		KeyedMessage<String, String> msg6 = createKafkaMessage("0", "2047675", "p2309692.m3940.l2", "33333", "guid2", "user2", "", baseTime.getMillis());

		try {
			producer.send(msg1);
			Thread.sleep(100);
			producer.send(msg2);
			Thread.sleep(100);
			producer.send(msg3);
			Thread.sleep(100);
			producer.send(msg4);
			Thread.sleep(100);
			producer.send(msg5);
			Thread.sleep(100);
			producer.send(msg6);
		} catch (Exception e) {
			throw e;
		} finally {
			producer.close();
		}
	}
}
