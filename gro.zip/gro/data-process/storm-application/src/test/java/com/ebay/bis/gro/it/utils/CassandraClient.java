package com.ebay.bis.gro.it.utils;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Metadata;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class CassandraClient {

	private static final Logger LOG = LoggerFactory.getLogger(CassandraClient.class);

	private Cluster cluster;
	private Session session;

	private String node;
	private int port;

	public CassandraClient(String nodeName, int nativePort) {
		this.node = nodeName;
		this.port = nativePort;
	}

	public void connect() {
		cluster = Cluster.builder().addContactPoint(node).withPort(port).build();
		Metadata metadata = cluster.getMetadata();
		LOG.info("Connected to cluster ", metadata.getClusterName());
	}

	public void close() {
		cluster.close();
	}

	public List<String> executeCql(String cql) {
		session = cluster.connect();
		ResultSet results = session.execute(cql);
		List<String> retVal = this.convertResultSetToList(results);
		printResult(retVal);
		session.close();
		return retVal;
	}

	public List<String> getAllDataFromTable(String keySpace, String tableName) {
		session = cluster.connect();
		String table = keySpace + "." + tableName;
		String cql = "select * from " + table + ";";
		ResultSet results = session.execute(cql);
		List<String> retVal = this.convertResultSetToList(results);
		LOG.info("----------------------------- Data in Cassandra Table " + table + " -----------------------------");
		printResult(retVal);
		session.close();
		return retVal;
	}

	private void printResult(List<String> results) {
		System.out.println("-----------------------------------------------------");
		for (String row : results) {
			System.out.println(row);
		}
		System.out.println("-----------------------------------------------------");
	}

	private List<String> convertResultSetToList(ResultSet results) {
		List<String> retVal = new ArrayList<String>();
		for (Row row : results.all()) {
			retVal.add(row.toString());
		}
		return retVal;
	}
}
