#!/usr/bin/env bash

set -e
mvn clean package

rsync -Pvaz target/data-process-0.1-job.jar phxdpeba008.phx.ebay.com:projects/gro/
