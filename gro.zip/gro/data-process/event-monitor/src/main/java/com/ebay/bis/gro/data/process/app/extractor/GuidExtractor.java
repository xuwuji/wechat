package com.ebay.bis.gro.data.process.app.extractor;

import com.ebay.hadoop.platform.model.Event;
import com.ebay.hadoop.platform.model.SessionContainer;

public class GuidExtractor extends AbstractExtractor {
	@Override
	public Object extract(SessionContainer sc, Event e) {
		return sc.getSessionHeader().getGuid();
	}
}
