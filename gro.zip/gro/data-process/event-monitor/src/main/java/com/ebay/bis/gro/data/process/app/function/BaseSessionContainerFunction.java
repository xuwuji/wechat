package com.ebay.bis.gro.data.process.app.function;

import java.util.Map;

import cascading.flow.FlowProcess;
import cascading.operation.BaseOperation;
import cascading.operation.Function;
import cascading.operation.FunctionCall;
import cascading.operation.OperationCall;
import cascading.tuple.Fields;
import cascading.tuple.Tuple;

import com.ebay.bi.model.BISessionContainer;
import com.ebay.bi.model.SessionContainerWrap;
import com.ebay.hadoop.platform.model.SessionContainer;
import com.google.common.collect.Table;

public class BaseSessionContainerFunction extends BaseOperation<String> implements Function<String> {
	private static final long serialVersionUID = -5703207013458215347L;
	private SessionContainerHandler handler = null;
	
	public BaseSessionContainerFunction(SessionContainerHandler handler){
		super(new Fields(handler.getFields()));
		this.handler = handler;
	}
	
	@Override
	public void prepare(FlowProcess flowProcess, OperationCall<String> operationCall) {
		//System.out.println("prepare is called.");
	}

	@Override
	public void operate(FlowProcess flowProcess, FunctionCall<String> functionCall) {
		//System.out.println("operate is called.");
		BISessionContainer bisc = (BISessionContainer) functionCall.getArguments().getObject(0);
		SessionContainer sc = SessionContainerWrap.fromBISessionContainer(bisc);
		
		String[] fields = handler.getFields();
		Table<Integer, String, Object> table = handler.process(sc);
		
		Tuple tuple = Tuple.size(fields.length);
		
		for ( int row : table.rowKeySet() ){
			Map<String, Object> columns = table.row(row);
			for ( int i = 0; i<fields.length; i++ ){
				Object value = columns.get(fields[i]);
				tuple.set(i, value);
			}
			functionCall.getOutputCollector().add(tuple);
		}
	}
}
