package com.ebay.bis.gro.data.process.app.extractor;

import org.apache.commons.lang.StringUtils;

import com.ebay.hadoop.platform.model.Event;
import com.ebay.hadoop.platform.model.SessionContainer;

public class URLExtractor extends AbstractExtractor {
	@Override
	public Object extract(SessionContainer sc, Event e) {
		String url = StringUtils.trimToEmpty(e.getUrlQueryString()).toLowerCase();
		if ( StringUtils.isEmpty(url) ) return "";
		
		int index = StringUtils.indexOfAny(url, "?&");
		if ( index == -1 ) return url;
		 return StringUtils.substring(url, 0, index);
	}
}
