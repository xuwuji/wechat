package com.ebay.bis.gro.data.process.app;

import java.util.Properties;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import cascading.flow.Flow;
import cascading.flow.FlowConnector;
import cascading.flow.hadoop2.Hadoop2MR1FlowConnector;
import cascading.pipe.Each;
import cascading.pipe.Pipe;
import cascading.property.AppProps;
import cascading.scheme.Scheme;
import cascading.scheme.hadoop.TextDelimited;
import cascading.scheme.hadoop.WritableSequenceFile;
import cascading.tap.SinkMode;
import cascading.tap.Tap;
import cascading.tap.hadoop.Hfs;
import cascading.tuple.Fields;

import com.ebay.bi.model.BISessionContainer;
import com.ebay.bis.gro.data.process.app.function.BaseSessionContainerFunction;
import com.ebay.bis.gro.data.process.app.function.SimpleDataHandler;

public class Sample02Application extends Configured implements Tool{
	public Sample02Application(){
	}
	
	private String inputSojPath = null;
	private String outputPath = null;
	
	@SuppressWarnings("static-access")
	public Options getOptions(){
		Options options = new Options();
		
		Option help = new Option( "h", "help", false, "print this message" );
		Option dir = OptionBuilder.withLongOpt( "soj-dir" )
				.withDescription( "soj data directory" )
				.hasArg()
				.withArgName("DIRECTORY")
				.withValueSeparator('=')
				.create('i');
		
		Option output = OptionBuilder.withLongOpt( "output" )
				.withDescription( "output data directory" )
				.hasArg()
				.withArgName("DIRECTORY")
				.withValueSeparator('=')
				.create('o');
		
		options.addOption(help).addOption(dir).addOption(output);
		return options;
	}
	
	public boolean parseArgument(String[] argv) throws ParseException{
		Options options = getOptions();
		HelpFormatter formatter = new HelpFormatter();
		
		CommandLineParser parser = new GnuParser();
		CommandLine line = parser.parse(options, argv, true);
		
		if ( line.hasOption("help" )){
			formatter.printHelp(Sample02Application.class.getSimpleName(), options );
			return false; 
		}
		
		if ( line.hasOption("soj-dir") ){
			inputSojPath = line.getOptionValue("soj-dir");
		}
		
		if ( line.hasOption("output") ){
			outputPath = line.getOptionValue("output");
		}
		
		boolean good = true;
		if ( StringUtils.isEmpty(inputSojPath) ){
			System.out.println("soj-dir can't be empty.");
			good = false;
		}
		
		if ( StringUtils.isEmpty(outputPath) ){
			System.out.println("output can't be empty.");
			good = false;
		}
		
		if ( !good ){
			formatter.printHelp(Sample02Application.class.getSimpleName(), options );
			return false;
		}
		return true;
	}
	
	public void dataProcess(){
		Scheme sourceScheme = new WritableSequenceFile( new Fields( "key", "value" ), Text.class, BISessionContainer.class );
		Tap source = new Hfs( sourceScheme, inputSojPath ); 

		// the 'head' of the pipe assembly
		Pipe assembly = new Pipe( "sample2" );

		SimpleDataHandler extractor = new SimpleDataHandler();
		// For each input Tuple
		assembly = new Each( assembly, new Fields( "value" ), new BaseSessionContainerFunction(extractor) ); 

		Scheme sinkScheme = new TextDelimited( /*new Fields( "key" )*/ );
		Tap sink = new Hfs( sinkScheme, outputPath, SinkMode.REPLACE ); 

		// initialize app properties, tell Hadoop which jar file to use
		Properties properties = AppProps.appProps() 
		  .setName( "word-count-application" )
		  .setJarClass( Sample02Application.class )
		  .buildProperties(this.getConf());

		// plan a new Flow from the assembly using the source and sink Taps
		// with the above properties
		FlowConnector flowConnector = new Hadoop2MR1FlowConnector( properties ); 
		Flow flow = flowConnector.connect( "sample2", source, sink, assembly ); 

		// execute the flow, block until complete
		flow.complete();
	}
	
	public static void main(String[] args) throws Exception{
		int res = ToolRunner.run(new Sample02Application(), args);
	    System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {
		boolean valid = parseArgument(args);
		if ( !valid ) return -1;
		dataProcess();
		return 0;
	}
}
