package com.ebay.bis.gro.data.process.app.extractor;

import com.ebay.hadoop.platform.model.Event;
import com.ebay.hadoop.platform.model.SessionContainer;

public abstract class AbstractExtractor implements IExtractor {

	@Override
	public Object extract(SessionContainer sc, Event e) {
		throw new UnsupportedOperationException();
	}

}
