package com.ebay.bis.gro.data.process.app.function;

import com.ebay.hadoop.platform.model.SessionContainer;
import com.ebay.hadoop.platform.model.SessionHeader;
import com.ebay.searchscience.base.soj.util.DateUtil;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class SimpleDataHandler implements SessionContainerHandler {
	private static final long serialVersionUID = 8198900103736666198L;
	public final static String[] fields = {"guid","skey","ts","date"};
	
	@Override
	public String[] getFields() {
		return fields;
	}

	@Override
	public Table<Integer, String, Object> process(SessionContainer sc) {
		Table<Integer, String, Object> table = HashBasedTable.create();
		
		SessionHeader sh = sc.getSessionHeader();
		String guid = sh.getGuid();
		String skey = "" + sh.getSessionKey();
		long ts = sh.getStartTimestamp();
		String dt = DateUtil.getEbayDate(ts) + ":" + DateUtil.getEbayTimeStamp(ts);
		//String dt = sh.getStartTimestampAsDate().toGMTString();
		
		table.put(0, fields[0], guid);
		table.put(0, fields[1], skey);
		table.put(0, fields[2], ts);
		table.put(0, fields[3], dt);
		
		return table;
	}

}
