package com.ebay.bis.gro.data.process.app.extractor;

import com.ebay.hadoop.platform.model.Event;
import com.ebay.hadoop.platform.model.SessionContainer;
import com.ebay.searchscience.base.soj.util.DateUtil;

public class SessionDateExtractor extends AbstractExtractor{
	
	@Override
	public Object extract(SessionContainer sc, Event e) {
		return DateUtil.getEbayDate(sc.getSessionHeader().getStartTimestamp());
	}
	
}
