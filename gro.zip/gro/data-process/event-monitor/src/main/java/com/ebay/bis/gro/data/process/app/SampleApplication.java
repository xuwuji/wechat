package com.ebay.bis.gro.data.process.app;

import java.util.Properties;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import cascading.flow.Flow;
import cascading.flow.FlowConnector;
import cascading.flow.hadoop2.Hadoop2MR1FlowConnector;
import cascading.operation.Aggregator;
import cascading.operation.Function;
import cascading.operation.aggregator.Count;
import cascading.operation.regex.RegexGenerator;
import cascading.pipe.Each;
import cascading.pipe.Every;
import cascading.pipe.GroupBy;
import cascading.pipe.Pipe;
import cascading.property.AppProps;
import cascading.scheme.Scheme;
import cascading.scheme.hadoop.TextDelimited;
import cascading.scheme.hadoop.TextLine;
import cascading.tap.SinkMode;
import cascading.tap.Tap;
import cascading.tap.hadoop.Hfs;
import cascading.tuple.Fields;

public class SampleApplication extends Configured implements Tool{
	public SampleApplication(){
		
	}
	
	private String inputSojPath = null;
	private String outputPath = null;
	
	@SuppressWarnings("static-access")
	public Options getOptions(){
		Options options = new Options();
		
		Option help = new Option( "h", "help", false, "print this message" );
		Option dir = OptionBuilder.withLongOpt( "soj-dir" )
				.withDescription( "soj data directory" )
				.hasArg()
				.withArgName("DIRECTORY")
				.withValueSeparator('=')
				.create('i');
		
		Option output = OptionBuilder.withLongOpt( "output" )
				.withDescription( "output data directory" )
				.hasArg()
				.withArgName("DIRECTORY")
				.withValueSeparator('=')
				.create('o');
		
		options.addOption(help).addOption(dir).addOption(output);
		return options;
	}
	
	public boolean parseArgument(String[] argv) throws ParseException{
		Options options = getOptions();
		HelpFormatter formatter = new HelpFormatter();
		
		CommandLineParser parser = new GnuParser();
		CommandLine line = parser.parse(options, argv, true);
		
		if ( line.hasOption("help" )){
			formatter.printHelp(SampleApplication.class.getSimpleName(), options );
			return false; 
		}
		
		if ( line.hasOption("soj-dir") ){
			inputSojPath = line.getOptionValue("soj-dir");
		}
		
		if ( line.hasOption("output") ){
			outputPath = line.getOptionValue("output");
		}
		
		boolean good = true;
		if ( StringUtils.isEmpty(inputSojPath) ){
			System.out.println("soj-dir can't be empty.");
			good = false;
		}
		
		if ( StringUtils.isEmpty(outputPath) ){
			System.out.println("output can't be empty.");
			good = false;
		}
		
		if ( !good ){
			formatter.printHelp(SampleApplication.class.getSimpleName(), options );
			return false;
		}
		return true;
	}
	
	public void dataProcess(){
		Scheme sourceScheme = new TextLine( new Fields( "line" ) );
		Tap source = new Hfs( sourceScheme, inputSojPath ); 

		// the 'head' of the pipe assembly
		Pipe assembly = new Pipe( "wordcount" );

		// For each input Tuple
		// parse out each word into a new Tuple with the field name "word"
		// regular expressions are optional in Cascading
		String regex = "(?<!\\pL)(?=\\pL)[^ ]*(?<=\\pL)(?!\\pL)";
		Function function = new RegexGenerator( new Fields( "word" ), regex );
		assembly = new Each( assembly, new Fields( "line" ), function ); 

		// group the Tuple stream by the "word" value
		assembly = new GroupBy( assembly, new Fields( "word" ) );  

		// For every Tuple group
		// count the number of occurrences of "word" and store result in
		// a field named "count"
		Aggregator count = new Count( new Fields( "count" ) );
		assembly = new Every( assembly, count );  

		Scheme sinkScheme = new TextDelimited( new Fields( "word", "count" ) );
		Tap sink = new Hfs( sinkScheme, outputPath, SinkMode.REPLACE ); 

		// initialize app properties, tell Hadoop which jar file to use
		Properties properties = AppProps.appProps() 
		  .setName( "word-count-application" )
		  .setJarClass( SampleApplication.class )
		  .buildProperties(this.getConf());

		// plan a new Flow from the assembly using the source and sink Taps
		// with the above properties
		FlowConnector flowConnector = new Hadoop2MR1FlowConnector( properties ); 
		Flow flow = flowConnector.connect( "word-count", source, sink, assembly ); 

		// execute the flow, block until complete
		flow.complete();
	}
	
	public static void main(String[] args) throws Exception{
		int res = ToolRunner.run(new SampleApplication(), args);
	    System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {
		boolean valid = parseArgument(args);
		if ( !valid ) return -1;
		dataProcess();
		return 0;
	}
}
