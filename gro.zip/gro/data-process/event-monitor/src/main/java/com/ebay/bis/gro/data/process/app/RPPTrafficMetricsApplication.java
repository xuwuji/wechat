package com.ebay.bis.gro.data.process.app;

import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import cascading.flow.Flow;
import cascading.flow.FlowConnector;
import cascading.flow.hadoop2.Hadoop2MR1FlowConnector;
import cascading.pipe.Each;
import cascading.pipe.Pipe;
import cascading.pipe.assembly.AggregateBy;
import cascading.pipe.assembly.SumBy;
import cascading.property.AppProps;
import cascading.scheme.Scheme;
import cascading.scheme.hadoop.TextDelimited;
import cascading.scheme.hadoop.WritableSequenceFile;
import cascading.tap.SinkMode;
import cascading.tap.Tap;
import cascading.tap.hadoop.Hfs;
import cascading.tuple.Fields;

import com.ebay.bi.model.BISessionContainer;
import com.ebay.bis.gro.data.process.app.function.BaseSessionContainerFunction;
import com.ebay.bis.gro.data.process.app.function.RPPTrafficMetricsDataHandler;
import com.ebay.bis.gro.data.process.util.ProgressReporter;

public class RPPTrafficMetricsApplication extends Configured implements Tool{
	public RPPTrafficMetricsApplication(){
	}
	
	public String getJobName(){
		return "GRO-TrafficMetrics";
	}
	
	private String inputSojPath = null;
	private String outputPath = null;
	
	@SuppressWarnings("static-access")
	public Options getOptions(){
		Options options = new Options();
		
		Option help = new Option( "h", "help", false, "print this message" );
		Option dir = OptionBuilder.withLongOpt( "soj-dir" )
				.withDescription( "soj data directory" )
				.hasArg()
				.withArgName("DIRECTORY")
				.withValueSeparator('=')
				.create('i');
		
		Option output = OptionBuilder.withLongOpt( "output" )
				.withDescription( "output data directory" )
				.hasArg()
				.withArgName("DIRECTORY")
				.withValueSeparator('=')
				.create('o');
		
		options.addOption(help).addOption(dir).addOption(output);
		return options;
	}
	
	public boolean parseArgument(String[] argv) throws ParseException{
		Options options = getOptions();
		HelpFormatter formatter = new HelpFormatter();
		
		CommandLineParser parser = new GnuParser();
		CommandLine line = parser.parse(options, argv, true);
		
		if ( line.hasOption("help" )){
			formatter.printHelp(RPPTrafficMetricsApplication.class.getSimpleName(), options );
			return false; 
		}
		
		if ( line.hasOption("soj-dir") ){
			inputSojPath = line.getOptionValue("soj-dir");
		}
		
		if ( line.hasOption("output") ){
			outputPath = line.getOptionValue("output");
		}
		
		boolean good = true;
		if ( StringUtils.isEmpty(inputSojPath) ){
			System.out.println("soj-dir can't be empty.");
			good = false;
		}
		
		if ( StringUtils.isEmpty(outputPath) ){
			System.out.println("output can't be empty.");
			good = false;
		}
		
		if ( !good ){
			formatter.printHelp(RPPTrafficMetricsApplication.class.getSimpleName(), options );
			return false;
		}
		return true;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void dataProcess(){
		Scheme sourceScheme = new WritableSequenceFile( new Fields( "key", "value" ), Text.class, BISessionContainer.class );
		Tap source = new Hfs( sourceScheme, inputSojPath ); 

		// the 'head' of the pipe assembly
		Pipe assembly = new Pipe( "Head - " + inputSojPath);

		RPPTrafficMetricsDataHandler handler = new RPPTrafficMetricsDataHandler();
		// For each input SessionContainer, extract info for traffic metrics
		Pipe sojOut = new Each( assembly, new Fields( "value" ), new BaseSessionContainerFunction(handler) ); 
		
		//group by keys on sojOut table.
		//sum sp, pv, fp and lp
		Fields groupFields = new Fields("guid", "skey", "date", "siteid", "pageid", "url");
		SumBy spSumBy = new SumBy(new Fields("sp"), new Fields("sp-total"), Long.class);
		SumBy pvSumBy = new SumBy(new Fields("pv"), new Fields("pv-total"), Long.class);
		SumBy fpSumBy = new SumBy(new Fields("fp"), new Fields("fp-total"), Long.class);
		SumBy lpSumBy = new SumBy(new Fields("lp"), new Fields("lp-total"), Long.class);
		
		Pipe outPipe = new AggregateBy(sojOut, groupFields, spSumBy, pvSumBy, fpSumBy, lpSumBy);
		
		Scheme sinkScheme = new TextDelimited( /*new Fields( "key" )*/ );
		Tap sink = new Hfs( sinkScheme, outputPath, SinkMode.REPLACE ); 

		// initialize app properties, tell Hadoop which jar file to use
		Properties properties = AppProps.appProps() 
		  .setName( getJobName() )
		  .setJarClass( RPPTrafficMetricsApplication.class )
		  .buildProperties(this.getConf());

		// plan a new Flow from the assembly using the source and sink Taps
		// with the above properties
		FlowConnector flowConnector = new Hadoop2MR1FlowConnector( properties ); 
		Flow flow = flowConnector.connect( getJobName(), source, sink, outPipe ); 
		
		//print progress
		ProgressReporter report = new ProgressReporter(flow);
		ExecutorService es = Executors.newSingleThreadExecutor();
		es.execute(report);
		
		flow.complete();
		report.stop();
		
		es.shutdown();
		try {
			es.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
			es.shutdownNow();
		}
	}
	
	public static void main(String[] args) throws Exception{
		int res = ToolRunner.run(new RPPTrafficMetricsApplication(), args);
	    System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {
		boolean valid = parseArgument(args);
		if ( !valid ) return -1;
		dataProcess();
		return 0;
	}
}
