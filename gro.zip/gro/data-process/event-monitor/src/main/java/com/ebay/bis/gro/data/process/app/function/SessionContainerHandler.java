package com.ebay.bis.gro.data.process.app.function;

import java.io.Serializable;

import com.ebay.hadoop.platform.model.SessionContainer;
import com.google.common.collect.Table;

public interface SessionContainerHandler extends Serializable {

	public String[] getFields();

	public Table<Integer, String, Object> process(SessionContainer sc);
	
}
