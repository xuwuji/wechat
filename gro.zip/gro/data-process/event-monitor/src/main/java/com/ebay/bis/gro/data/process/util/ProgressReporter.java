package com.ebay.bis.gro.data.process.util;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RunningJob;
import org.apache.log4j.Logger;

import cascading.flow.Flow;
import cascading.stats.CascadingStats;
import cascading.stats.FlowStepStats;
import cascading.stats.hadoop.HadoopStepStats;

public class ProgressReporter implements Runnable {
	Logger logger = Logger.getLogger(ProgressReporter.class);
	private Flow flow;
	private boolean running = false;

	public ProgressReporter(Flow flow) {
		this.flow = flow;
	}

	public void stop() {
		running = false;
	}

	@Override
	public void run() {
		running = true;
		logger.info("start running...");
		while (running) {
			boolean isFlowDone = false;
			JobClient jobClient = null;
			try {
				jobClient = new JobClient((JobConf) flow.getConfig());
			} catch (IOException e) {
				logger.error("Error while trying to fetch the hadoop job client!", e);
				return;
			}

			while (!isFlowDone) {
				List<FlowStepStats> stats = flow.getFlowStats().getFlowStepStats();

				for (FlowStepStats each : stats) {
					if (each.getStatus() == CascadingStats.Status.PENDING || each.getStatus() == CascadingStats.Status.RUNNING) {
						isFlowDone = false;
					} else {
						isFlowDone = true;
					}

					HadoopStepStats stepStats = (HadoopStepStats) each;

					RunningJob job = stepStats.getJobStatusClient();
					if ( job == null ){
						logger.info("Status client is null for " + stepStats.getID() + ", " + stepStats.getName());
						continue;
					}
					
					try {
						String info = String.format("job id : %s map %.0f%% reduce %.0f%%", job.getID().toString(), job.mapProgress()*100, job.reduceProgress()*100);
						logger.info(info);
					} catch (IOException e) {
						logger.error(e);
					}
				}

				try {
					Thread.sleep(10 * 1000);
				} catch (InterruptedException ie) {
					logger.error("interrupted:" + ie.getMessage());
				}
			}
		}
		logger.info("Progress report quit");
	}

}
