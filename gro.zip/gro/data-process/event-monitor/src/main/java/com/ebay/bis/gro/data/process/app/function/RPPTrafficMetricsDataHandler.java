package com.ebay.bis.gro.data.process.app.function;

import java.util.ArrayList;
import java.util.List;

import com.ebay.bis.gro.data.process.app.extractor.GuidExtractor;
import com.ebay.bis.gro.data.process.app.extractor.PageIDExtractor;
import com.ebay.bis.gro.data.process.app.extractor.SessionDateExtractor;
import com.ebay.bis.gro.data.process.app.extractor.SessionKeyExtractor;
import com.ebay.bis.gro.data.process.app.extractor.SiteIDExtractor;
import com.ebay.bis.gro.data.process.app.extractor.URLExtractor;
import com.ebay.bis.gro.data.process.util.EventUtils;
import com.ebay.hadoop.platform.model.Event;
import com.ebay.hadoop.platform.model.SessionContainer;
import com.ebay.searchscience.base.soj.PageType;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class RPPTrafficMetricsDataHandler implements SessionContainerHandler {
	private static final long serialVersionUID = 8647903659839349373L;
	public final static String[] fields = {
		  "guid"
		, "skey"
		, "date"
		, "siteid"
		, "pageid"
		, "url"
		, "sp"/*1 if it's single page session, or 0*/ 
		, "pv"
		, "fp"/*1 if it's the first page in the session, or 0 */
		, "lp"/*1 if it's the last page in the session, or 0  */
	};
	
	@Override
	public String[] getFields() {
		return fields;
	}
	

	@Override
	public Table<Integer, String, Object> process(SessionContainer sc) {
		Table<Integer, String, Object> table = HashBasedTable.create();
		
		SessionDateExtractor sde = new SessionDateExtractor();
		GuidExtractor ge = new GuidExtractor();
		SessionKeyExtractor ske = new SessionKeyExtractor();
		SiteIDExtractor sIDe = new SiteIDExtractor();
		PageIDExtractor pIDe = new PageIDExtractor();
		URLExtractor urle = new URLExtractor();
		//RPPEventIDExtractor eventIDExt = new RPPEventIDExtractor();
		//RPPEventGroupIDExtractor eventGroupIDExt = new RPPEventGroupIDExtractor();
		
		
		String guid = (String)ge.extract(sc, null);
		long skey = (long)ske.extract(sc, null);
		String dt = (String)sde.extract(sc, null);
		
		//filter event, keep valid events only in eventList.
		List<Event> eventList = new ArrayList<Event>();
		for ( Event event: sc.getEvents() ){
			if ( event.getRdt() != 0 ) continue;  //filter out redirect event
			if ( PageType.isFrameBased(event) ) continue; //filter out frame event
			if ( EventUtils.isRoverEvent(event) ) continue; //filter out rover event
			
			eventList.add(event);
		}
		
		int index = 0, totalCount = eventList.size();
		if ( totalCount == 0 ) return table;
		
		//for each valid event
		for ( int i = 0; i < totalCount; i++ ){
			Event event = eventList.get(i);
			
			//we only handle page we are interested
			if ( !isInterestedEvent(event) ) continue;
			
			int siteId = (int)sIDe.extract(sc, event);
			int pageId = (int)pIDe.extract(sc, event);
							
			String url = (String)urle.extract(sc, event);
			//String rppEventId = rppEventID(event);
			//String rppEventGroupId = rppEventGroupID(event);
			
			int sp = (totalCount == 1) ? 1 : 0;
			int pv = 1;
			int fp = (i == 0) ? 1 : 0;
			int lp = (i == totalCount - 1) ? 1 : 0;
			
			table.put(index, fields[0], guid);
			table.put(index, fields[1], skey);
			table.put(index, fields[2], dt);
			table.put(index, fields[3], siteId);
			table.put(index, fields[4], pageId);
			table.put(index, fields[5], url);
			table.put(index, fields[6], sp);
			table.put(index, fields[7], pv);
			table.put(index, fields[8], fp);
			table.put(index, fields[9], lp);
			index++;
		}
		
		return table;
	}

	
	private boolean isInterestedEvent(Event event) {
		int pageId = event.getPageTypeId();
		return pageId == EventUtils.RPP_HOME || pageId == EventUtils.RPP_EVENT_PAGE_ID;
	}

}
