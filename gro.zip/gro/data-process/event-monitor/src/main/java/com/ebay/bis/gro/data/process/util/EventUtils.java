package com.ebay.bis.gro.data.process.util;

import java.net.URLDecoder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.ebay.globalenv.sojourner.GlobalTags;
import com.ebay.globalenv.sojourner.TrackingProperty;
import com.ebay.hadoop.platform.model.Event;
import com.ebay.hadoop.platform.model.SessionContainer;

public class EventUtils {

	private static Set<Integer> ROVER_IDS = new HashSet<Integer>(Arrays.asList(
			3084, 3085, 3086, 3668, 3914, 3962, 3963, 4078, 4249, 4319, 4253,
			4602, 4827, 4815, 5095, 5111, 5759, 5660, 5771, 6047, 6077, 6078));

	private static Set<Integer> EXCLUDED_FRAME_IDS = new HashSet<Integer>(
			Arrays.asList(2045577));
	
	public static int FEEDHOME_PAGE_ID = 2050601;
	public static int PROFILE_PAGE_ID = 2050430;
	public static int EBAYTODAY_PAGE_ID = 2057337;
	public static int SHARE_PAGE_ID = 2050886;
	// just for test
	public final static int RAPTOR_SRP_PAGE_ID = 2045573;
	public final static int COLLECTION_PAGE_ID = 2057253;
	public final static int COLLECTION_SPOKE_PAGE_ID = 2057254;
	public final static int STORE_PAGE_ID = 2056350;
	public final static int RAPTOR_VI_PAGE_ID = 2047675;
	public final static int RAPTOR_SIS_PAGE_ID = 2054436;
	public final static int RAPTOR_SOI_PAGE_ID = 2046732;

	public static final int RAPTOR_VILAYER_PAGE_ID = 2056016;

	public static final int ROVER_3914 = 3914;

	public static final int BROWSE_ALLCATS = 2055845;
	public static final int BROWSE_CP = 2053587;
	public static final int BROWSE_DCP = 2051337;
	
	/* 
	 * add myebay by fanwenjun start 
	 */
	public final static int MYEBAY_SUMMARY_PAGE_ID = 2060778;
	public final static int MYEBAY_WATCH_LIST_PAGE_ID = 2055119;
	public final static int MYEBAY_BIDS_OFFERS_PAGE_ID = 2055359;
	public final static int MYEBAY_PCH_HIST_PAGE_ID = 2059210;
	public final static int MYEBAY_SAVED_SELLER_PAGE_ID = 2053788;
	
	/**
	 * Add RPP pages
	 */
	public final static int RPP_WELCOME = 2051540;
	public final static int RPP_HOME = 2051541;
	public final static int RPP_EVENT_PAGE_ID = 2051542;
	public final static int RPP_SUBSCRIPTION = 2051543;
	public final static int RPP_AJAX = 2051544;
	
	
	public static boolean isMyebaySummaryPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == MYEBAY_SUMMARY_PAGE_ID);
	}
	
	public static boolean isMyebayWatchListPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == MYEBAY_WATCH_LIST_PAGE_ID);
	}
	
	public static boolean isMyebayBidsOffersPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == MYEBAY_BIDS_OFFERS_PAGE_ID);
	}
	
	public static boolean isMyebayPchHistPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == MYEBAY_PCH_HIST_PAGE_ID);
	}
	
	public static boolean isMyebaySavedSellerPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == MYEBAY_SAVED_SELLER_PAGE_ID);
	}
	
	public static boolean isBelongMyebay(Event event) {
		return event.getRdt() == 0
				&& (event.getPageTypeId() == MYEBAY_SUMMARY_PAGE_ID
						|| event.getPageTypeId() == MYEBAY_WATCH_LIST_PAGE_ID
						|| event.getPageTypeId() == MYEBAY_BIDS_OFFERS_PAGE_ID
						|| event.getPageTypeId() == MYEBAY_PCH_HIST_PAGE_ID || event
						.getPageTypeId() == MYEBAY_SAVED_SELLER_PAGE_ID);
	}
	
	public final static int MYEBAY_BETA_ID = 3984;
	/* 
	 * add myebay by fanwenjun end 
	 */

	public static final int LANDING_EXP_PAGE_ID = 2141725;
	
	public static boolean isRoverEvent(Event event) {
		return ROVER_IDS.contains(event.getPageTypeId());
	}

	public static boolean isExcludedFrameEvent(Event event) {
		return EXCLUDED_FRAME_IDS.contains(event.getPageTypeId());
	}

	public static boolean isProfilePage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == PROFILE_PAGE_ID);
	}

	public static boolean isShareEvent(Event event) {
		return event.getPageTypeId() == SHARE_PAGE_ID;
	}

	public static boolean isCollectionPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == COLLECTION_PAGE_ID);
	}

	public static String getCIID(Event event) {
		String ciid = event.getAppData(GlobalTags.CURRENT_IMPRESSION_ID);
		if (ciid == null)
			ciid = "";
		return ciid;
	}

	public static String getSIID(Event event) {
		String siid = event.getAppData(GlobalTags.SOURCE_IMPRESSION_ID);
		if (siid == null)
			siid = "";
		return siid;
	}

	public static int getSIDPage(Event event) {
		String sid = event.getAppData(GlobalTags.TRACK_SID);
		if (sid == null)
			return Integer.MIN_VALUE;
		String[] tokens = sid.split("\\.");
		for (String token : tokens) {
			if (token.startsWith("p")) {
				String pid = token.substring(1).trim();
				try {
					return Integer.parseInt(pid);
				} catch (NumberFormatException e) {
					return Integer.MIN_VALUE;
				}
			}
		}
		return Integer.MIN_VALUE;
	}
	
	public static int getSIDCModule(Event event) {
		String sid = event.getAppData(GlobalTags.TRACK_SID);
		if (sid == null)
			return Integer.MIN_VALUE;
		String[] tokens = sid.split("\\.");
		for (String token : tokens) {
			if (token.startsWith("c")) { 
				String pid = token.substring(1).trim();
				try {
					return Integer.parseInt(pid);
				} catch (NumberFormatException e) {
					return Integer.MIN_VALUE;
				}
			}
		}
		return Integer.MIN_VALUE;
	}
	
	public static String getPGIValue(Event event, String property){
		String pgi = event.getAppData(GlobalTags.PAGE_IMPRESSION);
		if ( pgi == null ) return "";
		String[] tokens = StringUtils.split(pgi, '|');
		
		for ( String token : tokens ){
			String[] kvs = StringUtils.split(token, ':');
			if ( kvs.length < 2 ) {
				kvs = StringUtils.splitByWholeSeparator(token, "%3A"); //if pgi is url encoded.
				if ( kvs.length < 2) continue;
			}
			
			if (StringUtils.equalsIgnoreCase(kvs[0], property)) return kvs[1];
		}
		return "";
	}

	public static int getSIDLink(Event event) {
		String sid = event.getAppData(GlobalTags.TRACK_SID);
		if (sid == null)
			return Integer.MIN_VALUE;
		String[] tokens = sid.split("\\.");
		for (String token : tokens) {
			if (token.startsWith("l")) {
				String pid = token.substring(1).trim();
				try {
					return Integer.parseInt(pid);
				} catch (NumberFormatException e) {
					return Integer.MIN_VALUE;
				}
			}
		}
		return Integer.MIN_VALUE;
	}

	public static int getSIDModule(Event event) {
		String sid = event.getAppData(GlobalTags.TRACK_SID);
		if (sid == null)
			return Integer.MIN_VALUE;
		String[] tokens = sid.split("\\.");
		for (String token : tokens) {
			if (token.startsWith("m")) {
				String pid = token.substring(1).trim();
				try {
					return Integer.parseInt(pid);
				} catch (NumberFormatException e) {
					return Integer.MIN_VALUE;
				}
			}
		}
		return Integer.MIN_VALUE;
	}

	public static int getSPID(Event event) {
		String spid = event.getAppData(TrackingProperty.SRC_PAGE_ID);
		if (spid == null)
			return Integer.MIN_VALUE;
		String[] tokens = spid.split("\\.");
		for (String token : tokens) {
			if (token.startsWith("p")) {
				String pid = token.substring(1);
				try {
					return Integer.parseInt(pid);
				} catch (NumberFormatException e) {
					return Integer.MIN_VALUE;
				}
			}
		}
		return Integer.MIN_VALUE;
	}

	public static boolean isCollectionSpokePage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == COLLECTION_SPOKE_PAGE_ID);
	}

	public static boolean isStorePage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == STORE_PAGE_ID);
	}

	public static String safeDecode(String str) {
		if (str == null)
			return "";
		String v = str;
		String tmp = str;
		do {
			tmp = v;
			try {
				v = URLDecoder.decode(v, "utf-8");
			} catch (Exception e) {
				// ignore
			}
		} while (!tmp.equals(v));
		return v;
	}

	public static boolean isSRPPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == RAPTOR_SRP_PAGE_ID);
	}

	public static boolean isSISPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == RAPTOR_SIS_PAGE_ID);
	}

	public static boolean isSOIPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == RAPTOR_SOI_PAGE_ID);
	}

	public static boolean isVIPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == RAPTOR_VI_PAGE_ID);
	}

	public static boolean isVILayerPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == RAPTOR_VILAYER_PAGE_ID);
	}

	public static boolean isLandingEXPPage(Event event) {
		return (event.getRdt() == 0 && event.getPageTypeId() == LANDING_EXP_PAGE_ID);
	}
	
	public static String getPaginationItemIds(Event event) {
		String str = event.getUrlQueryString();
		if (str == null)
			return "";
		int offset = str.indexOf("?");
		if (offset < 0)
			return "";
		str = str.substring(offset + 1);
		String[] tokens = str.split("&");
		for (String token : tokens) {
			String splits[] = token.split("=");
			if (splits[0].equals("itemIds") && splits.length > 1) {
				return splits[1];
			}
		}
		return "";
	}

	public static String getPaginationNoItemIds(Event event) {
		String str = event.getUrlQueryString();
		if (str == null)
			return "";
		int offset = str.indexOf("?");
		if (offset < 0)
			return "";
		str = str.substring(offset + 1);
		String[] tokens = str.split("&");
		for (String token : tokens) {
			String splits[] = token.split("=");
			if (splits[0].equals("nonitemlist") && splits.length > 1) {
				return splits[1];
			}
		}
		return "";
	}

	// if SID == "p2050601.m2186.l3620" || "p2050601.m2187.l3620", means the
	// event is for
	// old VI Layer
	public static boolean isOldVILayerShownSID(String sid) {
		return sid.equals("p2050601.m2186.l3620")
				|| sid.equals("p2050601.m2187.l3620");
	}

	public static boolean isEventPageMatch(Event e, int pageId) {
		return (e.getRdt() == 0 && e.getPageTypeId() == pageId);
	}

	public static boolean isBrowsePages(Event event) {
		int pageId = event.getPageTypeId();
		return (event.getRdt() == 0 && (pageId == BROWSE_ALLCATS
				|| pageId == BROWSE_CP || pageId == BROWSE_DCP));
	}

	public static boolean isPage(Event event, int pageId) {
		return /*event.getRdt() == 0 &&*/ event.getPageTypeId() == pageId;
	}
	
	public static boolean isRPPEvent(Event event){
		int pageId = event.getPageTypeId();
		return event.getRdt() == 0 && (
				pageId == EventUtils.RPP_AJAX ||
				pageId == EventUtils.RPP_HOME ||
				pageId == EventUtils.RPP_EVENT_PAGE_ID ||
				pageId == EventUtils.RPP_SUBSCRIPTION ||
				pageId == EventUtils.RPP_WELCOME
			);
	}
	
	public static String getAppData(Event e, String tagName){
		Map<String, String> payloadMap = e.getAppPayloadMap();
        String tagValue = payloadMap.get(tagName);
        if (tagValue != null) {
            return tagValue;
        }
        tagValue = payloadMap.get("!"+tagName);
        if (tagValue != null) {
            return tagValue;
        }
        String value = payloadMap.get("!_" + tagName);
        if ( value == null ) return "";
        return value;
	}

	public static String getDevice(SessionContainer ec) {
		// '0','1','2','3','4','5','10','11' : PC
		// '6','7','8','9' : Mobile
		int cobrand = ec.getSessionHeader().getCobrand();
		switch (cobrand) {
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 10:
		case 11:
			return "PC";
		case 6:
		case 7:
		case 8:
		case 9:
			return "Mobile";
		default:
			return "Unknown";
		}
	}
	
	public static String RPPHomePseduoPageId(Event event) {
		assert(event.getPageTypeId() == EventUtils.RPP_HOME);
		
		/*
		String fsType = EventUtils.getPGIValue(event, "3205");
		if ( StringUtils.isEmpty(fsType) ) fsType = "EMPTY";
		return event.getPageTypeId() + "-" + fsType;
		*/
		String queryStr = safeDecode(event.getUrlQueryString());
		if ( StringUtils.isEmpty(queryStr) ){
			return event.getPageTypeId() + "-" + "EMPTY";
		}
		
		queryStr = queryStr.toLowerCase();
		queryStr.replace("_", "-");
		if ( StringUtils.startsWith(queryStr, "/rpp/") ){
			queryStr = StringUtils.substring(queryStr, 5);
			int idx = StringUtils.indexOfAny(queryStr, new char[]{'/','?', '&', '#', '@', ';'});
			if (  idx != -1 ){
				queryStr = StringUtils.substring(queryStr, 0, idx);
			}
			return event.getPageTypeId() + "-" + queryStr;
		}
		
		return event.getPageTypeId() + "-" + "EMPTY";
	}
	
	public static int DEALS_FEATURED_PAGE_ID = 1468660;
	public static int DEALS_TECH_PAGE_ID = 2051643;
	public static int DEALS_FASHION_PAGE_ID = 2051640;
	public static int DEALS_HOME_PAGE_ID = 2051641;
	public static int DEALS_OTHER_PAGE_ID = 2051642;
	public static int DEALS_SHOP_PAGE_ID = 2065859;
	public static int DEALS_POPULAR_PAGE_ID = 2065262;
	public static int DEALS_SEARCH_PAGE_ID = 2058484;
	
	public static boolean isDealsEvent(Event event) {
		int pageId = event.getPageTypeId();
		return (event.getRdt() == 0 && (
				pageId == DEALS_FEATURED_PAGE_ID ||
				pageId == DEALS_TECH_PAGE_ID ||
				pageId == DEALS_FASHION_PAGE_ID ||
				pageId == DEALS_HOME_PAGE_ID ||
				pageId == DEALS_OTHER_PAGE_ID ||
				pageId == DEALS_SHOP_PAGE_ID ||
				pageId == DEALS_POPULAR_PAGE_ID) ||
				pageId == DEALS_SEARCH_PAGE_ID);
	}

	public static String RPPEventPseduoPageId(Event event) {
		if ( event.getPageTypeId() != RPP_EVENT_PAGE_ID ){
			throw new RuntimeException("extractRPPEventId only accepts " + RPP_EVENT_PAGE_ID + ", " + event.getPageTypeId() + " is invalid.");
		}
		
		String fsType = getPGIValue(event, "1670");
		if ( StringUtils.isEmpty(fsType) ) return "" + event.getPageTypeId();
		return event.getPageTypeId() + "-" + fsType;
	}
}

