# GRO Service Summary

## Inventory Selection Services

[Service Detail](inventory_selection/README.md)

## Event Quality Services

[Service Detail](event_quality/README.md)