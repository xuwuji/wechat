# Event Quality Service Layer

In this project, we provide basic web services for project **Event Quality**.



## Prepare QA/Prod Env

### Database

#### QA

```
1. Login gro-qa-680636.lvs01.eaz.ebayc3.com
2. Login local mysql
3. Switch GRO database grodb
4. Update following three tables content
   4.1 brand_distribution
   4.2 cluster
   4.3 cluster_metrics
```

#### Prod

```
1. Login gro prod mysql
2. Switch event quality database gro_event_quality
3. Update following three tables content
   3.1 brand_distribution
   3.2 cluster
   3.3 cluster_metrics
```

### Models

#### QA

```
1. Login GRO prod servers
2. Update two models in folder: /home/kairosweb/wekamodels
```

#### Prod

```
1. Login gro-qa-680636.lvs01.eaz.ebayc3.com
2. Update two models in folder: /home/kairosweb/wekamodels
```

## Service Hostname

Please replace the service hostname based on your profiles.

### QA
``` http://gro-qa.corp.ebay.com/ ```

### Prod
``` http://gro.corp.ebay.com/ ```

## Service Interfaces

* [**Category Quality**](#catg_qlty)
* [**Item Quality**](#itm_qlty)
* [**Cluster List**](#clst_lst)
* [**Top Brand**](#top_bnd)
* [**Category Query**](#categ_qry)
* [**RPP Event Query**](#rpp_event_qry)
* [**RPP Event Item Query**](#rpp_item_qry)

### <a name="catg_qlty"></a>Category Quality

This service uses data in table **Cluster Metrics** to calculate **category** level quality score of all input items. 

#### Endpoint

```
POST  

http://gro-qa.corp.ebay.com/gro/service/eventqlty/category

```

#### Input
Serivce consumer must provide following information in service request:

* Event Cluster ID
* Event Item ID List

```
{
  "clusterId": 1,
  "items": [
    381469659146,
    141836827131,
    201474385323,
    331694929342,
    111515554297
  ]
}
```

Service will query Elastic Search cluster for **Selection Magic** to find input items' leaf category ID. Then apply category quality algorithm on overall leaf category set.

#### Output

Service output includes:

| Field | Description | Comment |
|:-----|:-----------| :-------- |
| nRS | normalized rank scorce | |
| nVRS | normalized vertical rank score | available only if input items coming from same vertical |
| nCRS | normalized category rank score | available only if input items coming from same parent category in same vertical |
| categoryCoverage | the percentage of categories above score covered |
| itemCoverage | the percentage of items above score covered |
| currentLeaves | array of **all** input leaf categories with score |
| suggestLeaves | array of recommand leaf categories of **selected cluster** |
| suggestVerticalLeaves | array of recommand leaf categories of **selected cluster and vertical** | available only if input items coming from same vertical |
| suggestCategoryLeaves | array of recommand leaf categories of **lowest common parent category** | available only if input items coming from same vertical  and has common parent category |
| notScoreLeaves | array of leaf categories we cannot provide scores |

```
{
  "nRS": 0.022887243589057964,
  "nVRS": "NaN",
  "nCRS": "NaN",
  "categoryCoverage": 100,
  "itemCoverage": 100,
  "currentLeaves": [
    {
      "leafCategId": 137085,
      "vertical": "Fashion",
      "score": 0.0001575561702467273,
      "userSelected": true
    },
    {
      "leafCategId": 175750,
      "vertical": "Home & Garden",
      "score": 0.00002531264981504317,
      "userSelected": true
    },
    {
      "leafCategId": 31787,
      "vertical": "Fashion",
      "score": 0.000000061167337164,
      "userSelected": true
    },
    {
      "leafCategId": 214,
      "vertical": "Collectibles",
      "score": 0,
      "userSelected": true
    },
    {
      "leafCategId": 68816,
      "vertical": "Lifestyle",
      "score": 0,
      "userSelected": true
    }
  ],
  "suggestLeaves": [
    {
      "leafCategId": 29585,
      "vertical": "Fashion",
      "score": 0.526463166841,
      "userSelected": true
    },
    {
      "leafCategId": 31387,
      "vertical": "Fashion",
      "score": 0.14669506965411988,
      "userSelected": true
    },
    {
      "leafCategId": 63852,
      "vertical": "Fashion",
      "score": 0.05373325944950576,
      "userSelected": false
    },
    {
      "leafCategId": 10986,
      "vertical": "Fashion",
      "score": 0.03942630614790474,
      "userSelected": true
    },
    {
      "leafCategId": 155101,
      "vertical": "Fashion",
      "score": 0.03294833359185033,
      "userSelected": true
    }
  ],
  "suggestVerticalLeaves": [],
  "suggestCategoryLeaves": [],
  "notScoreLeaves": []
}
```

### <a name="itm_qlty"></a>Item Quality

This service uses two item quality models, provided by Roman, to calculate **item** level quality score of all input items. 

#### Endpoint

```
POST  

http://gro-qa.corp.ebay.com/gro/service/eventqlty/item

```

#### Input

Serivce consumer must provide following information in service request:

* Event Cluster ID
* Event Item ID List

```
{
  "clusterId": 1,
  "items": [
    381469659146,
    141836827131,
    201474385323,
    331694929342,
    111515554297
  ]
}
```

Service will query Elastic Search cluster for **Selection Magic** to find input items' leaf category ID and several other item and categories features. Then apply item quality score models to each input items.

Item features include:

 1. num_trans_7
 2. gmv_7
 3. num_trans_14
 4. gmv_14
 5. num_trans_21
 6. gmv_21
 7. num_trans_28
 8. gmv_30
 9. num_wtch_7
 10. num_wtch_14
 11. num_wtch_21
 12. num_wtch_28
 13. num_vi_7
 14. num_vi_14
 15. num_vi_21
 16. num_vi_28
 17. likelihood (leaf category) _**Optional**_
 18. entropy (leaf category) _**Optional**_
 19. score
 20. rank
 21. quality (**good** score >= 60%, **average** 30% <= score < 60%, **poor** score < 30%)


#### Output

Service output includes:

| Field | Description | Comment |
|:----- |:-----------| :------- |
| summary | percentage of items which quality score is larger than **Threshold** (0.5)  |  |
| scoreItems | array of items which have quality scores |  |
| noneScoreItems | array of items which cannot calculate quality scores |  |

```
{
  "summary": {
    "coverage": 20
  },
  "scoreItems": [
    {
      "id": 381469659146,
      "leafCategId": 52,
      "features": {
        "num_trans_7": 2,
        "gmv_7": 11.9,
        "num_trans_14": 2,
        "gmv_14": 11.9,
        "num_trans_21": 3,
        "gmv_21": 17.85,
        "num_trans_28": 3,
        "gmv_28": 17.85,
        "num_wtch_7": 1,
        "num_wtch_14": 2,
        "num_wtch_21": 2,
        "num_wtch_28": 2,
        "num_vi_7": 0,
        "num_vi_14": 0,
        "num_vi_21": 0,
        "num_vi_28": 0,
        "categoryFeatures": {
          "likelihood": 0.00000121381078323017,
          "entropy": 0
        }
      },
      "score": 0.66,
      "rank": 1,
      "quality": "good"
    },
    {
      "id": 141836827131,
      "leafCategId": 180957,
      "features": {
        "num_trans_7": 1,
        "gmv_7": 149.99,
        "num_trans_14": 2,
        "gmv_14": 299.98,
        "num_trans_21": 2,
        "gmv_21": 299.98,
        "num_trans_28": 4,
        "gmv_28": 599.96,
        "num_wtch_7": 1,
        "num_wtch_14": 3,
        "num_wtch_21": 6,
        "num_wtch_28": 6,
        "num_vi_7": 34,
        "num_vi_14": 66,
        "num_vi_21": 91,
        "num_vi_28": 121,
        "categoryFeatures": {
          "likelihood": 0.00012617357544397,
          "entropy": 0.306422810463162
        }
      },
      "score": 0.495,
      "rank": 2,
      "quality": "average"
    },
    {
      "id": 201474385323,
      "leafCategId": 71240,
      "features": {
        "num_trans_7": 1,
        "gmv_7": 15.99,
        "num_trans_14": 2,
        "gmv_14": 31.98,
        "num_trans_21": 2,
        "gmv_21": 31.98,
        "num_trans_28": 4,
        "gmv_28": 63.96,
        "num_wtch_7": 1,
        "num_wtch_14": 1,
        "num_wtch_21": 2,
        "num_wtch_28": 2,
        "num_vi_7": 1,
        "num_vi_14": 30,
        "num_vi_21": 42,
        "num_vi_28": 114,
        "categoryFeatures": {
          "likelihood": 0.0000231630148660794,
          "entropy": 0.485537028788335
        }
      },
      "score": 0.13716666666666666,
      "rank": 3,
      "quality": "poor"
    },
    {
      "id": 331694929342,
      "leafCategId": 20445,
      "features": {
        "num_trans_7": 3,
        "gmv_7": 75,
        "num_trans_14": 3,
        "gmv_14": 75,
        "num_trans_21": 3,
        "gmv_21": 75,
        "num_trans_28": 3,
        "gmv_28": 75,
        "num_wtch_7": 4,
        "num_wtch_14": 6,
        "num_wtch_21": 7,
        "num_wtch_28": 7,
        "num_vi_7": 52,
        "num_vi_14": 60,
        "num_vi_21": 62,
        "num_vi_28": 66,
        "categoryFeatures": {
          "likelihood": 0.0420302267964555,
          "entropy": 0.495001242725592
        }
      },
      "score": 0.055,
      "rank": 4,
      "quality": "poor"
    },
    {
      "id": 111515554297,
      "leafCategId": 22610,
      "features": {
        "num_trans_7": 3,
        "gmv_7": 104.97,
        "num_trans_14": 7,
        "gmv_14": 244.93,
        "num_trans_21": 9,
        "gmv_21": 314.91,
        "num_trans_28": 13,
        "gmv_28": 454.87,
        "num_wtch_7": 6,
        "num_wtch_14": 13,
        "num_wtch_21": 17,
        "num_wtch_28": 19,
        "num_vi_7": 0,
        "num_vi_14": 0,
        "num_vi_21": 0,
        "num_vi_28": 0,
        "categoryFeatures": {
          "likelihood": 0.00000137608495211121,
          "entropy": 0
        }
      },
      "score": 0.05,
      "rank": 5,
      "quality": "poor"
    }
  ],
  "noneScoreItems": []
}
```

### <a name="clst_lst"></a>Cluster List

This service returns all clusters of a given site.

#### Endpoint

```
GET

http://gro-qa.corp.ebay.com/gro/service/eventqlty/clusters?site_id=SITE_ID
```

#### Input

ID of each site.

#### Output

Service output is a list of Cluster. Each cluster contains:

| Field | Description | Comment |
|:----- |:-----------| :------- |
| cluster_id |   |  |
| cluster_name |  |  |

```
[{"cluster_id":1,"cluster_name":"Holiday"}]
```

### <a name="top_bnd"></a>Top Brand

This service returns top 5 brands (by count) of given leaf category ID.

#### Endpoit

```
GET

http://gro-qa.corp.ebay.com/gro/service/eventqlty/brand?leaf_categ_id=177
```

#### Input

Leaf category ID

#### Output

Service output is a list of Brand. Each brand contains:

| Field | Description | Comment |
|:----- |:-----------| :------- |
| date | Data update time |  |
| date_range | Statistic date range. | 60 means using 60 days data to calculate count. |
| leaf\_categ\_id | Leaf category ID |  |
| brand | Brand Value |  |
| count | Count |  |

```
[
  {
    "date": "20151202",
    "date_range": 60,
    "leaf_categ_id": 177,
    "brand": "dell",
    "count": 259708
  },
  {
    "date": "20151202",
    "date_range": 60,
    "leaf_categ_id": 177,
    "brand": "hp",
    "count": 206409
  },
  {
    "date": "20151202",
    "date_range": 60,
    "leaf_categ_id": 177,
    "brand": "lenovo",
    "count": 148505
  },
  {
    "date": "20151202",
    "date_range": 60,
    "leaf_categ_id": 177,
    "brand": "asus",
    "count": 107729
  },
  {
    "date": "20151202",
    "date_range": 60,
    "leaf_categ_id": 177,
    "brand": "toshiba",
    "count": 71793
  }
]
```

### <a name="categ_qry"></a>Category Query

This service provides dynamic query ability on table dw_category_groupings.

#### Endpoint

```
POST
Content-Type: application/json;
http://nous.corp.ebay.com/drill/query.json
```

#### Input

```
{"queryType":"SQL","query":"select leaf_categ_id, leaf_categ_name from dfs.tdhdp.dw_category_groupings where leaf_categ_id in (177) and site_id = 0"}
```

#### Output

```
{
  "columns": [
    "leaf_categ_id",
    "leaf_categ_name"
  ],
  "rows": [
    {
      "leaf_categ_id": "177",
      "leaf_categ_name": "Computers/Tablets & Networking:Laptops & Netbooks:PC Laptops & Netbooks"
    }
  ]
}
```


### <a name="rpp_event_qry"></a>RPP Event Query
This service provides query on table rpp_event.

#### Endpoint

```
POST
Content-Type: application/json;
http://nous.corp.ebay.com/drill/query.json
```

#### Input

```
{"queryType":"SQL","query":"select rpp_event_id, event_name, url_txt, start_ts, end_ts from dfs.tdhdp.`rpp_event` where site_id = 0 and url_txt is not null order by start_ts desc"}
```

#### Output

```
{
  "columns": [
    "rpp_event_id",
    "event_name",
    "url_txt",
    "start_ts",
    "end_ts"
  ],
  "rows": [
    {
      "start_ts": null,
      "url_txt": "http://www.ebay.com/rpp/dailydealevents/Gift-Card-Flash-SaleSun-Oct-19-19-48-14-GMT-07-00-2014",
      "end_ts": "1414569600000",
      "event_name": "Gift Card Flash SaleSun Oct 19 19:48:14 GMT-07:00 2014",
      "rpp_event_id": "544477efe4b0ff4307785fea"
    },
    {
      "start_ts": "1456769251000",
      "url_txt": "http://www.ebay.com/rpp/test-tablet-2/simon-test-1",
      "end_ts": "1459428259000",
      "event_name": "simon test 1",
      "rpp_event_id": "54b82671e4b01a54b1607bd2"
    },
    ... 
   ]
}
```

### <a name="rpp_item_qry"></a>RPP Event Item Query
This service provides query on table rpp_event_item_map.

#### Endpoint

```
POST
Content-Type: application/json;
http://nous.corp.ebay.com/drill/query.json
```

#### Input

```
{"queryType":"SQL","query":"select item_id from dfs.tdhdp.`rpp_event_item_map` where rpp_event_id = '55e78f30e4b0d15403da4de3'"}
```

### Output

```
{
  "columns": [
    "item_id"
  ],
  "rows": [
    {
      "item_id": "151801223071"
    },
    {
      "item_id": "361305038896"
    },
    ...
  ]
}
```
