# Inventory Selection

## Data Flow

### Step 1: Teradata Data Preparation
Owner: B, Veera(AWF) <veeb@ebay.com>

#### <a name="source-table"></a>Source Tables
```
ACCESS_VIEWS.DEAL_ITEM_HST
ACCESS_VIEWS.DW_ATTR_DETAIL_VALUES
ACCESS_VIEWS.DW_ATTR_LSTG_DTL
ACCESS_VIEWS.DW_ATTR_LSTG_DTL
ACCESS_VIEWS.DW_ATTR_LSTG_PRDCT_IDENTIFIER
ACCESS_VIEWS.DW_ATTR_SHPMT_DTL
ACCESS_VIEWS.DW_CAL_DT
ACCESS_VIEWS.DW_CATEGORY_GROUPINGS
ACCESS_VIEWS.DW_CHECKOUT_TRANS
ACCESS_VIEWS.DW_LSTG_ITEM
ACCESS_VIEWS.DW_LSTG_ITEM_COLD
ACCESS_VIEWS.DW_LSTG_ITEM_COLD_V
ACCESS_VIEWS.DW_LSTG_RMSI_PRMTN
ACCESS_VIEWS.DW_LSTG_VI_METRIC
ACCESS_VIEWS.ITEM_ASPCT_CLSSFCTN
ACCESS_VIEWS.ITEM_ASPCT_CLSSFCTN
ACCESS_VIEWS.LSTG_ITEM_CNDTN
ACCESS_VIEWS.LSTG_ITEM_PIC
ACCESS_VIEWS.LSTG_ITEM_VRTN
ACCESS_VIEWS.SDM_MDP_BOB_SELLER
ACCESS_VIEWS.SSA_PRODUCT_FACT
ACCESS_VIEWS.SSA_SHPMT_LSTG_FACT
PRS_RESTRICTED_V.NA_DEAL_CK_TRANS_SUM_VDM
PRS_RESTRICTED_V.NA_DEAL_ITEM_VDM
PRS_RESTRICTED_V.SPS_LEVEL
```

#### Output Table

```
app_buyer_t.P_ACCT_LISTING_DETAIL_AGG
```

### Step 2: Teradata Data Dump to HDFS

Owner: B, Veera(AWF) <veeb@ebay.com>

#### HDFS Folder

```
/apps/hdmi-technology/b_app_buyer/P_ACCT_LISTING_DETAIL_AGG/${YYYYMMDD}000000
```

### Step 3: Data Clean

Owner: Woody, Zhou <yangzhou@ebay.com>

#### Job Location

**PHX008** /projects/GRO/InventorySelection

#### Pig scripts

* pigs/invSelClean.pig
* pigs/invSelEPID.pig

#### Output HDFS Folders

```
/apps/hdmi-prod/b_bis/gro/invsel/data/{us,uk,de,afie}
/apps/hdmi-prod/b_bis/gro/invsel/iis_data/{us,uk,de}
```

### Step 4: Index Data To Elastic Search

Owner: Woody, Zhou <yangzhou@ebay.com>

#### Job Location

**PHX008** /projects/GRO/InventorySelection

#### Script

* bin/index.site.pl


### Step 5: Call IIS Service For Compete Price and Deal Flag

Owner: Woody, Zhou <yangzhou@ebay.com>

#### Job Location

**PHX007** /projects/GRO/InventorySelection

#### Script

* iis_us.sh
* iis_uk.sh
* iis_de.sh


### UC4 Job for Step 3 to 5

Client: 1400

Job Name: GRO.INVSEL.PROD.DATA.JOB

Job Path: /BPE/JOBPLANS/GRO.RETAIL

## Dependencies 

Teradata dependencies are [here](#source-table)

Compete price and deal flags dependency [IIS](https://wiki.vip.corp.ebay.com/display/CATALOGSPD/IIS+-+GetProductInfo)

## Deployment

[Reference](https://wiki.vip.corp.ebay.com/display/DataServicesandSolutions/3.+Inventory_Selection#id-3.Inventory_Selection-C3ES)

## Frameworks

Backend: Spring 

Frontend: Nodejs

## Data Modeling

[TBD]

## Services

### Service Hostname

Please replace the service hostname based on your profiles.

#### QA
``` http://gro-qa.corp.ebay.com/ ```

#### Prod
``` http://gro.corp.ebay.com/ ```


### Alias Service

HTTP Action: GET

URL: ```http://gro-qa.corp.ebay.com/gro/service/invsel/alias/${alias_name}```

Response: 

```
{
  "magic-us-20151201": {
    "aliases": {
      "sm_us_alias": {}
    },
    "rtlweek": [
      48,
      47,
      46,
      45,
      44,
      43
    ]
  }
}
```

### ES Query Service

HTTP Action: POST

URL: ```http://gro-qa.corp.ebay.com/gro/service/invsel/search/${alias_name}/item/```

This service is a wrap of regular ES [query service](https://www.elastic.co/guide/en/elasticsearch/reference/1.7/search-search.html). They share the same input and output schema. 

### Download Service

HTTP Action: Form POST

Form: 

* q: search query same as **ES Query Service** above
* c: (Optional) download fields list

URL: ```http://gro-qa.corp.ebay.com/gro/service/invsel/download/${site}```
